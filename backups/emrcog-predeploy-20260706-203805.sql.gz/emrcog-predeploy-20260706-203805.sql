--
-- PostgreSQL database dump
--

\restrict Kb05GoQ8OCCK2jKehJCzMlBidtD8grWil1QnQta3YeD0bJiJWOEwv4ujRLRUB1k

-- Dumped from database version 15.18
-- Dumped by pg_dump version 15.18

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: pg_trgm; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS pg_trgm WITH SCHEMA public;


--
-- Name: EXTENSION pg_trgm; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION pg_trgm IS 'text similarity measurement and index searching based on trigrams';


SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: add_on_bundles; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.add_on_bundles (
    id character varying DEFAULT gen_random_uuid() NOT NULL,
    name text NOT NULL,
    slug text NOT NULL,
    description text,
    price numeric(12,2) NOT NULL,
    currency text DEFAULT 'USD'::text NOT NULL,
    add_on_ids jsonb NOT NULL,
    is_active boolean DEFAULT true NOT NULL,
    display_order integer DEFAULT 0 NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_at timestamp without time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.add_on_bundles OWNER TO postgres;

--
-- Name: add_ons; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.add_ons (
    id character varying DEFAULT gen_random_uuid() NOT NULL,
    name text NOT NULL,
    slug text NOT NULL,
    description text,
    pricing_type text DEFAULT 'one_time'::text NOT NULL,
    price numeric(12,2) NOT NULL,
    currency text DEFAULT 'USD'::text NOT NULL,
    billing_cycle text,
    max_quantity_per_user integer DEFAULT 1 NOT NULL,
    compatible_package_ids jsonb,
    is_active boolean DEFAULT true NOT NULL,
    display_order integer DEFAULT 0 NOT NULL,
    metadata jsonb,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_at timestamp without time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.add_ons OWNER TO postgres;

--
-- Name: announcements; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.announcements (
    id character varying DEFAULT gen_random_uuid() NOT NULL,
    title text NOT NULL,
    message text NOT NULL,
    type text DEFAULT 'info'::text NOT NULL,
    is_active boolean DEFAULT true,
    expires_at timestamp without time zone,
    created_by character varying,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_at timestamp without time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.announcements OWNER TO postgres;

--
-- Name: app_settings; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.app_settings (
    id character varying DEFAULT gen_random_uuid() NOT NULL,
    key text NOT NULL,
    value text NOT NULL,
    updated_at timestamp without time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.app_settings OWNER TO postgres;

--
-- Name: audit_logs; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.audit_logs (
    id character varying DEFAULT gen_random_uuid() NOT NULL,
    admin_user_id character varying NOT NULL,
    action text NOT NULL,
    entity_type text NOT NULL,
    entity_id character varying,
    details jsonb,
    created_at timestamp without time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.audit_logs OWNER TO postgres;

--
-- Name: bookmarks; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.bookmarks (
    id character varying DEFAULT gen_random_uuid() NOT NULL,
    user_id character varying NOT NULL,
    topic_id character varying NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.bookmarks OWNER TO postgres;

--
-- Name: books; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.books (
    id character varying DEFAULT gen_random_uuid() NOT NULL,
    title text NOT NULL,
    description text,
    image_url text,
    is_published boolean DEFAULT false,
    "order" integer DEFAULT 0,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_at timestamp without time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.books OWNER TO postgres;

--
-- Name: chapters; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.chapters (
    id character varying DEFAULT gen_random_uuid() NOT NULL,
    book_id character varying NOT NULL,
    title text NOT NULL,
    description text,
    "order" integer DEFAULT 0,
    is_published boolean DEFAULT false,
    created_at timestamp without time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.chapters OWNER TO postgres;

--
-- Name: code_redemptions; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.code_redemptions (
    id character varying DEFAULT gen_random_uuid() NOT NULL,
    code_id character varying NOT NULL,
    user_id character varying NOT NULL,
    book_id character varying,
    duration_days integer NOT NULL,
    subscription_started_at timestamp without time zone NOT NULL,
    subscription_expires_at timestamp without time zone NOT NULL,
    ip_address text,
    created_at timestamp without time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.code_redemptions OWNER TO postgres;

--
-- Name: content_blocks; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.content_blocks (
    id character varying DEFAULT gen_random_uuid() NOT NULL,
    topic_id character varying NOT NULL,
    type text NOT NULL,
    content text NOT NULL,
    "order" integer DEFAULT 0,
    created_at timestamp without time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.content_blocks OWNER TO postgres;

--
-- Name: content_reports; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.content_reports (
    id character varying DEFAULT gen_random_uuid() NOT NULL,
    user_id character varying NOT NULL,
    content_type text NOT NULL,
    content_id character varying NOT NULL,
    report_type text NOT NULL,
    description text NOT NULL,
    status text DEFAULT 'pending'::text NOT NULL,
    reviewed_by character varying,
    reviewed_at timestamp without time zone,
    created_at timestamp without time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.content_reports OWNER TO postgres;

--
-- Name: coupon_usage; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.coupon_usage (
    id character varying DEFAULT gen_random_uuid() NOT NULL,
    coupon_id character varying NOT NULL,
    user_id character varying NOT NULL,
    subscription_id character varying,
    discount_applied numeric(12,2) NOT NULL,
    used_at timestamp without time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.coupon_usage OWNER TO postgres;

--
-- Name: coupons; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.coupons (
    id character varying DEFAULT gen_random_uuid() NOT NULL,
    code text NOT NULL,
    description text,
    campaign_id character varying,
    discount_type text NOT NULL,
    discount_value numeric(12,2) NOT NULL,
    min_purchase_amount numeric(12,2),
    max_discount_amount numeric(12,2),
    applicable_package_ids jsonb,
    applicable_add_on_ids jsonb,
    max_total_uses integer,
    max_uses_per_user integer DEFAULT 1 NOT NULL,
    current_use_count integer DEFAULT 0 NOT NULL,
    valid_from timestamp without time zone,
    valid_until timestamp without time zone,
    is_stackable boolean DEFAULT false NOT NULL,
    referral_user_id character varying,
    is_active boolean DEFAULT true NOT NULL,
    metadata jsonb,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_at timestamp without time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.coupons OWNER TO postgres;

--
-- Name: invoice_line_items; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.invoice_line_items (
    id character varying DEFAULT gen_random_uuid() NOT NULL,
    invoice_id character varying NOT NULL,
    type text NOT NULL,
    description text NOT NULL,
    package_id character varying,
    add_on_id character varying,
    quantity integer DEFAULT 1 NOT NULL,
    unit_price numeric(12,2) NOT NULL,
    total numeric(12,2) NOT NULL,
    period_start timestamp without time zone,
    period_end timestamp without time zone,
    metadata jsonb,
    created_at timestamp without time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.invoice_line_items OWNER TO postgres;

--
-- Name: invoices; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.invoices (
    id character varying DEFAULT gen_random_uuid() NOT NULL,
    invoice_number text NOT NULL,
    user_id character varying NOT NULL,
    subscription_id character varying,
    status text DEFAULT 'draft'::text NOT NULL,
    subtotal numeric(12,2) NOT NULL,
    discount_total numeric(12,2) DEFAULT 0,
    tax_total numeric(12,2) DEFAULT 0,
    total numeric(12,2) NOT NULL,
    currency text DEFAULT 'USD'::text NOT NULL,
    paid_at timestamp without time zone,
    due_at timestamp without time zone,
    period_start timestamp without time zone,
    period_end timestamp without time zone,
    coupon_id character varying,
    notes text,
    metadata jsonb,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_at timestamp without time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.invoices OWNER TO postgres;

--
-- Name: manual_payment_proofs; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.manual_payment_proofs (
    id character varying DEFAULT gen_random_uuid() NOT NULL,
    user_id character varying NOT NULL,
    package_id character varying NOT NULL,
    price_id character varying,
    status text DEFAULT 'pending'::text NOT NULL,
    amount_claimed numeric(12,2),
    currency text,
    payment_method text,
    sender_reference text,
    user_note text,
    proof_image_url text NOT NULL,
    proof_filename text,
    reviewed_by character varying,
    reviewed_at timestamp without time zone,
    rejection_reason text,
    created_subscription_id character varying,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_at timestamp without time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.manual_payment_proofs OWNER TO postgres;

--
-- Name: mcqs; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.mcqs (
    id character varying DEFAULT gen_random_uuid() NOT NULL,
    topic_id character varying NOT NULL,
    question text NOT NULL,
    options jsonb NOT NULL,
    correct_answer text NOT NULL,
    explanation text,
    option_explanations jsonb,
    difficulty text DEFAULT 'medium'::text NOT NULL,
    "references" text,
    tags jsonb,
    is_published boolean DEFAULT false,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_at timestamp without time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.mcqs OWNER TO postgres;

--
-- Name: package_features; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.package_features (
    id character varying DEFAULT gen_random_uuid() NOT NULL,
    package_id character varying NOT NULL,
    name text NOT NULL,
    description text,
    value_type text DEFAULT 'check'::text NOT NULL,
    value text,
    display_order integer DEFAULT 0 NOT NULL,
    feature_key text,
    created_at timestamp without time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.package_features OWNER TO postgres;

--
-- Name: package_prices; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.package_prices (
    id character varying DEFAULT gen_random_uuid() NOT NULL,
    package_id character varying NOT NULL,
    billing_cycle text NOT NULL,
    custom_duration_days integer,
    price numeric(12,2) NOT NULL,
    currency text DEFAULT 'USD'::text NOT NULL,
    original_price numeric(12,2),
    is_active boolean DEFAULT true NOT NULL,
    revenuecat_offering_id text,
    package_version integer DEFAULT 1 NOT NULL,
    metadata jsonb,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_at timestamp without time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.package_prices OWNER TO postgres;

--
-- Name: password_reset_tokens; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.password_reset_tokens (
    id character varying DEFAULT gen_random_uuid() NOT NULL,
    user_id character varying NOT NULL,
    token text NOT NULL,
    expires_at timestamp without time zone NOT NULL,
    used boolean DEFAULT false,
    created_at timestamp without time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.password_reset_tokens OWNER TO postgres;

--
-- Name: payment_transactions; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.payment_transactions (
    id character varying DEFAULT gen_random_uuid() NOT NULL,
    invoice_id character varying,
    user_id character varying NOT NULL,
    status text DEFAULT 'pending'::text NOT NULL,
    amount numeric(12,2) NOT NULL,
    currency text DEFAULT 'USD'::text NOT NULL,
    payment_gateway text NOT NULL,
    gateway_transaction_id text,
    gateway_response jsonb,
    failure_reason text,
    failure_code text,
    refunded_amount numeric(12,2),
    refunded_at timestamp without time zone,
    refund_reason text,
    metadata jsonb,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_at timestamp without time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.payment_transactions OWNER TO postgres;

--
-- Name: quiz_attempts; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.quiz_attempts (
    id character varying DEFAULT gen_random_uuid() NOT NULL,
    user_id character varying NOT NULL,
    topic_id character varying,
    mode text NOT NULL,
    score integer NOT NULL,
    total_questions integer NOT NULL,
    correct_count integer NOT NULL,
    wrong_count integer NOT NULL,
    time_taken integer,
    answers jsonb NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.quiz_attempts OWNER TO postgres;

--
-- Name: recent_activity; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.recent_activity (
    id character varying DEFAULT gen_random_uuid() NOT NULL,
    user_id character varying NOT NULL,
    topic_id character varying NOT NULL,
    viewed_at timestamp without time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.recent_activity OWNER TO postgres;

--
-- Name: review_schedule; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.review_schedule (
    id character varying DEFAULT gen_random_uuid() NOT NULL,
    user_id character varying NOT NULL,
    mcq_id character varying NOT NULL,
    ease_factor integer DEFAULT 250 NOT NULL,
    "interval" integer DEFAULT 1 NOT NULL,
    repetitions integer DEFAULT 0 NOT NULL,
    next_review_at timestamp without time zone DEFAULT now() NOT NULL,
    last_reviewed_at timestamp without time zone,
    created_at timestamp without time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.review_schedule OWNER TO postgres;

--
-- Name: scratch_code_batches; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.scratch_code_batches (
    id character varying DEFAULT gen_random_uuid() NOT NULL,
    prefix text NOT NULL,
    book_id character varying,
    duration_days integer NOT NULL,
    total_codes integer NOT NULL,
    description text,
    is_active boolean DEFAULT true NOT NULL,
    created_by character varying,
    created_at timestamp without time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.scratch_code_batches OWNER TO postgres;

--
-- Name: scratch_codes; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.scratch_codes (
    id character varying DEFAULT gen_random_uuid() NOT NULL,
    batch_id character varying NOT NULL,
    code text NOT NULL,
    status text DEFAULT 'unused'::text NOT NULL,
    redeemed_by character varying,
    redeemed_at timestamp without time zone,
    created_at timestamp without time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.scratch_codes OWNER TO postgres;

--
-- Name: subscription_add_ons; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.subscription_add_ons (
    id character varying DEFAULT gen_random_uuid() NOT NULL,
    subscription_id character varying NOT NULL,
    add_on_id character varying NOT NULL,
    quantity integer DEFAULT 1 NOT NULL,
    price_at_purchase numeric(12,2) NOT NULL,
    is_active boolean DEFAULT true NOT NULL,
    activated_at timestamp without time zone DEFAULT now() NOT NULL,
    canceled_at timestamp without time zone,
    created_at timestamp without time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.subscription_add_ons OWNER TO postgres;

--
-- Name: subscription_audit_logs; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.subscription_audit_logs (
    id character varying DEFAULT gen_random_uuid() NOT NULL,
    subscription_id character varying,
    user_id character varying NOT NULL,
    performed_by character varying,
    action text NOT NULL,
    previous_status text,
    new_status text,
    details jsonb,
    source text DEFAULT 'system'::text NOT NULL,
    ip_address text,
    created_at timestamp without time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.subscription_audit_logs OWNER TO postgres;

--
-- Name: subscription_packages; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.subscription_packages (
    id character varying DEFAULT gen_random_uuid() NOT NULL,
    name text NOT NULL,
    slug text NOT NULL,
    description text,
    short_description text,
    icon_url text,
    status text DEFAULT 'active'::text NOT NULL,
    is_visible_to_users boolean DEFAULT true NOT NULL,
    display_order integer DEFAULT 0 NOT NULL,
    trial_days integer DEFAULT 0 NOT NULL,
    trial_requires_payment_method boolean DEFAULT false NOT NULL,
    grace_period_days integer DEFAULT 0 NOT NULL,
    max_subscribers integer DEFAULT 0 NOT NULL,
    version integer DEFAULT 1 NOT NULL,
    metadata jsonb,
    revenuecat_product_id text,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_at timestamp without time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.subscription_packages OWNER TO postgres;

--
-- Name: subscriptions; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.subscriptions (
    id character varying DEFAULT gen_random_uuid() NOT NULL,
    user_id character varying NOT NULL,
    package_id character varying NOT NULL,
    price_id character varying,
    status text DEFAULT 'trialing'::text NOT NULL,
    trial_start_at timestamp without time zone,
    trial_end_at timestamp without time zone,
    activated_at timestamp without time zone,
    current_period_start timestamp without time zone,
    current_period_end timestamp without time zone,
    canceled_at timestamp without time zone,
    cancel_reason text,
    cancel_at_period_end boolean DEFAULT true NOT NULL,
    paused_at timestamp without time zone,
    resumed_at timestamp without time zone,
    expired_at timestamp without time zone,
    grace_period_end_at timestamp without time zone,
    failed_payment_count integer DEFAULT 0 NOT NULL,
    last_payment_failed_at timestamp without time zone,
    next_retry_at timestamp without time zone,
    billing_cycle text NOT NULL,
    price_at_purchase numeric(12,2) NOT NULL,
    currency text DEFAULT 'USD'::text NOT NULL,
    coupon_id character varying,
    discount_amount numeric(12,2),
    external_subscription_id text,
    payment_gateway text DEFAULT 'revenuecat'::text,
    package_version_at_purchase integer DEFAULT 1 NOT NULL,
    metadata jsonb,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_at timestamp without time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.subscriptions OWNER TO postgres;

--
-- Name: topics; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.topics (
    id character varying DEFAULT gen_random_uuid() NOT NULL,
    chapter_id character varying NOT NULL,
    title text NOT NULL,
    description text,
    "order" integer DEFAULT 0,
    is_published boolean DEFAULT false,
    author text,
    source text,
    "references" text,
    last_reviewed_at timestamp without time zone,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_at timestamp without time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.topics OWNER TO postgres;

--
-- Name: user_progress; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.user_progress (
    id character varying DEFAULT gen_random_uuid() NOT NULL,
    user_id character varying NOT NULL,
    topic_id character varying NOT NULL,
    is_completed boolean DEFAULT false,
    completed_at timestamp without time zone,
    created_at timestamp without time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.user_progress OWNER TO postgres;

--
-- Name: user_sessions; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.user_sessions (
    id character varying DEFAULT gen_random_uuid() NOT NULL,
    user_id character varying NOT NULL,
    device_id text NOT NULL,
    device_label text,
    platform text,
    user_agent text,
    ip_address text,
    refresh_token_hash text NOT NULL,
    is_active boolean DEFAULT true NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    last_seen_at timestamp without time zone DEFAULT now() NOT NULL,
    expires_at timestamp without time zone NOT NULL,
    revoked_at timestamp without time zone,
    revoked_by character varying,
    revoke_reason text
);


ALTER TABLE public.user_sessions OWNER TO postgres;

--
-- Name: users; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.users (
    id character varying DEFAULT gen_random_uuid() NOT NULL,
    email text NOT NULL,
    password text NOT NULL,
    name text NOT NULL,
    role text DEFAULT 'student'::text NOT NULL,
    subscription_status text DEFAULT 'none'::text NOT NULL,
    subscription_plan text,
    subscription_expires_at timestamp without time zone,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    is_email_verified boolean DEFAULT false NOT NULL,
    email_verification_token text,
    email_token_expires_at timestamp without time zone,
    phone_number text,
    is_phone_verified boolean DEFAULT false NOT NULL,
    phone_verification_token text,
    phone_token_expires_at timestamp without time zone,
    is_active boolean DEFAULT true NOT NULL,
    deactivated_at timestamp without time zone,
    deactivation_reason text,
    deletion_requested_at timestamp without time zone,
    deletion_status text DEFAULT 'none'::text NOT NULL,
    avatar_url text,
    device_limit_override_enabled boolean DEFAULT false NOT NULL,
    device_limit_max integer
);


ALTER TABLE public.users OWNER TO postgres;

--
-- Data for Name: add_on_bundles; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.add_on_bundles (id, name, slug, description, price, currency, add_on_ids, is_active, display_order, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: add_ons; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.add_ons (id, name, slug, description, pricing_type, price, currency, billing_cycle, max_quantity_per_user, compatible_package_ids, is_active, display_order, metadata, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: announcements; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.announcements (id, title, message, type, is_active, expires_at, created_by, created_at, updated_at) FROM stdin;
592151fc-7595-459f-9dbf-94085c2de614	checking	checking 12345	info	t	2026-02-28 00:00:00	demo-user-001	2026-02-07 21:05:09.789265	2026-03-05 11:54:11.402
fed74c45-2b31-4dbf-b7a8-2030670a612c	Book published 	We are happy to announce that you can buy MaterMind in book form	promo	t	2026-02-20 00:00:00	demo-user-001	2026-02-19 11:59:26.377787	2026-03-05 11:54:14.283
db40c452-4619-4fd3-96c6-63784e552b36	New topics added	Updated new topics added	info	t	2026-02-26 00:00:00	demo-user-001	2026-02-25 16:23:45.448545	2026-03-05 11:54:16.827
9247ba19-bffc-4ee4-b7ac-8630ad72573d	Welcome to Maternal Mind	Your OB-GYN learning journey starts here. Explore topics and quizzes.	info	t	\N	\N	2026-03-04 21:09:04.592143	2026-03-05 11:54:19.252
f9792e51-96d6-42aa-9937-8ded35758fb8	Announcements 	New announcement 	update	t	2026-03-07 00:00:00	demo-user-001	2026-03-05 12:49:55.568976	2026-06-02 03:06:57.151
\.


--
-- Data for Name: app_settings; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.app_settings (id, key, value, updated_at) FROM stdin;
294e60f2-0094-4c68-90fb-51b7ddb34cc6	support_whatsapp_number	+923360830836	2026-05-14 11:05:45.522534
ea2c0d7b-86c2-4bf7-953b-caf9b6020368	support_phone_number	+923360830836	2026-05-14 11:05:45.622353
e0038588-d5ea-401c-af8c-b0b274718dc5	support_email	support@maternalmind.com.pk	2026-05-14 11:05:46.014244
4c026f2b-f744-4248-b466-11d786a4dcfb	support_whatsapp_default_message	Hello Support Team, I need help.	2026-05-14 11:05:46.047001
bae2129e-ad7c-41d6-bab8-200e7e9cf6f1	brevo_smtp_host	smtp-relay.brevo.com	2026-05-14 11:06:02.709
8ecdbed3-4db9-4bae-b283-4f11105ebcdd	brevo_smtp_port	587	2026-05-14 11:06:02.753
ba7819c7-b010-4097-a1b5-035b36a97e61	brevo_smtp_user	a18bec001@smtp-brevo.com	2026-05-14 11:06:02.771
9e005109-d5fe-44ef-89a7-955f8996a5b8	brevo_smtp_pass	xsmtpsib-da222d5dc0df2086546ec4b894f048f840bfc21a8f6b742906727c878fb87444-7OqyTiMRrtYM4Lpk	2026-05-14 11:06:02.797
4aa28852-0aca-4a8b-913d-b1666a5c775f	brevo_from_email	noreply@maternalmind.com.pk	2026-05-14 11:06:02.888
ca2198e8-eda7-4d18-8776-8b1a6c89d707	brevo_from_name	Maternal Mind	2026-05-14 11:06:02.909
6171887c-20a4-448e-a322-ff28266337ab	payment_instructions	{"currency":"PKR","instructions":"Transfer the package amount to one of the accounts below, then upload a screenshot of your payment receipt. Your subscription will activate once an admin verifies it.","bank":{"bankName":"HBL","accountTitle":"Farzana Muneer","accountNumber":"08477902077901","iban":"PK85HABB0008477902077901","branch":"Chowk Azam, Layyah"},"wallets":[{"name":"JazzCash","accountTitle":"Farzana Muneer","number":"03360830836"}]}	2026-07-05 15:18:46.307222
\.


--
-- Data for Name: audit_logs; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.audit_logs (id, admin_user_id, action, entity_type, entity_id, details, created_at) FROM stdin;
ae2452c6-12ed-42a1-a99f-1ac9b58a43a8	demo-user-001	update	book	book-obstetrics	{"isPublished": false}	2026-02-07 20:59:55.294777
44f131db-529a-4abe-8eb2-98aa1a1cd6f0	demo-user-001	update	book	book-obstetrics	{"isPublished": true}	2026-02-07 20:59:57.444514
0bac7036-e073-4905-ba29-26ceecb1f9bf	demo-user-001	update	user	demo-user-001	{"name": "Dr. Farzana Muneer", "role": "admin", "subscriptionPlan": "premium", "subscriptionStatus": "active"}	2026-02-07 21:01:52.342697
ef68e957-f1b4-4ffd-a43c-ae9715b51c98	demo-user-001	update	user	51268d4e-a5cf-4e92-948c-0c708d200d48	{"name": "Dr. Faisal Maqsood Anwar", "role": "student", "subscriptionPlan": "quarterly", "subscriptionStatus": "active"}	2026-02-07 21:02:24.236035
013dc1df-8bc4-4e9e-bab2-3ac4d5dc4fe0	demo-user-001	create	announcement	592151fc-7595-459f-9dbf-94085c2de614	{"title": "checking"}	2026-02-07 21:05:09.798922
82fdbce7-64f1-4d0f-a731-68540d99e133	demo-user-001	update	user	51268d4e-a5cf-4e92-948c-0c708d200d48	{"name": "Dr. Faisal Maqsood Anwar", "role": "student", "isEmailVerified": true, "isPhoneVerified": true, "subscriptionPlan": "quarterly", "subscriptionStatus": "active"}	2026-02-07 21:07:46.242126
fb3e8306-8629-4298-88eb-c39ecbe57f06	demo-user-001	update	chapter	ch-obs-1	{"isPublished": false}	2026-02-08 12:56:36.07096
524deb00-2071-4e0d-ae54-dc9db04f699a	demo-user-001	update	chapter	ch-obs-1	{"isPublished": false}	2026-02-08 12:56:36.949118
ab3eadfc-3417-4ee6-8b06-5622f7b24a32	demo-user-001	update	topic	t-gyn-2-1	{"title": "Pelvic Inflammatory Diseases", "author": "Dr. Berek", "description": "CDC diagnostic criteria, causative organisms, antibiotic regimens, and complications."}	2026-02-08 14:33:00.385634
5999a9f7-f7cf-4696-b097-8690c08b2a56	demo-user-001	create	topic	884f7d64-320a-416c-838e-cf5c1bc87e8a	{"title": "Infertility "}	2026-02-08 14:33:34.230589
d00be907-f338-4062-aed7-aeccff81e4ab	demo-user-001	create	book	24cb427d-4f9a-4e5a-8349-fe1d37b9454e	{"title": "Rcog guidance "}	2026-02-08 15:51:14.812499
f5cb8c03-e133-4e15-a17a-88e1cf8c9a91	demo-user-001	create	book	78e7ff39-9837-4788-91db-957e798fb9b9	{"title": "Maternal Mind "}	2026-02-08 15:52:13.479761
7a8b5a75-a2b6-4689-a738-7a5edaa23221	demo-user-001	create	book	a0847e36-d038-4ad6-9c49-6715f20fadff	{"title": "Sub fertility "}	2026-02-08 15:53:43.764898
606d86d9-b1f8-4e1d-a88a-bfe7eacb6199	demo-user-001	create	chapter	559812a9-d524-4a06-bcd2-0490a868ce19	{"title": "General Gynaecology "}	2026-02-08 16:13:21.045962
06811bdb-5965-4dcf-85d3-a8426a6ac3a3	demo-user-001	update	book	78e7ff39-9837-4788-91db-957e798fb9b9	{"isPublished": true}	2026-02-09 09:22:08.782264
d8cc0c86-c70a-44e6-a48f-ec126d66dc4b	demo-user-001	update	chapter	559812a9-d524-4a06-bcd2-0490a868ce19	{"title": "General Gynaecology ", "description": "GENERAL GYNAECOLOGY:\\n1. HMB\\n2. UTERINE FIBROIDS\\n3. UAE\\n4. SURGICAL TREATMENT OF FIBROID\\n5. MENOPAUSE AND HRT\\n6. HRT\\n7. HRT AFTER GYNAECOLOGICAL MALIGNANCY\\n8. UNSHEDULED BLEEDS ON HRT\\n9. POST – MENOPAUSAL BLEEDING \\n10. CHRONIC PELVIC PAIN\\n11. PRE – MENSTRUAL SYNDROME\\n12. P0 AMENORRHEA\\n13. III AMENORRHEA\\n14. INTER SEX & KARYOTYPING \\n15. CONGENITAL UTERINE ANOMALIES\\n16. OUTFLOW TRACK DISORDERS OF VAGINA\\n17. MRKH\\n18. DYSMENORRHEA\\n19. FEMALE GENITAL MUTATION (FGM)\\n20. HIRSUTISM IN YOUNG WOMEN\\n21. HMB IN ADOLESCENCE\\n22. PRECOCIOUS PUBERTY\\n"}	2026-02-09 16:58:46.871777
2fb0d946-0bbf-4de4-b969-fd1a68d633a3	demo-user-001	update	chapter	ch-obs-1	{"isPublished": true}	2026-02-09 17:30:08.624308
eb524f09-8b35-4d63-aa5c-9a79df25145b	demo-user-001	update	chapter	ch-obs-1	{"isPublished": false}	2026-02-09 17:30:09.711063
322859ec-fe32-4d3b-8d85-7fd901e7672d	demo-user-001	update	chapter	ch-obs-1	{"isPublished": true}	2026-02-09 17:30:12.213391
37404b2e-f475-4a53-af34-e7533a54d4ac	demo-user-001	create	chapter	eafd4da6-fc88-40a7-8c69-b4fc9b43a3a1	{"title": "labour and delivery"}	2026-02-12 02:44:26.975801
907b488e-85a5-4fa7-8a23-46563c3a2ed1	demo-user-001	create	topic	c5c5ba4d-dfa4-46cd-8788-8ec5a6f208ea	{"title": "labour analgesia"}	2026-02-12 02:45:07.782492
daacd1f0-eaf1-44ae-aeab-4dd2d0a82b65	demo-user-001	update	mcq	mcq-060	\N	2026-02-12 04:54:35.284316
9fbe0af6-da79-4b1e-8d80-9d412debdb3d	demo-user-001	update	mcq	mcq-060	\N	2026-02-12 04:54:37.295715
cfe8dc77-48d2-411d-8498-f67448294f74	demo-user-001	update	mcq	mcq-060	\N	2026-02-12 04:54:40.256917
e75c890e-2a67-435d-81d5-14b2d783f545	demo-user-001	update	mcq	mcq-060	\N	2026-02-12 04:54:43.655666
5f030dff-8202-4fac-8b0b-8bd9e7ffb569	demo-user-001	update	mcq	mcq-060	\N	2026-02-12 04:54:49.590907
af4a83ff-ac1d-4cd6-b54f-226b9e9b2133	demo-user-001	update	mcq	mcq-060	\N	2026-02-12 04:54:53.901899
e4f4a579-4a01-48e9-bec0-1e844fe661d1	demo-user-001	update	mcq	mcq-060	\N	2026-02-12 04:54:55.5224
16097455-f570-4a2a-8120-3f920c7eabe5	demo-user-001	update	mcq	mcq-060	\N	2026-02-12 04:54:57.147948
de8af1ca-19ea-4a20-bccb-c80439925e06	demo-user-001	update	book	book-obstetrics	{"isPublished": false}	2026-02-15 10:25:32.810666
73fa4ec3-5e6a-4476-a627-0b9a9fa7fc3c	demo-user-001	create	topic	185d3971-4493-498d-a11f-a788a49cf2e9	{"title": "hhk"}	2026-02-18 23:18:37.15135
ae9edec0-c1cb-4986-a042-c53f28fd0409	demo-user-001	update	topic	t-obs-1-2	{"isPublished": false}	2026-02-18 23:18:41.394342
c518a807-cfb1-40ca-be94-d1bc8535f22c	demo-user-001	update	topic	t-obs-1-2	{"isPublished": true}	2026-02-18 23:18:43.994101
8ab8a9ef-9585-45f0-9dbe-c3253d474c6c	demo-user-001	create	topic	64983e3b-2cb2-4564-bfbb-f9454b304a8b	{"title": "sddl"}	2026-02-19 07:36:55.759043
e18fd2cb-67da-4673-965d-107f4a6069c3	demo-user-001	update	topic	64983e3b-2cb2-4564-bfbb-f9454b304a8b	{"isPublished": true}	2026-02-19 07:37:01.484915
d1ee7ea4-4143-47e9-9ed9-6f6a51441214	demo-user-001	update	topic	64983e3b-2cb2-4564-bfbb-f9454b304a8b	{"isPublished": false}	2026-02-19 07:37:03.980501
cc6f15d5-e8d6-49f1-b54d-b3de13571f30	demo-user-001	delete	topic	64983e3b-2cb2-4564-bfbb-f9454b304a8b	\N	2026-02-19 07:37:13.748219
35ea55db-7cff-4f22-8ca5-4adcffc6324d	demo-user-001	create	topic	703b239f-06bc-47bc-9d7c-a4e1f338c678	{"title": "1. HMB"}	2026-02-19 09:17:13.068474
f608c471-5bbe-4a45-a4a7-e9af96772c25	demo-user-001	create	content_block	0f154244-4975-4df3-b3b8-cfdf1a9c1122	\N	2026-02-19 09:17:46.206484
b8c2efab-7a5c-4cb2-bcc2-6dcd97304116	demo-user-001	delete	topic	703b239f-06bc-47bc-9d7c-a4e1f338c678	\N	2026-02-19 09:18:08.952232
a43b14d1-33e4-46d1-9ac6-169d52f8256f	demo-user-001	create	topic	e04b575b-9275-4f85-92e7-eee73c573d90	{"title": "1. HMB"}	2026-02-19 09:18:26.476376
1733abb5-f1e8-4041-b5f8-6e660275c56b	demo-user-001	create	content_block	7212adf7-e08f-43e4-97de-7bb56c275218	\N	2026-02-19 09:19:03.256351
57e8910f-e7f7-465c-8545-9c74f88ca8a3	demo-user-001	update	content_block	7212adf7-e08f-43e4-97de-7bb56c275218	\N	2026-02-19 09:23:18.764127
dfcb1336-061b-43b3-9fd7-ac1cd1bc2abc	demo-user-001	create	content_block	d81e238d-1f5d-4a59-b3b6-64365e3d6d59	\N	2026-02-19 09:36:32.763321
2f6c01c3-d6ca-447d-98cd-1117dd36bac9	demo-user-001	delete	content_block	d81e238d-1f5d-4a59-b3b6-64365e3d6d59	\N	2026-02-19 09:37:11.127932
70549c3c-8b6a-42fa-ac9b-e5fdd6fbeb1e	demo-user-001	update	content_block	7212adf7-e08f-43e4-97de-7bb56c275218	\N	2026-02-19 09:37:19.383893
3f14a106-6e40-4fd7-b757-a2e66c897546	demo-user-001	create	content_block	a8c601c8-8a14-461b-8716-22e3b05934c1	\N	2026-02-19 09:38:59.15186
081add7c-7990-471f-b3e1-fe5d3f2866f2	demo-user-001	update	content_block	a8c601c8-8a14-461b-8716-22e3b05934c1	\N	2026-02-19 11:51:57.823646
c22d9b8e-e015-4ea3-bb69-6eb201a08551	demo-user-001	update	user	7c45a099-3c4f-4068-8140-8b2f7ffe828e	{"name": "Asif Ali", "role": "student", "isEmailVerified": true, "isPhoneVerified": true, "subscriptionPlan": "", "subscriptionStatus": "none"}	2026-02-19 11:55:29.514083
e6b546ce-2d07-4960-b89a-29c3a4c6acb8	demo-user-001	create	announcement	fed74c45-2b31-4dbf-b7a8-2030670a612c	{"title": "Book published "}	2026-02-19 11:59:26.38082
49c272c3-3d94-4a1e-98f6-09ddcb0ffff1	demo-user-001	create	content_block	98456156-d9f3-4d16-ba24-964a6ec72cb7	\N	2026-02-22 12:22:45.499982
e43e9c06-fc9d-408d-893b-11c24d877e85	demo-user-001	create	content_block	fca7cb8b-c271-46b6-8a35-8bdbd547e39b	\N	2026-02-22 12:22:53.768745
963a141f-4d7b-4873-a5d5-04eb40853ba8	demo-user-001	delete	content_block	98456156-d9f3-4d16-ba24-964a6ec72cb7	\N	2026-02-22 12:23:02.02732
b77e9549-5ca2-4172-b5f0-43fcbda2c9da	demo-user-001	create	topic	f150f3bb-1b2e-4024-9751-2ccdaaf9c5e9	{"title": "xyz"}	2026-02-24 12:14:15.68166
0c9dbfb1-d512-4a58-8fb2-4ea36a4acba7	demo-user-001	create	content_block	03f88ac5-929b-4540-aa8f-93c879bc64bb	\N	2026-02-24 12:14:20.752867
f5574695-c26d-4678-a93e-2fa7b73b0296	demo-user-001	update	topic	f150f3bb-1b2e-4024-9751-2ccdaaf9c5e9	{"title": "2. UTERINE FIBROIDS:", "author": "", "description": ""}	2026-02-24 12:16:38.690113
d54e50ca-3288-4a7b-a03c-15dd13d3422b	demo-user-001	create	content_block	4b60045a-498d-40a2-86e5-8f7062cdbac0	\N	2026-02-24 14:06:19.703148
ca369044-8547-4cfc-a5ba-46f59b66939e	demo-user-001	create	content_block	38cac964-c338-49f6-a20f-72749911f714	\N	2026-02-24 14:10:16.780784
f910feba-8343-4045-846e-8fde49c9a4bf	demo-user-001	create	content_block	ac5bdf4f-6ba9-47b4-9317-ed801e840041	\N	2026-02-24 14:10:22.834106
d516d31c-439f-4765-a800-2d18fe1bcb45	demo-user-001	update	content_block	t-obs-1-1	"Batch saved 3 blocks"	2026-02-24 14:10:27.731822
b1653f92-e19c-423c-9548-34286c3a982d	demo-user-001	delete	topic	185d3971-4493-498d-a11f-a788a49cf2e9	\N	2026-02-24 14:17:47.984849
816186c9-fed2-4513-bfa2-b3b5bdcc55a0	demo-user-001	create	content_block	8b497a6c-abd2-4b23-8009-5f5b93618b06	\N	2026-02-24 14:27:23.87259
a3a05ad1-1ea5-493c-a91e-44228ab38485	demo-user-001	create	content_block	5f52e93a-4db8-4ca0-82c0-7272dc948e97	\N	2026-02-24 14:27:31.187054
1396e7ff-bfb0-4de1-bf99-af2629361baf	demo-user-001	update	content_block	f150f3bb-1b2e-4024-9751-2ccdaaf9c5e9	"Batch saved 1 blocks"	2026-02-24 14:47:35.811642
f49c4eea-e5f1-48c4-b695-0b08f7551d73	demo-user-001	update	content_block	f150f3bb-1b2e-4024-9751-2ccdaaf9c5e9	"Batch saved 1 blocks"	2026-02-24 17:14:21.823294
aa965553-4ca8-4c21-ba85-aae5df26cb89	demo-user-001	create	content_block	aaad6395-7f16-423f-930e-c35836931f22	\N	2026-02-25 13:04:23.990406
1e45245c-dd5d-4cbc-b960-8a37a877a37e	demo-user-001	update	content_block	t-rep-4-3	"Batch saved 2 blocks"	2026-02-25 13:04:33.14991
3a07496a-97b8-47c0-8601-80474337dbc7	demo-user-001	update	book	book-obstetrics	{"isPublished": true}	2026-02-25 13:46:54.90571
ae99b149-6651-4af8-9207-dc157ef737f7	demo-user-001	update	book	24cb427d-4f9a-4e5a-8349-fe1d37b9454e	{"isPublished": true}	2026-02-25 13:46:59.213379
8ed3347d-b1e8-4a03-af1c-bb44e37bce34	demo-user-001	update	book	a0847e36-d038-4ad6-9c49-6715f20fadff	{"isPublished": true}	2026-02-25 13:47:03.634375
bb21568c-ac9c-4398-8549-d65b0e08898e	demo-user-001	update	announcement	fed74c45-2b31-4dbf-b7a8-2030670a612c	\N	2026-02-25 13:50:47.273667
d992033a-4e6a-4ee5-8883-8d8af99ef36f	demo-user-001	update	announcement	fed74c45-2b31-4dbf-b7a8-2030670a612c	\N	2026-02-25 13:50:51.383203
863aac58-1768-4c5f-ba51-6a5b5e10a629	demo-user-001	update	announcement	592151fc-7595-459f-9dbf-94085c2de614	\N	2026-02-25 13:50:54.142096
bce80cfa-d18b-451a-9372-d33888e500db	demo-user-001	update	announcement	592151fc-7595-459f-9dbf-94085c2de614	\N	2026-02-25 13:50:56.256343
1a043c1c-4fe1-4fc1-bb42-2e1106b5efb2	demo-user-001	delete	user	991530f8-7288-4d62-bc81-81b72189e40b	\N	2026-02-25 13:54:27.319841
4b092d9e-76cf-4dfa-81d8-3ab145196316	demo-user-001	create	chapter	e1145cb6-7e48-491a-aecb-49f3635e0d5a	{"title": "subfertility"}	2026-02-25 15:06:48.545361
11f34a1e-4e93-4876-b0d3-58aaf3563536	demo-user-001	create	topic	56cc51cd-e906-4b18-8f0e-c999c92b2fe6	{"title": "fertility problems, assessment and treatment"}	2026-02-25 15:09:32.487006
685d5cd8-c92f-4d06-9803-e589a2dc6f08	demo-user-001	create	chapter	e590a149-18e5-4c6e-98dc-1166253e0fd7	{"title": "gynaecologic oncology"}	2026-02-25 15:10:17.613648
e15419eb-444e-4b3c-8fa1-08c4b9eba5fa	demo-user-001	create	chapter	edcccca0-81e4-4d2c-a6f1-9a61a70addb1	{"title": "urogynaecology"}	2026-02-25 15:10:35.638874
012f6e93-c41e-4f57-bdd1-9b06e6ecb856	demo-user-001	create	chapter	f2b8e01e-a768-446a-b583-fbef7f8d777f	{"title": "sexual and reproductive health"}	2026-02-25 15:11:00.812914
029dd6cd-688b-48d7-85f6-19461603e493	demo-user-001	create	chapter	39d9530a-a0db-4e64-9ffb-686b7718b433	{"title": "early pregnancy care"}	2026-02-25 15:11:21.866989
451f2690-366a-420b-b9b8-5cb5aebc4101	demo-user-001	create	chapter	188b059c-1301-45ec-bddb-20768a108a59	{"title": "maternal medicine"}	2026-02-25 15:11:41.601413
6e7f9d7f-8ac6-4c9b-b9f4-8c5fc6d7c175	demo-user-001	create	chapter	6d1bbc63-26de-4642-95f6-8397a8f16d3d	{"title": "antenatal"}	2026-02-25 15:11:57.573923
a6fd30b7-56c8-4d67-9b52-d58bbfa8026b	demo-user-001	update	chapter	6d1bbc63-26de-4642-95f6-8397a8f16d3d	{"title": "antenatal care", "description": ""}	2026-02-25 15:12:34.215751
efb870c6-62b4-4708-ab89-e8f4754db0a6	demo-user-001	create	chapter	79f511f4-7738-4801-b75c-3e833fb74e9d	{"title": "labour and delivery"}	2026-02-25 15:13:01.092461
b574005e-8b7c-432a-b682-3449842a4254	demo-user-001	create	chapter	2d7f5825-ea1d-44f6-9de6-9679babbc9fe	{"title": "post partum care"}	2026-02-25 15:13:24.959937
9b0cf917-ddb8-4671-aef4-300fb0852425	demo-user-001	create	chapter	e4943348-833e-4af8-bfda-2b98f6524398	{"title": "teaching"}	2026-02-25 15:13:42.585619
06cfcb46-00bd-446d-8bd5-87550d204094	demo-user-001	create	chapter	127cc523-92a2-43c9-8e22-78d018fc0959	{"title": "clinical governance"}	2026-02-25 15:14:01.261058
8d731874-32c8-4369-8ff9-03b04badf614	demo-user-001	create	topic	50c80e18-0d3b-4768-a95c-34b53e75708c	{"title": "perinatal infections"}	2026-02-25 15:15:08.161657
45f7a129-202f-4133-b2ab-b67e1da74479	demo-user-001	create	topic	61b3cf32-e12a-4dcb-ac09-6c9f2f419b56	{"title": "maternal sepsis during and following pregnancy "}	2026-02-25 15:16:10.066986
2a4e1475-fcaf-4ca9-a47e-f7c84eeff4a3	demo-user-001	create	topic	868b0357-38d4-4976-9a19-52bff546474e	{"title": "obtetric cholestasis"}	2026-02-25 15:18:41.823502
8b011f75-90a1-4be9-a377-c5caf77596aa	demo-user-001	create	content_block	7421302e-c0d2-414e-8736-ee418e41d650	\N	2026-02-25 15:19:31.150171
9557220f-0f45-4ced-8c27-5a7c5d195407	demo-user-001	create	content_block	b64919e3-e7d4-4d60-a1c3-c7acbf03f067	\N	2026-02-25 15:19:47.133395
36d9b6e9-eba8-486a-b613-bd1209f54eb7	demo-user-001	create	content_block	74eae3dd-476e-46c5-9594-00bb84e3b54c	\N	2026-02-25 15:20:59.023544
dd916ecf-7c72-4d90-8031-fb884a376fec	demo-user-001	create	content_block	e61596a6-9f6b-4f1e-a55f-b0dcba14e6e4	\N	2026-02-25 15:21:15.099928
d4098190-62af-46d8-a403-cacc8a02c7d1	demo-user-001	create	content_block	595c2a3f-6960-4ff5-aebc-5167022de2e0	\N	2026-02-25 15:22:15.708224
8017d4b8-c947-4c46-ae7a-4968698616f8	demo-user-001	update	content_block	868b0357-38d4-4976-9a19-52bff546474e	"Batch saved 3 blocks"	2026-02-25 15:23:55.793725
65c5e3e1-2d6b-4332-81a4-421039d9b935	demo-user-001	update	chapter	559812a9-d524-4a06-bcd2-0490a868ce19	{"isPublished": true}	2026-02-25 15:25:15.310356
c440544f-12a6-4efe-bb73-8fedf8407941	demo-user-001	update	chapter	e1145cb6-7e48-491a-aecb-49f3635e0d5a	{"isPublished": true}	2026-02-25 15:25:20.05386
3a2a22b6-0742-4b62-81f9-0728a647734e	demo-user-001	update	chapter	e590a149-18e5-4c6e-98dc-1166253e0fd7	{"isPublished": true}	2026-02-25 15:25:20.686667
1853518a-d3ca-462f-b434-4b64885948af	demo-user-001	update	chapter	edcccca0-81e4-4d2c-a6f1-9a61a70addb1	{"isPublished": true}	2026-02-25 15:25:21.464499
fa550627-7f34-4395-9c2c-6aee11ecc6b5	demo-user-001	update	chapter	f2b8e01e-a768-446a-b583-fbef7f8d777f	{"isPublished": true}	2026-02-25 15:25:22.081119
b52bd52a-940c-45e7-8196-1be51ccc92fc	demo-user-001	update	chapter	39d9530a-a0db-4e64-9ffb-686b7718b433	{"isPublished": true}	2026-02-25 15:25:22.57005
686bfb81-e0e1-4f8d-b54d-41af7fe03b9a	demo-user-001	update	chapter	188b059c-1301-45ec-bddb-20768a108a59	{"isPublished": true}	2026-02-25 15:25:22.980129
c1c151ea-41b4-418b-830c-333de807c364	demo-user-001	update	chapter	6d1bbc63-26de-4642-95f6-8397a8f16d3d	{"isPublished": true}	2026-02-25 15:25:23.494268
ad2ad27d-62ac-44b6-a5df-80bfe859a7fd	demo-user-001	update	chapter	79f511f4-7738-4801-b75c-3e833fb74e9d	{"isPublished": true}	2026-02-25 15:25:23.872463
6c90efed-729e-44d3-a562-4a6d07649ef9	demo-user-001	update	chapter	2d7f5825-ea1d-44f6-9de6-9679babbc9fe	{"isPublished": true}	2026-02-25 15:25:24.256125
4e7aba88-07b1-4f5d-a673-bedacd2ce892	demo-user-001	update	chapter	e4943348-833e-4af8-bfda-2b98f6524398	{"isPublished": true}	2026-02-25 15:25:25.823841
923e5a7f-edb1-42a6-b57d-bc81186598dc	demo-user-001	update	chapter	127cc523-92a2-43c9-8e22-78d018fc0959	{"isPublished": true}	2026-02-25 15:25:26.417417
8c88823d-9834-4823-ae5c-b9cec00d07af	demo-user-001	update	chapter	6d1bbc63-26de-4642-95f6-8397a8f16d3d	{"isPublished": true}	2026-02-25 15:25:51.636318
a5b0272f-6d8a-4d07-905b-accfac583bab	demo-user-001	update	chapter	6d1bbc63-26de-4642-95f6-8397a8f16d3d	{"isPublished": false}	2026-02-25 15:25:53.660762
89e8db89-2778-4d3f-adb2-c9f2884c08db	demo-user-001	update	chapter	6d1bbc63-26de-4642-95f6-8397a8f16d3d	{"isPublished": true}	2026-02-25 15:26:01.388892
8d0d183d-c9c3-465d-be1f-7851491315ee	demo-user-001	update	topic	e04b575b-9275-4f85-92e7-eee73c573d90	{"isPublished": true}	2026-02-25 15:27:47.651118
5afee1a9-b577-44fb-9481-99bc78e4b9ea	demo-user-001	update	topic	f150f3bb-1b2e-4024-9751-2ccdaaf9c5e9	{"isPublished": true}	2026-02-25 15:27:49.519511
1a235001-a4c2-4fe4-8b8b-8bd4e081fabe	demo-user-001	update	topic	50c80e18-0d3b-4768-a95c-34b53e75708c	{"isPublished": true}	2026-02-25 15:28:40.169736
14523b83-86fe-4410-8dad-0a61802f52dd	demo-user-001	update	topic	61b3cf32-e12a-4dcb-ac09-6c9f2f419b56	{"isPublished": true}	2026-02-25 15:28:41.134687
34690e82-4824-4a89-b8c6-7cfbcd8ab924	demo-user-001	update	topic	868b0357-38d4-4976-9a19-52bff546474e	{"isPublished": true}	2026-02-25 15:28:41.862566
3189701d-b1e2-4e54-b665-8fe5048cae98	demo-user-001	update	content_block	868b0357-38d4-4976-9a19-52bff546474e	"Batch saved 0 blocks"	2026-02-25 15:28:55.200235
6886234f-7c45-4dbe-8198-050f6fa0dd02	demo-user-001	update	content_block	868b0357-38d4-4976-9a19-52bff546474e	"Batch saved 0 blocks"	2026-02-25 15:28:55.907329
e6c9b848-707d-4175-88d4-62559ac29f69	demo-user-001	update	chapter	188b059c-1301-45ec-bddb-20768a108a59	{"isPublished": false}	2026-02-25 15:30:00.455789
a5536792-3af1-4968-97b4-4a636aefde64	demo-user-001	update	chapter	188b059c-1301-45ec-bddb-20768a108a59	{"isPublished": true}	2026-02-25 15:30:02.480586
29887a79-4399-4cf5-bbde-cb7301fe5c08	demo-user-001	update	book	78e7ff39-9837-4788-91db-957e798fb9b9	{"isPublished": false}	2026-02-25 15:30:12.121747
477db8bb-efb6-48ad-887a-4adeacc1e031	demo-user-001	update	book	78e7ff39-9837-4788-91db-957e798fb9b9	{"isPublished": true}	2026-02-25 15:30:15.196722
759c92ee-9784-4ef2-886a-f6b7104b495c	demo-user-001	update	book	78e7ff39-9837-4788-91db-957e798fb9b9	{"title": "Maternal Mind ", "imageUrl": "", "description": ""}	2026-02-25 15:30:21.512313
23c598a9-5ea9-496e-964a-7daa51f869f9	demo-user-001	delete	content_block	595c2a3f-6960-4ff5-aebc-5167022de2e0	\N	2026-02-25 15:31:58.881397
688ce99f-0e2a-475d-b0cd-b7c0c5da2ffe	demo-user-001	delete	content_block	e61596a6-9f6b-4f1e-a55f-b0dcba14e6e4	\N	2026-02-25 15:32:05.651502
9fa0d3be-6ba5-4bd1-9f25-7096409f4b36	demo-user-001	create	content_block	7a1120f3-4443-4adc-b31d-576f67da7078	\N	2026-02-25 15:32:19.80857
cc30855d-200c-4288-a5e0-367b319184ee	demo-user-001	create	content_block	05267c8e-0f05-4abc-8fb7-595440dfadfb	\N	2026-02-25 15:34:28.981561
bf62c729-d9a6-4455-bde4-b0dd7158f04f	demo-user-001	delete	content_block	74eae3dd-476e-46c5-9594-00bb84e3b54c	\N	2026-02-25 15:34:51.609249
2d30b95e-5975-4707-bab7-d5b0ca05ad93	demo-user-001	create	content_block	860f8369-7c2e-4597-a961-8282441b5b0c	\N	2026-02-25 15:34:57.468094
099a58f0-2c56-4d66-acf1-c4b98e03a670	demo-user-001	update	content_block	868b0357-38d4-4976-9a19-52bff546474e	"Batch saved 3 blocks"	2026-02-25 15:35:16.523107
e716adec-2eab-4b50-9f04-d669da97d1c6	demo-user-001	update	content_block	868b0357-38d4-4976-9a19-52bff546474e	"Batch saved 0 blocks"	2026-02-25 15:35:40.899356
2c648a1a-4a50-45e1-a60e-f11272a92e6a	demo-user-001	update	content_block	868b0357-38d4-4976-9a19-52bff546474e	"Batch saved 0 blocks"	2026-02-25 15:36:08.320459
4d68c4c1-f74d-4f19-8e6e-bbf4f11aff8e	demo-user-001	create	content_block	881d4ffd-9fb3-41f0-ae09-76f390bdbc56	\N	2026-02-25 15:37:01.431911
a5928f99-412d-4be0-a048-3276deada30c	demo-user-001	delete	content_block	881d4ffd-9fb3-41f0-ae09-76f390bdbc56	\N	2026-02-25 15:37:26.608225
c52a94b0-43a3-4f91-9224-7ed620e8a952	demo-user-001	create	content_block	4e601d4c-38de-4e98-9b01-e7912cfe6ac3	\N	2026-02-25 15:37:35.799515
8466b75d-8645-4dea-91c9-f0d68d6d4ab3	demo-user-001	delete	content_block	4e601d4c-38de-4e98-9b01-e7912cfe6ac3	\N	2026-02-25 15:38:36.033557
4dc0e042-799f-41f2-bbff-3e8bae64fcc0	demo-user-001	create	content_block	ea8bb8f9-f91e-4b5f-b601-04294aea214f	\N	2026-02-25 15:38:50.737699
ce7639ef-4c5c-488d-9386-f90d2e12aa41	demo-user-001	create	content_block	44f05b78-04d7-432f-99ec-0b91de540df1	\N	2026-02-25 15:39:32.140428
9a7af571-a1ba-4f18-9282-4b963d60b0ae	demo-user-001	create	content_block	37ca7d70-fa77-413a-bcc9-aa858ea774f1	\N	2026-02-25 15:39:32.311316
bb9abac8-d45e-4969-9b27-9011db787909	demo-user-001	delete	content_block	37ca7d70-fa77-413a-bcc9-aa858ea774f1	\N	2026-02-25 15:39:37.742648
db4c7e37-0946-4838-aac0-c5bc7a9c420b	demo-user-001	create	content_block	764e1d11-4f72-4f36-8602-f1c337650cc1	\N	2026-02-25 15:39:52.982951
1ed87952-378e-4727-bf19-52d22d97b11c	demo-user-001	create	content_block	9c5e1070-0d3e-4fd5-a130-99f82e1846e5	\N	2026-02-25 15:40:47.057997
2314e70b-8c4d-4cfd-bf6c-0e54ac691412	demo-user-001	create	topic	54b2544a-4bce-41e2-8f2a-e7a29653b139	{"title": "3. UTERINE ARTERY EMBOLIZATION"}	2026-02-25 15:40:53.60986
a2a0bda1-8ba4-4d7c-938e-84eff0f9c833	demo-user-001	create	content_block	78515d86-fb64-4f57-8751-c98dbdb319fd	\N	2026-02-25 15:40:59.6746
168158fc-aff4-4b4d-ab3e-b9479c9c2f18	demo-user-001	delete	content_block	9c5e1070-0d3e-4fd5-a130-99f82e1846e5	\N	2026-02-25 15:41:05.459598
899ec399-6f72-476e-83f4-b3e77b54803d	demo-user-001	create	content_block	a21b23b8-36fc-4b79-a7d1-bb9611188348	\N	2026-02-25 15:41:10.331243
2b7d4ab0-45c5-4546-be47-546f20954170	demo-user-001	delete	content_block	ea8bb8f9-f91e-4b5f-b601-04294aea214f	\N	2026-02-25 15:41:29.46821
c4b937f4-6318-4eeb-abb5-7477c335f13a	demo-user-001	delete	content_block	44f05b78-04d7-432f-99ec-0b91de540df1	\N	2026-02-25 15:41:39.784515
1a74242d-05a7-4d85-baca-f099e61a34e9	demo-user-001	delete	content_block	764e1d11-4f72-4f36-8602-f1c337650cc1	\N	2026-02-25 15:41:46.59488
9173deb4-0667-4db1-8c31-a23bd3697eab	demo-user-001	update	content_block	54b2544a-4bce-41e2-8f2a-e7a29653b139	"Batch saved 1 blocks"	2026-02-25 15:42:39.114317
64c85353-5a05-4f7b-87ea-9707f7ed4163	demo-user-001	update	content_block	54b2544a-4bce-41e2-8f2a-e7a29653b139	"Batch saved 0 blocks"	2026-02-25 15:44:17.909935
941d186a-8736-4378-b1f2-84433df33a8b	demo-user-001	update	content_block	868b0357-38d4-4976-9a19-52bff546474e	"Batch saved 1 blocks"	2026-02-25 15:44:47.675283
11a118a3-cb77-4391-8f8c-327f50ae9ba2	demo-user-001	update	content_block	868b0357-38d4-4976-9a19-52bff546474e	"Batch saved 0 blocks"	2026-02-25 15:44:59.169321
69833e9a-c66e-4e14-b029-e25b0892c3ca	demo-user-001	update	content_block	868b0357-38d4-4976-9a19-52bff546474e	"Batch saved 0 blocks"	2026-02-25 15:45:28.014357
220ca521-281b-4b03-834c-3c3835d9d260	demo-user-001	create	topic	fc3b87ae-5575-454a-8b2e-927762892b14	{"title": "SURGICAL TREATMENT OF FIBROID"}	2026-02-25 15:45:54.25272
15d5b675-d164-4745-8f53-500fd0c3e0cf	demo-user-001	create	content_block	c4a698d2-8d86-4435-8369-aa9fc877d23c	\N	2026-02-25 15:46:11.515931
40cf3329-1fc9-4d12-9b17-49842c3f55b6	demo-user-001	delete	content_block	860f8369-7c2e-4597-a961-8282441b5b0c	\N	2026-02-25 15:46:26.543679
697c3e89-b81e-483d-8728-62d2110f5b1e	demo-user-001	delete	content_block	7a1120f3-4443-4adc-b31d-576f67da7078	\N	2026-02-25 15:46:35.242505
9b22e6f1-a2d7-41f9-8cfb-1a17c7f2083f	demo-user-001	update	content_block	fc3b87ae-5575-454a-8b2e-927762892b14	"Batch saved 1 blocks"	2026-02-25 15:46:44.145699
828fc975-04ba-4b67-980d-57e1a49ba7cb	demo-user-001	create	content_block	768d23f5-a780-4661-b6f4-f5a4ed7adbc4	\N	2026-02-25 15:47:53.89807
b26034e9-c2a8-46c9-b060-b66f98af5fa5	demo-user-001	create	topic	352ec72b-564e-4229-bdba-d351e81b5b6d	{"title": "5. MENOPAUSE AND HRT"}	2026-02-25 15:48:04.448126
f8a77632-72f3-4119-90ee-b3f512b9d1d5	demo-user-001	create	content_block	3e066e43-b4c0-4552-a659-62ff11d130da	\N	2026-02-25 15:48:15.794806
a48c7836-a792-4c54-bbe6-8e65272448fc	demo-user-001	update	content_block	868b0357-38d4-4976-9a19-52bff546474e	"Batch saved 3 blocks"	2026-02-25 15:48:34.201376
aab94fe7-b6d9-4bdd-aa50-7dee96886318	demo-user-001	update	content_block	868b0357-38d4-4976-9a19-52bff546474e	"Batch saved 0 blocks"	2026-02-25 15:48:55.364457
3b0e4101-61bc-456e-a75d-874ca8d1b36b	demo-user-001	create	content_block	5db50127-53c2-4c80-9d92-e9e19f830320	\N	2026-02-25 15:49:36.536648
b780dcc4-0fe6-4017-8167-b933b8ec88c0	demo-user-001	create	content_block	dadb1263-fc26-436b-9cfc-0636bf8492ed	\N	2026-02-25 15:49:36.925741
6fc8dd45-a405-4daf-9e3b-6887f7db421a	demo-user-001	delete	content_block	dadb1263-fc26-436b-9cfc-0636bf8492ed	\N	2026-02-25 15:49:56.909766
b5acdadb-bcac-4ed8-bdd8-c13dc0b8ff9e	demo-user-001	update	content_block	868b0357-38d4-4976-9a19-52bff546474e	"Batch saved 0 blocks"	2026-02-25 15:50:38.630652
890ce0ef-35d7-4236-b648-bc6c727bd010	demo-user-001	update	topic	868b0357-38d4-4976-9a19-52bff546474e	{"isPublished": false}	2026-02-25 15:50:48.434574
9c7e80ac-f783-491c-bc58-bb27ae176127	demo-user-001	update	topic	868b0357-38d4-4976-9a19-52bff546474e	{"isPublished": true}	2026-02-25 15:50:50.712421
58c6f0ba-26c2-4435-9468-a2d96417c96f	demo-user-001	create	topic	a6f0e957-4c8c-42e0-8163-3b685c7c1152	{"title": "reduced fetal movements"}	2026-02-25 15:54:59.20228
43a9e5db-e8b1-4daa-97fa-6b590cd952f4	demo-user-001	create	content_block	59c9dfcc-5d8b-4245-b501-5b65926fba2f	\N	2026-02-25 15:56:02.825113
c66079f6-1b16-4e40-8638-5d2f57f812d4	demo-user-001	create	content_block	a4021107-b09a-4eb3-a374-d1eed7c186bf	\N	2026-02-25 15:56:44.241164
2062d0dd-10f8-4018-96e3-fce232f51230	demo-user-001	create	content_block	8f0bc988-0413-4430-b281-e9b2a0e7b6e2	\N	2026-02-25 15:56:53.646948
30e9c22a-9d2b-47fb-864b-4ee308327897	demo-user-001	delete	content_block	768d23f5-a780-4661-b6f4-f5a4ed7adbc4	\N	2026-02-25 15:57:00.288888
e97aad48-0824-4201-942b-814b27f78b2a	demo-user-001	delete	content_block	5db50127-53c2-4c80-9d92-e9e19f830320	\N	2026-02-25 15:57:03.88444
4e44af2b-96dd-420a-b7f6-158b4acf3fdf	demo-user-001	update	content_block	868b0357-38d4-4976-9a19-52bff546474e	"Batch saved 0 blocks"	2026-02-25 15:57:18.319694
29ce4ec0-984e-4edf-8032-e5f9a885c235	demo-user-001	update	content_block	352ec72b-564e-4229-bdba-d351e81b5b6d	"Batch saved 3 blocks"	2026-02-25 15:58:49.32165
b2b6a6dd-a15d-49d0-9ac9-fdb5a90dcc95	demo-user-001	delete	content_block	59c9dfcc-5d8b-4245-b501-5b65926fba2f	\N	2026-02-25 16:01:38.77246
f6629d34-a9fe-4954-8c88-74ff1fde7595	demo-user-001	create	content_block	c1f72d7a-8e9c-4a25-88c7-01f00340e470	\N	2026-02-25 16:01:45.336232
eb012de7-5383-4421-a6b3-d5fd15c8a687	demo-user-001	create	content_block	0857b6b1-bf1a-4e78-a55d-f09fa8578875	\N	2026-02-25 16:08:21.742239
b95f66fa-9f59-489f-a78e-3555b180ef08	demo-user-001	create	content_block	8d76a54a-ab20-4c7f-862b-0478bb9500e0	\N	2026-02-25 16:08:22.182277
93673925-48ba-4ffa-8072-4b6493136884	demo-user-001	delete	content_block	8d76a54a-ab20-4c7f-862b-0478bb9500e0	\N	2026-02-25 16:08:24.659639
0c85260b-a0e7-42cc-ab93-99be73f8aa4d	demo-user-001	delete	content_block	0857b6b1-bf1a-4e78-a55d-f09fa8578875	\N	2026-02-25 16:08:26.067286
0256e042-91c5-4952-a184-c3fb831680f5	demo-user-001	update	content_block	352ec72b-564e-4229-bdba-d351e81b5b6d	"Batch saved 1 blocks"	2026-02-25 16:12:05.501894
0aa045e8-3581-4867-8151-6b3f1d501c8b	demo-user-001	create	content_block	53607bdf-73e8-4078-9ca4-f5cf4b3da031	\N	2026-02-25 16:14:05.269415
00047585-c580-4c11-b02d-58faed4a651a	demo-user-001	delete	content_block	53607bdf-73e8-4078-9ca4-f5cf4b3da031	\N	2026-02-25 16:14:25.7733
292a61fb-19fa-4a34-886d-792a8615e214	demo-user-001	create	content_block	16c8e05f-84ce-452a-b669-90cb19aea64b	\N	2026-02-25 16:14:39.912993
911b1cb8-fd97-4045-89d9-f1c74b1d07d3	demo-user-001	create	content_block	916dd95a-e835-4218-bed3-251dfd66f640	\N	2026-02-25 16:15:59.84376
48628da4-0833-4466-a0ad-f6847573e931	demo-user-001	create	content_block	22b14e20-b1f9-475b-9b26-f082f55ffe59	\N	2026-02-25 16:16:22.036575
1c27875c-b2fc-468c-9c27-e65214fb22da	demo-user-001	update	content_block	352ec72b-564e-4229-bdba-d351e81b5b6d	"Batch saved 5 blocks"	2026-02-25 16:16:45.196597
48569f12-2bf5-4959-86a6-4005120c671e	demo-user-001	update	topic	54b2544a-4bce-41e2-8f2a-e7a29653b139	{"isPublished": true}	2026-02-25 16:18:09.497944
6df6be62-3489-450e-bd20-8717eff32e0a	demo-user-001	update	topic	fc3b87ae-5575-454a-8b2e-927762892b14	{"isPublished": true}	2026-02-25 16:18:10.07233
6b1f3c99-afee-434a-9471-08f097312737	demo-user-001	update	topic	352ec72b-564e-4229-bdba-d351e81b5b6d	{"isPublished": true}	2026-02-25 16:18:10.44581
ff6e0c6b-7980-4639-963b-f86c4f6c40d8	demo-user-001	update	content_block	f150f3bb-1b2e-4024-9751-2ccdaaf9c5e9	"Batch saved 0 blocks"	2026-02-25 16:18:27.117174
8d341aad-3ea8-4e7d-8c4b-d371d0c13412	demo-user-001	delete	content_block	a8c601c8-8a14-461b-8716-22e3b05934c1	\N	2026-02-25 16:20:16.764164
4343d575-d1da-4efb-b5e6-3b5312eb3a3f	demo-user-001	update	content_block	e04b575b-9275-4f85-92e7-eee73c573d90	"Batch saved 0 blocks"	2026-02-25 16:20:19.459849
734186c5-ea60-47e6-8455-0a2869246d57	demo-user-001	update	content_block	352ec72b-564e-4229-bdba-d351e81b5b6d	"Batch saved 0 blocks"	2026-02-25 16:21:23.316595
c453cce5-adc5-41d7-88d5-798f0d2c5fa6	demo-user-001	update	content_block	352ec72b-564e-4229-bdba-d351e81b5b6d	"Batch saved 0 blocks"	2026-02-25 16:21:42.401292
48f19257-b577-48f1-8146-99137e4ac594	demo-user-001	create	announcement	9e969605-5c45-4636-97af-d553082cdf8b	{"title": "New topics added"}	2026-02-25 16:22:47.212429
db7a9bb1-c02b-47b4-ab64-1e48240bda97	demo-user-001	delete	announcement	9e969605-5c45-4636-97af-d553082cdf8b	\N	2026-02-25 16:23:12.928875
54376db3-62ac-4b6c-9616-314d3efe379b	demo-user-001	create	announcement	db40c452-4619-4fd3-96c6-63784e552b36	{"title": "New topics added"}	2026-02-25 16:23:45.455227
ce6d2223-01ae-43a8-ae08-5666ab3e95a5	demo-user-001	update	topic	352ec72b-564e-4229-bdba-d351e81b5b6d	{"isPublished": false}	2026-02-25 16:24:24.608645
cacaaa3a-011f-4ba8-ae67-c04ead345641	demo-user-001	update	topic	352ec72b-564e-4229-bdba-d351e81b5b6d	{"title": "MENOPAUSE AND HRT", "author": "", "description": ""}	2026-02-25 16:24:37.083015
cbd0fc41-66a4-4571-85ad-7fcbc6b48a6b	demo-user-001	update	topic	54b2544a-4bce-41e2-8f2a-e7a29653b139	{"title": "UTERINE ARTERY EMBOLIZATION", "author": "", "description": ""}	2026-02-25 16:24:51.929892
9393f8cd-ebb4-4e23-928d-ef5ecf97fdae	demo-user-001	update	topic	f150f3bb-1b2e-4024-9751-2ccdaaf9c5e9	{"title": "UTERINE FIBROIDS:", "author": "", "description": ""}	2026-02-25 16:25:20.528824
2efc4703-3bc8-47ee-bd47-7cbdc2b3104c	demo-user-001	update	topic	e04b575b-9275-4f85-92e7-eee73c573d90	{"title": "HMB", "author": "Dr. Farzana Muneer", "description": ""}	2026-02-25 16:25:34.413157
ae42c2e6-a3c8-42b8-8a1c-c8778987ebd2	demo-user-001	update	topic	352ec72b-564e-4229-bdba-d351e81b5b6d	{"isPublished": true}	2026-02-25 16:27:36.64224
994d73b3-972a-47cf-ad32-6c907abfb6f5	demo-user-001	update	topic	352ec72b-564e-4229-bdba-d351e81b5b6d	{"isPublished": true}	2026-02-25 16:27:37.647124
c2f076ef-f818-4d23-94a7-9fd80dd42f68	demo-user-001	update	content_block	352ec72b-564e-4229-bdba-d351e81b5b6d	"Batch saved 0 blocks"	2026-02-25 16:28:32.664015
03d327f1-15b1-4bed-bec6-5f4698883b35	demo-user-001	create	content_block	e17d741b-6d58-482e-89ef-afc86c89c8a8	\N	2026-02-25 16:38:46.920357
0ca26ef1-e29d-4ff2-a9d4-a6801af9fd9f	demo-user-001	create	content_block	d3affbc4-2e95-46ec-9b89-2b981c7543bd	\N	2026-02-25 16:39:17.602996
1028cf67-e94a-439a-a5fc-11ad972cd34d	demo-user-001	create	content_block	1c59e44f-6ef1-4094-9bd2-e4d4f9824a11	\N	2026-02-25 16:40:12.837582
714a7f7c-bdb4-4877-8dc7-cc29a469e8ac	demo-user-001	create	content_block	bcc4d550-9423-48f3-bc8e-4b2beff9821d	\N	2026-02-25 16:40:48.829018
59303c1f-1ba6-4010-a5fa-d8a2c013accf	demo-user-001	create	content_block	b71852b3-7750-4141-8c18-c63f4c848119	\N	2026-02-25 16:41:36.952782
05c844ed-1904-4cd6-a167-af112c4ee8ee	demo-user-001	create	content_block	bc7fec72-501e-4550-a5a8-7d18da5c3cff	\N	2026-02-25 16:43:17.88693
23cc20cc-ad4e-4fe6-b741-d75a0b084b8c	demo-user-001	create	content_block	2975156a-dc04-49af-8680-543de0694ebf	\N	2026-02-25 16:43:55.991913
f3a766bb-0d53-46f2-b832-565ad145a8cf	demo-user-001	create	content_block	8aef6a41-fc34-4ac2-8e37-cc99a19fb163	\N	2026-02-25 16:44:50.558723
5b7716f6-904c-44f0-b4ab-b824b244ca6a	demo-user-001	delete	content_block	8aef6a41-fc34-4ac2-8e37-cc99a19fb163	\N	2026-02-25 16:45:27.048629
5d95b1d9-da9a-4c55-93aa-0308a6c00056	demo-user-001	update	content_block	e04b575b-9275-4f85-92e7-eee73c573d90	"Batch saved 8 blocks"	2026-02-25 16:45:32.399415
d7f25521-a15a-4927-9373-685700ef3585	demo-user-001	update	content_block	e04b575b-9275-4f85-92e7-eee73c573d90	"Batch saved 0 blocks"	2026-02-25 16:49:06.714427
a53e9818-0d07-4519-ab03-8646b7e9aacf	demo-user-001	create	content_block	41048c6d-3d82-4fa5-8a07-d07f8269e155	\N	2026-02-25 16:54:48.176906
dd9aa385-3e4b-413c-8acf-e2e05060b574	demo-user-001	update	content_block	f150f3bb-1b2e-4024-9751-2ccdaaf9c5e9	"Batch saved 2 blocks"	2026-02-25 16:55:08.826242
56185801-331e-452b-8ed8-f67cc1255767	demo-user-001	update	content_block	f150f3bb-1b2e-4024-9751-2ccdaaf9c5e9	"Batch saved 0 blocks"	2026-02-25 16:55:40.871371
dc574400-da49-484f-941d-55e2b97390fc	demo-user-001	create	content_block	d38dd14a-05fa-48e5-aa0d-011bcd08d5e8	\N	2026-02-25 16:56:36.310104
7b0d3560-d4aa-4ce6-ad3f-d0c9318d673f	demo-user-001	create	content_block	0065bbbf-e85d-4755-88cb-18c8cabda293	\N	2026-02-25 16:56:59.090176
1bd90980-fbe4-44c1-a513-a25bdd79c3c6	demo-user-001	update	content_block	54b2544a-4bce-41e2-8f2a-e7a29653b139	"Batch saved 3 blocks"	2026-02-25 16:57:07.266955
f2019874-efeb-4da2-9a9a-c3bd6a903f35	demo-user-001	update	content_block	54b2544a-4bce-41e2-8f2a-e7a29653b139	"Batch saved 0 blocks"	2026-02-25 16:57:39.060568
346c78cb-7382-4e98-a53e-de5b0a7c6b25	demo-user-001	update	content_block	f150f3bb-1b2e-4024-9751-2ccdaaf9c5e9	"Batch saved 1 blocks"	2026-02-25 16:59:18.998684
9bd91170-6a22-4c05-8937-d559e47ccc02	demo-user-001	update	content_block	f150f3bb-1b2e-4024-9751-2ccdaaf9c5e9	"Batch saved 1 blocks"	2026-02-25 17:00:40.882679
8edc8e3c-4a51-4d8a-adc1-14df068c042b	demo-user-001	update	content_block	f150f3bb-1b2e-4024-9751-2ccdaaf9c5e9	"Batch saved 0 blocks"	2026-02-25 17:01:04.842838
c7632a49-4b4e-4c84-9c64-fe0681a555da	demo-user-001	update	content_block	54b2544a-4bce-41e2-8f2a-e7a29653b139	"Batch saved 1 blocks"	2026-02-25 17:03:21.444524
32011777-83f5-414f-bd13-d07fb1956f8c	demo-user-001	update	content_block	54b2544a-4bce-41e2-8f2a-e7a29653b139	"Batch saved 0 blocks"	2026-02-25 17:03:43.114414
8cefff33-03a1-486b-92dd-44c7aef36184	demo-user-001	create	content_block	21be90e2-7cfd-4707-b834-b6f3cc897318	\N	2026-02-25 17:04:53.060744
93ec0909-2755-4725-bde5-3f7f6a96951c	demo-user-001	create	content_block	40bb80e8-68be-4c76-a651-2349bdafc5ed	\N	2026-02-25 17:05:20.900741
843e9251-b45b-4a95-8d77-5896ce73100f	demo-user-001	create	content_block	6ad1a2a6-0130-4c3d-84ee-feb3b2aadd4e	\N	2026-02-25 17:07:22.553413
364af536-7564-4355-ac30-9435be67c944	demo-user-001	create	content_block	7811d858-8b9b-43f9-b63d-b477ae52078d	\N	2026-02-25 17:07:41.3868
8dff3aab-3ba5-474f-808a-39c003428dc3	demo-user-001	update	content_block	fc3b87ae-5575-454a-8b2e-927762892b14	"Batch saved 5 blocks"	2026-02-25 17:07:48.88566
6c0fd7da-22b7-49a3-80e2-65e1d4f2a654	demo-user-001	update	content_block	fc3b87ae-5575-454a-8b2e-927762892b14	"Batch saved 1 blocks"	2026-02-25 17:09:27.326262
61565c11-02c5-483b-adcf-2e7da3646c38	demo-user-001	update	content_block	fc3b87ae-5575-454a-8b2e-927762892b14	"Batch saved 0 blocks"	2026-02-25 17:09:34.638835
8ad1b2d1-c50f-4609-a581-6bc4667a3595	demo-user-001	update	content_block	352ec72b-564e-4229-bdba-d351e81b5b6d	"Batch saved 2 blocks"	2026-02-25 17:12:05.261121
32d11ee0-2cca-4810-8ada-ace2e2e5f707	demo-user-001	create	topic	5d2c7a3f-af8b-4425-96d6-74f710a731d1	{"title": "HRT"}	2026-02-25 17:13:37.669008
e2ee43af-3412-4372-a410-a869019c3f97	demo-user-001	create	content_block	efd0a4a0-53ec-4ed9-ada4-f86db7606633	\N	2026-02-25 17:14:26.142566
c2227cbb-2b41-491a-91f0-48afd05acba4	demo-user-001	update	content_block	352ec72b-564e-4229-bdba-d351e81b5b6d	"Batch saved 1 blocks"	2026-02-25 17:14:58.910761
4a311888-f9a2-4210-aa14-8f210f145020	demo-user-001	create	content_block	9c2dc749-1bd0-4816-9b7a-f03e80b785f4	\N	2026-02-25 17:15:44.800979
11a90f27-a2a0-4c1c-8bda-e37a8428b795	demo-user-001	create	content_block	9767d51e-8a1f-43e0-9dc6-ea55ded6bee0	\N	2026-02-25 17:15:57.199127
96b649f2-f478-4127-83e6-72a39c5a10c7	demo-user-001	update	content_block	352ec72b-564e-4229-bdba-d351e81b5b6d	"Batch saved 1 blocks"	2026-02-25 17:16:49.773837
20530828-b5a0-4db3-bc75-3ffb54de6e5c	demo-user-001	create	content_block	f41df123-7796-4f96-b935-2d495d24f165	\N	2026-02-25 17:17:38.512273
80e79425-0d0f-4b9d-9efd-eb52f900b4ff	demo-user-001	create	content_block	9075467a-8e98-42a1-a4c2-941a3c39d345	\N	2026-02-25 17:17:51.449947
992b3728-a82e-4bf2-be95-2ba108d6c462	demo-user-001	create	content_block	0901a4ec-8512-4006-9b1a-8756b9d02fca	\N	2026-02-25 17:17:56.375507
64119689-6ec2-4bec-9041-94e26b171dab	demo-user-001	create	content_block	965aba35-e622-43e0-a48f-55e27406c0ac	\N	2026-02-25 17:18:20.48316
14ec5950-fada-416c-a281-f2b21ba895c1	demo-user-001	create	content_block	cf04760c-2687-45b0-97cb-2d45ecf4680a	\N	2026-02-25 17:23:02.222121
61bf1a14-c05b-4c47-aceb-de6db39d1f6c	demo-user-001	create	content_block	1ba5525f-8cf7-4b6f-b5b9-f53de61dbd02	\N	2026-02-25 17:23:19.439568
5875abf7-73cc-4e06-ad16-96db500de769	demo-user-001	create	content_block	d268f8d8-085a-4083-a5b9-3b798eb6e78c	\N	2026-02-25 17:23:25.015742
8cf05a65-66f9-4654-a03b-d1dc4fdf1948	demo-user-001	create	content_block	fe0b3f9e-8ca7-4132-bdb5-cd7b73414085	\N	2026-02-25 17:24:02.420003
524c290f-2017-4466-8b79-699ac3e7e285	demo-user-001	create	content_block	4a852905-e230-4845-aaee-904a818286c6	\N	2026-02-25 17:24:20.492257
9dfcbaff-99fe-420a-aff7-0ba27652d971	demo-user-001	create	content_block	742d19d8-d23b-453a-a4d7-b7eb14850536	\N	2026-02-25 17:24:51.76038
1a499718-7b5e-4b10-8ee7-fe69d4595a2d	demo-user-001	create	content_block	25506d1c-2051-4fab-9b94-a7184a0b8175	\N	2026-02-25 17:24:57.709325
033fcc78-a46b-4fd3-b66f-7de2d30f0ff7	demo-user-001	update	content_block	5d2c7a3f-af8b-4425-96d6-74f710a731d1	"Batch saved 14 blocks"	2026-02-25 17:25:19.697916
c704b5ef-e2e1-4c3e-b2a4-02657b0e4491	demo-user-001	update	content_block	5d2c7a3f-af8b-4425-96d6-74f710a731d1	"Batch saved 0 blocks"	2026-02-25 17:29:42.030149
172c7512-31a7-42f6-bd83-c4e5c443b35f	demo-user-001	create	topic	b8d9bdac-99ac-4832-bc08-3ba2ea3f2d2c	{"title": "HRT AFTER GYNAECOLOGICAL MALIGNANCY"}	2026-02-25 17:30:01.167859
4af68c71-3982-4954-82f1-666f2152a98d	demo-user-001	create	content_block	fc0fd415-7331-4e76-acdb-2ef5bc0d6be1	\N	2026-02-25 17:31:50.753427
974e640a-0a4a-44c6-bf61-969d022454e9	demo-user-001	create	content_block	15494225-6836-4748-be8a-dc21560a67ba	\N	2026-02-25 17:32:27.311114
bc0afab8-d308-41cd-8f4f-36a74e76dcf2	demo-user-001	update	content_block	b8d9bdac-99ac-4832-bc08-3ba2ea3f2d2c	"Batch saved 2 blocks"	2026-02-25 17:32:49.594216
a92af3d5-c435-4303-9c53-91bd3aa8516c	demo-user-001	create	content_block	bb8d327e-f66f-4694-ba43-00cf04d962ba	\N	2026-02-25 18:34:16.641297
f469955f-518c-41f4-8b06-654eab5511ee	demo-user-001	delete	content_block	bb8d327e-f66f-4694-ba43-00cf04d962ba	\N	2026-02-25 18:34:39.138157
fcdeaae0-6cbe-4b5e-90ae-bc419749e35a	demo-user-001	update	content_block	b8d9bdac-99ac-4832-bc08-3ba2ea3f2d2c	"Batch saved 1 blocks"	2026-02-25 18:34:43.56817
7e0d6637-5e91-4e1e-9972-89af341e81ba	demo-user-001	create	topic	96beb37f-a2c2-483b-8744-597610348a9c	{"title": "POST MENOPAUSAL BLEEDING"}	2026-02-25 18:35:02.716194
ad75f43f-12e3-4ded-8278-f33c3a894b4e	demo-user-001	update	topic	5d2c7a3f-af8b-4425-96d6-74f710a731d1	{"isPublished": true}	2026-02-25 18:35:09.104712
21becbc1-2670-4c45-b1f5-9f55d65fcc65	demo-user-001	update	topic	b8d9bdac-99ac-4832-bc08-3ba2ea3f2d2c	{"isPublished": true}	2026-02-25 18:35:10.762578
59b6c86c-c7b8-4b8b-944f-59e1f27ee45a	demo-user-001	create	content_block	0e31d44a-87e6-45f9-b0a8-c8bba13ea2b2	\N	2026-02-25 18:35:21.410176
c92e0c4f-c6cb-4713-8f9f-99ae9bd036ef	demo-user-001	update	content_block	96beb37f-a2c2-483b-8744-597610348a9c	"Batch saved 1 blocks"	2026-02-25 18:36:01.730005
431d07dd-5646-4699-a2c7-e8be2cb51167	demo-user-001	update	content_block	96beb37f-a2c2-483b-8744-597610348a9c	"Batch saved 0 blocks"	2026-02-25 18:36:10.117328
24f4a1e0-87f2-4ce4-854c-208835560c35	demo-user-001	create	topic	40ce2af7-6a31-4996-82ff-09957fd7bf45	{"title": "CHRONIC PELVIC PAIN"}	2026-02-25 18:36:48.658493
3016d211-cbbb-45f9-90e4-939db17bcbb5	demo-user-001	create	content_block	a239b72e-3a5b-499d-9a47-67877e5f39e4	\N	2026-02-25 18:37:00.970465
382e83c5-7975-4cf6-9f2b-bc9190510322	demo-user-001	create	content_block	5348b92c-e668-476d-a387-5af5da12ca81	\N	2026-02-25 18:38:07.967919
2a8b00f1-b259-42f3-9202-83946fd1d0e6	demo-user-001	delete	content_block	5348b92c-e668-476d-a387-5af5da12ca81	\N	2026-02-25 18:39:02.928901
5ee3a85d-2284-473e-b273-e6397634ac3d	demo-user-001	update	content_block	40ce2af7-6a31-4996-82ff-09957fd7bf45	"Batch saved 1 blocks"	2026-02-25 18:39:06.914137
15ba5d80-2fc5-4523-a5cf-ce7c792dc5e5	demo-user-001	update	content_block	40ce2af7-6a31-4996-82ff-09957fd7bf45	"Batch saved 0 blocks"	2026-02-25 18:39:16.487923
292aa59b-b6bf-43bb-8acb-0790f73cde0c	demo-user-001	create	topic	c950088d-86c0-424f-8a79-b5d3cd893d83	{"title": "PMS"}	2026-02-25 18:39:42.375257
67a5d23a-9d3c-49fe-82e5-8ce92c549d5e	demo-user-001	update	topic	96beb37f-a2c2-483b-8744-597610348a9c	{"isPublished": true}	2026-02-25 18:39:48.874164
82c07925-9201-4fcd-a4c7-a4f228a4f1e4	demo-user-001	update	topic	40ce2af7-6a31-4996-82ff-09957fd7bf45	{"isPublished": true}	2026-02-25 18:39:50.196132
fabf0b4c-7f90-4f66-bd0c-91777e50160a	demo-user-001	create	content_block	bef9853d-4966-4eb9-a878-3c8b21627d67	\N	2026-02-25 18:39:58.978985
fa132c44-2cfc-4946-a565-f5efb20c160a	demo-user-001	create	content_block	0985ffee-0d49-40e5-9d40-59a0150aba20	\N	2026-02-25 18:41:16.031839
b1d4fc12-f67d-471e-8b54-482cb5d63eee	demo-user-001	create	content_block	a6be9608-94f8-4fed-b3e6-6ae15c48ecdf	\N	2026-02-25 18:41:57.098262
77b1dc72-a278-4b10-9826-9e82f17525b9	demo-user-001	create	content_block	1bb16cc2-3218-445e-aff2-71ec903f74ec	\N	2026-02-25 18:42:11.609233
021169ea-9536-42f8-a58a-e06feaa59948	demo-user-001	create	content_block	7a163df0-0d7f-4b13-8897-d6a87b1a1eba	\N	2026-02-25 18:42:17.071479
9d3de816-b652-4b28-af28-52d2f7c7c043	demo-user-001	create	content_block	68f15e06-3183-4d21-b041-da9aa4779f9b	\N	2026-02-25 18:43:11.374113
9be8cd62-178c-44a6-be02-04e25999c6c8	demo-user-001	create	content_block	e96f3b76-b245-40dd-862e-615410f3e519	\N	2026-02-25 18:43:17.722477
d4787c4c-df46-4f80-958e-56acb3ec3be2	demo-user-001	create	content_block	5b596158-00f9-4059-81b7-567386e22450	\N	2026-02-25 18:43:35.090689
7d5265e0-c5d5-46a0-b0f7-f5fc6822047d	demo-user-001	create	content_block	6dec36df-97fe-42f2-804c-0e51ccd3c917	\N	2026-02-25 18:43:47.055179
e9bd984a-3d59-4855-9e16-dda37f3ff377	demo-user-001	update	content_block	c950088d-86c0-424f-8a79-b5d3cd893d83	"Batch saved 9 blocks"	2026-02-25 18:44:09.750226
51256af8-3168-4337-a959-881a7b686a60	demo-user-001	update	content_block	c950088d-86c0-424f-8a79-b5d3cd893d83	"Batch saved 0 blocks"	2026-02-25 18:47:50.296192
1f7fcefb-e67e-4813-8d35-57c33e85bef3	demo-user-001	create	topic	ca15a188-5c2f-4740-8b5f-2bb2da33a3d5	{"title": "P AMENORRHEA"}	2026-02-25 18:49:04.539545
75c94fac-828a-4b06-94cb-a58f20436f5c	demo-user-001	update	topic	c950088d-86c0-424f-8a79-b5d3cd893d83	{"isPublished": true}	2026-02-25 18:49:11.007943
551dd6aa-b50d-480e-b75d-c206492eeadf	demo-user-001	create	content_block	2f22b51c-7de7-4a3d-93fd-d87b87da0b74	\N	2026-02-25 18:49:21.263961
b1b08890-ce37-403c-b927-4e70d5e79248	demo-user-001	delete	book	book-obstetrics	{"title": "Obstetrics"}	2026-02-26 17:16:04.354547
16b650d2-ef73-4f95-a30e-6bc115b903d2	demo-user-001	delete	book	book-gynecology	{"title": "Gynecology"}	2026-02-26 17:16:07.303237
15449690-470d-410b-8727-9044591eb955	demo-user-001	delete	book	book-reproductive	{"title": "Reproductive Endocrinology & Infertility"}	2026-02-26 17:16:10.392791
3b206ccf-635c-4dc9-8ba4-71788126f144	demo-user-001	create	book	cc8b3900-dc51-48c0-b974-7abe4dcc9a30	{"title": "General Gynaecology "}	2026-02-26 17:16:47.976677
9df5bc34-cbf2-44d7-8e6f-9287d855d760	demo-user-001	delete	book	a0847e36-d038-4ad6-9c49-6715f20fadff	{"title": "Sub fertility "}	2026-02-26 17:17:16.875511
f4c1e7c4-af79-4308-9476-aa7d4b070d70	demo-user-001	create	book	2e7f623d-f97c-4d77-b7ad-17a71048a9f4	{"title": "Subfertility "}	2026-02-26 17:17:27.260506
7c51ae57-a07b-404a-9db8-ec90efeaa9f1	demo-user-001	create	book	1331473c-c5f3-4015-8feb-ae87d434904c	{"title": "Gynaecologic oncology"}	2026-02-26 17:19:09.738848
1fa73954-c22e-436f-b588-69435c80c28d	demo-user-001	update	book	cc8b3900-dc51-48c0-b974-7abe4dcc9a30	{"title": "General Gynaecology ", "imageUrl": "", "description": ""}	2026-02-26 17:19:19.513592
a72fd2f3-793c-41d7-a281-f3cd85051fa0	demo-user-001	update	book	cc8b3900-dc51-48c0-b974-7abe4dcc9a30	{"isPublished": true}	2026-02-26 17:19:23.982861
b8c01858-63dc-4ed9-b75a-d4f1ec87d6ca	demo-user-001	create	chapter	66245ecd-6a08-44a2-a6d4-b41da2d19795	{"title": "HMB"}	2026-02-26 17:20:01.657632
e6eb85ea-8d17-40d2-94e9-25eee1ea00c9	demo-user-001	create	chapter	36fccc7a-90bf-427c-9091-fc39ce15e714	{"title": "Uterine fibroids"}	2026-02-26 17:20:45.678247
6267871c-26a8-4cba-879e-617c486a90bf	demo-user-001	update	chapter	66245ecd-6a08-44a2-a6d4-b41da2d19795	{"isPublished": true}	2026-02-26 17:20:52.86831
cff1a0b6-2b88-403b-b5b9-76fbbd9e9c8a	demo-user-001	update	chapter	36fccc7a-90bf-427c-9091-fc39ce15e714	{"isPublished": true}	2026-02-26 17:20:53.31149
66d8a22c-f01a-4d1e-b1f9-f52d01d4af63	demo-user-001	create	topic	b3725a7a-0060-492d-ab42-4cb138058249	{"title": "History"}	2026-02-26 17:22:39.614852
8b5733ff-c5fb-4854-9a54-a8b0b5a0684f	demo-user-001	create	topic	81cb566f-733d-4b40-acdf-85e422d30c65	{"title": "Causes"}	2026-02-26 17:23:07.249452
9da565eb-f1d3-4fc6-beb1-88946257bc90	demo-user-001	create	topic	75843afe-cdfa-45b0-bdd6-ebb19df0bb80	{"title": "Investigations"}	2026-02-26 17:24:03.021009
19e4af20-5400-4544-be79-7b64ae07fbb7	demo-user-001	create	topic	ff98e04c-c927-48c3-a970-4872c26931af	{"title": "Management "}	2026-02-26 17:24:19.651805
6e6f893e-dfa3-4094-9701-a81d7601b1a5	demo-user-001	create	topic	72d3df27-90db-4ab9-a784-bc9f80ca0fc4	{"title": "Endometrial ablation "}	2026-02-26 17:25:22.489722
6a2d9626-e592-487d-a190-73090f58c2d5	demo-user-001	update	topic	b3725a7a-0060-492d-ab42-4cb138058249	{"isPublished": true}	2026-02-26 17:26:16.988566
440fe006-eec3-46ef-a9ce-e894105b6595	demo-user-001	update	topic	81cb566f-733d-4b40-acdf-85e422d30c65	{"isPublished": true}	2026-02-26 17:26:17.678469
757e287c-8f20-4ee0-835d-f9b0ea3455fc	demo-user-001	update	topic	75843afe-cdfa-45b0-bdd6-ebb19df0bb80	{"isPublished": true}	2026-02-26 17:26:17.892121
94843311-dee1-485c-80db-124b96196f97	demo-user-001	update	topic	ff98e04c-c927-48c3-a970-4872c26931af	{"isPublished": true}	2026-02-26 17:26:18.39163
8ae94d50-d06d-44e5-9577-25aa09d3a92b	demo-user-001	update	topic	72d3df27-90db-4ab9-a784-bc9f80ca0fc4	{"isPublished": true}	2026-02-26 17:26:18.806858
3a29244d-5128-4b35-b66d-0b0e027ee8d8	demo-user-001	create	content_block	a80cbc3b-106e-4b43-929d-db7de62f58b3	\N	2026-02-26 17:39:09.974155
ffe7aafd-da5c-4862-89be-8796a0d5e86a	demo-user-001	update	content_block	b3725a7a-0060-492d-ab42-4cb138058249	"Batch saved 1 blocks"	2026-02-26 17:39:18.086425
1abce18a-79e1-4c7b-a64d-bdb2f9a46fd0	demo-user-001	create	content_block	bff0ff86-6d93-4aa3-850e-226726e74cac	\N	2026-02-26 17:40:19.006659
21c9ba22-29a0-4337-bf57-4a9963174f02	demo-user-001	update	content_block	81cb566f-733d-4b40-acdf-85e422d30c65	"Batch saved 1 blocks"	2026-02-26 17:42:56.512456
b90b02c1-fa71-48ab-bd2b-c9747909d48a	demo-user-001	update	content_block	81cb566f-733d-4b40-acdf-85e422d30c65	"Batch saved 1 blocks"	2026-02-26 17:43:17.432918
647fa8f1-4749-4378-bf13-9fb041f2f4c0	demo-user-001	update	content_block	81cb566f-733d-4b40-acdf-85e422d30c65	"Batch saved 1 blocks"	2026-02-26 17:44:41.426867
6990df62-a061-4587-8525-3dc391b4b7ad	demo-user-001	update	content_block	81cb566f-733d-4b40-acdf-85e422d30c65	"Batch saved 0 blocks"	2026-02-26 17:45:00.034967
2494cde5-45ec-441f-963b-18517a0c7a2b	demo-user-001	create	content_block	8f601e43-ee77-41fe-8f88-e323ff412e95	\N	2026-02-26 17:45:57.259646
cce1fa97-6578-4f75-806b-c156587a3d55	demo-user-001	delete	content_block	8f601e43-ee77-41fe-8f88-e323ff412e95	\N	2026-02-26 17:46:33.594202
90cd4a49-d762-4b01-bcad-7df6125cec2f	demo-user-001	create	content_block	7391c48d-4d93-4c48-a896-498ac5476aa1	\N	2026-02-26 17:46:40.381276
ab7f6f98-414d-4eff-bdaf-2516dbfaaa2a	demo-user-001	delete	content_block	7391c48d-4d93-4c48-a896-498ac5476aa1	\N	2026-02-26 17:46:51.292735
8bdf43bd-6dba-42ef-bdce-4b40777e363e	demo-user-001	create	content_block	3a4514ae-b1c3-4010-ba77-6cf862fad16e	\N	2026-02-26 17:46:57.056419
371c2c98-4248-48d9-9b10-d848e294467d	demo-user-001	delete	content_block	3a4514ae-b1c3-4010-ba77-6cf862fad16e	\N	2026-02-26 17:47:06.481648
1631732b-0279-4fbe-97de-4d81f272ec3a	demo-user-001	create	content_block	ecd8f05b-7d08-4f5a-96ee-36f3a4e27768	\N	2026-02-26 17:47:12.531098
d0b66fa8-3905-4893-bc19-1f5386e5b3fa	demo-user-001	delete	content_block	ecd8f05b-7d08-4f5a-96ee-36f3a4e27768	\N	2026-02-26 17:47:18.905069
9199b703-cc7a-4579-963d-1c299e7edeeb	demo-user-001	create	content_block	3ff957ec-ec89-43eb-b045-8cc8b815df0a	\N	2026-02-26 17:47:23.496491
9e2f59ae-36dc-4d11-aa29-6622f5a7dca3	demo-user-001	update	content_block	81cb566f-733d-4b40-acdf-85e422d30c65	"Batch saved 1 blocks"	2026-02-26 17:48:23.18885
74c65d93-b597-4427-a57e-adedd1f89649	demo-user-001	update	topic	81cb566f-733d-4b40-acdf-85e422d30c65	{"isPublished": false}	2026-02-26 17:49:09.58462
5c07446e-3591-4951-9766-0db617064bca	demo-user-001	update	topic	81cb566f-733d-4b40-acdf-85e422d30c65	{"isPublished": true}	2026-02-26 17:49:11.195707
7250387e-c065-47e3-bf74-c506946e1951	demo-user-001	update	content_block	81cb566f-733d-4b40-acdf-85e422d30c65	"Batch saved 0 blocks"	2026-02-26 17:49:17.431958
4ee496b3-cb77-4ed9-9e9a-d669d6ef24c9	demo-user-001	delete	content_block	bff0ff86-6d93-4aa3-850e-226726e74cac	\N	2026-02-26 17:51:05.761268
8c8abaa8-51d1-4546-a42c-c57726c00010	demo-user-001	create	content_block	6cb925de-897a-4f2d-87e8-3581aa97921f	\N	2026-02-26 17:51:20.417867
c4ced2ce-0229-490e-a011-4e812c7c1667	demo-user-001	update	content_block	81cb566f-733d-4b40-acdf-85e422d30c65	"Batch saved 2 blocks"	2026-02-26 17:52:05.531519
8fc845ea-714e-4993-9cd9-08e1a0418cd5	demo-user-001	delete	content_block	3ff957ec-ec89-43eb-b045-8cc8b815df0a	\N	2026-02-26 17:52:30.55415
f4fbd07b-953f-43c1-a6eb-ab90df84c873	demo-user-001	create	content_block	2a76e162-c9df-4f1b-b6a9-67b30dd51020	\N	2026-02-26 17:53:28.598247
dd4f8908-46b0-4b42-851c-e58553fae66d	demo-user-001	delete	content_block	2a76e162-c9df-4f1b-b6a9-67b30dd51020	\N	2026-02-26 17:54:04.500505
36132cde-bbe4-455a-8019-1aa375479641	demo-user-001	create	content_block	08fab7df-a59a-42f8-90da-8774c450fb08	\N	2026-02-26 17:54:10.267215
f62c16be-13e8-452c-af87-9abdb89670f2	demo-user-001	create	content_block	a4750b1b-f295-46f9-98ca-179fd1f71eb1	\N	2026-02-26 17:58:41.072305
dacc130f-4148-4dcc-9c79-adadff7e7e23	demo-user-001	delete	content_block	a4750b1b-f295-46f9-98ca-179fd1f71eb1	\N	2026-02-26 17:58:54.411965
5cc2a7f9-3412-4ccc-8845-733275d8e728	demo-user-001	delete	content_block	08fab7df-a59a-42f8-90da-8774c450fb08	\N	2026-02-26 17:58:58.089248
bb53e445-ae69-4091-8e29-4ae3c4a4e795	demo-user-001	create	content_block	2d3989d4-8bc4-49b7-96cf-3d75376500a9	\N	2026-02-26 17:59:03.757743
6058376c-8b4f-4df7-8dfd-93d29eadd95f	demo-user-001	update	content_block	81cb566f-733d-4b40-acdf-85e422d30c65	"Batch saved 1 blocks"	2026-02-26 17:59:29.826823
622cdc47-1663-4936-a5c6-ca3f9db166ac	demo-user-001	delete	content_block	2d3989d4-8bc4-49b7-96cf-3d75376500a9	\N	2026-02-26 18:13:01.214302
6cdf96e6-bc87-438e-96e0-7b1ae50a4ff7	demo-user-001	create	content_block	f0327e07-54fd-4337-a848-6febfe6435f9	\N	2026-02-26 18:13:12.407931
c8c3cab4-a84c-4898-a519-30884a5df5b9	demo-user-001	update	content_block	81cb566f-733d-4b40-acdf-85e422d30c65	"Batch saved 1 blocks"	2026-02-26 18:13:59.596121
a434a582-f269-408d-b753-321f4cd0ffcc	demo-user-001	create	content_block	e7598f43-49e8-4e11-8cfc-033752ce8177	\N	2026-03-01 11:03:53.727241
5a6f9bac-d214-4cca-9405-de66bffb41e2	demo-user-001	delete	content_block	a80cbc3b-106e-4b43-929d-db7de62f58b3	\N	2026-03-01 11:04:17.638197
8df16c6b-5b3f-42f5-8400-fd2b50020416	demo-user-001	create	content_block	d4016b4f-ad0d-45a3-8a7f-97a0501637c9	\N	2026-03-01 11:04:22.717754
e176bc82-4e49-4289-b947-21b35c2ab264	demo-user-001	update	content_block	b3725a7a-0060-492d-ab42-4cb138058249	"Batch saved 2 blocks"	2026-03-01 11:04:53.49428
831bc799-8e3b-471a-8cdd-bee723a59f61	demo-user-001	create	content_block	c66bd1c0-b612-4f79-8cc1-36a2d208b56e	\N	2026-03-01 11:05:55.311391
a73d3abe-8a15-4492-9d6a-2dcd7effbb81	demo-user-001	create	content_block	008dcb10-6afd-4865-87f1-2367531aa09e	\N	2026-03-01 11:05:59.016177
d6ecf5bf-9e99-4a67-9f2c-562499f5e592	demo-user-001	update	content_block	b3725a7a-0060-492d-ab42-4cb138058249	"Batch saved 2 blocks"	2026-03-01 11:06:02.228244
0d88ff6d-2b20-4c6d-9a13-4042d257a960	demo-user-001	update	content_block	b3725a7a-0060-492d-ab42-4cb138058249	"Batch saved 0 blocks"	2026-03-01 11:06:20.721393
8273c933-f9bc-4acd-a6dc-11cc0fe8064c	demo-user-001	create	content_block	5e93052e-eedc-49d5-90b5-3a2396581c9c	\N	2026-03-01 11:07:22.388949
07c49b7c-f535-4408-a30b-db5bc3ba3fe6	demo-user-001	delete	content_block	5e93052e-eedc-49d5-90b5-3a2396581c9c	\N	2026-03-01 11:07:44.635772
f2fccd31-f598-4dda-a42a-3f159f0b5402	demo-user-001	create	content_block	bc581d23-b32a-4d65-9065-d5c46fd9a587	\N	2026-03-01 11:07:52.318221
841f9f5d-0225-4806-bb8e-75a1880010f9	demo-user-001	create	content_block	c0aa94a6-3ff1-4c3b-b767-37e00cd13092	\N	2026-03-01 11:07:59.189824
1862838f-7e8c-48b4-a395-c9160cf42b76	demo-user-001	delete	book	24cb427d-4f9a-4e5a-8349-fe1d37b9454e	{"title": "Rcog guidance "}	2026-03-03 07:13:46.046719
67094e3c-026d-481a-95ed-bac44c97f8d3	demo-user-001	delete	book	78e7ff39-9837-4788-91db-957e798fb9b9	{"title": "Maternal Mind "}	2026-03-03 07:13:48.911081
5da36332-97b4-4b47-9328-cff7c408e6c3	demo-user-001	delete	book	cc8b3900-dc51-48c0-b974-7abe4dcc9a30	{"title": "General Gynaecology "}	2026-03-03 07:13:51.197268
f0615436-6e4d-4344-a3be-9363a9c2fd4c	demo-user-001	delete	book	2e7f623d-f97c-4d77-b7ad-17a71048a9f4	{"title": "Subfertility "}	2026-03-03 07:13:54.239764
3176210e-4959-4608-bfbf-7a4e2962a97a	demo-user-001	delete	book	1331473c-c5f3-4015-8feb-ae87d434904c	{"title": "Gynaecologic oncology"}	2026-03-03 07:13:56.34466
3f05fd90-c92c-4f7c-bc48-89c14b7497d1	demo-user-001	create	book	a886d6e1-9dea-4b5e-b700-f26cdd53f897	{"title": "Gynaecology "}	2026-03-03 07:15:13.704139
10b77079-4e4c-4239-ab8e-f5c92ec70a9d	demo-user-001	create	chapter	dbec251c-b50c-408b-85ca-5a92d99980ed	{"title": "General Gynaecology "}	2026-03-03 07:15:26.832021
22f9fe5d-bb44-4376-a235-f88790555ebc	demo-user-001	create	chapter	b63ab97b-1ade-4083-b1be-be75c5f1ae67	{"title": "Subfertility "}	2026-03-03 07:15:38.357433
0ceda2e6-43ff-4ed2-a38f-05b06b5dac10	demo-user-001	create	chapter	b108a79f-5d9c-4839-9074-3534616914a4	{"title": "Gynaecologic Oncology "}	2026-03-03 07:15:55.478526
30ea4381-5fad-45d2-9b77-f328c0491452	demo-user-001	create	chapter	a326891f-f3d2-4e76-b1ae-5b0064dea77e	{"title": "Urogynaecology "}	2026-03-03 07:16:14.825335
a1b1e6d6-745d-4575-b831-8af8d499be9a	demo-user-001	create	topic	52c2375a-221f-40db-be86-b66990fdd20a	{"title": "HMB"}	2026-03-03 07:16:38.241969
f6f5d299-e495-4db3-a460-d6c315f41a90	demo-user-001	create	content_block	005e00ad-59cb-4079-a86a-2ec518d5709b	\N	2026-03-03 07:17:25.987413
b9cf95aa-9b42-4b4d-bede-f3e8e382ee57	demo-user-001	delete	content_block	005e00ad-59cb-4079-a86a-2ec518d5709b	\N	2026-03-03 07:18:34.432289
14e026a6-535a-4d5e-8089-b7488cbc52b4	demo-user-001	create	content_block	18785a66-959c-465b-b728-f74c2a2f89db	\N	2026-03-03 07:18:37.900559
657d2ac4-3bd4-4740-a8ec-606565163ddb	demo-user-001	update	content_block	52c2375a-221f-40db-be86-b66990fdd20a	"Batch saved 1 blocks"	2026-03-03 07:18:42.920545
b915a415-398d-49af-98b4-eefa332e21c3	demo-user-001	create	content_block	e1a8efc5-874b-4be2-9db3-2653f547d0cc	\N	2026-03-03 07:18:54.115764
01ca01bb-f5fc-4f49-abbd-62148c897541	demo-user-001	update	content_block	52c2375a-221f-40db-be86-b66990fdd20a	"Batch saved 1 blocks"	2026-03-03 07:19:28.173347
93947ad7-c5d8-4fb0-993c-b77a064f0ebb	demo-user-001	create	content_block	820c7f95-40fa-47a0-a3f8-a9da36d3ac0e	\N	2026-03-03 07:19:36.042286
90581b00-1b15-42df-811d-e130cfa6043f	demo-user-001	create	content_block	7d44976a-73ac-49af-a5ee-59d330819b8f	\N	2026-03-03 07:19:41.06134
b0830de6-657b-412a-a099-14e1c079f550	demo-user-001	update	content_block	52c2375a-221f-40db-be86-b66990fdd20a	"Batch saved 2 blocks"	2026-03-03 07:19:53.35934
38601cd4-8877-426f-81c8-7db7cae8d0dd	demo-user-001	update	book	a886d6e1-9dea-4b5e-b700-f26cdd53f897	{"isPublished": true}	2026-03-03 07:20:21.156892
80e25f24-2ea1-4aea-8aa3-0226682b10a1	demo-user-001	update	chapter	dbec251c-b50c-408b-85ca-5a92d99980ed	{"isPublished": true}	2026-03-03 07:20:35.710464
011e8c1b-942f-4bc3-a24b-314a2302f14f	demo-user-001	update	chapter	b63ab97b-1ade-4083-b1be-be75c5f1ae67	{"isPublished": true}	2026-03-03 07:20:36.238567
74f1ecbe-614a-4b9a-9afa-6a33f8c0cb70	demo-user-001	update	chapter	b108a79f-5d9c-4839-9074-3534616914a4	{"isPublished": true}	2026-03-03 07:20:36.740222
ca6f3c3d-8fc3-4824-9b5c-b51b7776ebf4	demo-user-001	update	chapter	a326891f-f3d2-4e76-b1ae-5b0064dea77e	{"isPublished": true}	2026-03-03 07:20:37.162111
cfcd6711-455a-4b62-9dd8-521b0db108d9	demo-user-001	update	topic	52c2375a-221f-40db-be86-b66990fdd20a	{"isPublished": true}	2026-03-03 07:20:41.67328
e4241a17-bf42-4905-8c63-6c487fcd1a8b	demo-user-001	update	content_block	52c2375a-221f-40db-be86-b66990fdd20a	"Batch saved 1 blocks"	2026-03-03 07:21:45.812744
bc730c9b-6c46-48a8-b048-c9594fe5382e	demo-user-001	create	content_block	3d1cc662-d8fb-4415-9dfe-718761f7ef87	\N	2026-03-03 07:22:33.504702
eb45384f-1221-4800-b1b5-8346afb1b81e	demo-user-001	create	content_block	272a1b65-0039-4280-a21b-ee4059c15130	\N	2026-03-03 07:22:47.051481
1ac06fb8-b6d4-4c97-8c2a-b185d4756c1f	demo-user-001	update	content_block	52c2375a-221f-40db-be86-b66990fdd20a	"Batch saved 2 blocks"	2026-03-03 07:22:57.353432
21eb493a-19a4-4dce-a09f-f63c1bc97d5f	demo-user-001	create	content_block	fa3ad4c4-d412-4275-bfea-58d00accc12e	\N	2026-03-03 07:23:45.632358
16df5777-ed7f-44c4-9252-990321a4d457	demo-user-001	create	content_block	63b2fd82-3167-4cb4-a60b-8ef60dcae593	\N	2026-03-03 07:26:40.036946
5f6d6150-493c-4185-b147-8615f71986a6	demo-user-001	update	content_block	52c2375a-221f-40db-be86-b66990fdd20a	"Batch saved 2 blocks"	2026-03-03 07:28:38.170126
600604eb-4506-4c00-90db-60567c3ea7c9	demo-user-001	update	topic	52c2375a-221f-40db-be86-b66990fdd20a	{"isPublished": false}	2026-03-03 07:28:41.613958
be37fc7d-5a1d-4f19-8867-f6cfffa3d389	demo-user-001	update	topic	52c2375a-221f-40db-be86-b66990fdd20a	{"isPublished": true}	2026-03-03 07:28:45.088985
3cc86c07-9f3c-4b79-99e9-d10b4f2dafbf	demo-user-001	delete	content_block	e1a8efc5-874b-4be2-9db3-2653f547d0cc	\N	2026-03-04 09:04:47.573081
552aee10-e25c-4fa7-b2ea-41f2e4d583e8	demo-user-001	create	content_block	d4f7f1df-a28a-40d3-987a-d0a09ff52f4c	\N	2026-03-04 09:04:53.480455
b516988f-5b4c-43a7-9468-a788bb1f58be	demo-user-001	create	content_block	28a1614a-f011-4b02-957a-ec1e5a9e0730	\N	2026-03-04 09:04:53.728452
f0da64d7-43ef-490c-9633-86bbdddf7733	demo-user-001	delete	content_block	7d44976a-73ac-49af-a5ee-59d330819b8f	\N	2026-03-04 09:05:44.942134
68ab7aa0-b833-4c02-8ea8-6a1f3c6cb37f	demo-user-001	delete	content_block	fa3ad4c4-d412-4275-bfea-58d00accc12e	\N	2026-03-04 09:06:40.821813
33c4a66f-444d-40c8-810e-64b468300137	demo-user-001	delete	content_block	63b2fd82-3167-4cb4-a60b-8ef60dcae593	\N	2026-03-04 09:06:45.18418
9b1aa333-b236-44c1-b492-7e0641681f38	demo-user-001	delete	content_block	272a1b65-0039-4280-a21b-ee4059c15130	\N	2026-03-04 09:07:34.15303
d2685dd8-ea7e-452d-8c21-2f28dc205e7f	demo-user-001	create	content_block	73277894-4dbb-4c62-a49d-2751d8aeff0d	\N	2026-03-04 09:07:46.217598
d3cb590c-616c-432f-bb68-6a8cd92e8fd8	demo-user-001	update	content_block	52c2375a-221f-40db-be86-b66990fdd20a	"Batch saved 4 blocks"	2026-03-04 09:08:06.464645
4344ff3b-99a0-418a-b701-35130f2c5632	demo-user-001	create	content_block	74d00924-6c80-49f5-956f-513230190bc6	\N	2026-03-04 09:08:55.934209
0354cf2d-0255-4b60-a01f-e973c16d27e8	demo-user-001	create	content_block	3f17ec96-e090-4f2e-a880-47b92e056014	\N	2026-03-04 09:09:17.262105
dd880506-b7d1-4a20-ae37-0a097f342905	demo-user-001	create	content_block	8e818846-354e-4707-8995-57f9199d738f	\N	2026-03-04 09:09:46.985656
f4a95f54-c626-4825-ab6f-36d4298f8812	demo-user-001	create	content_block	92f6c4de-49d0-4179-899e-ccdde311039d	\N	2026-03-04 09:10:10.252374
507c6ebf-c133-4979-aa2e-9a9d632d8cb5	demo-user-001	create	content_block	adb31983-e85b-45bc-b930-93cf1e57ff85	\N	2026-03-04 09:10:37.298907
e15a9c87-2e09-4818-8f9e-3ab321018be7	demo-user-001	create	content_block	ae506800-4c11-4af5-a3d2-922d3cb5d5d5	\N	2026-03-04 09:11:03.297083
783cec74-4368-4d1d-a8e9-2a227b2dd511	demo-user-001	create	content_block	b4fc6bbe-41bc-4546-b928-6418a2ec2515	\N	2026-03-04 09:12:36.355692
fefb5294-3456-4883-b299-1bded952276f	demo-user-001	create	content_block	cdf83ad7-f9fe-45fe-9821-d4862204536b	\N	2026-03-04 09:12:52.202955
8cc6b5bc-11fa-4f16-a247-3a70d2d8da3a	demo-user-001	delete	content_block	cdf83ad7-f9fe-45fe-9821-d4862204536b	\N	2026-03-04 09:12:57.608306
6cfb0859-89d7-4ff8-a276-31bbc93f2735	demo-user-001	create	content_block	07bbf79e-fa83-4559-9f55-6e7e884b7b9a	\N	2026-03-04 09:13:02.459709
aed58830-6241-4047-bea8-2b3152844ef6	demo-user-001	create	content_block	d797de8e-7806-4391-a458-ca2031c1361a	\N	2026-03-04 09:13:28.142765
22f1f688-5ef2-4332-b84b-822f678ef2fa	demo-user-001	create	content_block	e8d4d0da-c22b-464b-917f-04ea82eb2a22	\N	2026-03-04 09:13:53.822284
24d05c93-854e-4a3c-a3b7-aaf5aa315b48	demo-user-001	update	content_block	52c2375a-221f-40db-be86-b66990fdd20a	"Batch saved 10 blocks"	2026-03-04 09:14:53.946481
ec3d5fa2-186d-4c13-bff6-8d6ce016eb1a	demo-user-001	create	content_block	6917da74-c66b-46ad-8e16-2350378dbc88	\N	2026-03-04 09:15:20.963063
86c803c4-5ceb-4d15-9318-c04c70e8e101	demo-user-001	create	content_block	42b9383a-860b-4fc5-949b-7078f934b73e	\N	2026-03-04 09:15:31.767079
bcdde167-380b-4d23-93f5-ce2a4e14abfd	demo-user-001	create	content_block	f024e1b1-6459-49f5-adeb-218519660d18	\N	2026-03-04 09:16:11.503267
f920026d-1155-468a-990e-d339c7ffbcca	demo-user-001	create	content_block	8d4ec55f-38b1-4077-8869-b7aa2c52c0f2	\N	2026-03-04 09:16:28.550936
8319af95-d796-4581-b918-1eb10a08123c	demo-user-001	create	content_block	5a7f806f-4034-41ae-a95f-8177346d2bef	\N	2026-03-04 09:16:49.596165
a0ef8893-1c99-46b1-be0d-5bd84ea84618	demo-user-001	create	content_block	0528a659-e2ba-4513-9f56-45e31db4e8ea	\N	2026-03-04 09:17:10.779822
8f30572d-7806-4776-a077-78b1b75e2a23	demo-user-001	create	content_block	06cf644e-1a9e-4e89-8afd-3681ca624b02	\N	2026-03-04 09:17:37.315811
8ad951d1-b8cd-4206-8161-6d14518f7d8b	demo-user-001	delete	content_block	06cf644e-1a9e-4e89-8afd-3681ca624b02	\N	2026-03-04 09:18:04.018408
32b3edb4-c9f2-43f6-8f2b-f125f3dba69f	demo-user-001	create	content_block	bc63bd16-9a3e-48c0-8e4b-a6894b1f1c5d	\N	2026-03-04 09:18:09.761706
93efa7d5-4505-4887-b0e4-685a6d220b5d	demo-user-001	create	content_block	2d85c2e7-88dd-4be4-9ef4-bd3ddd1a142d	\N	2026-03-04 09:18:47.03809
e05d4817-9c85-4557-b5af-d525ae1fa0bd	demo-user-001	create	content_block	231409e1-2294-4d17-9e26-5a3e5109cea7	\N	2026-03-04 09:19:24.622459
4e451b5c-5297-4858-8cb7-cbedbf05317e	demo-user-001	create	content_block	f3150b58-b511-44bd-b066-22ef4e869c39	\N	2026-03-04 09:19:59.109478
bb3c0f19-56f0-4319-9994-8b99c9c0c762	demo-user-001	create	content_block	84a25df4-1a70-4341-96e2-001882d554d9	\N	2026-03-04 09:20:15.699635
cb394043-da97-44db-87e2-09d98ed88340	demo-user-001	create	content_block	987f9a1a-0095-4c3e-b215-43162b4def1a	\N	2026-03-04 09:20:44.711661
61a9e326-71a0-4325-bec5-22e7b70d3246	demo-user-001	create	content_block	fa97639c-6b10-43ba-b23f-2c86e62d0af8	\N	2026-03-04 09:20:57.721729
4382dc19-b260-40b5-948d-e8c77b68c1b1	demo-user-001	create	content_block	50c4324c-8a62-4105-8d94-1b5a33a684e8	\N	2026-03-04 09:21:34.007947
92039836-dae1-43e3-aa5e-79400b745f02	demo-user-001	create	content_block	04cf0d53-a941-495e-922a-3be4a240a650	\N	2026-03-04 09:21:51.874374
6f909e4c-66ec-4d31-aa35-a3c6ece8b579	demo-user-001	create	content_block	eedccb5b-faf3-4c30-bee2-b3be611e6399	\N	2026-03-04 09:22:35.828002
3e9ffae4-b37f-4f37-bf32-27f5f3818ae8	demo-user-001	create	content_block	678da756-00be-4dc9-99cc-65d19e110ffc	\N	2026-03-04 09:23:12.574017
2c4b4336-86ee-4ac7-ac33-11856040ce23	demo-user-001	update	content_block	52c2375a-221f-40db-be86-b66990fdd20a	"Batch saved 17 blocks"	2026-03-04 09:23:46.66671
d9a0e094-7a20-4237-8daf-ea338a8c75fe	demo-user-001	update	content_block	52c2375a-221f-40db-be86-b66990fdd20a	"Batch saved 0 blocks"	2026-03-04 09:24:14.532131
1239ee0a-8e56-46c5-9282-8600cbc0062f	demo-user-001	update	content_block	52c2375a-221f-40db-be86-b66990fdd20a	"Batch saved 0 blocks"	2026-03-04 09:25:30.53682
af671126-aa22-4715-99db-e775d3f9bbec	demo-user-001	update	content_block	52c2375a-221f-40db-be86-b66990fdd20a	"Batch saved 0 blocks"	2026-03-04 09:25:42.125562
ecceb0db-0f6e-4ce3-9530-58e9770167d9	demo-user-001	create	topic	c7578a7b-6acb-48bb-a9f7-9c54c8f23e20	{"title": "UTERINE FIBROIDS"}	2026-03-04 09:26:12.535926
81ac8b9b-9cbf-4b85-b55c-15445a28f744	demo-user-001	create	content_block	4cb4a81e-8e9d-4547-ba97-12ff377d0070	\N	2026-03-04 09:26:25.555833
e85f8c19-cccf-4255-8460-0cf23b47def1	demo-user-001	create	content_block	068a48df-03bc-4434-b081-ad8c917a91a6	\N	2026-03-04 09:27:16.700526
8d4aef21-0761-40d4-aafa-f8511a702be4	demo-user-001	create	content_block	0fed16c9-5c80-4966-af55-22124372bfff	\N	2026-03-04 09:27:34.35817
ae3f3cda-1d3a-4617-8568-1f64d94ef83f	demo-user-001	create	content_block	a6d3c567-725c-4c2b-8a69-e237a02b83ba	\N	2026-03-04 09:27:53.326981
7a5c76e5-aba5-4137-9726-563db13f4063	demo-user-001	create	content_block	a0ddea9a-3df1-44de-b62c-3ebcd4290fb3	\N	2026-03-04 09:28:11.781082
a20f04c3-2d9c-460e-8deb-3d44be04c835	demo-user-001	create	content_block	3811e05d-a90a-4b22-8ac4-c54462d1f96c	\N	2026-03-04 09:28:55.856478
895ac185-6c1c-4262-8b1a-74ec37275eeb	demo-user-001	create	content_block	360c3167-a1f6-499d-88ac-32d2b68c07df	\N	2026-03-04 09:29:13.551501
4e9b61dc-ba1a-445f-98ef-ffbb0c9ed4ed	demo-user-001	create	content_block	d33b849d-8559-4b95-a06f-2affdfa2459a	\N	2026-03-04 09:29:36.330638
b91ea453-10d1-4e6a-9b1e-b6fff7c6f21c	demo-user-001	create	content_block	f516862b-90aa-48ea-8558-895a15eac699	\N	2026-03-04 09:29:51.254901
dc17dc95-fdc6-43bf-b3c9-ea9d94a58d8e	demo-user-001	create	content_block	6d08cc0e-f624-4ee3-8b57-f2581cc6f0f7	\N	2026-03-04 09:30:39.586304
b0d148aa-76dd-49c0-a19f-bbcb72f4338d	demo-user-001	create	content_block	f7b81b4c-3662-4ebb-a6ea-cb0096afa234	\N	2026-03-04 09:31:10.130274
d8d2c80c-48b6-49ec-bda7-4b66b17bb22b	demo-user-001	create	content_block	2c6c1261-f032-49e6-93b1-19c019a74ba3	\N	2026-03-04 09:31:28.600839
c3b4693c-13f9-40e7-9eef-e0e1441ae099	demo-user-001	create	content_block	3aaf73c7-d3bc-425e-bb62-5aff7157a6af	\N	2026-03-04 09:31:49.753037
f48b28e6-af79-4a33-8936-023a147cae6c	demo-user-001	create	content_block	80d83803-32c0-4e08-be8d-ccf229e044e7	\N	2026-03-04 09:33:30.858346
1b959464-aa46-4aa7-8ddf-5f040dac9b79	demo-user-001	create	content_block	c5dbbcf0-6ca0-470b-bb00-bb5423a009b5	\N	2026-03-04 09:33:51.898242
7c84081a-b8c2-472a-bc9d-fbe7cfd0b7dc	demo-user-001	create	content_block	cc34f2f9-bd1f-4bc0-bb8d-ad4f4c2370c7	\N	2026-03-04 09:34:29.259647
d7c821fc-675f-4ee5-a884-4d21c1f2a088	demo-user-001	create	content_block	d79dab61-7975-428f-8dde-55de48a43de1	\N	2026-03-04 09:34:48.238998
5322006c-6ec6-4608-a1f6-18551d67f0ee	demo-user-001	update	content_block	c7578a7b-6acb-48bb-a9f7-9c54c8f23e20	"Batch saved 17 blocks"	2026-03-04 09:34:57.946326
2041f8b6-0647-4671-be54-c4d57efaa746	demo-user-001	update	content_block	c7578a7b-6acb-48bb-a9f7-9c54c8f23e20	"Batch saved 0 blocks"	2026-03-04 09:38:41.615188
e67869d1-1769-4582-a00d-258155e10bf8	demo-user-001	create	content_block	6db06b70-028b-4af3-bc20-71aebeb13e9f	\N	2026-03-04 09:38:54.493698
bfc4e2a9-5b96-4a08-b765-c3683dcd0f20	demo-user-001	delete	content_block	6db06b70-028b-4af3-bc20-71aebeb13e9f	\N	2026-03-04 09:39:47.379656
33ca5cdd-451a-4a09-b4e2-72ee06828d72	demo-user-001	update	content_block	c7578a7b-6acb-48bb-a9f7-9c54c8f23e20	"Batch saved 1 blocks"	2026-03-04 09:39:52.946692
78f32427-b617-42bd-8c7a-99d828b11905	demo-user-001	update	topic	c7578a7b-6acb-48bb-a9f7-9c54c8f23e20	{"isPublished": true}	2026-03-04 09:40:01.008164
b6bd113e-cea5-46e5-b9e0-356f00d93f18	demo-user-001	create	topic	025e984c-0ed5-46c5-8825-99318063c146	{"title": "UTERINE ARTERY EMBOLIZATION"}	2026-03-04 09:40:27.020112
b8924a15-e3e4-4231-a07c-eb7a3ef01c3a	demo-user-001	create	content_block	27dbebfa-ddd5-4c37-acba-d391d90622bb	\N	2026-03-04 09:40:31.63894
7bef4334-67e3-4fcb-adc5-e087465c5470	demo-user-001	create	content_block	48f95981-0e03-4edf-a434-786f04133f2d	\N	2026-03-04 09:40:48.989769
91d2eb92-c37e-4e0b-8c58-ae1dd7a23655	demo-user-001	create	content_block	b223f485-59a4-4d7f-9f5a-06d2b8062011	\N	2026-03-04 09:41:05.457154
c7c799d8-f4b1-4519-bd5c-6d9256ae9424	demo-user-001	create	content_block	a54f1838-7f72-4a38-acc5-52a07de0e9de	\N	2026-03-04 09:42:04.724515
4ed7a14c-e85e-4f02-958e-b660044a4708	demo-user-001	create	content_block	862cf99f-657d-41f7-ac52-fd9f9e2df2e1	\N	2026-03-04 09:42:27.336272
4fa2025a-0ee0-47b0-a980-a854fbaf0c84	demo-user-001	create	content_block	890f99ad-850d-45bc-8040-008f212df000	\N	2026-03-04 09:42:47.022805
dcdc1a80-bccf-4be3-ac97-71201864612a	demo-user-001	create	content_block	d30dd2c5-27ed-4fcd-b1de-167a52e6aa10	\N	2026-03-04 09:43:04.654662
11aa71c8-9e22-4eb8-9836-b2bf0e2c2adf	demo-user-001	create	content_block	cf9a5338-3ad9-45ae-966d-e9228393d2e9	\N	2026-03-04 09:43:22.042042
ffefea0e-6c34-490d-8320-41533ce108a4	demo-user-001	create	content_block	480d5f55-6bad-493c-b982-6be7968277d5	\N	2026-03-04 09:43:34.978421
8f32e712-c96d-4513-8b41-38d5b86c2d98	demo-user-001	create	content_block	cb5eea98-3361-42fa-9cdc-1541b37f2126	\N	2026-03-04 09:44:07.551207
265db00d-1cab-4e88-aefb-589e8d7daf1b	demo-user-001	create	content_block	3164108c-4ad1-4c35-9263-841e9ed8696e	\N	2026-03-04 09:44:23.413811
1d7c2301-2e62-4e99-87af-61d39dbbb1c8	demo-user-001	create	content_block	448543e2-2c59-484a-ac51-f770e0fe31cd	\N	2026-03-04 09:44:43.779082
6ba8e722-7685-47d9-80f6-eb09c4509b5b	demo-user-001	create	content_block	6618238b-938e-4b47-948c-e4ac4d7e9059	\N	2026-03-04 09:45:26.731863
55fc237f-2713-41af-99ad-6be90b01fc2b	demo-user-001	create	content_block	c857e5b9-bdad-4a97-a3ac-c59306133854	\N	2026-03-04 09:45:45.63193
277622a5-28ec-48df-99fa-ffc83dfde8df	demo-user-001	create	content_block	6b084229-ac60-4aa7-a82b-847a094ee56d	\N	2026-03-04 09:46:16.011342
5cf66e3d-17d5-4771-9ff6-9ce872f0c290	demo-user-001	update	content_block	025e984c-0ed5-46c5-8825-99318063c146	"Batch saved 15 blocks"	2026-03-04 09:46:35.538965
1a7ddb77-4a4d-47d1-a25c-1f289e9ad84d	demo-user-001	create	content_block	5c69bd48-ffa5-4118-8e7c-267ca25d6d74	\N	2026-03-04 09:48:02.11925
e2d01a89-7ceb-4cfc-8b7b-d7ee5369e0da	demo-user-001	create	content_block	f5264874-29ee-432a-bf29-b28949c2bd63	\N	2026-03-04 09:48:57.188416
05aa6d02-52a5-4709-b61e-359779329fee	demo-user-001	create	content_block	330eb45c-912d-4e16-bbd0-3acfed4330ab	\N	2026-03-04 09:49:18.350656
8a422561-bd4e-4a0f-9549-26b9090c6e12	demo-user-001	create	content_block	473faf45-d5f4-49d8-a907-349cdb863538	\N	2026-03-04 09:49:38.456794
bebee862-0fca-4860-ab47-01a0599ca06a	demo-user-001	create	content_block	d3cc8580-db39-41ce-8c1c-e8f4b3950785	\N	2026-03-04 09:50:05.86137
572b612e-22fa-495c-aa83-2c9191be026c	demo-user-001	update	content_block	025e984c-0ed5-46c5-8825-99318063c146	"Batch saved 6 blocks"	2026-03-04 09:50:43.013079
ddf4c52c-0821-4e65-a28e-16b2bec239ee	demo-user-001	update	content_block	025e984c-0ed5-46c5-8825-99318063c146	"Batch saved 0 blocks"	2026-03-04 09:51:08.303447
bface5ac-84e0-41cd-8db4-1de309927deb	demo-user-001	update	topic	025e984c-0ed5-46c5-8825-99318063c146	{"isPublished": true}	2026-03-04 09:51:15.51026
df3a740c-3a49-409b-8a05-8bd565669c1c	demo-user-001	create	topic	de882ed5-4ae9-43a0-b80d-d51aae5f6a97	{"title": "SURGICAL TREATMENT OF FIBROID"}	2026-03-04 09:51:22.9812
713afeb2-193d-4322-8548-45a7d009f1be	demo-user-001	create	content_block	78dc4f56-354a-4ea1-9008-d4e8d240f4b0	\N	2026-03-04 09:51:39.223236
504a6e73-ac6d-49ff-bc39-2d07a4cab4dc	demo-user-001	create	content_block	420bf138-49a5-4897-b7af-be81b040e8fc	\N	2026-03-04 09:51:57.253973
d070577d-2332-47a0-919c-c92a7846602c	demo-user-001	create	content_block	a6d73bcf-09cd-419f-918a-9410544de7a8	\N	2026-03-04 09:52:14.115863
55e10f0a-d314-403a-a69b-07417e50fb91	demo-user-001	create	content_block	db674ad9-937d-4535-9058-799b19c14f19	\N	2026-03-04 09:52:37.427497
e3d9ea13-c575-42e0-a4bb-5814ddfb5151	demo-user-001	create	content_block	6f498fe2-943e-4864-aeb3-db648148fb7f	\N	2026-03-04 09:53:10.634421
12314eef-23cf-4e30-b996-82cecec1b4d7	demo-user-001	create	content_block	8030e461-1f18-4db7-a35c-c0ccce87f5b7	\N	2026-03-04 09:53:28.243458
5c1c8182-c623-474b-8fae-a807de013bf0	demo-user-001	create	content_block	83366d4d-d40f-435b-a790-a59612ed47fb	\N	2026-03-04 09:53:56.261282
a3c1f846-8532-4362-8a9b-3284a7e22c6f	demo-user-001	create	content_block	be40d2b4-5fd5-4252-956d-3c06d4b9ee8e	\N	2026-03-04 09:54:14.41506
59fa4d93-badd-43ab-ab32-9601909fa42f	demo-user-001	create	content_block	e69d877c-e8d6-4f9e-8202-0107ca23b651	\N	2026-03-04 09:54:30.33805
4ac53622-b14f-4fae-b386-24614ee34ae5	demo-user-001	create	content_block	b42f924d-2ab0-41e3-9fab-2fd8bae367b7	\N	2026-03-04 09:54:43.121707
352e9c83-572e-4f9a-b385-dfc36dd86242	demo-user-001	create	content_block	130d3ce3-9c4a-4975-b7ce-b0bfcb8b6602	\N	2026-03-04 09:54:56.110926
27726d2b-e136-4485-ac72-af6a605da1f2	demo-user-001	create	content_block	130d83ac-75ee-4016-bfd4-84b83d8c466f	\N	2026-03-04 09:55:22.746066
1c869ffe-6843-42da-be7f-aba5621aad0b	demo-user-001	create	content_block	83e65ac8-e43b-4692-8b5d-c0518fb5d9b6	\N	2026-03-04 09:55:41.736383
c2b68470-33d5-4f6b-8e60-16845be2eaa5	demo-user-001	create	content_block	ab82b61a-595f-47ba-a3ab-9b0ad5c804a7	\N	2026-03-04 09:56:01.435942
7cf497a3-fd4b-48c6-9f14-b60ae90e0a61	demo-user-001	create	content_block	20fb0aab-e629-43dd-8848-14fa56de82e3	\N	2026-03-04 09:56:17.454263
3300fff8-f0b0-4400-ae78-74658de09b76	demo-user-001	create	content_block	fae8400b-81db-4b5b-acbb-b8c6094222fa	\N	2026-03-04 09:56:58.478302
20bbc32d-012b-4a82-af07-cc726f33873c	demo-user-001	create	content_block	d8b43509-62cc-44d6-9f28-48badc69d49f	\N	2026-03-04 09:57:11.941149
6fc06c4e-b80f-443c-9a1a-2f85488d4dab	demo-user-001	delete	content_block	d8b43509-62cc-44d6-9f28-48badc69d49f	\N	2026-03-04 09:57:19.642498
55842f4a-fe77-462c-ac81-21b179e7d9ef	demo-user-001	create	content_block	25c262cc-1e1e-4ae1-808e-b83e948e520d	\N	2026-03-04 09:57:31.962774
3b1fe0c5-e5e3-48ab-99b6-1178b6999e7e	demo-user-001	create	content_block	061c5adb-05a7-4afe-88d0-aea5bc412cda	\N	2026-03-04 09:57:47.413501
ecbac6ae-0d70-42f3-97b5-5e53695ca34e	demo-user-001	create	content_block	c85faa29-3d62-43ec-85de-28de7a65c291	\N	2026-03-04 09:58:01.249529
9a11b339-b55b-4f2c-ae30-a27e7f6b396f	demo-user-001	create	content_block	564e4d70-d84f-47fa-b5a9-17995904f90a	\N	2026-03-04 09:59:30.532215
62e7e7fa-1480-4d4f-8739-d82eb87554c1	demo-user-001	create	content_block	d9f49bcd-ce9d-41f9-83dc-3161446538ff	\N	2026-03-04 09:59:46.509489
f90e7037-5010-40c7-ad3d-2721b495da7b	demo-user-001	create	content_block	5ad639af-967e-4e86-8df3-e8d114427b7e	\N	2026-03-04 10:00:09.268126
20d1b5c8-9259-47df-8953-894c824767ed	demo-user-001	create	content_block	0b697f1c-0feb-4774-b7a1-8ec355ee8f50	\N	2026-03-04 10:00:35.607443
ee481583-9dd0-430d-830e-c99ba23bf289	demo-user-001	create	content_block	ab9112b7-3f6e-487b-b087-15381f883281	\N	2026-03-04 10:00:53.586411
04b9eb9d-0ee8-4bc8-9e52-9f09398e5fc9	demo-user-001	update	content_block	de882ed5-4ae9-43a0-b80d-d51aae5f6a97	"Batch saved 24 blocks"	2026-03-04 10:01:16.441059
c22d473a-6c18-4832-a091-1a68fcd0a2b6	demo-user-001	create	content_block	be276563-9a59-4dda-bc78-f2c7d2f071f7	\N	2026-03-04 10:01:23.250693
a88c74f1-0c1a-4454-9cb6-2a84cd1fcd98	demo-user-001	create	content_block	fc52c5c5-f9ae-4010-a6a3-b50be1c347eb	\N	2026-03-04 10:02:48.973074
5180c316-105f-4f80-ba29-e264b56faf5e	demo-user-001	create	content_block	41ff42e5-9bdb-41f4-a33b-03060ec5075c	\N	2026-03-04 10:03:40.720369
75632e03-7c63-4033-91b9-a395d188aaa9	demo-user-001	delete	content_block	41ff42e5-9bdb-41f4-a33b-03060ec5075c	\N	2026-03-04 10:03:47.547357
ea4c8077-197f-4d45-9a6c-0dada37d2eff	demo-user-001	create	content_block	489a45bd-49bd-4a70-b9a8-5ac1d61bfe6d	\N	2026-03-04 10:03:53.268486
cb25c863-3b18-49b0-a340-a61bb1c527e6	demo-user-001	create	content_block	dfcc4222-6ab4-4419-966b-b592a1e3ef40	\N	2026-03-04 10:04:10.598307
4376c2f1-2dbe-4f59-afa1-24735b3279dd	demo-user-001	create	content_block	1982adf6-0d55-4044-872f-a0b8da1b5604	\N	2026-03-04 10:04:37.50592
30685fd7-6d58-4920-a71c-a59b6d7db1c5	demo-user-001	create	content_block	ded1f202-fcd6-4471-9765-de9706a1b142	\N	2026-03-04 10:05:08.087102
65587f93-1471-452e-b237-0fb7c68fb326	demo-user-001	update	content_block	de882ed5-4ae9-43a0-b80d-d51aae5f6a97	"Batch saved 6 blocks"	2026-03-04 10:05:44.283582
53452efe-86ab-40b7-af00-99314ab2b3eb	demo-user-001	create	content_block	505e5fcf-d09a-45e6-af5d-bbeec6f2d3df	\N	2026-03-04 10:05:47.63964
ceaf2c14-9575-4c79-a297-85f63eeef594	demo-user-001	create	content_block	7a290c75-0bf1-4cec-afe6-c341955c2d36	\N	2026-03-04 10:07:16.046098
c7cad17d-f90e-4792-9411-7f05368aa498	demo-user-001	create	content_block	93e1e5de-7df3-479a-b128-d4a312dbf76e	\N	2026-03-04 10:07:44.362926
51b485ea-72c4-447a-bc12-773b799aa2af	demo-user-001	create	content_block	a16e468f-09be-4d07-a4f6-abbe6a8e2893	\N	2026-03-04 10:08:00.390945
537738ed-8cee-4ed6-a9de-1729f0263c79	demo-user-001	update	content_block	de882ed5-4ae9-43a0-b80d-d51aae5f6a97	"Batch saved 4 blocks"	2026-03-04 10:08:35.482566
f73440c9-f955-4e92-846e-ad046123042b	demo-user-001	update	content_block	de882ed5-4ae9-43a0-b80d-d51aae5f6a97	"Batch saved 0 blocks"	2026-03-04 10:08:40.101029
ffd5739d-9bea-4a43-adc7-fffa007f280c	demo-user-001	update	topic	de882ed5-4ae9-43a0-b80d-d51aae5f6a97	{"isPublished": true}	2026-03-04 10:08:55.101084
5a241e75-be1d-4b7a-bbb9-9bd2b68b8ead	demo-user-001	create	topic	631e8033-60a7-46e8-8aac-713aad3674c8	{"title": "MENOPAUSE AND HRT"}	2026-03-04 10:29:44.4007
bb6aa6ff-db29-4673-9bef-88a4aa3b1855	demo-user-001	create	content_block	4b0d588b-019a-452c-a54a-82b4005c10f1	\N	2026-03-04 10:30:16.689296
4d2d3972-4f86-4fe3-be39-cc76728e9c05	demo-user-001	update	content_block	631e8033-60a7-46e8-8aac-713aad3674c8	"Batch saved 1 blocks"	2026-03-05 07:16:54.139972
2fe61e38-7241-4364-afb5-b4d6db823e67	demo-user-001	create	content_block	31d8bff9-4f8c-4df3-8325-876333a2a365	\N	2026-03-05 07:16:55.573157
d7ee9af0-1d24-448c-8a12-19edb7b3a074	demo-user-001	create	content_block	bbcd64eb-5555-4328-bdce-79bcc208a595	\N	2026-03-05 07:17:24.792309
59c2ea3b-0163-4d45-b95a-dc5942070171	demo-user-001	create	content_block	57c05cbc-e77e-4436-9431-096ffb96f114	\N	2026-03-05 07:18:05.169426
1d300d91-f337-4efd-abbc-add2e1f265ce	demo-user-001	delete	content_block	57c05cbc-e77e-4436-9431-096ffb96f114	\N	2026-03-05 07:18:33.033516
ab76a7e5-6743-4f7c-b0bf-f8bd4795d2a9	demo-user-001	create	content_block	c91a2f1a-7cb1-4e33-b1a8-3c169e2fa9b7	\N	2026-03-05 07:18:55.114047
8d8f9324-c5b8-49b2-996e-7306931771cb	demo-user-001	create	content_block	a6c8cf87-06e6-4e3a-9529-f45057c04f06	\N	2026-03-05 07:19:04.089405
8c4e0447-a55e-40ed-8bf8-fcf19664027f	demo-user-001	delete	content_block	a6c8cf87-06e6-4e3a-9529-f45057c04f06	\N	2026-03-05 07:19:09.425806
fde8a24a-c166-4861-b120-601bab5639c0	demo-user-001	create	content_block	28425bfe-48e0-43d6-bba4-61bc750a6033	\N	2026-03-05 07:19:14.237204
7b5d7ed1-5d65-4106-9aa0-dd16c2952d65	demo-user-001	update	content_block	631e8033-60a7-46e8-8aac-713aad3674c8	"Batch saved 4 blocks"	2026-03-05 07:19:21.527003
1d6b1c7d-c6de-4e74-8ca1-3840698d9f70	demo-user-001	update	content_block	631e8033-60a7-46e8-8aac-713aad3674c8	"Batch saved 0 blocks"	2026-03-05 07:19:27.544402
1aad8aec-1610-495d-a38d-793593b6bedd	demo-user-001	update	content_block	631e8033-60a7-46e8-8aac-713aad3674c8	"Batch saved 1 blocks"	2026-03-05 07:25:33.379677
ed74d3a1-2e80-4884-9dd3-c3c026a3da38	demo-user-001	create	content_block	a8313bc0-8390-49e2-aec8-89d57c93d8ed	\N	2026-03-05 07:30:17.380047
abf37b61-d630-49a2-80c5-e1b186013d09	demo-user-001	create	content_block	c6cb4954-4850-4665-b521-f17fb90e050e	\N	2026-03-05 07:30:24.717624
df4da2ff-e952-475f-8c72-ecd0d57472f3	demo-user-001	delete	content_block	c6cb4954-4850-4665-b521-f17fb90e050e	\N	2026-03-05 07:30:51.905585
f4b0d07f-3d8d-4e7a-8a63-23583f4b5851	demo-user-001	create	content_block	f175bfbc-8068-4ee9-a723-3071327431a4	\N	2026-03-05 07:30:57.983358
c752287c-f288-415b-ba20-f4d1cca93698	demo-user-001	create	content_block	945fc827-765f-4108-81d1-185b7ec8ec40	\N	2026-03-05 07:32:26.386783
3018b5b1-2d33-41c7-8fc0-416148ba8d33	demo-user-001	create	content_block	daf3797d-bef2-4258-8f9e-2e0cd5d23140	\N	2026-03-05 07:32:44.31152
1deb35f6-2f09-4507-93f4-1ae53a8824fd	demo-user-001	create	content_block	4ad4a968-509f-47db-8342-c66145eb8510	\N	2026-03-05 07:33:14.72356
714315fd-1c4d-49d4-a5b3-a2656180b241	demo-user-001	create	content_block	b39414ff-2fd5-4c44-868e-b37f04d32e3b	\N	2026-03-05 07:33:31.867823
f30bb147-4cd9-4f9b-bd12-43529fd63bc2	demo-user-001	create	content_block	22e03d0b-0c9c-4324-b365-52dc74baaba8	\N	2026-03-05 07:34:37.729474
bb20cccd-cc32-4ca6-bd05-dede86634d58	demo-user-001	create	content_block	82b66caf-e26a-4728-8ef6-227fb64e5f60	\N	2026-03-05 07:34:51.220228
989cd0ab-ec8a-462d-bc6b-17bee11ac30c	demo-user-001	create	content_block	2fc00f13-358f-4b4f-915e-bf5bd287dc31	\N	2026-03-05 07:35:09.779443
ccb713c8-e9d8-4d8e-9489-d1aefc209fe1	demo-user-001	create	content_block	ea16bebe-9dfc-4b2d-ba45-74c6bfec0cdd	\N	2026-03-05 07:35:30.016081
4821a900-965b-4ee9-b634-34836fb17bca	demo-user-001	create	content_block	906d9c91-dde6-4e7f-896d-c49df813b2ad	\N	2026-03-05 07:35:50.3553
257acb98-bca4-49c0-8539-632fe15c54c4	demo-user-001	create	content_block	3fffce1c-efe1-4cb7-83c8-e6501c295757	\N	2026-03-05 07:36:23.030019
f226d4dc-85d1-4496-8b69-59e09e3fdc02	demo-user-001	create	content_block	65bedc49-668f-4e55-9cab-708122711583	\N	2026-03-05 07:36:33.296531
90b593b8-89c2-49ad-9b6a-5fba5d70d9d9	demo-user-001	create	content_block	070c05c7-da20-496a-853a-6908ec0f7bd8	\N	2026-03-05 07:37:09.597388
ebc57ba5-5a15-4e2f-8fb7-ad78d239326f	demo-user-001	create	content_block	13d25da4-de9c-4dc4-9e7f-a570a980fb28	\N	2026-03-05 07:37:26.348151
f0417612-90f8-40ba-aa4b-20b2c0e7b6fd	demo-user-001	create	content_block	02bcd59d-4698-4948-8fc6-aadc7338fe6b	\N	2026-03-05 07:38:23.389504
f42c993e-9a46-496e-adf5-536afe595542	demo-user-001	delete	content_block	b39414ff-2fd5-4c44-868e-b37f04d32e3b	\N	2026-03-05 07:39:01.652762
3e8f6db9-b916-4936-b924-78934741e195	demo-user-001	update	content_block	631e8033-60a7-46e8-8aac-713aad3674c8	"Batch saved 15 blocks"	2026-03-05 07:39:05.614029
135f62be-b8a1-4f34-8121-2ef43a154f31	demo-user-001	update	content_block	631e8033-60a7-46e8-8aac-713aad3674c8	"Batch saved 0 blocks"	2026-03-05 07:43:03.258951
9eba70ac-1ba8-4fb2-864c-d12f721661dc	demo-user-001	update	content_block	631e8033-60a7-46e8-8aac-713aad3674c8	"Batch saved 0 blocks"	2026-03-05 07:43:09.18555
cd4791b4-22cb-4e40-b904-ce8985e40c8e	demo-user-001	update	topic	631e8033-60a7-46e8-8aac-713aad3674c8	{"isPublished": true}	2026-03-05 07:43:17.476378
b7b78a24-e1bc-4026-9e87-ab594c7ccb73	demo-user-001	create	content_block	2c2dad6c-7c1c-48ed-9efe-a8bd89606d11	\N	2026-03-05 07:43:59.506468
b718f420-f53f-42e3-b05c-35346c8aa22b	demo-user-001	create	content_block	9406bebe-519b-4f25-8a10-dfbfad0718d2	\N	2026-03-05 07:44:05.983428
2855454d-f50c-4140-b5dc-8b4d952cd9f0	demo-user-001	create	content_block	5684823e-5392-4648-b827-a858384a568d	\N	2026-03-05 07:44:22.785945
f21fd665-2e04-426e-ad4d-220b73318a08	demo-user-001	create	content_block	92d9a8d9-19b8-4ce8-8de7-ae08fb95db2e	\N	2026-03-05 07:44:37.941211
e029186f-8364-4d7b-a8d8-57756ef95164	demo-user-001	update	content_block	631e8033-60a7-46e8-8aac-713aad3674c8	"Batch saved 5 blocks"	2026-03-05 07:45:41.562162
ed82d566-7ce6-4d7a-a956-0e4f13083a57	demo-user-001	create	topic	dce6694e-93b3-4281-b546-8cb995c03b1d	{"title": "HRT"}	2026-03-05 07:46:09.679786
3592a5ba-e554-45b0-a7da-a1de2c33b6db	demo-user-001	create	content_block	b89842b6-5b29-4223-b7a6-a16f4e991ed1	\N	2026-03-05 07:46:28.764744
329a13d9-17af-4406-b064-720504cdba97	demo-user-001	create	content_block	d01c33e6-e6f8-4440-ac0f-2c4996be774f	\N	2026-03-05 07:46:38.337496
bf42f2dc-d458-401e-abcb-dc365aa40a6d	demo-user-001	create	content_block	20d82702-a851-4a32-843f-7e48be93457b	\N	2026-03-05 07:46:48.750564
903dcb2a-f7c3-475e-8d3e-52d6ec74deb2	demo-user-001	create	content_block	cc372a65-43ec-41ef-bf80-43a15bccd135	\N	2026-03-05 07:47:07.625328
eb48c2d6-abd2-4e2d-9876-2d5c61c8eb6e	demo-user-001	create	content_block	6b2f9a61-8102-4e29-8aa0-0b76ed619d29	\N	2026-03-05 07:47:15.80379
c89a6511-5467-4aab-9318-0c1573c77f4a	demo-user-001	create	content_block	65b66ce5-7210-4929-85cc-c2ad5ad1c4e7	\N	2026-03-05 07:47:34.303933
bc30a1e0-c63c-447a-b2b0-35cd3df97135	demo-user-001	create	content_block	b42bd086-8d1b-4871-9fb1-f2ed6d40ba35	\N	2026-03-05 07:47:41.681031
8a12a1b0-15a0-47ff-b496-0e6d21197465	demo-user-001	create	content_block	d06b2f34-804f-4af7-bfcf-58503072320d	\N	2026-03-05 07:48:02.279742
eab3c6d1-900a-4275-9b68-3a095e295a0d	demo-user-001	create	content_block	3a11d900-359c-4e15-8e5e-19de7f9147df	\N	2026-03-05 07:48:08.646323
cb17cefd-448a-46e3-a807-5eb72630c346	demo-user-001	create	content_block	97121965-13e9-4e25-b7f0-cf37088c7c59	\N	2026-03-05 07:48:32.593065
3a046beb-e97b-49ab-99f8-1a33a62c8027	demo-user-001	create	content_block	276bfbc9-d352-46fa-a245-80ec0b143460	\N	2026-03-05 07:48:42.117829
a0ee0c64-18d6-4174-970b-6afd22db4802	demo-user-001	create	content_block	fcc77a63-b21d-4327-ac23-af2d724b07b4	\N	2026-03-05 07:49:03.233843
aeb77e27-d1d5-49a2-a054-3e720efe3d88	demo-user-001	create	content_block	f5bb4eb0-f40f-49fe-9c71-a381810727e0	\N	2026-03-05 07:49:09.790223
b6f9bbe6-a7a2-4564-881a-411f270a0a79	demo-user-001	create	content_block	0325d607-a949-473d-bcd6-38d9de853941	\N	2026-03-05 07:49:23.811788
cd25623f-d56b-470b-968f-a420c2eacaa8	demo-user-001	create	content_block	5955a551-3c1a-41d9-8991-5a2c9e7940b9	\N	2026-03-05 07:49:53.119036
6e6eb0b9-227e-4369-81a6-435bb4680b40	demo-user-001	create	content_block	860d7b05-0362-4ba2-90fe-d37b13b3b773	\N	2026-03-05 07:50:15.934387
30fc4d00-8205-4644-9aa2-665453c32cc4	demo-user-001	create	content_block	d08fa4aa-5390-46a1-9e63-75e396b2b15a	\N	2026-03-05 07:50:22.606117
88733a33-9170-4f3c-aed5-0c130efedc92	demo-user-001	create	content_block	aad5b021-0c39-435a-892d-c74bada80093	\N	2026-03-05 07:50:52.678008
de086f29-fbd4-49b5-872a-45c957106dcd	demo-user-001	create	content_block	9dab8d73-4add-479c-b198-9dc15a398c23	\N	2026-03-05 07:51:13.506406
7ac820c9-731f-43bf-be8d-fad07d21e16f	demo-user-001	create	content_block	c5756aa0-5342-46f8-a080-992370b82b60	\N	2026-03-05 07:51:26.22152
ed34f89a-e58d-4d37-ae52-80dd081ad3a8	demo-user-001	create	content_block	3e2ce27b-3338-4b76-a653-a8f42eb6dc40	\N	2026-03-05 07:51:28.784974
be616b81-b9db-4900-8c6d-902d834a264c	demo-user-001	create	content_block	b30c44bc-f00a-47ee-bc19-7f5fd54c5422	\N	2026-03-05 07:51:29.045165
747d6b19-98ed-433c-b519-3c6cc8987d73	demo-user-001	delete	content_block	b30c44bc-f00a-47ee-bc19-7f5fd54c5422	\N	2026-03-05 07:51:51.629452
89883c45-b306-4248-b06f-f48c30714c21	demo-user-001	create	content_block	c8b5ed3f-d80e-44a4-ac73-585e29996502	\N	2026-03-05 07:51:58.443999
7034b3f4-9e68-4fe6-ac34-01af7e08e4c0	demo-user-001	create	content_block	44294460-4483-4b3e-90d5-1e7afb1d6d15	\N	2026-03-05 09:05:26.460201
fd6351ad-139c-4abc-906b-97e38762be3f	demo-user-001	update	content_block	dce6694e-93b3-4281-b546-8cb995c03b1d	"Batch saved 22 blocks"	2026-03-05 07:52:33.137841
c3b015ff-65cf-4d0b-bb1d-b45435fad077	demo-user-001	create	content_block	ebbdba40-330a-4716-b477-7ed7f2b14516	\N	2026-03-05 07:53:16.468939
5daf1acd-9853-477e-a693-5983c78befa1	demo-user-001	create	content_block	05236a2e-8fcb-43ca-ac98-7b27e0a2f00d	\N	2026-03-05 07:53:27.887914
c90319fe-777f-4f82-8043-8501d95e86d9	demo-user-001	create	content_block	106709fa-cbaf-4ad2-b9f2-755c175d8708	\N	2026-03-05 07:53:46.645751
8b9e87ae-e4ff-42c7-b912-7e30fe486ccf	demo-user-001	create	content_block	d2183bbb-400c-4efe-85df-dbba4bd44fb4	\N	2026-03-05 07:54:10.041149
9647b988-dc32-4ea0-9fcd-34d71ab17e0c	demo-user-001	create	content_block	7d1b366d-87d5-40ef-8daa-ba5f54f68887	\N	2026-03-05 07:54:26.437486
b4778717-c50c-467c-8061-e594b3cd8c76	demo-user-001	create	content_block	20176f9f-e0b3-43fc-9d1d-125d6961a588	\N	2026-03-05 07:55:04.22581
f65261e0-8338-4313-9322-a6c08e9d18d1	demo-user-001	create	content_block	62b7166a-feca-4c3f-a91e-955275ba87b7	\N	2026-03-05 07:55:20.070238
83818435-7140-453c-9e32-7126b7be1b4a	demo-user-001	create	content_block	757c169a-32b1-4770-9abe-eb73b4bf34b6	\N	2026-03-05 07:55:44.621098
d9d11cd7-ed2b-415d-a4ec-3c182eb06084	demo-user-001	create	content_block	43814668-5f7a-4156-8b28-c8a56a854afc	\N	2026-03-05 07:55:53.668306
975bc25f-d445-410c-bbdd-b0413b6ad759	demo-user-001	create	content_block	b70a4345-4976-4485-8d43-c6ca82c26b92	\N	2026-03-05 07:56:03.652438
a7e66c2f-58a5-48a3-bd44-df7a565cc181	demo-user-001	update	content_block	dce6694e-93b3-4281-b546-8cb995c03b1d	"Batch saved 10 blocks"	2026-03-05 07:56:23.813913
5df402a0-dbc3-4ab0-88e6-04bb9998808b	demo-user-001	update	content_block	dce6694e-93b3-4281-b546-8cb995c03b1d	"Batch saved 1 blocks"	2026-03-05 07:57:01.200744
20dcc99b-aa5f-4e92-89d5-020d8466e717	demo-user-001	update	topic	dce6694e-93b3-4281-b546-8cb995c03b1d	{"isPublished": true}	2026-03-05 07:57:09.251494
98228a9b-70d6-4e1e-958d-db89b5e4577d	demo-user-001	update	topic	dce6694e-93b3-4281-b546-8cb995c03b1d	{"isPublished": false}	2026-03-05 07:57:10.816347
8b0b966c-77b5-4233-9645-b13b8dce465b	demo-user-001	create	topic	126fe5cf-71e2-4469-8a89-2bf0498f7cc5	{"title": "HRT AFTER GYNAECOLOGICAL MALIGNANCY"}	2026-03-05 07:57:31.336797
6f61b8d1-3616-4c6e-90e7-4c97d3be71d5	demo-user-001	create	content_block	0511fcf5-7143-4f4c-8869-b6fd4a924ec6	\N	2026-03-05 07:57:51.581134
6c895724-599f-4d0b-8589-f4e9be385ab8	demo-user-001	create	content_block	951d7589-5e77-47ee-acf0-1634ed33f0bd	\N	2026-03-05 07:58:00.824187
bb0a63b7-a93a-4910-959a-3ba9e22ec629	demo-user-001	create	content_block	748269fd-53b7-4b29-91ba-ad4e3d45ffbc	\N	2026-03-05 07:58:10.407359
c0d89903-b416-4c99-8467-dde63dad8835	demo-user-001	create	content_block	df40cfb0-8dba-4eb2-813f-568d54eb8bf4	\N	2026-03-05 07:58:23.554857
6ac0a6ba-cbec-4a51-8a1d-e03956b60497	demo-user-001	create	content_block	023d8887-a226-41a7-9c3a-6dc38d8b9420	\N	2026-03-05 07:58:38.034754
d93162a7-f722-4773-a9d4-93e41e853066	demo-user-001	create	content_block	e4e2653a-6198-4ce0-9f40-65fba1dff16d	\N	2026-03-05 07:58:52.747905
266a2abd-d71a-408a-9487-6aea1278b54e	demo-user-001	create	content_block	3b5e666c-bd6a-4c38-9b40-da36e0aa8d2d	\N	2026-03-05 07:59:09.190823
ab106f39-7f6d-4f9b-be1b-9cd6d0f86e11	demo-user-001	create	content_block	190173aa-24df-463f-ae01-c10394653a22	\N	2026-03-05 07:59:23.556566
5632b508-5ac8-4971-a848-8f0eab690ca9	demo-user-001	update	content_block	126fe5cf-71e2-4469-8a89-2bf0498f7cc5	"Batch saved 8 blocks"	2026-03-05 07:59:37.762484
7a21cc85-fbab-48c0-9659-e2872e752c70	demo-user-001	create	content_block	47f2dd9f-7745-43b5-b759-68b70aaa195b	\N	2026-03-05 08:29:54.739476
4f6e0dd9-57f5-4ed6-8782-e1a62b892d4b	demo-user-001	update	content_block	126fe5cf-71e2-4469-8a89-2bf0498f7cc5	"Batch saved 1 blocks"	2026-03-05 08:47:12.538336
bdfc1a1b-b494-4eb7-b3dd-c1745a2284d0	demo-user-001	create	content_block	5a8f13df-49d4-4de4-a655-a72b5bdf100d	\N	2026-03-05 08:55:58.488979
161b6c79-cc6d-4e51-9211-829627b8da5e	demo-user-001	delete	content_block	5a8f13df-49d4-4de4-a655-a72b5bdf100d	\N	2026-03-05 08:56:03.848288
168dd484-abc5-4247-be73-72a4d4eec527	demo-user-001	create	content_block	0c70a164-0a90-4daf-9999-b841aa4fdf37	\N	2026-03-05 08:56:09.502106
cf88b3c2-dde6-4849-9575-3e3820bcdf0a	demo-user-001	delete	content_block	0c70a164-0a90-4daf-9999-b841aa4fdf37	\N	2026-03-05 08:56:34.282663
a3935fb5-bc22-4465-b23b-52eb17dac98f	demo-user-001	update	content_block	126fe5cf-71e2-4469-8a89-2bf0498f7cc5	"Batch saved 0 blocks"	2026-03-05 08:56:37.403797
2d98055f-d86b-47be-8aa2-049e3622be25	demo-user-001	create	topic	6f36db59-1cc0-4586-8c6a-1c8bb00a8e0c	{"title": "POST MENOPAUSAL BLEEDING"}	2026-03-05 08:56:48.861187
d2a2bca3-5b87-43f8-8447-0467be639de1	demo-user-001	create	content_block	a8fc0868-f4ca-48e9-818c-49b95c3f72a5	\N	2026-03-05 08:57:10.275234
6c45d5c2-dc7e-42cc-8bd5-b289a1e9e605	demo-user-001	create	content_block	9c541f15-5d2b-4648-b3b7-d9f6f5137a1a	\N	2026-03-05 08:57:18.228879
e19972f2-8e5c-47ff-8a0b-a242e979631e	demo-user-001	create	content_block	f7163397-b32b-4f44-8628-5758f717f78c	\N	2026-03-05 08:57:35.504353
93061eb4-c932-4ea4-8d96-41258244499c	demo-user-001	create	content_block	f70578f9-cb20-4dc8-a9be-5ce3ac8616a2	\N	2026-03-05 08:58:06.734878
8627d0af-037d-4358-a62f-9069432bdfd3	demo-user-001	create	content_block	43bc2ee2-5460-4299-8eec-e68d82bfb7bb	\N	2026-03-05 08:58:25.47124
3c38d408-fb14-4515-9930-2cf62abcabd5	demo-user-001	update	content_block	6f36db59-1cc0-4586-8c6a-1c8bb00a8e0c	"Batch saved 5 blocks"	2026-03-05 08:58:49.306827
d09114f2-a7d2-479e-a8b7-41be14cb6e51	demo-user-001	create	topic	1ec05f17-3698-4528-b414-f33f8f9e0c2b	{"title": "CHRONIC PELVIC PAIN"}	2026-03-05 08:59:11.903473
7022adb0-a2bf-45c6-9768-1a3a1fe3ce0e	demo-user-001	create	content_block	cda2440f-7690-4895-9347-15bafabd179a	\N	2026-03-05 08:59:38.459176
851b2cdf-37d3-4569-8671-c1dc059f6528	demo-user-001	create	content_block	f5dcce3d-ce4e-4ae1-ab41-1b8d60b29336	\N	2026-03-05 08:59:44.004118
20b5e5cc-5af9-4b40-9345-c34f507568a3	demo-user-001	create	content_block	209b04e6-c455-4d38-ab64-56301ae218bd	\N	2026-03-05 08:59:59.565421
47ecacf9-2fbf-4c08-8ee8-da5462af4ee2	demo-user-001	create	content_block	b0a0fa80-764c-4f3c-b42f-c18ab51601e9	\N	2026-03-05 09:00:15.330345
276e8031-39cb-4003-8292-725bf4c5b992	demo-user-001	create	content_block	0e205ed2-2fed-4034-8591-52d706db448b	\N	2026-03-05 09:00:52.565979
3d7ada60-12e8-4e18-87af-1a36ebfc0c05	demo-user-001	create	content_block	0c583ccb-2511-40ca-b1be-0085a07035e8	\N	2026-03-05 09:01:05.925949
a17b01c9-2088-405d-8ac5-1ce0a102face	demo-user-001	create	content_block	ec2d7c64-1ef9-4b3b-b96f-af5bf997188a	\N	2026-03-05 09:02:10.412296
08435847-af37-43f6-be32-84e24ca7d2bb	demo-user-001	create	content_block	ed9153d3-59b6-42f0-bf26-8035e73de055	\N	2026-03-05 09:02:35.226983
8f4daefc-3d21-464f-8798-9cf85f180655	demo-user-001	create	content_block	1e78a859-7070-4a94-a694-50f7654d1a85	\N	2026-03-05 09:03:02.407516
8fd55058-72d3-4b2c-ac82-1b954aaf4f68	demo-user-001	create	content_block	c167540d-20bf-46e7-bb18-a502a7380dd1	\N	2026-03-05 09:03:32.008151
fdf7bee1-f509-43ac-a919-127e2aad0895	demo-user-001	create	content_block	7b78b16a-ff0b-4e14-920f-a17664f1213b	\N	2026-03-05 09:04:16.048245
35870107-e12c-455a-a8c0-503e3dd41a32	demo-user-001	create	content_block	d63de386-d70d-45e8-afe3-2e72efa4aff6	\N	2026-03-05 09:04:24.788318
2c7a8013-7c95-4421-97d8-297474f51920	demo-user-001	update	content_block	1ec05f17-3698-4528-b414-f33f8f9e0c2b	"Batch saved 13 blocks"	2026-03-05 09:05:32.609382
a093aa33-4d35-4376-80c1-05b37c8b301a	demo-user-001	update	content_block	1ec05f17-3698-4528-b414-f33f8f9e0c2b	"Batch saved 0 blocks"	2026-03-05 09:05:39.215869
a10fb111-ae65-4817-a682-7d60663c148f	demo-user-001	update	content_block	1ec05f17-3698-4528-b414-f33f8f9e0c2b	"Batch saved 0 blocks"	2026-03-05 09:06:09.551554
6be59f2d-3ab3-491f-8092-74905103d469	demo-user-001	update	topic	dce6694e-93b3-4281-b546-8cb995c03b1d	{"isPublished": true}	2026-03-05 09:06:18.845817
9bc14551-186c-4426-9ec5-202eebc06790	demo-user-001	update	topic	126fe5cf-71e2-4469-8a89-2bf0498f7cc5	{"isPublished": true}	2026-03-05 09:06:20.441181
0732b716-50ee-415e-ace8-f894a627cb2c	demo-user-001	update	topic	6f36db59-1cc0-4586-8c6a-1c8bb00a8e0c	{"isPublished": true}	2026-03-05 09:06:22.212459
1c6fe3de-a9b7-44ee-a71c-78cbf9501464	demo-user-001	update	topic	1ec05f17-3698-4528-b414-f33f8f9e0c2b	{"isPublished": true}	2026-03-05 09:06:24.578691
33ca56bf-1c86-4244-886b-1fd120bbc92b	demo-user-001	create	topic	dc104b3f-ed6a-4f1f-8046-73c069161cb6	{"title": "PMS"}	2026-03-05 09:07:11.144747
77e313fc-4ecd-4095-b33f-727edd44998d	demo-user-001	create	content_block	eb93c947-ac59-40b4-b74a-0ec9ef56005a	\N	2026-03-05 09:07:40.683931
62e8ad12-9b4b-4006-9768-7aa7960e206b	demo-user-001	create	content_block	2f893548-dda2-4e96-a90c-00654d917c9a	\N	2026-03-05 09:07:46.194824
40c99d26-c762-4696-8e3a-14372e0b6de2	demo-user-001	create	content_block	bb5c0c18-aeda-4204-8c7f-2a57e3b2e885	\N	2026-03-05 09:08:05.157927
2eeba992-e5e8-4ce7-babb-90b49d04adf1	demo-user-001	create	content_block	6820515e-83e0-4fab-a36d-ef2076717d38	\N	2026-03-05 09:08:25.813159
71bc6e0b-e716-407b-aa34-8c9fac54ea01	demo-user-001	create	content_block	9422e372-7615-4a58-9f54-7919181451ce	\N	2026-03-05 09:08:44.049174
b29d8509-641b-4ffb-bfb0-8cef3c081952	demo-user-001	create	content_block	b02f508d-a3cc-48f7-94f7-4e45bec89a31	\N	2026-03-05 09:09:23.576697
c1d1af75-0d62-42ba-b389-6202b2013a76	demo-user-001	create	content_block	2b21d3e1-0e59-4cb1-84df-b6d9049b491a	\N	2026-03-05 09:09:39.421776
c5d93856-842f-4a67-9035-ad093f0edc7a	demo-user-001	update	content_block	dc104b3f-ed6a-4f1f-8046-73c069161cb6	"Batch saved 7 blocks"	2026-03-05 09:09:46.748274
32481cfe-62e4-4224-b7cd-974007ea872d	demo-user-001	create	content_block	9b72b3dc-33b5-4285-a492-36a9acf3c7ee	\N	2026-03-05 09:10:31.602944
debf8e57-ea9d-422c-bcfb-f99f3b924f3f	demo-user-001	create	content_block	bcdac350-b895-4fe1-bc51-6be3ba884ca2	\N	2026-03-05 09:11:03.222703
a27d19aa-737a-4930-886c-b59beac5f645	demo-user-001	update	content_block	dc104b3f-ed6a-4f1f-8046-73c069161cb6	"Batch saved 3 blocks"	2026-03-05 09:11:24.521995
dbbe453b-081d-44a0-a5e3-7c8eaed5296b	demo-user-001	update	content_block	dc104b3f-ed6a-4f1f-8046-73c069161cb6	"Batch saved 0 blocks"	2026-03-05 09:11:50.735103
29e75d99-9d1e-4ff1-ba1f-c216c0ed0d65	demo-user-001	update	user	7c45a099-3c4f-4068-8140-8b2f7ffe828e	{"name": "Asif Ali", "role": "student", "isEmailVerified": true, "subscriptionPlan": "quarterly", "subscriptionStatus": "active"}	2026-03-05 10:40:18.647762
4f777821-68a0-4b63-96a0-76a7360bbe7b	demo-user-001	update	announcement	592151fc-7595-459f-9dbf-94085c2de614	\N	2026-03-05 11:54:09.496115
49f893aa-6912-4114-b20b-9b9df04471b8	demo-user-001	update	announcement	592151fc-7595-459f-9dbf-94085c2de614	\N	2026-03-05 11:54:11.406323
249f8add-0692-4ab7-9166-48ac679781ab	demo-user-001	update	announcement	fed74c45-2b31-4dbf-b7a8-2030670a612c	\N	2026-03-05 11:54:12.91058
0fedc8d4-01a2-4d41-a098-1a38104ecfc6	demo-user-001	update	announcement	fed74c45-2b31-4dbf-b7a8-2030670a612c	\N	2026-03-05 11:54:14.288234
47481fa9-bc34-4373-bcae-9b47494d4c23	demo-user-001	update	announcement	db40c452-4619-4fd3-96c6-63784e552b36	\N	2026-03-05 11:54:15.569185
7b2675d0-847e-4ee9-be56-318c32dfe58b	demo-user-001	update	announcement	db40c452-4619-4fd3-96c6-63784e552b36	\N	2026-03-05 11:54:16.835351
5da4f3ee-47e5-4f9b-afc5-e471165fd3fe	demo-user-001	update	announcement	9247ba19-bffc-4ee4-b7ac-8630ad72573d	\N	2026-03-05 11:54:18.032268
78ee3284-22d9-4a1c-b56e-eb165c92fed1	demo-user-001	update	announcement	9247ba19-bffc-4ee4-b7ac-8630ad72573d	\N	2026-03-05 11:54:19.275142
c7b24396-168f-48ea-8378-c8b9ac7f4302	demo-user-001	create	announcement	f9792e51-96d6-42aa-9937-8ded35758fb8	{"title": "Announcements "}	2026-03-05 12:49:55.579953
3c4c8a6f-8da4-4551-9d6a-500fd6ad2361	demo-user-001	update	content_block	dc104b3f-ed6a-4f1f-8046-73c069161cb6	"Batch saved 0 blocks"	2026-03-05 13:35:33.101538
45e97f73-f9dd-4226-8db1-f1fb685e26bd	demo-user-001	update	content_block	126fe5cf-71e2-4469-8a89-2bf0498f7cc5	"Batch saved 1 blocks"	2026-03-06 13:04:23.746064
5e150932-a6c4-4e8b-877d-1b042a3db4fd	demo-user-001	update	content_block	126fe5cf-71e2-4469-8a89-2bf0498f7cc5	"Batch saved 1 blocks"	2026-03-06 13:07:08.036047
d65f7845-688b-4987-8e5e-03fc171de4d3	demo-user-001	update	content_block	dc104b3f-ed6a-4f1f-8046-73c069161cb6	"Batch saved 1 blocks"	2026-03-06 13:13:54.92399
21fa7ab9-14b0-4a61-9ae5-4a1eeeba8b25	demo-user-001	update	topic	dc104b3f-ed6a-4f1f-8046-73c069161cb6	{"isPublished": true}	2026-03-06 13:14:01.187354
7df4295b-f722-46bd-80b3-e6e6403db17a	demo-user-001	update	topic	dc104b3f-ed6a-4f1f-8046-73c069161cb6	{"isPublished": false}	2026-03-06 13:14:50.376189
0f6d2340-9fe2-48bb-82b5-caf4ea3c917c	demo-user-001	update	topic	dc104b3f-ed6a-4f1f-8046-73c069161cb6	{"isPublished": true}	2026-03-06 13:14:52.142535
77e4be96-e224-462d-9048-445cf2c07d70	demo-user-001	update	content_block	dc104b3f-ed6a-4f1f-8046-73c069161cb6	"Batch saved 1 blocks"	2026-03-06 13:17:19.56784
b63af68d-0fc8-4364-94a5-c56c2da5e80a	demo-user-001	create	content_block	0c9f857a-96a6-41ef-8318-632e91046260	\N	2026-03-06 13:18:28.747991
665867c2-354b-48ca-ae27-1a9fc3d979ab	demo-user-001	update	book	a886d6e1-9dea-4b5e-b700-f26cdd53f897	{"title": "Gynaecology ", "imageUrl": "", "description": "Test"}	2026-05-14 08:17:18.204143
97b6074b-2100-4ed8-a860-1d81053886b0	demo-user-001	update	book	a886d6e1-9dea-4b5e-b700-f26cdd53f897	{"isPublished": false}	2026-05-14 08:17:22.596584
2ae95a79-27ac-4b70-82ea-e51c47419b74	demo-user-001	update	book	a886d6e1-9dea-4b5e-b700-f26cdd53f897	{"isPublished": false}	2026-05-14 08:17:24.391029
40cff9e7-f2e2-4274-93c1-9881c8189095	demo-user-001	update	book	a886d6e1-9dea-4b5e-b700-f26cdd53f897	{"isPublished": true}	2026-05-14 08:17:25.318684
28f81783-0e0e-46a9-a6b4-76ab1e15fb74	demo-user-001	update	book	a886d6e1-9dea-4b5e-b700-f26cdd53f897	{"isPublished": true}	2026-05-14 08:17:26.181064
af13a415-2a6c-4d53-bc81-11c15beda717	demo-user-001	create	book	46799a77-8be1-457e-bb75-9bee5369ed87	{"title": "Test"}	2026-05-14 08:18:06.674825
0b105f79-dde1-4606-8b1c-3d88523e1ed1	demo-user-001	create	chapter	722dcdfb-1262-4d13-bd51-f6a22a1f8433	{"title": "Test1"}	2026-05-14 08:18:26.442739
616c75db-76fb-4b8b-acc0-d3cfe048eb7e	demo-user-001	update	announcement	f9792e51-96d6-42aa-9937-8ded35758fb8	\N	2026-05-14 08:21:03.02212
1cc57b5d-f960-46a7-b9a2-fcf8e4fa2e4c	demo-user-001	update	user	040f6153-ec47-41a7-9b0f-d3c6f7b9cd5d	{"name": "Muzammil", "role": "student", "isEmailVerified": true, "subscriptionPlan": "", "subscriptionStatus": "none"}	2026-05-14 11:03:33.224807
27f54fc2-03d7-4847-94f7-be813293d4df	demo-user-001	update	user	412ed3e2-e62d-4a4a-8d11-e91175a84a77	{"name": "Amir Sohail", "role": "student", "isEmailVerified": true, "subscriptionPlan": "", "subscriptionStatus": "none"}	2026-05-14 11:03:50.534852
3798b9d2-7145-44f7-a554-9192b7b4214c	demo-user-001	update	topic	52c2375a-221f-40db-be86-b66990fdd20a	{"isPublished": false}	2026-05-24 17:40:10.840829
20dd136b-d442-457d-aea5-80a54e7f314a	demo-user-001	update	topic	52c2375a-221f-40db-be86-b66990fdd20a	{"isPublished": false}	2026-05-24 17:40:11.821629
47596c17-90b8-4de3-a246-589042eb2bed	demo-user-001	update	topic	52c2375a-221f-40db-be86-b66990fdd20a	{"isPublished": true}	2026-05-24 17:40:52.67091
665515c7-938b-40a5-90d5-24ee198d3d4f	demo-user-001	update	chapter	dbec251c-b50c-408b-85ca-5a92d99980ed	{"isPublished": false}	2026-05-24 17:51:18.504131
175cd77a-36d1-4717-b14b-fadd6fd673ea	demo-user-001	update	chapter	dbec251c-b50c-408b-85ca-5a92d99980ed	{"isPublished": true}	2026-05-24 17:51:23.073589
994441b3-b1c5-4596-b080-a8d202df3bff	demo-user-001	create	chapter	b3afd200-5f4f-49b1-a607-ae1abb2be1a7	{"title": "Sexual and reproductive health"}	2026-05-25 06:22:43.066645
39b25b06-51f1-40e2-a106-92e82d0fdbd3	demo-user-001	update	chapter	b3afd200-5f4f-49b1-a607-ae1abb2be1a7	{"isPublished": true}	2026-05-25 06:23:26.418955
aefef88e-1478-4357-b41f-86346e4c0846	demo-user-001	create	chapter	bacaf815-66ec-4a41-afcb-6f178b8e4a87	{"title": "Early pregnancy care"}	2026-05-25 06:23:56.77259
11878d3e-b638-435b-8e2d-80c08e25d0ed	demo-user-001	update	book	46799a77-8be1-457e-bb75-9bee5369ed87	{"title": "Obstetrics", "imageUrl": "", "description": ""}	2026-05-25 06:24:30.526292
8064b9cf-cde6-478a-9931-c6aa8b1fee20	demo-user-001	update	book	46799a77-8be1-457e-bb75-9bee5369ed87	{"isPublished": true}	2026-05-25 06:24:33.028696
87ca09d4-e889-47a4-b687-eecec12665e4	demo-user-001	create	chapter	1c366ea0-72fd-4859-881c-734381c1b01b	{"title": "Maternal medicine"}	2026-05-25 06:27:39.100783
a1606011-3376-47db-baad-abd5fc62be79	demo-user-001	delete	chapter	722dcdfb-1262-4d13-bd51-f6a22a1f8433	\N	2026-05-25 06:27:44.107044
997148dc-4adf-4bc4-93c1-b39fc26f7e1a	demo-user-001	create	chapter	015cd5bd-973c-4086-acec-ca8459ed9225	{"title": "Labour and delivery "}	2026-05-25 06:28:09.439114
37612159-0975-4509-ad84-dc744b57a328	demo-user-001	update	chapter	1c366ea0-72fd-4859-881c-734381c1b01b	{"isPublished": true}	2026-05-25 06:28:11.833983
02b6ad81-99c5-480f-9491-0a77cd39dc4f	demo-user-001	update	chapter	015cd5bd-973c-4086-acec-ca8459ed9225	{"isPublished": true}	2026-05-25 06:28:12.85086
129393c5-cb16-4949-8e79-e8f38d8c354d	demo-user-001	create	chapter	28f5de83-fd41-4bdc-994f-c06c795a88a9	{"title": "Post partum"}	2026-05-25 06:28:30.268117
f090b353-8a37-4c8a-9452-b1262c065a2e	demo-user-001	update	chapter	015cd5bd-973c-4086-acec-ca8459ed9225	{"title": "Antenatal care", "description": ""}	2026-05-25 06:29:25.340014
6e30b584-88e4-43c0-ad2f-2028b70f0787	demo-user-001	update	chapter	28f5de83-fd41-4bdc-994f-c06c795a88a9	{"title": "Labour and delivery ", "description": ""}	2026-05-25 06:29:42.312714
af990d8c-0551-41d6-9c85-708a2e3c9593	demo-user-001	create	chapter	b8a054ef-e541-4d49-9bae-02c41ef8eb92	{"title": "Post partum"}	2026-05-25 06:29:52.814506
b3ac8fbb-7544-4ed1-9659-78517e6ccd55	demo-user-001	update	chapter	28f5de83-fd41-4bdc-994f-c06c795a88a9	{"isPublished": true}	2026-05-25 06:29:55.899029
714e9b53-a680-4d97-805d-37c5c2c15c43	demo-user-001	update	chapter	b8a054ef-e541-4d49-9bae-02c41ef8eb92	{"isPublished": true}	2026-05-25 06:29:56.400383
37357cec-a359-4582-b8f7-90f0772edfc7	demo-user-001	create	book	0d859a82-c9fd-47e8-9643-81e3de9588fc	{"title": "Miscellaneous "}	2026-05-25 06:31:11.223853
46eaac28-58ad-40af-ba13-b53444e763ef	demo-user-001	create	chapter	7d80628c-5d83-46e9-922d-ab659f7c0768	{"title": "Teaching"}	2026-05-25 06:31:23.046078
3b7d1444-859c-4b52-90cd-cbd84983f620	demo-user-001	create	chapter	2ce2539d-223c-45e5-90a0-272afedff9e3	{"title": "Clinical governance"}	2026-05-25 06:31:42.498036
d962f89a-987f-481d-a350-cc4cc3ec33f9	demo-user-001	update	chapter	bacaf815-66ec-4a41-afcb-6f178b8e4a87	{"title": "Core surgical skills and post operative complications ", "description": ""}	2026-05-25 06:34:52.916503
b4ecd36f-c1bd-4bbc-92a9-87e0ee3d4225	demo-user-001	update	chapter	bacaf815-66ec-4a41-afcb-6f178b8e4a87	{"isPublished": true}	2026-05-25 06:34:54.796231
625182a6-39b7-4995-88a2-2ab7e986ec71	demo-user-001	create	chapter	5640d3cf-5c87-4b49-8b8a-8948ad6ad905	{"title": "Early pregnancy care"}	2026-05-25 06:35:08.845062
be924837-b137-41c5-bffc-a6a67d5bcfc4	demo-user-001	update	chapter	5640d3cf-5c87-4b49-8b8a-8948ad6ad905	{"isPublished": true}	2026-05-25 06:35:13.997305
b1b05ccf-e4df-4d7c-90ed-1c151dc0e635	demo-user-001	update	topic	631e8033-60a7-46e8-8aac-713aad3674c8	{"title": "Menopause and management ", "author": "", "description": ""}	2026-05-25 06:36:29.150003
6c3f9323-17b7-443c-b0c9-2e5a0c6f3a04	demo-user-001	create	topic	4d4ecf5d-7535-46ca-b9ff-8f4b19de7353	{"title": "Fertility problems , assessment and treatment "}	2026-05-25 06:38:15.780351
a8d97a12-ca86-47cd-b2ad-9acc7d522bcf	demo-user-001	create	topic	9b5ca856-c888-487c-bf5e-0a5f4fa0652e	{"title": "Artificial reproductive technique, procedure review"}	2026-05-25 06:39:00.844796
5807769d-1f60-4ae2-9c8b-f075cbb02c44	demo-user-001	create	topic	51b95cd6-d5df-4ff6-acdd-8e9ebbee28e5	{"title": "Fertility preservation "}	2026-05-25 06:39:38.885116
7d854e19-9175-41d7-a1ff-a315ea53e7ab	demo-user-001	create	topic	ac9ca58f-c1fd-41c9-b22b-f2bccc750897	{"title": "Assessment of infertile male"}	2026-05-25 06:40:03.395237
f3ddd9a7-3098-4014-9694-84b5ca12d793	demo-user-001	create	topic	226d3f1d-49b6-4215-af72-8bf4d386ee3d	{"title": "Unexplained sub fertility "}	2026-05-25 06:40:45.365223
7cec3b62-4ad9-4cc0-a8d5-e27b93497db5	demo-user-001	create	topic	5429ab08-e367-42be-981a-75919d51e8e6	{"title": "Tubal tests and tubal surgery"}	2026-05-25 06:41:22.270535
8c3c9b82-ee4d-4e14-b40c-f1c6d7e37c77	demo-user-001	create	topic	99b1e0a9-60bd-4eb0-a911-570f96d324a4	{"title": "Management of sub fertile couple"}	2026-05-25 06:41:56.819048
57b39e44-0835-4172-b070-444052b84485	demo-user-001	create	topic	061c139e-f370-4c4d-8032-7e68e68edf98	{"title": "Early ovarian aging"}	2026-05-25 06:42:21.905209
6c8d4edf-dd82-4480-9bcc-3b8d66ece9a7	demo-user-001	create	topic	695fd8c5-65af-4a07-bdf8-afb67f7f42cf	{"title": "Long term consequences of PCOD"}	2026-05-25 06:42:50.10511
41a1aacb-d911-4d42-9146-b4c1e1d2b617	demo-user-001	create	topic	8ab6127d-19ed-4463-9137-39aa09066ffb	{"title": "Ovarian hyper stimulation syndrome "}	2026-05-25 06:43:27.511279
990bcda4-1cb3-4fd3-864f-05413aa8c4f9	demo-user-001	create	topic	fe2bfa7e-a245-4af1-9412-473ce84b6529	{"title": "Endometriosis "}	2026-05-25 06:43:41.421966
e3564f18-d9a5-4fed-86b8-cd82866c7ece	demo-user-001	update	topic	4d4ecf5d-7535-46ca-b9ff-8f4b19de7353	{"isPublished": true}	2026-05-25 06:43:45.704496
9811b960-079f-4858-b5dc-5ea598c29794	demo-user-001	update	topic	9b5ca856-c888-487c-bf5e-0a5f4fa0652e	{"isPublished": true}	2026-05-25 06:43:46.391341
28594fa5-e7f8-48b0-b972-a88987ef063e	demo-user-001	update	topic	51b95cd6-d5df-4ff6-acdd-8e9ebbee28e5	{"isPublished": true}	2026-05-25 06:43:46.955141
17d17009-114f-450b-8ec3-dd4f8e807d37	demo-user-001	update	topic	ac9ca58f-c1fd-41c9-b22b-f2bccc750897	{"isPublished": true}	2026-05-25 06:43:47.702599
58d8e21b-e1fc-4af2-89da-9086e01cdec8	demo-user-001	update	topic	226d3f1d-49b6-4215-af72-8bf4d386ee3d	{"isPublished": true}	2026-05-25 06:43:49.67266
f911c221-a246-4566-b84f-e3ee23c295e4	demo-user-001	update	topic	5429ab08-e367-42be-981a-75919d51e8e6	{"isPublished": true}	2026-05-25 06:43:50.181511
30914a90-9afc-43db-a05e-ac53516a682f	demo-user-001	update	topic	99b1e0a9-60bd-4eb0-a911-570f96d324a4	{"isPublished": true}	2026-05-25 06:43:51.562268
58f58bba-7340-4d26-ab0c-4f8123538fac	demo-user-001	update	topic	061c139e-f370-4c4d-8032-7e68e68edf98	{"isPublished": true}	2026-05-25 06:43:53.060718
37b5cf2d-9981-4cf1-853a-6856b5cf3451	demo-user-001	update	topic	695fd8c5-65af-4a07-bdf8-afb67f7f42cf	{"isPublished": true}	2026-05-25 06:43:55.316186
0b515ab9-9848-4b0a-b33c-2d262526fd31	demo-user-001	update	topic	8ab6127d-19ed-4463-9137-39aa09066ffb	{"isPublished": true}	2026-05-25 06:43:56.206897
519617a3-57ce-461e-aecd-6ba20c1f28d5	demo-user-001	update	topic	fe2bfa7e-a245-4af1-9412-473ce84b6529	{"isPublished": true}	2026-05-25 06:43:57.246286
67606027-e04e-4a81-abcf-d273884778d8	demo-user-001	create	topic	c57c867b-20a8-48c3-be7a-a309354e8e91	{"title": "Tumor markers "}	2026-05-25 06:44:34.431508
4f0f1f42-cf42-4685-9ec6-d26b39188479	demo-user-001	create	topic	f38932c9-6944-4977-8748-4bef336a81da	{"title": "Ultrasound appearance of different cysts "}	2026-05-25 06:45:00.323345
bffe3c15-aac1-4752-9944-d2ae1d0719c7	demo-user-001	create	topic	9c84da32-6d75-4182-907e-3825bc8bea9e	{"title": "Suspected ovarian masses in pre menopausal women"}	2026-05-25 06:45:42.07878
5e1cba69-8014-4202-a691-507725b6c079	demo-user-001	create	topic	096b7cdc-b92c-4118-81fb-eaea8d5bc526	{"title": "Ovarian cyst in post menopausal women"}	2026-05-25 06:46:17.22469
2ef082ae-615a-4c21-b7d6-6af8fe29b8ec	demo-user-001	create	topic	31f98154-6c8b-477c-b580-dd6fccdf9052	{"title": "Ovarian masses in children and adolescents "}	2026-05-25 06:46:53.862655
3270ad21-b93b-40c5-a0ac-cd0fda86e356	demo-user-001	create	topic	fd82ab80-b6ed-45ad-9e3d-faf210b0224a	{"title": "Adnexal masses in pregnancy "}	2026-05-25 06:47:57.401318
dc5b6e4f-b6f1-4a82-8a58-6b151ff065a6	demo-user-001	create	topic	fee1f915-9fef-4013-a893-e9222a6d39b4	{"title": "Borderline ovarian tumors"}	2026-05-25 06:48:19.016521
6519c6d3-7e9c-41f8-baaf-1ac58e4bae18	demo-user-001	create	topic	61bf142e-54a0-4575-985d-441a89305f45	{"title": "Risk reducing surgery in women at risk of epithelial tumors"}	2026-05-25 06:49:21.125256
14057205-0d0c-4e50-9405-53e8efb123f3	demo-user-001	create	topic	0aad86d2-58c1-4310-8162-7b866d1157a6	{"title": "Ovarian cancer"}	2026-05-25 06:49:34.409864
fab9542b-1a00-4006-8ff0-868f5a4967d7	demo-user-001	create	topic	ed1f2732-e99d-4c85-b4ac-3f5088eec343	{"title": "Endometrial hyperplasia "}	2026-05-25 06:49:53.615869
b32e8180-5a04-4c66-a8b7-d61d668ef7de	demo-user-001	create	topic	4fbcd90e-d6d1-4d31-bcd3-2aa6188305f7	{"title": "CA Endometrium"}	2026-05-25 06:50:21.472249
92f584a1-fd11-42a3-93e1-3faed81a144e	demo-user-001	create	topic	ebe28a85-2fd4-4b11-9997-6355b277c282	{"title": "Pre malignant lesions of cervix and cervical screening"}	2026-05-25 06:51:13.928457
6cf7c1d0-f87a-401f-97eb-6061fd645e19	demo-user-001	create	topic	c7e89b30-8c2c-480e-ad57-b3cbf17f4f46	{"title": "CA Cervix"}	2026-05-25 06:51:34.668835
df7b8b7f-31c5-4fb2-b881-18341f79b719	demo-user-001	create	topic	009da997-ea38-448c-b043-ff3aefbbbeeb	{"title": "Pre malignant lesions of vulva"}	2026-05-25 06:52:00.683359
cbf602ea-aeb5-43f7-8143-3bc6869e0c37	demo-user-001	create	topic	e730265c-3042-48e5-9b02-386b1f2629ac	{"title": "CA Vulva"}	2026-05-25 06:52:15.518665
328d11ff-df15-4fc0-af82-9fc9fd5b53ed	demo-user-001	update	topic	e730265c-3042-48e5-9b02-386b1f2629ac	{"isPublished": true}	2026-05-25 06:52:27.227197
93e55070-df16-4448-9faf-42c6be9a771b	demo-user-001	update	topic	009da997-ea38-448c-b043-ff3aefbbbeeb	{"isPublished": true}	2026-05-25 06:52:27.860685
d619aab8-a4fe-49dc-8f8a-c82b360de0b1	demo-user-001	update	topic	c7e89b30-8c2c-480e-ad57-b3cbf17f4f46	{"isPublished": true}	2026-05-25 06:52:28.289498
c50beea7-7fbe-4801-9325-b7faa4ded306	demo-user-001	update	topic	ebe28a85-2fd4-4b11-9997-6355b277c282	{"isPublished": true}	2026-05-25 06:52:28.744491
bd7402b9-7f36-441f-9ace-074832ba4be6	demo-user-001	update	topic	4fbcd90e-d6d1-4d31-bcd3-2aa6188305f7	{"isPublished": true}	2026-05-25 06:52:30.060142
f0a054ee-49bd-4aeb-b0b6-9ba9591331de	demo-user-001	update	topic	ed1f2732-e99d-4c85-b4ac-3f5088eec343	{"isPublished": true}	2026-05-25 06:52:30.677075
99defb20-b903-4359-ae1f-c4349c506fb5	demo-user-001	update	topic	0aad86d2-58c1-4310-8162-7b866d1157a6	{"isPublished": true}	2026-05-25 06:52:31.069422
f799c3a5-7177-4a36-ae09-e1f27bdd8c66	demo-user-001	update	topic	61bf142e-54a0-4575-985d-441a89305f45	{"isPublished": true}	2026-05-25 06:52:32.289121
a8e7791c-baf5-45a9-8ba0-fe25d3761c38	demo-user-001	update	topic	fee1f915-9fef-4013-a893-e9222a6d39b4	{"isPublished": true}	2026-05-25 06:52:32.671526
8fb997b9-0e83-401c-9534-08a1fa9b13b7	demo-user-001	update	topic	fd82ab80-b6ed-45ad-9e3d-faf210b0224a	{"isPublished": true}	2026-05-25 06:52:33.07885
272bc0b9-336b-46bc-bb07-57858edf06ae	demo-user-001	update	topic	31f98154-6c8b-477c-b580-dd6fccdf9052	{"isPublished": true}	2026-05-25 06:52:34.791771
819b0dff-2e65-4369-82c1-2c254f76d872	demo-user-001	update	topic	096b7cdc-b92c-4118-81fb-eaea8d5bc526	{"isPublished": true}	2026-05-25 06:52:35.186505
6073a6b3-e702-4a87-9424-cccd9ddab4fb	demo-user-001	update	topic	9c84da32-6d75-4182-907e-3825bc8bea9e	{"isPublished": true}	2026-05-25 06:52:37.725491
b3edd3d9-c646-4b82-acee-26702dd7dc3d	demo-user-001	update	topic	f38932c9-6944-4977-8748-4bef336a81da	{"isPublished": true}	2026-05-25 06:52:38.359808
92c78019-f6e9-4816-b0a4-9a4df43ba914	demo-user-001	update	topic	c57c867b-20a8-48c3-be7a-a309354e8e91	{"isPublished": true}	2026-05-25 06:52:39.018103
3571dae2-a9d1-4aa1-8196-bde694c4c565	demo-user-001	create	topic	92b5ee8b-32bf-4ab1-ab61-b1df07b92017	{"title": "Types of incontinence"}	2026-05-25 06:53:38.288515
85792891-8172-498c-a50b-43302da386e7	demo-user-001	create	topic	56cd36b6-ca5e-4279-936a-59303b867db5	{"title": "Over active bladder"}	2026-05-25 06:54:05.213013
6e3248d6-184d-4215-b6c7-b3770a977e6b	demo-user-001	create	topic	d5701748-bc01-4636-be5c-6337cabf92ad	{"title": "Sensory urgency "}	2026-05-25 06:54:53.946296
15696029-1add-4b7c-8360-f86f596aa8a6	demo-user-001	create	topic	e6feef9c-123b-4f94-a88e-363928e6ad79	{"title": "Stress urinary incontinence "}	2026-05-25 06:55:31.379442
8ca3f72f-68d3-46f6-968a-77d5de5e4d81	demo-user-001	create	topic	ebad03aa-d0cc-4cd6-a66b-6d90073459aa	{"title": "Urinary retention"}	2026-05-25 06:55:51.137138
04461607-03a3-4ad7-a6b0-75b822d209e7	demo-user-001	create	topic	3fb406ec-becd-4743-aed5-293304c8fab5	{"title": "Bladder pain syndrome "}	2026-05-25 06:56:09.866132
13656a4d-748e-4328-bbe9-6b6ae3f24fdf	demo-user-001	create	topic	64cc3319-26e3-434b-9138-fe7d7d0226a3	{"title": "Urethral diverticula"}	2026-05-25 06:56:36.471477
e3b27926-620c-4491-90e7-93f17d912c1e	demo-user-001	create	topic	8c0a6a24-6aec-4e85-b74c-547a6e95ee5a	{"title": "Recurrent UTI"}	2026-05-25 06:57:01.078982
5501f9ea-fe69-496d-89c0-2e054946f1be	demo-user-001	create	topic	93449ff0-81dc-4af5-8730-28d68ba5925d	{"title": "Pelvic organ prolapse "}	2026-05-25 06:57:18.181925
6096cc35-6bfe-4350-a147-1fcbb48f0ef1	demo-user-001	create	topic	a3d3307e-d67a-4324-9958-84f3e478379d	{"title": "Vault prolapse "}	2026-05-25 06:57:34.096824
ebd8f116-f805-4e36-9ba2-6550ad122ba1	demo-user-001	update	topic	92b5ee8b-32bf-4ab1-ab61-b1df07b92017	{"isPublished": true}	2026-05-25 06:59:31.880291
9ca2f4a1-9cce-42c5-b5f8-ddeb26f60ce4	demo-user-001	update	topic	56cd36b6-ca5e-4279-936a-59303b867db5	{"isPublished": true}	2026-05-25 06:59:32.341254
2f1511c8-c774-49ce-85a8-59c6c0fa5850	demo-user-001	update	topic	d5701748-bc01-4636-be5c-6337cabf92ad	{"isPublished": true}	2026-05-25 06:59:33.208223
3dbfc73e-af29-4a14-a77e-e78f0bd47dfb	demo-user-001	update	topic	e6feef9c-123b-4f94-a88e-363928e6ad79	{"isPublished": true}	2026-05-25 06:59:36.971261
9f98832a-1bdc-4b76-a6ca-32307b204e0e	demo-user-001	update	topic	ebad03aa-d0cc-4cd6-a66b-6d90073459aa	{"isPublished": true}	2026-05-25 06:59:40.637525
e0a7cd70-19b9-4355-ad40-1b6a9fe14870	demo-user-001	update	topic	3fb406ec-becd-4743-aed5-293304c8fab5	{"isPublished": true}	2026-05-25 06:59:42.070351
b5eb39cc-c06d-43e4-99cd-9b84d5dacb84	demo-user-001	update	topic	64cc3319-26e3-434b-9138-fe7d7d0226a3	{"isPublished": true}	2026-05-25 06:59:43.899438
f6fc09e9-7b58-49de-9227-f4840214a3f9	demo-user-001	update	topic	8c0a6a24-6aec-4e85-b74c-547a6e95ee5a	{"isPublished": true}	2026-05-25 06:59:45.7915
c01617fb-b271-429c-a2db-2f2891c0a36b	demo-user-001	update	topic	93449ff0-81dc-4af5-8730-28d68ba5925d	{"isPublished": true}	2026-05-25 06:59:47.508655
13b8035b-f198-4a68-96de-a9796c55edab	demo-user-001	update	topic	a3d3307e-d67a-4324-9958-84f3e478379d	{"isPublished": true}	2026-05-25 06:59:48.623354
904daf1d-9983-4500-990a-1ecaea493002	demo-user-001	create	topic	c293f92b-c305-42f4-b986-2dd110fdd68e	{"title": "Vaginal discharge "}	2026-05-25 07:00:51.560661
e1aac6ba-aefd-442b-9d86-618e8fd8a2e0	demo-user-001	create	topic	33c1071b-5ae8-4cd4-88aa-eb02042d7f19	{"title": "Genital infections and their treatment "}	2026-05-25 07:01:16.615845
0d15ee44-a974-4f03-983a-717b8d2e9367	demo-user-001	create	topic	c3a8e5d9-562d-4135-bf83-3f34cecf365d	{"title": "Pelvic inflammatory disease"}	2026-05-25 07:01:37.768808
9a76da82-ead3-4c33-9462-0262021ba261	demo-user-001	create	topic	b680bc1d-ab12-46a8-9aae-585622199795	{"title": "Genital conditions and their management "}	2026-05-25 07:02:00.79021
91f3c224-1185-4e4b-a738-a7679496b18f	demo-user-001	create	topic	366627fc-eb8c-4d7d-af71-39a0a33abf28	{"title": "Anogenital warts"}	2026-05-25 07:02:33.094317
1ed7ea0b-58e0-4b16-8c4f-59ffd9ba5906	demo-user-001	create	topic	697f3290-8b41-42be-a3b1-6b03f11a7994	{"title": "Abortion clauses"}	2026-05-25 07:02:53.366449
57b6030e-7f49-420d-8217-febd29abe02e	demo-user-001	create	topic	c778b357-ffc3-4d34-9e2e-372aef90fee8	{"title": "UK Medical eligibility criteria UKMEC"}	2026-05-25 07:03:26.907099
eff34870-1cac-49c6-b6d0-a621c41c0385	demo-user-001	create	topic	e544276a-50cc-442e-a43a-5e90febca300	{"title": "Combined hormonal contraception"}	2026-05-25 07:03:58.216338
2805c21e-fbd1-48a3-9b16-43b2a0326992	demo-user-001	create	topic	f79681ee-aa0a-4e81-a507-b97640de5aad	{"title": "Progesterone only pills"}	2026-05-25 07:04:19.053031
bc9ff4dc-f35b-452d-b51f-9dbb74d98f29	demo-user-001	create	topic	006062a0-1498-4d27-a636-d4c839ce668f	{"title": "Progesterone only injectable contraception "}	2026-05-25 07:04:55.308752
c2e90083-6660-4811-ad96-49db7ce0b88b	demo-user-001	create	topic	5662f871-1949-4f64-afd0-4ee8eedc7eb6	{"title": "Progesterone only implants "}	2026-05-25 07:06:34.595677
623f1bc3-7a49-49f7-8c37-0dbdf12c4897	demo-user-001	create	topic	b0a2a729-9dcf-4b84-a987-e361f78d59c0	{"title": "Emergency contraception "}	2026-05-25 07:06:51.186083
8a614147-eaaf-46e1-a5a2-c2b6255eb954	demo-user-001	create	topic	340afd9c-033b-4ef4-ad27-fe5bbcfc19d7	{"title": "Drug interactions with hormonal contraception "}	2026-05-25 07:07:35.016725
f2270227-20db-4cd4-b903-cdc31fcd2be8	demo-user-001	create	topic	a16d3e81-af62-4b93-b434-18b6741d9e26	{"title": "Problematic bleeding with hormonal contraceptives "}	2026-05-25 07:08:21.726392
06ede8c4-b9b3-4d90-96fc-6e37c4e22c6a	demo-user-001	create	topic	62eb7bb2-f22a-469e-9a1c-668f4bd38122	{"title": "Barrier method of contraception "}	2026-05-25 07:08:48.37428
ca1046f6-58da-4778-8c42-5b21a62dea24	demo-user-001	create	topic	47e51734-ae91-4b54-9a38-9b9ebbe0a63f	{"title": "Intrauterine contraception "}	2026-05-25 07:09:18.118236
cf5b93e6-c711-44b8-aea2-2e1d458a12d3	demo-user-001	create	topic	b1ea04fc-ddec-49af-9178-bc51a250338c	{"title": "Male and female sterilization "}	2026-05-25 07:09:55.964289
903aad2a-bcc4-49c7-8c9a-a7362576d290	demo-user-001	create	topic	016a1ed0-a333-4e84-946d-0e2779331f46	{"title": "Quick start contraception "}	2026-05-25 07:10:16.484843
b50d9ae4-3d19-49f0-9370-d8989c494a5a	demo-user-001	create	topic	6bab467c-8a2a-4d8b-9338-0b644334624c	{"title": "Contraception for women above 40 years of age"}	2026-05-25 07:11:10.599813
fb2055c8-d724-46df-ab51-469240b130f5	demo-user-001	create	topic	318f7429-4792-4bf8-a948-92d22ed71a32	{"title": "Contraception for young population "}	2026-05-25 07:13:07.780316
c25fbd63-fab8-4feb-9b76-48a7ae2985ff	demo-user-001	create	topic	0aeb33ca-776f-4dd3-8fe4-cd879ebc52b0	{"title": "Contraception in over weight and obese women"}	2026-05-25 07:13:54.683672
f29aeee6-38e2-40f1-8731-cbfd60412d68	demo-user-001	create	topic	c3acc2dc-d239-4777-bd73-037beafbbda5	{"title": "Contraception failure"}	2026-05-25 07:14:14.760762
01b6c409-e6b6-4d7f-8080-169c824051fb	demo-user-001	update	topic	c293f92b-c305-42f4-b986-2dd110fdd68e	{"isPublished": true}	2026-05-25 07:24:59.487946
fe757a8d-4adb-47b1-94b8-713c1b85351b	demo-user-001	update	topic	33c1071b-5ae8-4cd4-88aa-eb02042d7f19	{"isPublished": true}	2026-05-25 07:24:59.744965
343eda71-9cb3-4f7e-9c0a-a071ffaeafe0	demo-user-001	update	topic	c3a8e5d9-562d-4135-bf83-3f34cecf365d	{"isPublished": true}	2026-05-25 07:25:00.348569
93dc356d-e370-4ed4-89b3-9edcb760ce8f	demo-user-001	update	topic	b680bc1d-ab12-46a8-9aae-585622199795	{"isPublished": true}	2026-05-25 07:25:04.773102
c3e095a5-7c45-4467-9b29-0318962909e9	demo-user-001	update	topic	366627fc-eb8c-4d7d-af71-39a0a33abf28	{"isPublished": true}	2026-05-25 07:25:06.227638
d872cb3c-96ef-4cd1-a5bd-d3e66eae59c6	demo-user-001	update	topic	697f3290-8b41-42be-a3b1-6b03f11a7994	{"isPublished": true}	2026-05-25 07:25:07.236361
44e7e50b-2000-4676-b318-65a68b3eeb9c	demo-user-001	update	topic	c778b357-ffc3-4d34-9e2e-372aef90fee8	{"isPublished": true}	2026-05-25 07:25:08.439584
ce202fdd-8a81-4213-adac-b91f5daca78f	demo-user-001	update	topic	e544276a-50cc-442e-a43a-5e90febca300	{"isPublished": true}	2026-05-25 07:25:09.953862
c30ec37a-993e-4a4e-b1f3-26f2f0dc534a	demo-user-001	update	topic	f79681ee-aa0a-4e81-a507-b97640de5aad	{"isPublished": true}	2026-05-25 07:25:10.813643
e1cbc767-9faa-4f54-8647-45f6db3b39bd	demo-user-001	update	topic	006062a0-1498-4d27-a636-d4c839ce668f	{"isPublished": true}	2026-05-25 07:25:12.574159
323130d3-59b8-41fc-8fc0-5045b0bc0c77	demo-user-001	update	topic	5662f871-1949-4f64-afd0-4ee8eedc7eb6	{"isPublished": true}	2026-05-25 07:25:14.203935
8b9ee2f5-7880-443f-b1cf-99e3364db340	demo-user-001	update	topic	b0a2a729-9dcf-4b84-a987-e361f78d59c0	{"isPublished": true}	2026-05-25 07:25:15.890561
dd197a60-0aa2-4e2c-b1f5-ec1351e647dc	demo-user-001	update	topic	340afd9c-033b-4ef4-ad27-fe5bbcfc19d7	{"isPublished": true}	2026-05-25 07:25:17.509603
de18ff01-61a4-48f8-862b-b1df1da4f969	demo-user-001	update	topic	a16d3e81-af62-4b93-b434-18b6741d9e26	{"isPublished": true}	2026-05-25 07:25:19.023922
968c80ee-412f-4568-a869-2bc9e5d24674	demo-user-001	update	topic	62eb7bb2-f22a-469e-9a1c-668f4bd38122	{"isPublished": true}	2026-05-25 07:25:20.319167
896b05a8-7a87-4ae3-8967-4bb30ecc425c	demo-user-001	update	topic	47e51734-ae91-4b54-9a38-9b9ebbe0a63f	{"isPublished": true}	2026-05-25 07:25:21.687646
47d9b671-c9f8-478c-88ef-1199875d1377	demo-user-001	update	topic	b1ea04fc-ddec-49af-9178-bc51a250338c	{"isPublished": true}	2026-05-25 07:25:23.162989
34bfff56-6f4a-4faf-94b3-9019adaa2022	demo-user-001	update	topic	016a1ed0-a333-4e84-946d-0e2779331f46	{"isPublished": true}	2026-05-25 07:25:24.675368
3a2246e7-605f-497c-8ee5-28950b626f11	demo-user-001	update	topic	6bab467c-8a2a-4d8b-9338-0b644334624c	{"isPublished": true}	2026-05-25 07:25:26.155798
6c4668da-f573-4145-add9-54320264aca9	demo-user-001	update	topic	318f7429-4792-4bf8-a948-92d22ed71a32	{"isPublished": true}	2026-05-25 07:25:27.551122
5944ae06-3853-4f69-b2af-108351f3dda5	demo-user-001	update	topic	0aeb33ca-776f-4dd3-8fe4-cd879ebc52b0	{"isPublished": true}	2026-05-25 07:25:29.52685
476654cf-8751-4b52-ac09-5db5cdbb292d	demo-user-001	update	topic	c3acc2dc-d239-4777-bd73-037beafbbda5	{"isPublished": true}	2026-05-25 07:25:31.229548
32ab7b76-76f5-47e4-8462-5a4952ae401b	demo-user-001	create	topic	7582eeff-80c4-488b-9beb-64dac57524fe	{"title": "Obtaining valid consent"}	2026-05-25 07:34:22.516522
725c6a91-9a4c-456e-8127-3caa7a74c4f3	demo-user-001	create	topic	8f8f1c76-4248-45ae-a6e1-1e547ac93360	{"title": "Caesarean section"}	2026-05-25 07:34:48.204178
fee30e67-d839-438f-aaea-e50e9251a8aa	demo-user-001	create	topic	746dce12-309b-465e-959e-55f209bda77f	{"title": "Preventing entry related gynaecological laparoscopic injuries "}	2026-05-25 07:35:32.808447
52c7cec6-c5a0-4887-84d6-6d765856db79	demo-user-001	create	topic	15c1919a-8a04-48ae-aa30-3f131d9fea90	{"title": "Urinary track injuries "}	2026-05-25 07:35:49.143351
34891858-f2fb-409e-8243-25608531f701	demo-user-001	create	topic	62425119-0192-4c3b-bcbc-6faa09e2ecae	{"title": "Surgical nerve injuries"}	2026-05-25 07:36:10.229105
4018445e-8e62-4e94-ab48-ff88ff916ad5	demo-user-001	update	topic	15c1919a-8a04-48ae-aa30-3f131d9fea90	{"title": "Urinary track injuries during laparoscopy and their prevention", "author": "", "description": ""}	2026-05-25 07:36:59.487379
66543062-dc3f-4cf3-ac36-e4f11013e52c	demo-user-001	create	topic	64cea85a-0089-4b91-a842-3b7238c6817e	{"title": "Vascular injuries during surgery "}	2026-05-25 07:37:33.963757
28f860f7-e6a8-40e9-b874-97d8769f101f	demo-user-001	create	topic	a6c8b5fa-ab50-4d0d-bdb1-ca0fe4f6bc31	{"title": "Uterine perforation "}	2026-05-25 07:37:56.655611
342b9fd4-37f1-4174-9d39-39880bf35947	demo-user-001	create	topic	7be2cc15-53f3-44e9-bb80-4bcae28a27dc	{"title": "Surgical safety checklist "}	2026-05-25 07:38:16.542479
fdaa5b65-02c4-4083-86de-85ca8b7f9111	demo-user-001	create	topic	bc3525ef-c84c-494e-aa6f-ad0db374bb40	{"title": "Outpatient hysteroscopy "}	2026-05-25 07:38:39.033559
7e4b8a3b-0c4d-446f-9256-6745e91467c1	demo-user-001	create	topic	e2b390f7-41f9-40bc-8582-2175ebb9713a	{"title": "Steps of abdominal hysterectomy "}	2026-05-25 07:39:05.951118
4e04cbe7-a421-41df-90dd-544c98b4bb79	demo-user-001	create	topic	1eeae14d-911e-47ab-9d9d-6f03aa3d32a8	{"title": "Steps of vaginal hysterectomy "}	2026-05-25 07:39:24.055503
050fe12a-c569-48e2-9e46-d94ba89c8318	demo-user-001	create	topic	36543a67-f443-4587-a15c-eeca9409e894	{"title": "Steps of evacuation"}	2026-05-25 07:39:46.153545
4f970462-8bf7-472c-bf4d-df13343786cc	demo-user-001	create	topic	90deb252-c4bd-4530-aead-7c88471362b1	{"title": "MVA"}	2026-05-25 07:39:57.758819
344337c2-8a88-44b3-b7f4-1f465e82334d	demo-user-001	create	topic	3a9a3b9e-65d9-4484-99b8-0d07a9f2669b	{"title": "Steps of anterior repair"}	2026-05-25 07:40:17.45678
25cd8d1f-3490-4bee-b9ac-50f628b648e4	demo-user-001	create	topic	02539645-a323-4379-8a12-b938ffd1258b	{"title": "Steps of posterior repair"}	2026-05-25 07:40:36.921874
e1661279-3366-4f9c-8019-3cfe700c986a	demo-user-001	create	topic	120c0469-0c47-4e82-abb9-26e2351d04db	{"title": "Use of surgical drains"}	2026-05-25 07:41:55.712489
1c168c28-4e5e-44b0-b072-aca4c1245a7b	demo-user-001	create	topic	99b47941-82f2-4a74-96b5-829c905c42c4	{"title": "Post operative complications "}	2026-05-25 07:42:13.00292
e6977877-412c-4f0b-a675-d6037b06cf9c	demo-user-001	create	topic	6ecb13ca-9d1d-4898-9e51-b8f381a80b49	{"title": "Laparoscopic myomectomy "}	2026-05-25 07:45:07.585709
d3a31993-f00e-4fec-a751-58b694c902d8	demo-user-001	create	topic	f4344202-4daa-4199-838b-d9c7e4c729e8	{"title": "Laparoscopy in pregnancy "}	2026-05-25 07:45:21.121673
a032bbaa-b84b-4acb-85ce-a777eecd2d9f	demo-user-001	create	topic	45bbcd5b-01ca-4442-b683-0cf15e90ad6f	{"title": "Issues around vaginal vault closure "}	2026-05-25 07:45:45.816161
0ee67465-075d-4494-94cc-5a5d16b5ca2c	demo-user-001	create	topic	7c60191e-b16a-4043-9001-7aa96deab103	{"title": "Laparoscopy in urogynaecology"}	2026-05-25 07:47:35.355118
af758017-56ea-4c04-9b60-c2901f100253	demo-user-001	create	topic	e8fa0cb3-53c4-458f-b5aa-8b55a1b991fe	{"title": "Surgical smoke"}	2026-05-25 07:47:54.962673
5a241c5b-e361-4d11-90cf-745dbf589c62	demo-user-001	update	topic	7582eeff-80c4-488b-9beb-64dac57524fe	{"isPublished": true}	2026-05-25 07:48:04.33369
cfbfd789-2e17-4763-850e-7bc425dbb004	demo-user-001	update	topic	8f8f1c76-4248-45ae-a6e1-1e547ac93360	{"isPublished": true}	2026-05-25 07:48:04.65952
5bce8f56-f5c4-4f50-a152-aeef5b5c304b	demo-user-001	update	topic	746dce12-309b-465e-959e-55f209bda77f	{"isPublished": true}	2026-05-25 07:48:05.220435
747fe03c-a504-4622-88bd-91218f017788	demo-user-001	update	topic	15c1919a-8a04-48ae-aa30-3f131d9fea90	{"isPublished": true}	2026-05-25 07:48:06.430825
a6788818-fcff-4a36-b46f-2629c9dc7476	demo-user-001	update	topic	62425119-0192-4c3b-bcbc-6faa09e2ecae	{"isPublished": true}	2026-05-25 07:48:08.327427
5ec3992a-6879-43f0-981b-f196bc9f5de6	demo-user-001	update	topic	64cea85a-0089-4b91-a842-3b7238c6817e	{"isPublished": true}	2026-05-25 07:48:09.671137
22e0dd72-bbef-437d-a42d-413102b8b4b3	demo-user-001	update	topic	a6c8b5fa-ab50-4d0d-bdb1-ca0fe4f6bc31	{"isPublished": true}	2026-05-25 07:48:11.145005
86109f50-b732-4b60-9985-d3728e1c9293	demo-user-001	update	topic	7be2cc15-53f3-44e9-bb80-4bcae28a27dc	{"isPublished": true}	2026-05-25 07:48:11.912124
c05af241-da9c-4a19-a393-5ad32abba2e6	demo-user-001	update	topic	bc3525ef-c84c-494e-aa6f-ad0db374bb40	{"isPublished": true}	2026-05-25 07:48:13.325839
d4bc4a17-3ed9-4a30-9e2a-63bc41d6a9cf	demo-user-001	update	topic	e2b390f7-41f9-40bc-8582-2175ebb9713a	{"isPublished": true}	2026-05-25 07:48:14.296799
15382af3-6080-43e7-979b-d004b5c91727	demo-user-001	update	topic	1eeae14d-911e-47ab-9d9d-6f03aa3d32a8	{"isPublished": true}	2026-05-25 07:48:15.476279
98c19ea4-82dc-44e7-9619-acb0960e1e7a	demo-user-001	update	topic	36543a67-f443-4587-a15c-eeca9409e894	{"isPublished": true}	2026-05-25 07:48:16.885109
0c2f5412-bb95-439d-8b42-4024e95ddca8	demo-user-001	update	topic	90deb252-c4bd-4530-aead-7c88471362b1	{"isPublished": true}	2026-05-25 07:48:17.925138
b642265f-3cf0-4fe8-943c-5171469a32d8	demo-user-001	update	topic	3a9a3b9e-65d9-4484-99b8-0d07a9f2669b	{"isPublished": true}	2026-05-25 07:48:19.090118
a24ebf1d-5d54-423e-90fa-22e8d98f12ee	demo-user-001	update	topic	02539645-a323-4379-8a12-b938ffd1258b	{"isPublished": true}	2026-05-25 07:48:19.924741
f916ee8c-77df-42b5-b78d-d0f5a1eef537	demo-user-001	update	topic	120c0469-0c47-4e82-abb9-26e2351d04db	{"isPublished": true}	2026-05-25 07:48:21.369338
2b5e75d0-e90d-4033-9348-84367633271d	demo-user-001	update	topic	99b47941-82f2-4a74-96b5-829c905c42c4	{"isPublished": true}	2026-05-25 07:48:22.509537
77c878d7-58d7-4a20-8b3c-fdfeb3d004a9	demo-user-001	update	topic	6ecb13ca-9d1d-4898-9e51-b8f381a80b49	{"isPublished": true}	2026-05-25 07:48:23.49857
84592681-1511-4605-83c4-dd6c75e7402f	demo-user-001	update	topic	f4344202-4daa-4199-838b-d9c7e4c729e8	{"isPublished": true}	2026-05-25 07:48:24.144884
880dc6cc-9dd3-4fc2-84cb-c1022b4c59e9	demo-user-001	update	topic	45bbcd5b-01ca-4442-b683-0cf15e90ad6f	{"isPublished": true}	2026-05-25 07:48:25.671946
a31559b3-1bad-4746-9b48-f0133f2c9511	demo-user-001	update	topic	7c60191e-b16a-4043-9001-7aa96deab103	{"isPublished": true}	2026-05-25 07:48:27.66832
10e26315-3ef5-4c80-ab4a-1d87467c8adf	demo-user-001	update	topic	e8fa0cb3-53c4-458f-b5aa-8b55a1b991fe	{"isPublished": true}	2026-05-25 07:48:28.272192
afc61642-562e-480a-97eb-5ded5566271d	demo-user-001	create	topic	438f1d73-bdd9-4ce7-afbc-b4734c091bdb	{"title": "Recurrent pregnancy loss"}	2026-05-25 07:48:52.710097
5aff1ac7-faee-4394-97a1-5c77f5201eec	demo-user-001	create	topic	699010a2-e498-4e40-a2a7-9cd5dc2076c0	{"title": "Ectopic pregnancy "}	2026-05-25 07:49:03.768421
9e814169-fce0-4b5d-8d8b-11dce84a169a	demo-user-001	create	topic	85b212a7-355f-4c2a-8175-e5d1cdb11080	{"title": "Diagnostic algorithms of intrauterine and ectopic pregnancy "}	2026-05-25 07:49:38.354238
3924fea8-56a5-4c27-8a77-6c68e520afa0	demo-user-001	create	topic	e485d0e5-5293-4078-8809-9692e244af8d	{"title": "Gestational trophoblastic diseases"}	2026-05-25 07:50:27.093639
5bf8aafe-2119-4e70-ad28-efd72c983d65	demo-user-001	create	topic	73e4b8e9-97b8-4522-bdbc-60664f4b2b47	{"title": "Management of nausea and vomiting in pregnancy "}	2026-05-25 07:50:51.94943
caf11115-81c5-4e5d-bfd7-f1a003a639f7	demo-user-001	create	topic	6959d14c-bb89-45b6-9fa7-efe1ecbbfad1	{"title": "Evolution in down syndrome screening and CCFDND"}	2026-05-25 07:51:43.573672
53072b9f-deb1-401e-bcf5-c9c52b6d50e8	demo-user-001	create	topic	250ccdc2-184d-4bfe-b1f8-ebd98ae9f550	{"title": "Amniocentesis and CVS"}	2026-05-25 07:51:59.664577
01a147b6-edf7-472c-bcbd-68dc90e1c0ed	demo-user-001	update	topic	250ccdc2-184d-4bfe-b1f8-ebd98ae9f550	{"isPublished": true}	2026-05-25 07:52:03.657559
1ae50275-a51c-4877-9f61-b4bb3c6f94f4	demo-user-001	update	topic	6959d14c-bb89-45b6-9fa7-efe1ecbbfad1	{"isPublished": true}	2026-05-25 07:52:04.366263
840d19c8-d6a3-4238-9b0d-db49c41aa4e3	demo-user-001	update	topic	73e4b8e9-97b8-4522-bdbc-60664f4b2b47	{"isPublished": true}	2026-05-25 07:52:04.814172
4b4e52f9-68f3-4550-adf0-a018894550ed	demo-user-001	update	topic	e485d0e5-5293-4078-8809-9692e244af8d	{"isPublished": true}	2026-05-25 07:52:05.384304
184e7223-b276-4142-85af-a0c7d2c1a005	demo-user-001	update	topic	85b212a7-355f-4c2a-8175-e5d1cdb11080	{"isPublished": true}	2026-05-25 07:52:05.816661
0e14825d-8c55-4228-aa7a-e1462bdc841f	demo-user-001	update	topic	699010a2-e498-4e40-a2a7-9cd5dc2076c0	{"isPublished": true}	2026-05-25 07:52:06.207099
66fd0f2b-2507-43f2-9ba1-c33f7187819b	demo-user-001	update	topic	438f1d73-bdd9-4ce7-afbc-b4734c091bdb	{"isPublished": true}	2026-05-25 07:52:06.717437
51babf65-eb3f-4228-a5d0-17d203a07232	demo-user-001	update	topic	99b47941-82f2-4a74-96b5-829c905c42c4	{"title": "Post operative complications ", "author": "", "description": "Haemorrhage \\nHaematoma \\nWound dehiscence \\nThromboprophylaxix in gynaecology"}	2026-05-25 08:00:05.676884
980e95b3-0714-4a21-8975-1064833ba9b0	demo-user-001	update	topic	99b47941-82f2-4a74-96b5-829c905c42c4	{"isPublished": false}	2026-05-25 08:00:23.379229
ce20d05a-6790-4b80-9ad9-7aa8ed819e87	demo-user-001	update	topic	99b47941-82f2-4a74-96b5-829c905c42c4	{"isPublished": true}	2026-05-25 08:00:25.393533
65ba18ed-b3d3-4d92-b245-f3e95486fe09	demo-user-001	update	topic	99b47941-82f2-4a74-96b5-829c905c42c4	{"title": "Post operative complications ", "author": "", "description": "Haemorrhage \\nHaematoma \\nWound dehiscence \\nThromboprophylaxix in gynaecology\\nDVT\\npelvic abscess\\nAnaesthesia complications \\nVisceral injuries\\nUrinary tract complications \\nBowel complications \\nAcute colonic pseudo obstruction after c section"}	2026-05-25 08:02:32.39885
bc926144-6854-4b2c-a569-f4c736cdd7e8	demo-user-001	update	book	0d859a82-c9fd-47e8-9643-81e3de9588fc	{"isPublished": true}	2026-05-25 08:21:52.639021
85cbfbf1-3530-477f-96c4-8e4f08a2f1e5	demo-user-001	update	book	0d859a82-c9fd-47e8-9643-81e3de9588fc	{"isPublished": true}	2026-05-25 08:21:52.648431
fe3c0254-3390-4746-8b15-471df85f7bdf	demo-user-001	update	chapter	7d80628c-5d83-46e9-922d-ab659f7c0768	{"isPublished": true}	2026-05-25 08:22:00.89936
e5cd25d9-b015-4465-94ce-5f87cfa74d25	demo-user-001	update	chapter	2ce2539d-223c-45e5-90a0-272afedff9e3	{"isPublished": true}	2026-05-25 08:22:03.225078
340bcde2-4a2c-4eef-96a9-9b6428801243	demo-user-001	create	content_block	98a3138e-d8cc-4391-9865-9c3f240ee6e3	\N	2026-05-25 08:28:31.327673
6212543e-cc3c-4fd8-aa9d-c96897ec5708	demo-user-001	create	content_block	45977b90-a115-489c-928d-71ce6e0f5894	\N	2026-05-25 08:45:56.330028
f28f2686-8336-4cb2-873f-c547416fd7ee	demo-user-001	create	content_block	0f4439ca-2ebe-43c2-a92d-280de696e6c8	\N	2026-05-25 08:46:04.125972
16bf225b-5a30-45f5-9371-b786efaff749	demo-user-001	delete	content_block	0f4439ca-2ebe-43c2-a92d-280de696e6c8	\N	2026-05-25 08:46:12.81864
edf41168-8f36-4ac8-abdc-32e79ebd8b99	demo-user-001	delete	content_block	0f4439ca-2ebe-43c2-a92d-280de696e6c8	\N	2026-05-25 08:46:17.723042
6a62f79d-529d-4a94-9ed1-6883b9a2b798	demo-user-001	create	content_block	0f74ff39-29eb-49e1-8bbf-1acb9ef0a424	\N	2026-05-25 08:46:22.585136
9c4b77a0-2530-451e-94af-0bc5c0bd89ea	demo-user-001	create	content_block	9cdc5887-1461-4c73-822f-f1b9c65df801	\N	2026-05-25 08:46:40.37161
62179e83-2c0b-4d8e-b452-5d9fc27d5816	demo-user-001	update	book	46799a77-8be1-457e-bb75-9bee5369ed87	{"isPublished": false}	2026-05-27 07:03:33.219119
f9b31831-4a84-415f-92f9-ee3d147fb7b8	demo-user-001	update	book	0d859a82-c9fd-47e8-9643-81e3de9588fc	{"isPublished": false}	2026-05-27 07:03:35.317597
729291a7-cbfc-460c-b200-6402adb47872	demo-user-001	update	book	46799a77-8be1-457e-bb75-9bee5369ed87	{"isPublished": true}	2026-05-27 07:03:50.685342
e2b82cef-d04d-4a2f-b670-9eaa1c1f6343	demo-user-001	update	book	0d859a82-c9fd-47e8-9643-81e3de9588fc	{"isPublished": true}	2026-05-27 07:03:51.544262
68b192f3-dd18-4610-b4b5-525757e37ec0	demo-user-001	update	book	0d859a82-c9fd-47e8-9643-81e3de9588fc	{"title": "Miscellaneous ", "imageUrl": "", "description": ""}	2026-06-01 07:14:40.858944
4ca49c9e-5c8a-47eb-9ad9-470ac47f0aaa	demo-user-001	update	book	0d859a82-c9fd-47e8-9643-81e3de9588fc	{"title": "Miscellaneous ", "imageUrl": "", "description": ""}	2026-06-01 07:14:57.832327
62a204a4-e92b-40ac-a728-bccde341db2f	demo-user-001	create	topic	20944d53-c138-45a9-a769-c48bd4229f0f	{"title": "what is clinical governance"}	2026-06-01 07:16:42.511438
763f5bdc-3c3c-4489-8b9a-325348629526	demo-user-001	create	topic	9ffb1679-4328-47c6-b6c8-df01cc2337ed	{"title": "clinical effectiveness"}	2026-06-01 07:17:08.814035
0db281f8-ba1c-4adf-8341-bff915d865f1	demo-user-001	create	topic	358587df-8f59-4495-9488-56031c7dbed1	{"title": "clinical audit"}	2026-06-01 07:17:26.968121
7c8696c2-d1a7-4940-b32e-c88a871511d4	demo-user-001	create	topic	451cca65-ae17-4959-bfd9-043a725fa698	{"title": "risk management"}	2026-06-01 07:17:45.348898
4caf5c00-0f44-4d5a-9b8c-d5cf784acce2	demo-user-001	create	topic	524a24bc-11d0-4940-b38b-7510f98c20ef	{"title": "Patient and public involvement PALS"}	2026-06-01 07:18:17.468462
ff58fbb4-bd4e-4626-bad5-360e092553c3	demo-user-001	create	topic	f988c7af-2d0e-47aa-b1a6-ac3a9ec374b6	{"title": "Maternity dashboard"}	2026-06-01 07:18:40.575124
04383c51-db6c-41a2-92d5-f94fc0e44918	demo-user-001	update	topic	20944d53-c138-45a9-a769-c48bd4229f0f	{"title": "What is clinical governance", "author": "", "description": "", "isPublished": true}	2026-06-01 07:18:50.233178
593e9835-cdea-4290-a609-308c3213b48c	demo-user-001	update	topic	9ffb1679-4328-47c6-b6c8-df01cc2337ed	{"title": "Clinical effectiveness", "author": "", "description": "", "isPublished": true}	2026-06-01 07:18:59.126538
30eaab8f-e489-44a4-8e48-f1a4a35033f9	demo-user-001	update	topic	358587df-8f59-4495-9488-56031c7dbed1	{"title": "Clinical audit", "author": "", "description": "", "isPublished": true}	2026-06-01 07:19:08.602341
20a49742-2ad1-40c3-a6e8-5a627c2a86e5	demo-user-001	update	topic	451cca65-ae17-4959-bfd9-043a725fa698	{"title": "Risk management", "author": "", "description": "", "isPublished": true}	2026-06-01 07:19:18.072263
03cace4d-a14b-46d3-9dab-bd25a9e10991	demo-user-001	update	topic	20944d53-c138-45a9-a769-c48bd4229f0f	{"isPublished": false}	2026-06-01 07:19:28.512216
e5891d53-7fc5-465d-8ca8-77cb822db429	demo-user-001	update	topic	9ffb1679-4328-47c6-b6c8-df01cc2337ed	{"isPublished": false}	2026-06-01 07:19:32.012814
69c1e569-35ed-414f-ba81-44febf6279c9	demo-user-001	update	topic	9ffb1679-4328-47c6-b6c8-df01cc2337ed	{"isPublished": true}	2026-06-01 07:19:35.567674
95dcdc52-fa98-4c07-8da5-5abd7efa96aa	demo-user-001	update	topic	20944d53-c138-45a9-a769-c48bd4229f0f	{"isPublished": true}	2026-06-01 07:19:37.587969
21f16b43-1f77-49a3-934d-e0a1119fbea6	demo-user-001	update	topic	20944d53-c138-45a9-a769-c48bd4229f0f	{"isPublished": false}	2026-06-01 07:19:39.183383
d8956f60-6e86-4d6b-ae25-48318c1ce46f	demo-user-001	update	topic	20944d53-c138-45a9-a769-c48bd4229f0f	{"isPublished": true}	2026-06-01 07:19:55.851926
3045d51c-2ac0-4db5-8ec6-4be7f97ec11b	demo-user-001	create	content_block	d33e609b-74bb-457a-a7df-da7b5106b436	\N	2026-06-01 07:34:06.840743
4538c620-ed9f-4203-8ea0-1fd9009e8733	demo-user-001	create	content_block	e1715d6c-8565-44e4-8e51-6f870aa55e80	\N	2026-06-01 07:34:06.863051
9db65a2e-f26e-4a17-b8ac-686bcaaebc38	demo-user-001	create	content_block	d6f23bda-839d-4ea7-a572-96f608443dd6	\N	2026-06-01 07:35:03.069152
970ef2fe-57f0-468b-86a4-b01415c5d0df	demo-user-001	create	content_block	dd268f1c-4fe8-42b6-818d-15be5d721fce	\N	2026-06-01 07:35:42.641244
9bcab1bf-9882-4bb5-bcb2-931d39d6f0a6	demo-user-001	delete	content_block	dd268f1c-4fe8-42b6-818d-15be5d721fce	\N	2026-06-01 07:36:27.679526
4632ef84-1c6d-40e4-bf5b-118ee6836ffd	demo-user-001	create	content_block	682df4bb-e266-4c64-b0f8-89915dcdaf1d	\N	2026-06-01 07:36:31.179788
61536d24-1fab-4cc6-8c03-8af18e806833	demo-user-001	delete	content_block	682df4bb-e266-4c64-b0f8-89915dcdaf1d	\N	2026-06-01 07:36:37.371332
e63b3ddf-c343-41c7-a912-7e2c74cc282c	demo-user-001	create	content_block	e76bd470-d02b-4567-9908-3cd8192d0100	\N	2026-06-01 07:36:49.252719
4eb59b4e-6c26-4b0e-9e9c-1ec4c0106dda	demo-user-001	delete	content_block	e76bd470-d02b-4567-9908-3cd8192d0100	\N	2026-06-01 07:37:14.861406
3a133180-fc77-49f5-9c07-d17bc5d5aae6	demo-user-001	delete	content_block	e76bd470-d02b-4567-9908-3cd8192d0100	\N	2026-06-01 07:37:15.069923
a55dc810-d6ca-4565-a3be-86fe19582620	demo-user-001	create	content_block	706b025f-99f7-4521-bfda-adfe4f7f4e88	\N	2026-06-01 07:37:21.712977
4809a852-6092-4b8b-8b70-3c3f5dd3eb00	demo-user-001	create	content_block	38402271-dad1-4b40-a2cb-7fce95595b74	\N	2026-06-01 07:42:58.051528
d4025b58-6011-473b-b5a2-118095827a0e	demo-user-001	delete	content_block	38402271-dad1-4b40-a2cb-7fce95595b74	\N	2026-06-01 07:43:17.826582
0fa595b1-394e-41ad-96e8-abac23e3db53	demo-user-001	delete	content_block	706b025f-99f7-4521-bfda-adfe4f7f4e88	\N	2026-06-01 07:43:32.328434
250117df-adee-48fd-97ab-a0a3256697f2	demo-user-001	create	content_block	650a1d27-9fee-4d86-9e29-daa99bfc7335	\N	2026-06-01 07:43:48.3479
97174442-c9d0-4684-a16a-6832153de073	demo-user-001	delete	content_block	650a1d27-9fee-4d86-9e29-daa99bfc7335	\N	2026-06-01 07:44:04.700855
6e7deaa2-555d-4ffd-a5cc-d1ed8102d713	demo-user-001	create	content_block	4e0447cd-4316-4da8-a296-faea36476888	\N	2026-06-01 07:44:14.20839
2b068c74-1dd7-4c42-9325-a7d8c82f24cc	demo-user-001	update	content_block	20944d53-c138-45a9-a769-c48bd4229f0f	"Batch saved 4 blocks"	2026-06-01 07:48:03.646098
99909093-3fb6-4275-bf8f-6f458624094c	demo-user-001	create	content_block	226a28c5-b9ab-4e67-bc6e-0e940e9cc5f8	\N	2026-06-01 07:48:36.590971
58a8bf2e-c380-406d-9a53-e65ecdbf0ecf	demo-user-001	create	content_block	7b7771e7-dd92-406a-afce-b495146bc161	\N	2026-06-01 07:48:57.625142
29a60dbe-7dff-46ac-adf7-ee339254211c	demo-user-001	create	content_block	18488a94-f7b9-4b11-a9b0-3cb4cb9d2caf	\N	2026-06-01 07:49:36.267639
5870731e-af20-48cf-a128-5baf2daead9c	demo-user-001	create	content_block	d199f37b-490a-4e98-a68f-5612e1fa3651	\N	2026-06-01 07:50:20.003794
f19d5181-0e1c-4b22-8427-e236aed03401	demo-user-001	update	content_block	9ffb1679-4328-47c6-b6c8-df01cc2337ed	"Batch saved 4 blocks"	2026-06-01 07:52:08.591576
ff79f458-921a-41ef-b67d-c870908ccf70	demo-user-001	update	content_block	9ffb1679-4328-47c6-b6c8-df01cc2337ed	"Batch saved 0 blocks"	2026-06-01 07:52:15.916165
3d894e05-8bcd-4607-a85a-6f75a6f853a5	demo-user-001	create	content_block	2f70f67a-22f2-444c-956e-c0ea2e175d6c	\N	2026-06-01 07:53:45.317253
de7c3e8f-2707-4180-bc27-4d397de9377f	demo-user-001	create	content_block	4389e8f2-2fdc-4a1b-80a1-ba92f1168ae1	\N	2026-06-01 07:53:45.33753
6fe1a7e1-50d1-4d30-99c2-febbc89b1a6f	demo-user-001	create	content_block	30d47e4e-57c8-4ff2-b1c8-403414873fd6	\N	2026-06-01 07:54:25.669061
c39b5a15-9eed-46ee-8c95-9e09180e3703	demo-user-001	create	content_block	fe4aacb8-ceee-453e-987e-d5833e59610c	\N	2026-06-01 07:54:43.881104
c11b734c-9b9c-4d18-ab7d-29ae251688d1	demo-user-001	create	content_block	1d6e3d47-62f1-42ca-8af7-4a505c774178	\N	2026-06-01 07:55:20.445532
5e28e59e-5c72-4b08-a273-94b788144b4d	demo-user-001	create	content_block	d9f7c6c1-2cb3-4a56-97cf-a5aa50ab6b2d	\N	2026-06-01 07:55:43.896727
428d55fe-9b42-4806-98a2-5a8c93ec978b	demo-user-001	delete	content_block	d9f7c6c1-2cb3-4a56-97cf-a5aa50ab6b2d	\N	2026-06-01 07:55:54.02974
ebbe32eb-c475-4038-9252-69bb38225dfe	demo-user-001	create	content_block	47e016af-83cb-4482-84bc-9d3ac779e149	\N	2026-06-01 07:56:01.141949
c799dfc5-e959-457f-9d57-ce519b108b23	demo-user-001	create	content_block	90cc2add-1952-4e65-9965-8e456bee902d	\N	2026-06-01 07:57:00.602595
5d504cbf-21dd-42e6-a0f8-309fd3b2665a	demo-user-001	update	content_block	358587df-8f59-4495-9488-56031c7dbed1	"Batch saved 7 blocks"	2026-06-01 07:57:43.337064
3332c7c6-c16e-4848-9efc-6bcf262e8c6a	demo-user-001	update	topic	20944d53-c138-45a9-a769-c48bd4229f0f	{"isPublished": false}	2026-06-01 07:57:57.840737
beff499e-f370-4872-9213-a267dd468348	demo-user-001	update	topic	20944d53-c138-45a9-a769-c48bd4229f0f	{"isPublished": true}	2026-06-01 07:57:59.848462
edb90608-bfbc-4a04-a18e-4e6796ff1e09	demo-user-001	update	topic	9ffb1679-4328-47c6-b6c8-df01cc2337ed	{"isPublished": false}	2026-06-01 07:58:02.42388
6f0e4e4d-4f7d-40f5-bcf4-340670cea3ef	demo-user-001	update	topic	9ffb1679-4328-47c6-b6c8-df01cc2337ed	{"isPublished": true}	2026-06-01 07:58:04.262456
b45b5ff6-c903-47f8-a051-1820252b5f60	demo-user-001	create	content_block	75e87bf5-3e74-4312-847f-caecfeb69108	\N	2026-06-01 07:58:46.133962
43bc72e6-bd7a-4199-80fe-6b44ca2b8e00	demo-user-001	create	content_block	0cfdecc9-d1b6-4aa2-a5de-67d061bee571	\N	2026-06-01 07:59:12.91809
9b23028b-b419-446a-ac96-65cd92bc82c3	demo-user-001	create	content_block	5a76e23b-e792-425e-9b91-e135a557cc4d	\N	2026-06-01 07:59:22.908547
792c88f6-8576-47da-ab0e-2a602f632aa5	demo-user-001	create	content_block	72a270c2-1a51-4040-8c26-507b5ea21242	\N	2026-06-01 08:02:30.048154
8aac3894-5d44-47e2-9999-39bcc5cbbebc	demo-user-001	update	content_block	451cca65-ae17-4959-bfd9-043a725fa698	"Batch saved 4 blocks"	2026-06-01 08:04:32.845464
efd075c9-909a-40dd-a4f1-7307d65be83e	demo-user-001	update	content_block	451cca65-ae17-4959-bfd9-043a725fa698	"Batch saved 0 blocks"	2026-06-01 08:04:38.074592
4bb7c75b-53a8-4fab-a1ba-6568c04ea6fc	demo-user-001	create	content_block	4faffda8-640e-4aa2-927c-d0b871b1618f	\N	2026-06-01 08:11:03.406011
b7eb9caf-2191-4d22-943a-19a95cd45c2c	demo-user-001	create	content_block	f61d78d8-d874-4e63-96d8-0ec040588528	\N	2026-06-01 08:11:32.523255
f4a75155-2135-4121-9a32-b155af77e2ba	demo-user-001	create	content_block	6b88cef3-4e11-41a4-aa6a-538ed371f393	\N	2026-06-01 08:12:40.473051
3a075e35-5b01-40c0-8cb5-9f96bc6813b9	demo-user-001	create	content_block	dc147b8a-b9c1-4b17-aea8-315d3a0a020c	\N	2026-06-01 08:13:11.069398
687496c5-ae71-456b-bb12-3a14c2e59ece	demo-user-001	create	content_block	ad6c2cc3-a584-43f1-9bfe-f2de09b14d51	\N	2026-06-01 08:14:37.057177
c10feb9b-da3f-4de7-b8ad-a32f9b4d32a3	demo-user-001	delete	content_block	ad6c2cc3-a584-43f1-9bfe-f2de09b14d51	\N	2026-06-01 08:14:54.245568
767d19f8-590b-4ac2-93a1-2bd51dd0d0b7	demo-user-001	create	content_block	4115f6af-73c2-4e06-9528-c5d94096e723	\N	2026-06-01 08:16:30.042521
0e1f25c4-f8b6-4719-974b-5873d90ef5e7	demo-user-001	update	content_block	451cca65-ae17-4959-bfd9-043a725fa698	"Batch saved 5 blocks"	2026-06-01 08:17:45.310856
79537fb2-46e0-4697-b9e3-3219147bc915	demo-user-001	create	content_block	f4eadd56-7586-4d84-b94b-37c19f8716eb	\N	2026-06-01 08:19:00.408955
33a4a33f-7847-4b7a-9a48-38329112cc5b	demo-user-001	create	content_block	d207a022-2947-477c-9715-f66316932d62	\N	2026-06-01 08:19:20.511743
4254ec87-37c4-4bf6-8dcb-1af1d13eb149	demo-user-001	create	content_block	becc671c-4793-42cb-a7de-36949facb3cd	\N	2026-06-01 08:19:30.073423
2863067f-530e-477a-bab2-100dae924d7b	demo-user-001	create	content_block	a01d5ca8-3609-4a5e-84c6-33df42edc296	\N	2026-06-01 08:19:56.007131
5c92b6f2-f92b-4ca3-a115-2e2039d9e925	demo-user-001	create	content_block	02b2c0ea-0fe6-4b61-9f85-2905726da769	\N	2026-06-01 08:20:19.05343
237edd26-9516-4620-ba53-d10b4144704d	demo-user-001	create	content_block	171e05c2-637e-4f02-af68-b475a02fa10b	\N	2026-06-01 08:20:58.549236
a6cc44d4-4675-4f2a-8ab8-570b3c590201	demo-user-001	create	content_block	f48335f5-7b2f-479f-a58f-b00fe3b5232c	\N	2026-06-01 08:21:23.01253
0368fba6-85d7-4011-8a51-9e42a4f8b0ec	demo-user-001	update	content_block	524a24bc-11d0-4940-b38b-7510f98c20ef	"Batch saved 7 blocks"	2026-06-01 08:22:18.249493
041cd174-2a06-43a4-8cf5-d4918e85d372	demo-user-001	create	content_block	a3561102-3cc6-443e-ba20-3f8486554f81	\N	2026-06-01 08:23:02.448965
9ff82325-9076-43d7-b04d-2337375726e2	demo-user-001	create	content_block	5d7dfbd3-93a3-490d-9914-4a33e9bf9217	\N	2026-06-01 08:23:11.636796
51ddbe62-9724-47b5-af58-4e92cc8e81d7	demo-user-001	create	content_block	f0e27681-9a00-45b3-b66a-f8723d0537a6	\N	2026-06-01 08:24:56.131009
f5c1268c-ae45-4eff-9ebd-818da114f2e1	demo-user-001	create	content_block	c4418760-b1d9-454c-a97f-a3eac86cc8e1	\N	2026-06-01 08:25:08.131209
9b08e94e-4ef7-43df-9b7e-c3c1fe9f2729	demo-user-001	create	content_block	1232b4aa-5b81-4272-8439-e46aeffcb8c8	\N	2026-06-01 08:25:57.361899
26bb4e11-1fcd-4b35-8747-9e4333dfc7e2	demo-user-001	create	content_block	3ab65373-0cdb-422d-a11b-006904770c32	\N	2026-06-01 08:26:09.69727
a8cf2f97-3437-4fda-b1d1-408446cf68eb	demo-user-001	update	content_block	f988c7af-2d0e-47aa-b1a6-ac3a9ec374b6	"Batch saved 6 blocks"	2026-06-01 08:27:06.532992
791ea8c4-e234-47fd-bcc5-dc47144a80dd	demo-user-001	update	topic	358587df-8f59-4495-9488-56031c7dbed1	{"isPublished": false}	2026-06-01 08:27:19.088856
9f71bc1f-db0a-434c-bbb2-c2b35de32622	demo-user-001	update	topic	358587df-8f59-4495-9488-56031c7dbed1	{"isPublished": true}	2026-06-01 08:27:20.657169
bd4d1aab-7e68-497d-8736-293bd0391547	demo-user-001	update	topic	451cca65-ae17-4959-bfd9-043a725fa698	{"isPublished": false}	2026-06-01 08:27:23.787385
2b936ea2-772d-43fe-8e6b-854875e92d39	demo-user-001	update	topic	451cca65-ae17-4959-bfd9-043a725fa698	{"isPublished": true}	2026-06-01 08:27:25.549117
4c97cd66-c91b-42bd-b646-4254e461aa9a	demo-user-001	update	topic	524a24bc-11d0-4940-b38b-7510f98c20ef	{"isPublished": false}	2026-06-01 08:27:27.907607
334c696a-6568-465a-b8c6-fc6397a94203	demo-user-001	update	topic	524a24bc-11d0-4940-b38b-7510f98c20ef	{"isPublished": true}	2026-06-01 08:27:29.224628
af131a09-6bd3-4e1c-bec0-ed22471421c4	demo-user-001	create	topic	594220af-32d7-4d00-98ad-a2c733d4be33	{"title": "Teaching methods"}	2026-06-01 08:28:21.51566
ca4110c1-3634-43ac-98a6-c46eebf1be05	demo-user-001	create	topic	4dc9b993-9478-4088-80c5-3996d53748b8	{"title": "Induction interview/Apparaisal"}	2026-06-01 08:29:03.702172
3703d753-06b4-49ee-994d-0a10b36b72f4	demo-user-001	create	topic	95a94798-0d07-48c4-8238-f06aa0c591d5	{"title": "Work base assessment tools"}	2026-06-01 08:29:31.091816
63ef2922-ab66-457b-8f45-945dfbe14910	demo-user-001	create	topic	259577e9-5acd-4b6b-99a6-21ec4c50b261	{"title": "ARCP"}	2026-06-01 08:29:47.191037
118d2963-29e4-43b1-8e0b-7fba0093b109	demo-user-001	create	topic	7fed75f0-8cf4-4815-ac45-ba31b34bd30f	{"title": "Appraisal vs Revalidation"}	2026-06-01 08:30:13.800631
4111d10a-a2ef-44d2-8d56-d2cba553406e	demo-user-001	create	topic	5781eae1-5283-4b6e-8153-2313e29501a6	{"title": "Reflection"}	2026-06-01 08:30:30.180611
1aac0290-4cd2-4bb5-9d47-bd2f6a68e12f	demo-user-001	create	content_block	89a44e91-be6e-4f6c-8e5c-c1e01374e708	\N	2026-06-01 08:37:10.693449
11b5aef8-c5f5-4d4e-989e-52e191dd6f3b	demo-user-001	create	content_block	ec02c9f7-89f8-4fba-9602-e360ecf69747	\N	2026-06-01 08:37:18.823801
e598c9d3-8a5d-4842-84a6-59632b230361	demo-user-001	create	content_block	77862d3e-8489-4597-b7ec-66413350e5b2	\N	2026-06-01 08:37:40.335409
5c4c22b0-f795-4e04-9ff6-4f0c0ded81fb	demo-user-001	create	content_block	8a349285-7d12-4de5-94b4-fad5d0f27153	\N	2026-06-01 08:38:06.819575
11d95622-4973-43b7-8849-bd3deddca509	demo-user-001	update	content_block	594220af-32d7-4d00-98ad-a2c733d4be33	"Batch saved 4 blocks"	2026-06-01 08:41:04.243847
7d6c437e-0306-42d8-b118-31bf9a2b4c44	demo-user-001	update	content_block	594220af-32d7-4d00-98ad-a2c733d4be33	"Batch saved 0 blocks"	2026-06-01 08:41:05.044536
269192e5-978b-4610-a82d-20dab0f8e1ba	demo-user-001	create	content_block	3fa79c27-957c-40c8-be7d-fda50d134502	\N	2026-06-01 08:42:38.740012
9c1f8fc8-d4ee-4ec3-93ba-a59a1d5e25b4	demo-user-001	create	content_block	bd346de5-f17f-4429-a96c-3251873805d1	\N	2026-06-01 08:42:46.888348
738e0f31-0806-47ae-ad4f-c343e7e55e01	demo-user-001	update	content_block	4dc9b993-9478-4088-80c5-3996d53748b8	"Batch saved 2 blocks"	2026-06-01 08:43:10.765191
05650863-5eae-4fe1-9007-efd8c367997f	demo-user-001	create	content_block	5449f1f4-75fc-4394-a9b5-b3fddbd20a24	\N	2026-06-01 08:43:28.709791
9a51e980-e447-417b-a9b1-9147b3b33fac	demo-user-001	create	content_block	716a8319-cd82-48c2-8606-aeb37f2b78f1	\N	2026-06-01 08:44:28.493563
95ef16da-9415-4529-bcfc-03b524f18f6d	demo-user-001	create	content_block	d0d64817-b6d3-43f2-b7e0-f30cef141c36	\N	2026-06-01 08:44:46.474991
dd7d6390-57fd-4c38-a3ea-5f5fbe4affd2	demo-user-001	create	content_block	892c1734-d565-4d2d-a2e6-ca22e239e7c9	\N	2026-06-01 08:45:29.55721
ea8cca97-4fb3-479d-9f2f-4b6b171d21e8	demo-user-001	create	content_block	411daf8e-869e-4d70-b02b-0e39540c41b2	\N	2026-06-01 08:47:33.128642
df143222-a012-46fa-a23f-b8a2adfd04d6	demo-user-001	update	content_block	95a94798-0d07-48c4-8238-f06aa0c591d5	"Batch saved 5 blocks"	2026-06-01 08:49:10.858583
e80dcf22-1d22-418b-849e-126248582b99	demo-user-001	update	content_block	95a94798-0d07-48c4-8238-f06aa0c591d5	"Batch saved 1 blocks"	2026-06-01 09:17:23.842187
4233f21f-363c-4018-abd8-b6f6fa6823ee	demo-user-001	update	content_block	95a94798-0d07-48c4-8238-f06aa0c591d5	"Batch saved 0 blocks"	2026-06-01 09:35:25.220666
b1c9d972-6da2-4e1a-a340-5be1548b62cf	demo-user-001	create	content_block	bf619087-3d1e-4db3-bed5-f69e63f00d9e	\N	2026-06-01 09:35:59.431117
680cbd9b-9e24-4b7e-8d97-cf96c2573ffc	demo-user-001	update	content_block	259577e9-5acd-4b6b-99a6-21ec4c50b261	"Batch saved 1 blocks"	2026-06-01 09:36:11.444165
3aa53825-8f9e-48d0-9cb7-1da2036ea290	demo-user-001	create	content_block	e184d824-25ce-4fc2-8e82-bc5801c11267	\N	2026-06-01 09:36:46.333067
9061f49b-de12-47a7-9e02-5b56ff7fb198	demo-user-001	update	content_block	7fed75f0-8cf4-4815-ac45-ba31b34bd30f	"Batch saved 1 blocks"	2026-06-01 09:36:53.90554
2018dc43-6f97-4fb7-a024-a8d82554b007	demo-user-001	create	content_block	b522eb20-fea7-44e0-9dcc-b5f325e966e1	\N	2026-06-01 09:37:05.700817
1016212b-e586-435b-80f9-90cd4a178c77	demo-user-001	update	content_block	5781eae1-5283-4b6e-8153-2313e29501a6	"Batch saved 1 blocks"	2026-06-01 09:37:23.811632
13b9e84e-8f41-46ff-99d1-2935d76fcf4a	demo-user-001	update	content_block	5781eae1-5283-4b6e-8153-2313e29501a6	"Batch saved 0 blocks"	2026-06-01 09:37:32.31414
89bf1702-66b8-42c9-a540-202ddb893734	demo-user-001	create	content_block	4d13a544-8a13-41e1-9822-a8f2d2389e67	\N	2026-06-01 16:34:07.34723
c891fc46-2662-4cb0-874d-08bbc7b512d6	demo-user-001	create	content_block	79d88782-be8b-4773-9f17-1a857dfd549a	\N	2026-06-01 16:36:38.815721
b8e202f8-9df9-43bf-9a71-c21053e4f974	demo-user-001	update	content_block	250ccdc2-184d-4bfe-b1f8-ebd98ae9f550	"Batch saved 2 blocks"	2026-06-01 16:42:26.839432
38f810ae-f6cc-44f6-8ba0-6571fa515be2	demo-user-001	update	announcement	f9792e51-96d6-42aa-9937-8ded35758fb8	\N	2026-06-02 03:06:57.160293
c7d69ad4-cd17-4585-a1fa-ca6010010eab	demo-user-001	create	topic	9650ce9e-7f49-4a44-a5eb-1c56270bb0ad	{"title": "Post partum haemorrhage"}	2026-06-02 05:55:40.879674
a24fca21-e232-40d9-ae4a-7dfa8134a502	demo-user-001	create	topic	669a30c3-59e4-449e-b89d-1997522e1808	{"title": "3rd and 4th degree perineal tear"}	2026-06-02 05:56:50.667454
71904e78-4412-4e7d-9e75-3adcdf79c96a	demo-user-001	create	topic	ae07ff0d-4682-4df5-bd7d-f6067bd7b664	{"title": "vulval haematoma"}	2026-06-02 05:57:18.876131
d5c7c177-1070-45a7-ace9-3d02f08d8478	demo-user-001	update	topic	ae07ff0d-4682-4df5-bd7d-f6067bd7b664	{"title": "Vulval haematoma", "author": "", "description": "", "isPublished": true}	2026-06-02 05:58:41.324512
43a33944-2873-422b-8a0e-aff3f9e9cf2c	demo-user-001	create	topic	70afe946-2149-4948-bb0f-2d48fd2d08f4	{"title": "Post partum mastitis"}	2026-06-02 06:01:03.1614
42fdc9d6-1ebc-420d-b154-a03d066e4c70	demo-user-001	create	topic	06c82d3c-6651-48c2-8444-2362025f8f0c	{"title": "Post partum urinary retention PUR"}	2026-06-02 06:04:12.600054
9c18b0f1-759c-4597-ae77-1603ce35aa46	demo-user-001	create	topic	c4a99f45-fa0e-43c8-b7b6-90ef39b35144	{"title": "Maternal mental health"}	2026-06-02 06:25:18.554566
30b7cb16-faab-4b1e-88f1-8f0f9c400808	demo-user-001	create	topic	4328293d-d18c-43da-aed5-00d22a4c8b76	{"title": "Post partum contraception"}	2026-06-02 06:27:45.750336
29a21ecb-8718-46db-95fb-443c1261c982	demo-user-001	create	topic	b1c1aa64-a82b-49bf-b379-6c7753bee96e	{"title": "Maternal mortality"}	2026-06-02 06:29:15.484663
fdee0366-37bf-4e7d-ba83-589e9ddefce1	demo-user-001	create	topic	c7957bdf-9cd1-4ab8-99a9-ba170eff34a7	{"title": "MBRRACE"}	2026-06-02 06:29:35.163526
b9dabcee-cbf9-4f84-aea1-c03160da1f8d	demo-user-001	update	topic	9650ce9e-7f49-4a44-a5eb-1c56270bb0ad	{"isPublished": false}	2026-06-02 06:29:56.232231
afcb6647-1155-4580-abf8-130111b822cf	demo-user-001	update	topic	9650ce9e-7f49-4a44-a5eb-1c56270bb0ad	{"isPublished": true}	2026-06-02 06:30:00.486153
b3538343-6dd8-48d8-887f-f9104740b575	demo-user-001	create	content_block	983afaa4-3589-4782-9148-d46d413cff61	\N	2026-06-02 06:30:40.321109
563ca500-2fa6-4cea-86a6-7dec35146907	demo-user-001	create	content_block	eb3b4b6a-d721-494e-9eb7-6ade2c351179	\N	2026-06-02 06:31:22.775342
db99e693-fe11-45bf-ba8f-c4495dcaf1e4	demo-user-001	delete	content_block	eb3b4b6a-d721-494e-9eb7-6ade2c351179	\N	2026-06-02 06:32:48.436754
1d9ec2f3-2aa1-4aec-b0b0-b9a7d587357f	demo-user-001	create	content_block	d2c13d39-8cd8-410d-b6a8-01e499f52bb2	\N	2026-06-02 06:32:55.694342
9064e580-749f-4e2c-9c82-ef8261d30faf	demo-user-001	create	content_block	4cca000f-6a79-4ab6-a55c-358e57470940	\N	2026-06-02 06:33:30.423252
cd494b3b-01ff-48c4-b54b-9b4d4cec5ae5	demo-user-001	create	content_block	dda41d86-032b-43ab-acf6-9996b9d6f4b0	\N	2026-06-02 06:33:51.805757
f0ae5a54-ad95-4b4c-ab49-14fa724707a2	demo-user-001	create	content_block	2fe14304-d870-4974-af82-bf4f9dec75e9	\N	2026-06-02 06:34:15.375371
81749d4d-b606-4e01-9455-2348cc519862	demo-user-001	delete	content_block	2fe14304-d870-4974-af82-bf4f9dec75e9	\N	2026-06-02 06:34:21.881431
4e981908-444d-4132-aab4-7f0e6c041550	demo-user-001	create	content_block	bc83b602-d2f3-4526-8724-01227cef3662	\N	2026-06-02 06:34:28.176233
b2fc7bb8-e1a1-4907-ad04-633511f6e288	demo-user-001	create	content_block	a7cadba6-792e-4819-a2c6-0cc5c1773e13	\N	2026-06-02 07:33:28.616603
9e9a1f72-afbb-4b9b-a4dc-94fa08533da7	demo-user-001	create	content_block	428e96aa-533e-45bd-81e9-470ab3fd2d34	\N	2026-06-02 07:34:00.238055
5e465c38-6e68-4151-be43-155160a710fd	demo-user-001	create	content_block	1e053d4b-e452-4a09-b5eb-674ffe72a415	\N	2026-06-02 07:35:41.91994
0347d260-7118-4ebb-8aec-e7727db87d26	demo-user-001	create	content_block	973f02d3-838b-4167-90fe-5bceec0d65ec	\N	2026-06-02 07:36:07.284154
7b46f939-a198-498b-afc7-39d6bfd69f9f	demo-user-001	create	content_block	54d6beb4-838f-4e15-bbcd-48af15bcd2bc	\N	2026-06-02 07:41:00.700287
93252f5c-8617-4a80-a2cc-9fcbd1721366	demo-user-001	create	content_block	55ffbdca-c5b5-482b-8c86-c697cecec647	\N	2026-06-02 07:41:24.537221
fe08893b-9bae-4ee9-ab4c-f4707b6e8080	demo-user-001	create	content_block	f7289a32-29e3-4e29-a5ed-8f1a60768fa4	\N	2026-06-02 07:59:34.012638
1cda3da8-60fc-45d8-8e07-4867fe58ff0a	demo-user-001	update	content_block	9650ce9e-7f49-4a44-a5eb-1c56270bb0ad	"Batch saved 12 blocks"	2026-06-02 08:02:13.867833
de5cf7dd-b61f-4bd8-b5be-c3a3c059ce4d	demo-user-001	update	content_block	9650ce9e-7f49-4a44-a5eb-1c56270bb0ad	"Batch saved 0 blocks"	2026-06-02 08:03:41.232335
243e2fdd-848f-4a15-bc70-b6447cb2d56e	demo-user-001	create	content_block	8f1aad96-ab51-45c8-a96f-cfc626ca2849	\N	2026-06-02 08:04:34.337767
6a39d48b-e49c-48d7-a77b-b8ef7ee8d672	demo-user-001	update	content_block	669a30c3-59e4-449e-b89d-1997522e1808	"Batch saved 1 blocks"	2026-06-02 08:46:53.603875
121fec8a-fdf7-4b60-8889-e957354c5689	demo-user-001	create	content_block	d3107792-f134-4f4c-9653-3dd53090e364	\N	2026-06-02 08:47:50.520924
be66dd35-7cbd-4956-9ff1-259ab0ba8fa3	demo-user-001	update	content_block	ae07ff0d-4682-4df5-bd7d-f6067bd7b664	"Batch saved 1 blocks"	2026-06-02 09:20:10.039613
e6b93776-96f5-4ca4-8ad9-9ba64fea1f54	demo-user-001	create	content_block	9b8f0b8b-8497-4001-8078-f1cb04f1b696	\N	2026-06-02 09:21:00.492141
aab911c1-4b4f-49f5-9121-9cd140c370b7	demo-user-001	update	content_block	70afe946-2149-4948-bb0f-2d48fd2d08f4	"Batch saved 1 blocks"	2026-06-02 09:24:02.464427
ea6ef198-5434-43fe-b14e-028142f70726	demo-user-001	create	content_block	53cc50dd-a04b-44df-846b-5fe30319ae73	\N	2026-06-02 09:24:14.117922
36c30960-ccea-4c55-86bc-63ab40e20075	demo-user-001	create	content_block	f0f616b7-9665-450d-b711-5a73fe219d0f	\N	2026-06-05 07:48:19.021969
c309fdc6-3482-4a18-8714-db5ee547c61d	demo-user-001	delete	content_block	4e0447cd-4316-4da8-a296-faea36476888	\N	2026-06-06 07:18:38.068138
69cfe69d-cec6-4bcb-9342-23d07295fa3d	demo-user-001	create	content_block	2e6d429f-3abe-419e-add8-9a89e7539239	\N	2026-06-06 07:18:42.559068
7d78877f-40e3-4f83-8fe2-8a77b9b6328d	demo-user-001	delete	content_block	2e6d429f-3abe-419e-add8-9a89e7539239	\N	2026-06-06 07:19:19.346657
71796283-b819-4e4d-a5dc-4760c5944e15	demo-user-001	create	content_block	70f18485-9743-4e84-9a13-732436989dfe	\N	2026-06-06 07:19:26.302778
0709e944-72d7-42e9-bacb-fa85da4bd43a	demo-user-001	delete	content_block	70f18485-9743-4e84-9a13-732436989dfe	\N	2026-06-06 07:21:24.020056
9928283e-82ce-401d-882b-7db4d851965a	demo-user-001	create	content_block	e17e1f6d-26ad-42dd-827c-d85f621a7eb4	\N	2026-06-07 16:22:51.511277
108eb1f7-b003-495c-952c-988fd7d0d216	demo-user-001	update	content_block	ae07ff0d-4682-4df5-bd7d-f6067bd7b664	"Batch saved 2 blocks"	2026-06-07 16:26:29.917658
8f12deee-b81d-4ece-8107-d936a47cb100	demo-user-001	update	content_block	06c82d3c-6651-48c2-8444-2362025f8f0c	"Batch saved 1 blocks"	2026-06-07 16:38:34.532539
bcaa6aca-3fbd-411f-b6d9-661f14d4e22b	demo-user-001	create	content_block	e08a1d44-a97a-4821-9c47-cb34ecf0364c	\N	2026-06-07 16:40:31.993972
8576e707-9645-42dc-88bd-abde408bae3c	demo-user-001	update	content_block	4328293d-d18c-43da-aed5-00d22a4c8b76	"Batch saved 1 blocks"	2026-06-07 16:40:46.777684
deaf8e42-5d2e-4536-bddf-c632307c9fca	demo-user-001	update	content_block	4328293d-d18c-43da-aed5-00d22a4c8b76	"Batch saved 1 blocks"	2026-06-07 16:44:07.075594
1e224035-6392-4c15-b3dc-374a5e4ec626	demo-user-001	create	content_block	ab3f9bd8-5c62-460c-981e-579642ec5b10	\N	2026-06-07 16:45:12.007026
94be5915-5715-4480-b39e-506565835c97	demo-user-001	update	content_block	c4a99f45-fa0e-43c8-b7b6-90ef39b35144	"Batch saved 1 blocks"	2026-06-07 16:47:32.735504
77f62a05-c8ae-4594-8cbc-7e228095a27a	demo-user-001	create	content_block	5bbc8163-b032-44e4-82ee-773c4e68f0c4	\N	2026-06-07 16:48:48.261646
c8c947fc-455b-4ed9-8b2a-d6c14ce76aef	demo-user-001	create	content_block	4c670b76-fd23-4928-bd59-8a80e883640b	\N	2026-06-07 16:49:49.913361
0d6bf7a2-2d98-4f70-86e2-93b124ffff8c	demo-user-001	create	content_block	50b5d538-338a-4f0e-8f36-d5e765cf654c	\N	2026-06-07 16:51:44.835682
be4f3408-1575-4a4b-ba10-5f56c25dc4e8	demo-user-001	create	content_block	023d6d1e-f23c-444b-b8f9-39ede710bc40	\N	2026-06-07 16:55:02.396797
ecbf4543-07f0-4c0a-a422-dc98de6ecc21	demo-user-001	create	content_block	fe4b3b37-5029-4a70-8f5f-1ed5fa1ee62c	\N	2026-06-07 17:06:07.156
799a0a1b-6ed8-4408-b1c0-b09d47cd58fc	demo-user-001	update	content_block	c4a99f45-fa0e-43c8-b7b6-90ef39b35144	"Batch saved 6 blocks"	2026-06-07 17:14:53.662417
ddcbfe2b-9a49-430a-b89b-c45e61dfe01d	demo-user-001	create	content_block	b1e9cd4a-87eb-481c-a0cb-9d92962721ea	\N	2026-06-07 17:20:23.27615
ddd1c9b5-f980-42cc-8a21-6deff9589921	demo-user-001	create	content_block	1cf550d0-f5d8-4d9c-ab95-b82520a61f49	\N	2026-06-07 17:22:31.416271
39ba0552-d3a2-4fba-baf2-28f89f28379f	demo-user-001	create	content_block	0ea7a961-ae36-4ca0-a436-7a3af8d82747	\N	2026-06-07 17:26:54.785722
26d6b6dc-7bb6-46b7-bf3a-40768d489195	demo-user-001	create	content_block	107dd62f-6aa5-434c-b2a8-4baf9061da46	\N	2026-06-07 17:28:59.59007
4a3351ea-b343-45e8-869d-ba8ebfdeee21	demo-user-001	update	content_block	c4a99f45-fa0e-43c8-b7b6-90ef39b35144	"Batch saved 4 blocks"	2026-06-07 17:29:12.782793
121f923d-387f-4dfd-aea4-913159fe62e6	demo-user-001	create	topic	8ce2600e-2961-4eb5-8f96-319235e03173	{"title": "Intrapartum care of healthy normal pregnancies"}	2026-06-07 17:35:21.963499
86c85586-4f5a-4a34-bb0c-896b1bfcc771	demo-user-001	create	topic	6c89e07a-ec1e-4def-ac42-e6b2ede03088	{"title": "Neonatal care and resuscitation"}	2026-06-07 17:36:01.011352
527bc438-ad2a-4652-98ba-e80401c59823	demo-user-001	create	topic	92e1f445-5002-413d-8a33-e14ed7bd126b	{"title": "Intrapartum care of women with existing medical conditions and obstetric complications"}	2026-06-07 17:47:22.403011
5e2791b2-318f-4466-b70f-28c8a856d8ea	demo-user-001	create	topic	e3b4e100-df3c-4448-8819-9259329e7197	{"title": "Fetal monitoring during labour"}	2026-06-07 17:47:52.51819
47c03bc3-4fd6-4152-bc20-2cc392696583	demo-user-001	create	topic	9b6c66b5-b975-4976-aab0-8b669e665d08	{"title": "ECV "}	2026-06-07 17:48:14.987207
ec194561-8c13-4597-9ca5-412995b384ca	demo-user-001	create	topic	c79f2b67-796c-48b5-9d38-c447ff896df9	{"title": "Breech presentation"}	2026-06-07 17:49:05.988585
536abd37-bf1f-4031-8be6-77b735dee9f2	demo-user-001	update	topic	92e1f445-5002-413d-8a33-e14ed7bd126b	{"title": "Intrapartum care of women with existing medical conditions and obstetric complications", "author": "", "description": "1. Heart disease\\n2. Asthma\\n3. Women on long term systemic steroids\\n4. Bleeding disorders\\n5. Sub arachnoid haemorrhage or AV malformations of the brain\\n6. Renal disease\\n7. Obesity\\n8. Women with obstetric complications or no antenal care\\n9. Pyrexia\\n10. Sepsis\\n11. Intra partum haemorrhage\\n12. Breech in labour\\n13. Large for gestational age babies\\n14. Women with no antenatal care\\n15. Previous C/S\\n16. Labour after 42 weeks of pregnancy \\n", "isPublished": true}	2026-06-07 17:50:15.988318
f9b2f2e0-ac5d-41a7-b7c2-f195f3617b35	demo-user-001	create	topic	20c65258-1d41-4e72-9bdb-fe3039899c8c	{"title": "Pre term labour"}	2026-06-07 17:51:01.770089
d388c571-e845-4bcf-aee3-303b00ab8885	demo-user-001	create	topic	950fee0f-0427-4206-bf67-4b235f2f68da	{"title": "Pre PROM"}	2026-06-07 17:51:20.209028
75ff9756-ffb2-4fa4-bc41-cd18b2bcb519	demo-user-001	create	topic	16328fca-4d8d-4aa0-839a-3fdf001f8d72	{"title": "Vaginal birth after c section"}	2026-06-07 17:51:47.900712
373536c5-1d9b-422b-82c3-6e6cf44387c8	demo-user-001	create	topic	1753e412-9ad4-45ba-be24-7347a796715f	{"title": "Shoulder dystocia"}	2026-06-07 17:52:15.893577
ce27e4c9-d9a3-440f-9f94-bf6751ddf67f	demo-user-001	create	topic	dacb9f6f-63f2-4d9e-bae9-aa63692d25ae	{"title": "Cord prolapse"}	2026-06-07 17:52:37.416186
d89c19f6-30ba-465a-b83c-7c3e23eae9d6	demo-user-001	create	topic	23d86197-82bb-4f65-8742-9eaff7f540f6	{"title": "Assisted vaginal birth "}	2026-06-07 17:53:17.267454
525ec4a4-f857-44f2-b955-cdca5fbbeb6b	demo-user-001	create	topic	993577fb-3767-49dd-8160-92a3e03e2066	{"title": "Induction of labour"}	2026-06-07 17:53:49.534558
6c74da61-075b-4626-bc77-dcc2e5af93e8	demo-user-001	create	topic	bc603598-f547-4662-8699-64dadefba36a	{"title": "Perimortum C/S"}	2026-06-07 17:54:33.784149
b7ad5475-743c-4e1c-a8b0-bd7136bc4b88	demo-user-001	update	content_block	250ccdc2-184d-4bfe-b1f8-ebd98ae9f550	"Batch saved 4 blocks"	2026-06-25 22:40:12.278494
880e8ed1-1ad3-400a-ab51-b4c3cb26250f	demo-user-001	create	topic	992f9097-aac3-4b30-8c85-2d93c2e41038	{"title": "Maternal collapse"}	2026-06-07 17:54:09.491017
7b5cbea1-684f-4403-a2b5-2b7d1cecaab6	demo-user-001	delete	content_block	0ea7a961-ae36-4ca0-a436-7a3af8d82747	\N	2026-06-09 06:08:12.800911
0e65aab1-795b-4ba9-aced-2fbab6434c40	demo-user-001	delete	content_block	107dd62f-6aa5-434c-b2a8-4baf9061da46	\N	2026-06-09 06:09:08.19751
fca938e2-382b-4700-a7d9-fea823e9168c	demo-user-001	create	content_block	bba3e59d-730b-45ec-84b2-f62e9cfa5298	\N	2026-06-09 06:09:11.141223
73f524a4-8a2a-4716-8e3d-05f2651c4059	demo-user-001	create	content_block	2655d3f6-c9b2-4385-9a5c-d97aa771558c	\N	2026-06-09 06:11:31.822234
a11a4680-e06b-47c8-b311-676589fee21f	demo-user-001	create	content_block	87a56c46-66e0-479a-a401-bef21534f8e4	\N	2026-06-09 06:14:00.290807
010c08ff-6a1b-4db0-bb1a-fe9d95c084d2	demo-user-001	create	content_block	78efeed7-415f-4f3e-862b-e309a8263927	\N	2026-06-09 06:14:01.277233
251efa29-2e52-405d-b445-c2d8300d7279	demo-user-001	delete	content_block	78efeed7-415f-4f3e-862b-e309a8263927	\N	2026-06-09 06:15:49.421409
9da2fd5c-5a59-4957-8662-4355369c4453	demo-user-001	update	content_block	c4a99f45-fa0e-43c8-b7b6-90ef39b35144	"Batch saved 3 blocks"	2026-06-09 06:16:06.238528
6e6a1ea7-1412-4120-a807-1847152c191b	demo-user-001	create	content_block	94564060-9301-431b-b7bf-2e2756499123	\N	2026-06-09 06:17:17.999759
f7703956-2914-4dd9-b548-fd6325e287d5	demo-user-001	update	content_block	b1c1aa64-a82b-49bf-b379-6c7753bee96e	"Batch saved 1 blocks"	2026-06-09 06:18:54.660837
fde10a5b-5c5a-4044-bcb0-44a7cd25fb69	demo-user-001	create	content_block	d4e667bf-70b0-4558-8e6a-658a81d49af2	\N	2026-06-09 06:22:37.662379
33023bbb-63d0-44d1-a113-02d558770436	demo-user-001	update	content_block	bc603598-f547-4662-8699-64dadefba36a	"Batch saved 1 blocks"	2026-06-09 06:41:13.873988
b0c8aa8d-7265-4b40-82ed-88b152d8ddf2	demo-user-001	create	content_block	9b7ea93f-8b78-4c84-bf4f-0c89d5f7a7ae	\N	2026-06-09 06:44:23.570076
d260328f-4d43-48dd-bb47-7aecb9e013ae	demo-user-001	update	content_block	992f9097-aac3-4b30-8c85-2d93c2e41038	"Batch saved 1 blocks"	2026-06-09 07:36:41.314573
3f360e96-70f6-4a34-936e-f14768f960db	demo-user-001	update	content_block	992f9097-aac3-4b30-8c85-2d93c2e41038	"Batch saved 1 blocks"	2026-06-09 07:38:40.787035
4a61b8fc-2ae1-4a52-9d08-31d7adef2a08	demo-user-001	update	topic	992f9097-aac3-4b30-8c85-2d93c2e41038	{"title": "Induction of labour", "author": "", "description": "", "isPublished": true}	2026-06-09 07:39:13.498906
f049065f-3d64-4b8e-bb92-77e17044a8b2	demo-user-001	update	topic	993577fb-3767-49dd-8160-92a3e03e2066	{"title": "Maternal collapse", "author": "", "description": "", "isPublished": true}	2026-06-09 07:39:56.768917
70230cbf-8161-4455-9669-4840cb8af55a	demo-user-001	update	content_block	992f9097-aac3-4b30-8c85-2d93c2e41038	"Batch saved 1 blocks"	2026-06-09 07:41:00.495458
27f433a2-28f1-4fef-9efb-3dfd7d6334f1	demo-user-001	create	content_block	0910727e-89bf-4780-9fc0-fab886a8982f	\N	2026-06-09 07:46:46.069154
dbe7ca04-7f58-4bc9-a912-869fdc07c49f	demo-user-001	create	content_block	7372c6c2-3bfa-4b03-9bc4-6395ab80f5b1	\N	2026-06-15 13:22:29.973874
7e88c80f-c046-486e-bd0c-168edce5f5c5	demo-user-001	create	content_block	3eeb4511-5446-4663-a45d-03dac971af3b	\N	2026-06-15 13:22:53.232778
22ba9268-0c14-409d-9579-a089b2fefe12	demo-user-001	create	content_image	1781529787248-50a6ba07-c247-477c-b65b-6da83f50b124.jpg	{"size": 2638653, "filename": "1781529787248-50a6ba07-c247-477c-b65b-6da83f50b124.jpg", "mimeType": "image/jpeg"}	2026-06-15 13:23:07.329703
15624470-c6c6-4729-8ace-efc0309c2f3c	demo-user-001	delete	content_block	d33e609b-74bb-457a-a7df-da7b5106b436	\N	2026-06-15 13:40:27.934945
c77774c5-14f2-44cf-ace7-38b1030f2b8e	demo-user-001	delete	content_block	e1715d6c-8565-44e4-8e51-6f870aa55e80	\N	2026-06-15 13:40:32.531595
b70226d4-6c95-4fca-b962-a392b3b9a0a9	demo-user-001	delete	content_block	d6f23bda-839d-4ea7-a572-96f608443dd6	\N	2026-06-15 13:40:36.643371
5ad679b8-b646-4fb4-baa7-e3a613a1f90a	demo-user-001	create	content_block	1da5cc62-b289-4891-b1f7-3c83aba5876c	\N	2026-06-15 13:40:43.717996
ecdd0da6-0596-413d-861c-7eb43fc276a6	demo-user-001	create	content_block	00453a9d-52b1-4d56-8e7d-37f9573b53f4	\N	2026-06-15 13:41:30.526886
21ee99eb-3f32-4698-b07b-0cc5c7e0e2b3	demo-user-001	delete	content_block	00453a9d-52b1-4d56-8e7d-37f9573b53f4	\N	2026-06-15 13:41:37.051326
3dab0d2c-83e6-4052-9caa-97082c4d0d4c	demo-user-001	create	content_block	f5b8a57a-31d1-45a2-ad38-0ee03181e3ed	\N	2026-06-15 13:41:45.025186
161f66c1-4599-4797-84ff-33ffd2a19af0	demo-user-001	create	content_image	1781531082522-926ad7c0-9c18-46ad-bc27-f2d5d68e3918.png	{"size": 116732, "filename": "1781531082522-926ad7c0-9c18-46ad-bc27-f2d5d68e3918.png", "mimeType": "image/png"}	2026-06-15 13:44:42.527661
4412cf2d-8ade-47d1-838d-f10ca5096021	demo-user-001	delete	content_block	f5b8a57a-31d1-45a2-ad38-0ee03181e3ed	\N	2026-06-15 13:44:55.83257
b21ef6e7-49c4-4c6f-97b9-5cc4a84031ed	demo-user-001	create	content_block	6f8d6205-0edf-407d-af6d-4cf02d640ad6	\N	2026-06-15 13:45:02.075624
c8a18d2c-4306-4f67-a66e-bb4431a5bf22	demo-user-001	create	content_image	1781531111033-7d00fabe-3fe8-41fc-ad3e-21f9d14488db.png	{"size": 116732, "filename": "1781531111033-7d00fabe-3fe8-41fc-ad3e-21f9d14488db.png", "mimeType": "image/png"}	2026-06-15 13:45:11.041022
978c3bb7-a03c-43ad-94be-4c8342227f3b	demo-user-001	update	content_block	20944d53-c138-45a9-a769-c48bd4229f0f	"Batch saved 2 blocks"	2026-06-15 13:45:29.073804
cf4f0164-6bbb-4657-a2a2-8b8a4317cbad	demo-user-001	create	content_image	1781531183444-ca71b31b-3fe7-43e6-87ef-f0060943d29f.png	{"size": 1148922, "filename": "1781531183444-ca71b31b-3fe7-43e6-87ef-f0060943d29f.png", "mimeType": "image/png"}	2026-06-15 13:46:23.604373
36eab685-2819-4084-aa67-df09ff06a2b8	demo-user-001	delete	content_block	3eeb4511-5446-4663-a45d-03dac971af3b	\N	2026-06-15 13:46:35.556837
18b646a0-9095-4cc4-be70-6bc497e585b7	demo-user-001	update	content_block	9ffb1679-4328-47c6-b6c8-df01cc2337ed	"Batch saved 4 blocks"	2026-06-15 13:46:57.87013
1a6a5597-7f14-4e30-9e18-b0a89cfa820f	demo-user-001	create	content_image	1781531256126-759f4448-d7aa-4c5a-90f6-18f3750748cc.png	{"size": 1148922, "filename": "1781531256126-759f4448-d7aa-4c5a-90f6-18f3750748cc.png", "mimeType": "image/png"}	2026-06-15 13:47:36.140518
b26b50dc-6068-493f-8303-bb4d35cd2c96	demo-user-001	update	content_block	358587df-8f59-4495-9488-56031c7dbed1	"Batch saved 2 blocks"	2026-06-15 13:47:46.75557
9b4c16ec-1427-46a2-98aa-114f8f6c24e0	demo-user-001	delete	content_block	7372c6c2-3bfa-4b03-9bc4-6395ab80f5b1	\N	2026-06-15 13:48:07.085015
935eb299-df49-457b-a3b4-fb41816f4dfc	demo-user-001	update	content_block	9ffb1679-4328-47c6-b6c8-df01cc2337ed	"Batch saved 0 blocks"	2026-06-15 13:48:34.972758
bbbc1796-c510-48f2-8d67-9a94989f3b3d	demo-user-001	create	content_block	77df57b4-bc77-4740-b8a4-d181adae2036	\N	2026-06-15 13:50:22.310298
77767623-f73c-4740-aae5-80c9917bf69a	demo-user-001	create	content_image	1781531429998-cb7f6191-6610-4f3c-8b73-fbabb6c2d12d.png	{"size": 30581, "filename": "1781531429998-cb7f6191-6610-4f3c-8b73-fbabb6c2d12d.png", "mimeType": "image/png"}	2026-06-15 13:50:30.002242
e15f21bd-b7b8-4a45-9195-b64c550aeb8a	demo-user-001	create	content_block	1763a255-314a-49f6-8daf-139a9891eff8	\N	2026-06-15 13:50:49.083371
388f92b7-31d4-4fd4-a2cb-741b1368cddc	demo-user-001	create	content_image	1781531501040-382f58ed-e930-4c7d-b81e-9391b3a7fdaa.png	{"size": 121967, "filename": "1781531501040-382f58ed-e930-4c7d-b81e-9391b3a7fdaa.png", "mimeType": "image/png"}	2026-06-15 13:51:41.045234
d27c4161-5e28-42a7-aac5-4b0885ab49e4	demo-user-001	create	content_block	77f4296c-78f7-46d3-a125-71a43b91a41f	\N	2026-06-15 13:52:04.897284
12b61b67-bdca-4e66-9195-87622a9ad08d	demo-user-001	create	content_block	8148b36d-5ae8-49b9-837b-831fcd481546	\N	2026-06-15 13:52:40.572249
ef9ba9d7-9419-49be-9df6-a4d585614c3d	demo-user-001	create	content_block	88607813-2a24-4d58-8e06-a4a4a7f82913	\N	2026-06-15 13:53:09.699036
9ab402c8-3f0b-4cdb-9570-1c6cf4a24e15	demo-user-001	create	content_block	9912c503-7961-4c27-a3ad-534c411d520d	\N	2026-06-15 13:53:39.3699
6cc899ca-c047-43e4-9d8f-84a8c84aa22b	demo-user-001	create	content_image	1781531632386-0137a525-be09-4910-b97e-00a5de3b3971.png	{"size": 186102, "filename": "1781531632386-0137a525-be09-4910-b97e-00a5de3b3971.png", "mimeType": "image/png"}	2026-06-15 13:53:52.393444
1defaa5b-3074-487d-be11-19e22a033688	demo-user-001	update	content_block	451cca65-ae17-4959-bfd9-043a725fa698	"Batch saved 8 blocks"	2026-06-15 13:54:03.110377
aa699b18-8112-49a6-a83d-b86d14691d57	demo-user-001	create	content_block	968fb951-cae9-4c25-ae75-8ee6513ef514	\N	2026-06-15 13:59:25.331527
cc301118-2696-4c4c-9e3c-91c46b57616b	demo-user-001	create	content_image	1781531975749-a399b961-bcf9-4387-8c0e-788b5865c0a1.jpg	{"size": 2638653, "filename": "1781531975749-a399b961-bcf9-4387-8c0e-788b5865c0a1.jpg", "mimeType": "image/jpeg"}	2026-06-15 13:59:35.835074
698c0a2b-7b4e-46f4-bfca-225feedb9823	demo-user-001	update	content_block	9ffb1679-4328-47c6-b6c8-df01cc2337ed	"Batch saved 1 blocks"	2026-06-15 13:59:44.181891
7a4cd68e-0a7b-47a0-83e8-22dafb86a805	demo-user-001	update	content_block	ae07ff0d-4682-4df5-bd7d-f6067bd7b664	"Batch saved 1 blocks"	2026-06-15 14:06:36.474623
c4b21fce-9efa-4b1f-b6e3-8804d62b1ee6	demo-user-001	update	content_block	ae07ff0d-4682-4df5-bd7d-f6067bd7b664	"Batch saved 1 blocks"	2026-06-15 14:10:53.446112
abf4155f-3416-4196-9ef8-a2bbe08b03ca	demo-user-001	update	book	46799a77-8be1-457e-bb75-9bee5369ed87	{"isPublished": false}	2026-06-16 03:20:23.026265
c6494c96-7e2d-4dae-98cf-e68eb646fa19	demo-user-001	update	book	46799a77-8be1-457e-bb75-9bee5369ed87	{"isPublished": true}	2026-06-16 03:20:25.22389
6292e1d8-3162-4c1e-bada-da1e1ae09e20	demo-user-001	update	book	46799a77-8be1-457e-bb75-9bee5369ed87	{"isPublished": false}	2026-06-16 03:20:28.013752
ef3359c4-e666-473d-9486-455d5baa3e34	demo-user-001	update	user	61bd4894-7aa4-437b-bcb2-285bdc034994	{"name": "Asif Ali", "role": "student", "deviceLimitMax": 1, "isEmailVerified": true, "subscriptionPlan": "monthly", "subscriptionStatus": "cancelled", "deviceLimitOverrideEnabled": true}	2026-06-16 03:29:18.400161
aa530125-9068-4bcf-aa89-eec3c7178722	demo-user-001	update	user	61bd4894-7aa4-437b-bcb2-285bdc034994	{"name": "Asif Ali", "role": "student", "deviceLimitMax": 1, "isEmailVerified": true, "subscriptionPlan": "", "subscriptionStatus": "expired", "deviceLimitOverrideEnabled": true}	2026-06-16 03:31:47.911146
9f05a28e-f0dd-4794-9a95-0e24baddee2b	demo-user-001	update	user	61bd4894-7aa4-437b-bcb2-285bdc034994	{"name": "Asif Ali", "role": "student", "deviceLimitMax": 1, "isEmailVerified": true, "subscriptionPlan": "monthly", "subscriptionStatus": "expired", "deviceLimitOverrideEnabled": true}	2026-06-16 03:33:10.092317
ecda9b95-f421-4e60-9e32-08b5278326c5	demo-user-001	update	book	46799a77-8be1-457e-bb75-9bee5369ed87	{"isPublished": true}	2026-06-23 06:28:01.210175
ed2739e6-31c3-4873-9414-da98c25b566f	demo-user-001	update	content_block	ae07ff0d-4682-4df5-bd7d-f6067bd7b664	"Batch saved 1 blocks"	2026-06-23 06:30:47.433328
31767b9b-4c08-4543-b434-fc37504072eb	demo-user-001	create	content_image	1782196592270-6eda2914-bb97-41ce-9135-1dd716292732.jpg	{"size": 130221, "filename": "1782196592270-6eda2914-bb97-41ce-9135-1dd716292732.jpg", "mimeType": "image/jpeg"}	2026-06-23 06:36:32.28824
f0e44b67-29d7-4fd5-997d-3a70df07b737	demo-user-001	create	content_block	5e4ab459-b244-4b1a-9322-b8f3764cdc23	\N	2026-06-23 06:36:51.973007
f0a4f128-5462-4733-a06c-06b71a8cee39	demo-user-001	create	content_image	1782197023615-8f70bfc7-2953-4f58-8129-493a9d853d2d.jpg	{"size": 130221, "filename": "1782197023615-8f70bfc7-2953-4f58-8129-493a9d853d2d.jpg", "mimeType": "image/jpeg"}	2026-06-23 06:43:43.665091
06737cae-02ef-46ff-84d0-1c471dc2bae1	demo-user-001	update	content_block	20944d53-c138-45a9-a769-c48bd4229f0f	"Batch saved 2 blocks"	2026-06-23 06:44:53.728061
5824f101-53bc-4deb-a767-8581d7450951	demo-user-001	delete	content_block	6f8d6205-0edf-407d-af6d-4cf02d640ad6	\N	2026-06-23 06:47:15.558059
f5fba460-0e52-4130-a8c9-b1edf3b13d59	demo-user-001	create	content_image	1782197252414-f1339dfa-45b0-4533-bb1e-f40b6a4c29d6.jpg	{"size": 11593, "filename": "1782197252414-f1339dfa-45b0-4533-bb1e-f40b6a4c29d6.jpg", "mimeType": "image/jpeg"}	2026-06-23 06:47:32.584903
dd531ac4-a596-48fc-b85d-8659da126a66	demo-user-001	create	content_block	1a30067e-c55e-4259-9e16-cbf0b7df4c29	\N	2026-06-23 08:19:05.834816
9085864a-9fd1-4857-a81b-a746812f5218	demo-user-001	create	content_block	b5b80c3b-9ed4-408f-b0b2-d494c35999a0	\N	2026-06-23 08:19:06.00783
72c4f37f-bab8-4821-8fff-579f9658c882	demo-user-001	create	content_block	662a752c-38b3-4609-8c0d-78508bfa47ba	\N	2026-06-23 08:20:25.635324
8ea50ee0-24ab-4aa0-9a4a-07b2c5c601f5	demo-user-001	create	content_block	f6077c3e-bd6d-416d-9042-06653c211c42	\N	2026-06-23 08:20:27.469998
a9c42bbd-dbff-4792-80a0-347c184d5b83	demo-user-001	delete	content_block	f6077c3e-bd6d-416d-9042-06653c211c42	\N	2026-06-23 08:21:36.58645
768d5db6-edd9-42aa-ac81-7334c4482282	demo-user-001	delete	content_block	662a752c-38b3-4609-8c0d-78508bfa47ba	\N	2026-06-23 08:26:03.008773
883ab296-df90-4292-abee-69a3b4de6dfc	demo-user-001	create	content_image	1782241427234-45a7754c-bbf2-40e6-baba-cac3e8629722.png	{"size": 2491892, "filename": "1782241427234-45a7754c-bbf2-40e6-baba-cac3e8629722.png", "mimeType": "image/png"}	2026-06-23 19:03:47.567457
7797f784-223d-4f02-80e7-a3f10233ab9c	demo-user-001	create	content_block	c52e530a-2571-4b90-8b28-95e04be608c1	\N	2026-06-23 19:03:55.621345
37c5f75b-7d49-4553-ab7a-6480b5af28a3	demo-user-001	create	content_image	1782427130321-6eb5ed78-15d0-4449-a92a-6f58277d8833.png	{"size": 2401962, "filename": "1782427130321-6eb5ed78-15d0-4449-a92a-6f58277d8833.png", "mimeType": "image/png"}	2026-06-25 22:38:51.041586
8a7c804d-4de3-42a7-97ea-f0a0834c7d71	demo-user-001	create	content_block	76f2016e-a7c3-4ba4-bb7e-e429712ec093	\N	2026-06-25 22:39:00.612949
55d7a439-75eb-49ec-a1bf-b6928922a30f	demo-user-001	create	content_block	66aea617-a0ab-4e8d-ad11-71f0135bd67c	\N	2026-06-25 22:39:14.001409
\.


--
-- Data for Name: bookmarks; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.bookmarks (id, user_id, topic_id, created_at) FROM stdin;
05a3a00c-75ad-4147-886c-ca75ff039bf4	51268d4e-a5cf-4e92-948c-0c708d200d48	c7578a7b-6acb-48bb-a9f7-9c54c8f23e20	2026-03-05 09:55:01.63232
a448800e-31a4-432e-9347-b178b67be227	51268d4e-a5cf-4e92-948c-0c708d200d48	de882ed5-4ae9-43a0-b80d-d51aae5f6a97	2026-03-05 09:55:52.630998
cbdcfd21-911a-4f6e-9d49-f8a51fe17f31	61bd4894-7aa4-437b-bcb2-285bdc034994	c7578a7b-6acb-48bb-a9f7-9c54c8f23e20	2026-03-05 11:18:59.749129
f52c7a58-4aa3-4100-8b97-ab32e96c1b19	61bd4894-7aa4-437b-bcb2-285bdc034994	de882ed5-4ae9-43a0-b80d-d51aae5f6a97	2026-03-05 11:19:02.897765
a10946a8-b2b3-4599-bd9d-da4f8945012d	61bd4894-7aa4-437b-bcb2-285bdc034994	dce6694e-93b3-4281-b546-8cb995c03b1d	2026-03-05 11:19:06.345327
bb1ceeba-1331-41b6-8967-86f9566b67b0	61bd4894-7aa4-437b-bcb2-285bdc034994	52c2375a-221f-40db-be86-b66990fdd20a	2026-03-05 11:19:54.08131
a21e3e16-0413-403c-92cc-e6c4d9f32df3	51268d4e-a5cf-4e92-948c-0c708d200d48	126fe5cf-71e2-4469-8a89-2bf0498f7cc5	2026-03-19 00:14:46.893438
67a290bc-64bf-4bf6-9401-06275d7bec7a	e48a1d49-0a19-4f78-bb27-e8f26279052c	6f36db59-1cc0-4586-8c6a-1c8bb00a8e0c	2026-05-09 17:00:53.398263
d1924cdc-f069-4f9b-a6ce-46d9acf2b6a3	61bd4894-7aa4-437b-bcb2-285bdc034994	025e984c-0ed5-46c5-8825-99318063c146	2026-05-29 14:04:45.112231
d984a314-97f4-44d9-97e0-c5d4ae885707	51268d4e-a5cf-4e92-948c-0c708d200d48	c293f92b-c305-42f4-b986-2dd110fdd68e	2026-06-16 17:13:44.22137
\.


--
-- Data for Name: books; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.books (id, title, description, image_url, is_published, "order", created_at, updated_at) FROM stdin;
a886d6e1-9dea-4b5e-b700-f26cdd53f897	Gynaecology 	Test		t	0	2026-03-03 07:15:13.700219	2026-05-14 08:17:26.175
0d859a82-c9fd-47e8-9643-81e3de9588fc	Miscellaneous 			t	2	2026-05-25 06:31:11.191771	2026-06-01 07:14:57.827
46799a77-8be1-457e-bb75-9bee5369ed87	Obstetrics			t	1	2026-05-14 08:18:06.665601	2026-06-23 06:28:01.015
\.


--
-- Data for Name: chapters; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.chapters (id, book_id, title, description, "order", is_published, created_at) FROM stdin;
b63ab97b-1ade-4083-b1be-be75c5f1ae67	a886d6e1-9dea-4b5e-b700-f26cdd53f897	Subfertility 		1	t	2026-03-03 07:15:38.354962
b108a79f-5d9c-4839-9074-3534616914a4	a886d6e1-9dea-4b5e-b700-f26cdd53f897	Gynaecologic Oncology 		2	t	2026-03-03 07:15:55.475688
a326891f-f3d2-4e76-b1ae-5b0064dea77e	a886d6e1-9dea-4b5e-b700-f26cdd53f897	Urogynaecology 		3	t	2026-03-03 07:16:14.822069
dbec251c-b50c-408b-85ca-5a92d99980ed	a886d6e1-9dea-4b5e-b700-f26cdd53f897	General Gynaecology 		0	t	2026-03-03 07:15:26.826211
b3afd200-5f4f-49b1-a607-ae1abb2be1a7	a886d6e1-9dea-4b5e-b700-f26cdd53f897	Sexual and reproductive health		4	t	2026-05-25 06:22:43.014733
1c366ea0-72fd-4859-881c-734381c1b01b	46799a77-8be1-457e-bb75-9bee5369ed87	Maternal medicine		1	t	2026-05-25 06:27:39.088699
015cd5bd-973c-4086-acec-ca8459ed9225	46799a77-8be1-457e-bb75-9bee5369ed87	Antenatal care		2	t	2026-05-25 06:28:09.40402
28f5de83-fd41-4bdc-994f-c06c795a88a9	46799a77-8be1-457e-bb75-9bee5369ed87	Labour and delivery 		3	t	2026-05-25 06:28:30.26238
b8a054ef-e541-4d49-9bae-02c41ef8eb92	46799a77-8be1-457e-bb75-9bee5369ed87	Post partum		4	t	2026-05-25 06:29:52.807182
bacaf815-66ec-4a41-afcb-6f178b8e4a87	a886d6e1-9dea-4b5e-b700-f26cdd53f897	Core surgical skills and post operative complications 		5	t	2026-05-25 06:23:56.729601
5640d3cf-5c87-4b49-8b8a-8948ad6ad905	a886d6e1-9dea-4b5e-b700-f26cdd53f897	Early pregnancy care		6	t	2026-05-25 06:35:08.836394
7d80628c-5d83-46e9-922d-ab659f7c0768	0d859a82-c9fd-47e8-9643-81e3de9588fc	Teaching		0	t	2026-05-25 06:31:23.032948
2ce2539d-223c-45e5-90a0-272afedff9e3	0d859a82-c9fd-47e8-9643-81e3de9588fc	Clinical governance		1	t	2026-05-25 06:31:42.490777
\.


--
-- Data for Name: code_redemptions; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.code_redemptions (id, code_id, user_id, book_id, duration_days, subscription_started_at, subscription_expires_at, ip_address, created_at) FROM stdin;
\.


--
-- Data for Name: content_blocks; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.content_blocks (id, topic_id, type, content, "order", created_at) FROM stdin;
820c7f95-40fa-47a0-a3f8-a9da36d3ac0e	52c2375a-221f-40db-be86-b66990fdd20a	heading	causes	2	2026-03-03 07:19:36.033297
73277894-4dbb-4c62-a49d-2751d8aeff0d	52c2375a-221f-40db-be86-b66990fdd20a	heading	Physical Examination	4	2026-03-04 09:07:46.211783
a16e468f-09be-4d07-a4f6-abbe6a8e2893	de882ed5-4ae9-43a0-b80d-d51aae5f6a97	text	<p><strong>Pyomyoma:</strong> life threating due to infarction and infection of fibroid</p><p>Pain, fever, sepsis.</p><p><strong>Treatment:</strong></p><p><span>&nbsp;</span>1.<span>&nbsp; </span>laparotomy with Myomectomy / Hysterectomy.</p><p><span>&nbsp;&nbsp; </span>2.<span>&nbsp; </span>CT guided drainage</p><p><strong>Rupture of myoma:</strong> in post-partum period.</p>	33	2026-03-04 10:08:00.388517
28a1614a-f011-4b02-957a-ec1e5a9e0730	52c2375a-221f-40db-be86-b66990fdd20a	text	<p><span><strong>1.&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </strong></span>In pts with Related symptoms</p><p><span><strong>2.&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </strong>&nbsp;</span>Mirena insertion.</p>	5	2026-03-04 09:04:53.725675
a8313bc0-8390-49e2-aec8-89d57c93d8ed	631e8033-60a7-46e8-8aac-713aad3674c8	heading	Clinical Evaluation:	5	2026-03-05 07:30:17.369302
f175bfbc-8068-4ee9-a723-3071327431a4	631e8033-60a7-46e8-8aac-713aad3674c8	text	<h2><span><strong><em>1.</em>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </strong></span><strong><em>Vasomotor Symptoms:</em></strong></h2><p><span>-&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>70% more in 1<sup>st</sup> year due to pulsatile FSH</p><h2><span><strong><em>2.</em>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </strong></span><strong><em>Urogenital Symptoms:</em></strong></h2><h3><span>•&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span><strong><em><u>Genital:</u></em></strong></h3><p><span>-&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>Itching</p><p><span>-&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>Prolapse</p><p><span>-&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>Dysparunia 40%</p><p><span>-&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>Atrophy</p><p><span>-&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>Dryness 75%</p><h3><span>•&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp;</span><strong><em><u>Urological 50%</u></em></strong></h3><p><span>-&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>Nocturia</p><p><span>-&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>Dysurea</p><p><span>-&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>UTI – Recurrent 20%</p><p><span>-&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>Incontinence.</p><h2><span><strong><em>3.</em>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </strong></span><strong><em>Psychological:</em></strong></h2><p><span>-&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>Fatigue</p><p><span>-&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>Depression</p><p><span>-&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>Mood instability</p><p><span>-&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Decreased </span>libido due to<span>&nbsp;Decreased </span>Testosterone and atrophy</p><p><span>-&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>Memory loss</p><p><span>-&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>insomnia</p><h2><span><strong><em>4.</em>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </strong></span><strong><em>Osteoporosis:</em></strong></h2><p><span>-&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>More in vertebrae, femur, wrist.</p><p><span>-&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>2% @ 50yrs</p><p><span>25% @ 80yrs</span></p>	6	2026-03-05 07:30:57.979825
7a290c75-0bf1-4cec-afe6-c341955c2d36	de882ed5-4ae9-43a0-b80d-d51aae5f6a97	text	<p>Recommended and safe but <span>&nbsp;</span>increases operating time upto 15min</p><p><strong>indications</strong></p><p><span>-&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>Large fibroids</p><p><span>-&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>Sub-serosal fibroids</p><p><span>-&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>Fibroids posing difficulty in uterine closure.</p><p><strong>PNC</strong> : Fibroids regress after 3-6months of pregnancy in over 70% women.</p>	31	2026-03-04 10:07:16.0393
93e1e5de-7df3-479a-b128-d4a312dbf76e	de882ed5-4ae9-43a0-b80d-d51aae5f6a97	heading	Complications in postpartum period:	32	2026-03-04 10:07:44.360648
74d00924-6c80-49f5-956f-513230190bc6	52c2375a-221f-40db-be86-b66990fdd20a	heading	Investigation: (lab Tests)	6	2026-03-04 09:08:55.919199
3f17ec96-e090-4f2e-a880-47b92e056014	52c2375a-221f-40db-be86-b66990fdd20a	text	<p>CBC – <span>&nbsp;</span>offerd to all women (alongside treatment)</p><p>Coagulation Screen-(to rule out Willibrand disease VWD) , offered if</p><p><span>-&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>HMB from menarche.</p><p><span>-&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>Personal 0r family history of coagulation disorders.</p><p><u>Consider</u> TFTS – if symptoms are suggestive.</p><p><span>No role of serum ferritin and female hormone</span></p>	7	2026-03-04 09:09:17.25623
8e818846-354e-4707-8995-57f9199d738f	52c2375a-221f-40db-be86-b66990fdd20a	heading	Investigation of the cause:	8	2026-03-04 09:09:46.983572
92f6c4de-49d0-4179-899e-ccdde311039d	52c2375a-221f-40db-be86-b66990fdd20a	text	<ul><li><p>Offer pharmacological t/m before investigating cause of HMB if patient is low risk for</p></li></ul><p><span>1.&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>Fibroids</p><p><span>2.&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp;</span>Adenomyosis</p><p><span>3.&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>Histological Abnormality</p><p><span>4.&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>Structural abnormality.</p>	9	2026-03-04 09:10:10.249492
adb31983-e85b-45bc-b930-93cf1e57ff85	52c2375a-221f-40db-be86-b66990fdd20a	heading	Investigation for cause of HMB:	10	2026-03-04 09:10:37.295691
18785a66-959c-465b-b728-f74c2a2f89db	52c2375a-221f-40db-be86-b66990fdd20a	heading	History 	0	2026-03-03 07:18:37.89656
b4fc6bbe-41bc-4546-b928-6418a2ec2515	52c2375a-221f-40db-be86-b66990fdd20a	heading	MANAGEMENT	12	2026-03-04 09:12:36.35032
07bbf79e-fa83-4559-9f55-6e7e884b7b9a	52c2375a-221f-40db-be86-b66990fdd20a	text	<p>Mirena is 1<sup>st</sup> line in</p><p><span><strong><em>1.</em>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </strong></span><strong><em>No identified pathology</em></strong></p><p><span>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</span></p><p><span>2.&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span><strong><em>Fibroid &lt;3cm</em></strong><span><strong><em>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp;</em></strong></span></p><p><span>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</span></p><p><span><strong><em>3.</em>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </strong></span><strong><em>Adenomyosis</em></strong></p>	13	2026-03-04 09:13:02.452129
d797de8e-7806-4391-a458-ca2031c1361a	52c2375a-221f-40db-be86-b66990fdd20a	heading	Not suitable/decline Mirena:	14	2026-03-04 09:13:28.139682
92d9a8d9-19b8-4ce8-8de7-ae08fb95db2e	631e8033-60a7-46e8-8aac-713aad3674c8	text	<p><strong>1. Ospemifene</strong></p><p><span><strong>2.&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </strong></span><strong>lasofoxifene</strong></p><p><span>-&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>Oral: given where estrogen is contraindicated, licensed for dysparunia.</p><p><span><strong>3.&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </strong></span><strong>Tissue selective E complex</strong> treatment - oral.</p><p><span><strong>4.&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </strong></span><strong>Androgens </strong>DHEA - oral/vaginal can b given in vulvovaginal atrophy</p>	23	2026-03-05 07:44:37.935504
8d4ec55f-38b1-4077-8869-b7aa2c52c0f2	52c2375a-221f-40db-be86-b66990fdd20a	text	<p><span>•&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>patient Not fit or refuses for surgery</p><p><span>-&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span><span style="color: rgb(47, 84, 150);">Endometrium along with inner 5mm of myometrium need to be destroyed.</span></p>	19	2026-03-04 09:16:28.547389
ebbdba40-330a-4716-b477-7ed7f2b14516	dce6694e-93b3-4281-b546-8cb995c03b1d	heading	AVOID HRT:	22	2026-03-05 07:53:16.462891
05236a2e-8fcb-43ca-ac98-7b27e0a2f00d	dce6694e-93b3-4281-b546-8cb995c03b1d	text	<p><span>-&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>In Patients with multiple Risk Factors Age, BMI, previous venous thromboembolism, post thrombotic syndrome, 1st degree relative with venous thromboembolism.</p><p><span>-&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>Immobility for &gt;3days surgery &gt;60min</p><p><span>-&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>More risk of VTE in 1st year of use</p>	23	2026-03-05 07:53:27.88441
5a7f806f-4034-41ae-a95f-8177346d2bef	52c2375a-221f-40db-be86-b66990fdd20a	heading	Contraindications:	20	2026-03-04 09:16:49.590743
83e65ac8-e43b-4692-8b5d-c0518fb5d9b6	de882ed5-4ae9-43a0-b80d-d51aae5f6a97	text	<p><span>•&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>Infertility</p><p><span>•&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>miscarriage (14%)</p><p><span>•&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>Bleeding</p><p><span>•&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>Abruption</p><p><span>•&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>Previa (double risk)</p>	12	2026-03-04 09:55:41.733906
0528a659-e2ba-4513-9f56-45e31db4e8ea	52c2375a-221f-40db-be86-b66990fdd20a	text	<p><span>1.&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>Uterine size &gt; 10wks.</p><p><span>2.&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>Myometrial wall Thickness &lt;8mm.</p><p><span>3.&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>Structural uterine anomaly.</p><p><span>4.&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>Histological uterine Anomaly.</p><p><span>5.&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>Desire for future fertility</p>	21	2026-03-04 09:17:10.770026
2d85c2e7-88dd-4be4-9ef4-bd3ddd1a142d	52c2375a-221f-40db-be86-b66990fdd20a	heading	Endometrial Preparation:\n	23	2026-03-04 09:18:47.031636
231409e1-2294-4d17-9e26-5a3e5109cea7	52c2375a-221f-40db-be86-b66990fdd20a	text	<p>Is done by:</p><p><span>•&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>Danazol</p><p><span>•&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>GnRH Analogues</p><p><span>•&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>Progestogen withdrawal</p><p><span>•&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>Endometrial biopsy before ablation.</p>	24	2026-03-04 09:19:24.578228
d4f7f1df-a28a-40d3-987a-d0a09ff52f4c	52c2375a-221f-40db-be86-b66990fdd20a	text	<p><span>-&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>Nature of bleeding</p><p><span>-&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>Related symptoms</p><p><span>•&nbsp; </span>Pain</p><p><span>•&nbsp; </span>IMB</p><p><span>•&nbsp; </span>Pressure symptoms.</p><p><span>-&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>QOL</p><p><span>-&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>Comorbid factors</p><p><span>-&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>Previous treatment.</p>	1	2026-03-04 09:04:53.476144
6917da74-c66b-46ad-8e16-2350378dbc88	52c2375a-221f-40db-be86-b66990fdd20a	heading	ENDOMETRIAL ABLATION:	16	2026-03-04 09:15:20.956137
42b9383a-860b-4fc5-949b-7078f934b73e	52c2375a-221f-40db-be86-b66990fdd20a	text	<h2><strong><em>Generations:</em></strong></h2><p>1<sup>st:</sup> Operator dependent (hysteroscopic)<span>&nbsp;</span></p><p><span style="color: red;">- </span><span style="color: rgb(47, 84, 150);">Transcervical Resection of Endometrium.</span></p><p><span>&nbsp;</span><span style="color: rgb(47, 84, 150);">- Roller ball Ablation</span></p><p><span>&nbsp; </span><span style="color: rgb(47, 84, 150);">- Endo laser Ablation</span></p><p>2<sup>nd:</sup> Not OPerator Dependent (Non-Hysteroscopic)</p><p><span style="color: rgb(47, 84, 150);">- thermal Balloon Ablation</span></p><p><span style="color: rgb(47, 84, 150);">- bipolar radiofrequency endometrial ablation</span></p><p><span style="color: rgb(47, 84, 150);">- Hydrothermal</span><span>&nbsp;</span></p>	17	2026-03-04 09:15:31.762539
f3150b58-b511-44bd-b066-22ef4e869c39	52c2375a-221f-40db-be86-b66990fdd20a	heading	Contraception and ablation:	25	2026-03-04 09:19:59.106257
987f9a1a-0095-4c3e-b215-43162b4def1a	52c2375a-221f-40db-be86-b66990fdd20a	heading	complications:	27	2026-03-04 09:20:44.708462
4b0d588b-019a-452c-a54a-82b4005c10f1	631e8033-60a7-46e8-8aac-713aad3674c8	heading	Average age 50.5years 1 year earlier in smokers Perimenopause:\n	0	2026-03-04 10:30:16.686551
945fc827-765f-4108-81d1-185b7ec8ec40	631e8033-60a7-46e8-8aac-713aad3674c8	heading	Diagnosis:	7	2026-03-05 07:32:26.380393
4ad4a968-509f-47db-8342-c66145eb8510	631e8033-60a7-46e8-8aac-713aad3674c8	heading	MANAGEMENT OF MENOPAUSE:	9	2026-03-05 07:33:14.719234
f024e1b1-6459-49f5-adeb-218519660d18	52c2375a-221f-40db-be86-b66990fdd20a	heading	Indications:	18	2026-03-04 09:16:11.498232
50c4324c-8a62-4105-8d94-1b5a33a684e8	52c2375a-221f-40db-be86-b66990fdd20a	heading	Peri – Operative Complications: 	29	2026-03-04 09:21:34.005083
eedccb5b-faf3-4c30-bee2-b3be611e6399	52c2375a-221f-40db-be86-b66990fdd20a	heading	Long term complications:	31	2026-03-04 09:22:35.813675
9406bebe-519b-4f25-8a10-dfbfad0718d2	631e8033-60a7-46e8-8aac-713aad3674c8	text	<p><span>-&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span><u>Moisturizer &amp; lubricates</u> - effective in mild-<u>moderate dryness</u> - short term relief of dysparunia.</p><p><span>-&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span><u>Vaginal E deficiency</u> - short term relief</p><p><span>-&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span><u>HRT</u></p><p><span>-&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span><u>Laser treatment – </u>can be given to women where estrogen is contraindication.</p>	21	2026-03-05 07:44:05.981125
65b66ce5-7210-4929-85cc-c2ad5ad1c4e7	dce6694e-93b3-4281-b546-8cb995c03b1d	text	<p><span>•&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp;</span>For 100,000 HRT users/year:</p><p><span>1.&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp;</span>Colorectal cancer 6 times decreases.</p><p><span>2.&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp;</span>HIP fracture 5 times decreases.</p>	5	2026-03-05 07:47:34.30109
bc63bd16-9a3e-48c0-8e4b-a6894b1f1c5d	52c2375a-221f-40db-be86-b66990fdd20a	text	<p><span>•&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp;</span>Prior to EA – Rule out endometrial atypia/cancer by endometrial biopsy.</p><table class="mm-table" style="min-width: 150px;"><colgroup><col style="min-width: 25px;"><col style="min-width: 25px;"><col style="min-width: 25px;"><col style="min-width: 25px;"><col style="min-width: 25px;"><col style="min-width: 25px;"></colgroup><tbody><tr><td colspan="1" rowspan="1"><p><span style="color: black;"><strong>1<sup>st</sup> Generation</strong></span></p></td><td colspan="1" rowspan="1"><p><span style="color: black;"><strong>Mode</strong></span></p></td><td colspan="1" rowspan="1"><p><span style="color: black;"><strong>Endometrial preparation</strong></span></p></td><td colspan="1" rowspan="1"><p><span style="color: black;"><strong>Cavity length</strong></span></p><p><span style="color: black;"><strong>&gt; 10cm</strong></span></p></td><td colspan="1" rowspan="1"><p><span style="color: black;"><strong>Cx dilation required</strong></span></p></td><td colspan="1" rowspan="1"><p><span style="color: black;"><strong>Sub-mucus fibroids resection</strong></span></p></td></tr><tr><td colspan="1" rowspan="1"><p><span><strong>1.&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </strong></span><strong>TCRE</strong></p><p><span>•&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>Biopsy can be taken</p><p><span>•&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>Longest recovery time.</p><p><span>•&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>Highest complication</p></td><td colspan="1" rowspan="1"><p style="text-align: center;">&nbsp;</p><p style="text-align: center;">Mono/bipolar 3mm loop</p></td><td colspan="1" rowspan="1"><p style="text-align: center;">&nbsp;</p><p style="text-align: center;">&nbsp;</p><p style="text-align: center;">&nbsp;</p><p style="text-align: center;">Optional</p></td><td colspan="1" rowspan="1"><p style="text-align: center;">&nbsp;</p><p style="text-align: center;">&nbsp;</p><p style="text-align: center;">&nbsp;</p><p style="text-align: center;">yes</p></td><td colspan="1" rowspan="1"><p style="text-align: center;">&nbsp;</p><p style="text-align: center;">&nbsp;</p><p style="text-align: center;">&nbsp;</p><p style="text-align: center;">9mm</p></td><td colspan="1" rowspan="1"><p style="text-align: center;">&nbsp;</p><p style="text-align: center;">&nbsp;</p><p style="text-align: center;">&nbsp;</p><p style="text-align: center;">Yes</p></td></tr><tr><td colspan="1" rowspan="1"><p><span><strong>2.&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </strong></span><strong>RBA</strong></p><p><span>•&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>Repeat ablation can be undertaken</p></td><td colspan="1" rowspan="1"><p style="text-align: center;">&nbsp;</p><p style="text-align: center;">Mono / Bipolar</p></td><td colspan="1" rowspan="1"><p style="text-align: center;">&nbsp;</p><p style="text-align: center;">Optional</p></td><td colspan="1" rowspan="1"><p style="text-align: center;">&nbsp;</p><p style="text-align: center;">Yes</p></td><td colspan="1" rowspan="1"><p style="text-align: center;">&nbsp;</p><p style="text-align: center;">&gt;9mm</p></td><td colspan="1" rowspan="1"><p style="text-align: center;">&nbsp;</p><p style="text-align: center;">yes</p></td></tr><tr><td colspan="1" rowspan="1"><p><span>3.&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>ELA</p><p><span>•&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>Costly</p><p><span>•&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>Saline is used</p></td><td colspan="1" rowspan="1"><p style="text-align: center;">&nbsp;</p><p style="text-align: center;">Nd-yag</p></td><td colspan="1" rowspan="1"><p style="text-align: center;">&nbsp;</p><p style="text-align: center;">Required</p></td><td colspan="1" rowspan="1"><p style="text-align: center;">&nbsp;</p><p style="text-align: center;">Yes</p></td><td colspan="1" rowspan="1"><p style="text-align: center;">&nbsp;</p><p style="text-align: center;">7mm</p></td><td colspan="1" rowspan="1"><p style="text-align: center;">&nbsp;</p><p style="text-align: center;">No</p></td></tr><tr><td colspan="1" rowspan="1"><p><span style="color: black;"><strong>2<sup>nd</sup> Generation</strong></span></p></td><td colspan="1" rowspan="1"><p style="text-align: center;"><span style="color: black;"><strong>Mode</strong></span></p></td><td colspan="1" rowspan="1"><p style="text-align: center;"><span style="color: black;"><strong>Endo prep</strong></span></p></td><td colspan="1" rowspan="1"><p style="text-align: center;"><span style="color: black;"><strong>Maximum Cavity length</strong></span></p></td><td colspan="1" rowspan="1"><p style="text-align: center;"><span style="color: black;"><strong>Cervix dilation required</strong></span></p></td><td colspan="1" rowspan="1"><p style="text-align: center;"><span style="color: black;"><strong>Sub-mucus fibroids resection</strong></span></p></td></tr><tr><td colspan="1" rowspan="1"><p>1. Therma choice III</p><p>10-12min</p><p><span>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>C/I:</p><p>i. Classical c/s</p><p>ii. myomectomy</p></td><td colspan="1" rowspan="1"><p style="text-align: center;">Fluid filled thermal balloon</p></td><td colspan="1" rowspan="1"><p style="text-align: center;">No</p></td><td colspan="1" rowspan="1"><p style="text-align: center;">11mm</p></td><td colspan="1" rowspan="1"><p style="text-align: center;">5mm</p></td><td colspan="1" rowspan="1"><p style="text-align: center;">&lt;3cm</p></td></tr><tr><td colspan="1" rowspan="1"><p>2. Novassure</p><p>90 – 120sec</p><p>50ohm</p></td><td colspan="1" rowspan="1"><p style="text-align: center;">Bipolar radio frequency</p></td><td colspan="1" rowspan="1"><p style="text-align: center;">No</p></td><td colspan="1" rowspan="1"><p style="text-align: center;">11mm</p></td><td colspan="1" rowspan="1"><p style="text-align: center;">8mm</p></td><td colspan="1" rowspan="1"><p style="text-align: center;">&lt;3cm</p></td></tr><tr><td colspan="1" rowspan="1"><p>3. Hydrothermal ablators<span>&nbsp;</span></p><p>10min</p></td><td colspan="1" rowspan="1"><p style="text-align: center;">Heated Saline</p></td><td colspan="1" rowspan="1"><p style="text-align: center;">Yes</p></td><td colspan="1" rowspan="1"><p style="text-align: center;">6 - 10.5cm</p></td><td colspan="1" rowspan="1"><p style="text-align: center;">8mm</p></td><td colspan="1" rowspan="1"><p style="text-align: center;">&lt;4cm</p></td></tr></tbody></table>	22	2026-03-04 09:18:09.750075
84a25df4-1a70-4341-96e2-001882d554d9	52c2375a-221f-40db-be86-b66990fdd20a	text	<p><em>Sterilization with Essure along with ablation can be done</em></p><p><em>1<sup>st</sup> generations vs 2<sup>nd</sup> generation EA</em></p><p><span style="color: rgb(47, 84, 150);">Satisfaction rate, Acceptability ,Operative time , Local anesthesia </span><span>&nbsp;</span><span style="color: rgb(47, 84, 150);">and Pre-post OP </span><span>&nbsp;</span><span style="color: rgb(47, 84, 150);">complications all are in favour of 2<sup>nd</sup> generation EA.</span></p>	26	2026-03-04 09:20:15.690032
04cf0d53-a941-495e-922a-3be4a240a650	52c2375a-221f-40db-be86-b66990fdd20a	text	<p><span>&nbsp;</span>Metabolic Derangement.</p><ul><li><p><em>Transurethral resection syndrome</em></p></li></ul><p><span>-&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>In 1<sup>st</sup> generation due to glycine use leading to hyponatremia and hyperammonemia =&gt; MI, Coma, hemolysis, death</p><p>reference <span>&nbsp;</span>range of fluid deficit is 1.5 litre.</p><p><span>-&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>Most Common in laser &gt; TCRE&gt; RBA</p><ul><li><p>Extra uterine thermal Visceral damage.</p></li></ul>	30	2026-03-04 09:21:51.863592
ab82b61a-595f-47ba-a3ab-9b0ad5c804a7	de882ed5-4ae9-43a0-b80d-d51aae5f6a97	heading	3.\tBroad ligament:	13	2026-03-04 09:56:01.427055
20fb0aab-e629-43dd-8848-14fa56de82e3	de882ed5-4ae9-43a0-b80d-d51aae5f6a97	text	<p><span>•&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>Dextrorotation of uterus.</p>	14	2026-03-04 09:56:17.448232
678da756-00be-4dc9-99cc-65d19e110ffc	52c2375a-221f-40db-be86-b66990fdd20a	text	<p><span>1.&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>Infection</p><p><span>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; i.&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>Endometritis</p><p><span>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; ii.&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>Myometritis</p><p><span>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; iii.&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>PID</p><p>(Antibiotics after TCRE should be given)</p><p><span>2.&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>Pregnancy related <span>&nbsp;</span></p><p>miscarriage, PTB, ILUGR, ACRETA, RUPTURE, PPH, C/S</p><p><span>3.&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>Post ablative syndrome</p><p><span style="color: rgb(47, 84, 150);">Worsening pain during periods</span></p><p><span style="color: rgb(47, 84, 150);">Synechiae formation</span></p><p><span style="color: rgb(47, 84, 150);">Compartmentalization</span></p><p><span style="color: rgb(47, 84, 150);">Hematometra</span></p><p><span>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span><span style="color: rgb(47, 84, 150);">Un recognized Adenomyosis.</span></p><p><span>4.&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>Post ablation tubal sterilization syndrome</p><p><span>•&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>Occur when<span>&nbsp; </span>EA is combined with sterilization</p><p><span>•&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span><strong><u>S/S:</u></strong> cyclical unilateral/ Bilateral pelvic pain with vaginal spotting.</p><p><span>•&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span><strong><u>T/m:</u></strong> Removal of fallopian tubes <u>+</u> Hysterectomy.</p>	32	2026-03-04 09:23:12.567062
0fed16c9-5c80-4966-af55-22124372bfff	c7578a7b-6acb-48bb-a9f7-9c54c8f23e20	text	<p><span>-&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>Nulliparity<span>&nbsp;</span></p><p><span>-&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>Obesity</p><p><span>-&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp;</span>Ethnicity<span>&nbsp; </span>more in black</p><p><span>&nbsp;</span>(Black: White ,3-9:1)</p><p><span>-&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>ER , PR receptors +ve</p><p><span>-&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>Progesterone promote growth</p><p><span>-&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>1/4<sup>th</sup> are symptomatic</p><p><span>-&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>Rare before puberty and after menopause</p><p><span>&nbsp;</span>Median Growth 9% over 6months.</p>	2	2026-03-04 09:27:34.355861
f516862b-90aa-48ea-8558-895a15eac699	c7578a7b-6acb-48bb-a9f7-9c54c8f23e20	text	<h2><span><strong><em>1.</em>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </strong></span><span style="color: rgb(47, 84, 150);"><strong><em>Hormonal</em></strong></span></h2><ul><li><p><span> </span>COCP: Inconclusive role.</p></li><li><p>DMPA:<span>&nbsp;&nbsp;decrease  </span>Blood los<span>s decrease </span> volume of fibroid.</p></li><li><p>LNG: &lt;3cm,<span>&nbsp;decrease  </span>blood loss<span> increase </span>Hb (2g)</p></li><li><p>GnRH: - 36% reduction in size</p></li></ul><p><span>-&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>Improve symptoms in 12 weeks.</p><p><span>-&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>Return of symptoms after 4 – 8 weeks.</p><p><span>-&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>Return of size after 4 – 6weeks.</p>	8	2026-03-04 09:29:51.251187
80d83803-32c0-4e08-be8d-ccf229e044e7	c7578a7b-6acb-48bb-a9f7-9c54c8f23e20	heading	indication: 	13	2026-03-04 09:33:30.854025
c5dbbcf0-6ca0-470b-bb00-bb5423a009b5	c7578a7b-6acb-48bb-a9f7-9c54c8f23e20	text	<p><span>-&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>surgery/UAE failed</p><p><span>-&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>surgery/UAE not suitable</p><p><span>-&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>Pt refuses for UAE or surgery</p><p><strong><em>C/I:</em></strong> liver injury</p><p><strong><em>Dose:</em></strong> 5mg 4 Courses.</p>	14	2026-03-04 09:33:51.894651
d79dab61-7975-428f-8dde-55de48a43de1	c7578a7b-6acb-48bb-a9f7-9c54c8f23e20	text	<p>1.&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Before starting</p><p>2.&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; monthly for 2 courses</p><p>3.&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Once before new Course.</p><p>4.&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 2 – 4 weeks after treatment has stopped.</p><h2><span><strong><em>2.</em>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </strong></span><span style="color: rgb(47, 84, 150);"><strong><em>Non – Hormonal:</em></strong></span></h2><ul><li><p>Tranxamic acid -<span>&nbsp;&nbsp;&nbsp; </span>blood loss</p></li><li><p>NSAIDS -reduce blood loss and pain</p></li></ul><p>&nbsp;</p><p>&gt;&gt;HMB d/t Submucosal fibroids = 15%</p>	16	2026-03-04 09:34:48.235648
22e03d0b-0c9c-4324-b365-52dc74baaba8	631e8033-60a7-46e8-8aac-713aad3674c8	heading	Vasomotor symptoms:	10	2026-03-05 07:34:37.721874
2fc00f13-358f-4b4f-915e-bf5bd287dc31	631e8033-60a7-46e8-8aac-713aad3674c8	heading	Psychological:	12	2026-03-05 07:35:09.773938
906d9c91-dde6-4e7f-896d-c49df813b2ad	631e8033-60a7-46e8-8aac-713aad3674c8	heading	Urogenital atrophy:	14	2026-03-05 07:35:50.349133
65bedc49-668f-4e55-9cab-708122711583	631e8033-60a7-46e8-8aac-713aad3674c8	heading	Altered Sexual Function:	16	2026-03-05 07:36:33.293312
20d82702-a851-4a32-843f-7e48be93457b	dce6694e-93b3-4281-b546-8cb995c03b1d	heading	Types:	2	2026-03-05 07:46:48.748583
6b2f9a61-8102-4e29-8aa0-0b76ed619d29	dce6694e-93b3-4281-b546-8cb995c03b1d	heading	Benefits:	4	2026-03-05 07:47:15.798455
b42bd086-8d1b-4871-9fb1-f2ed6d40ba35	dce6694e-93b3-4281-b546-8cb995c03b1d	heading	Proper Use:	6	2026-03-05 07:47:41.676972
a0ddea9a-3df1-44de-b62c-3ebcd4290fb3	c7578a7b-6acb-48bb-a9f7-9c54c8f23e20	text	<table class="mm-table" style="min-width: 50px;"><colgroup><col style="min-width: 25px;"><col style="min-width: 25px;"></colgroup><tbody><tr><td colspan="1" rowspan="1"><p style="text-align: center;"><span style="color: black;"><strong>ESGE</strong></span></p></td><td colspan="1" rowspan="1"><p style="text-align: center;"><span style="color: black;"><strong>FIGO</strong></span></p></td></tr><tr><td colspan="1" rowspan="1"><p><strong>Type 0</strong>:</p><p><span>&nbsp;</span>No myometrium involvement</p><p><span>&nbsp;</span>Pedunculated entirely intra Cavity</p><p>&nbsp;</p><p><strong>Type 1:</strong> &lt;50% myometrium invasion.</p><p>&lt;90% angle of myoma surface to the uterine wall.</p><p>&gt; sessile</p><p><strong>Type 2:</strong></p><p><u>&gt;</u> 50% invasion</p><p><u>&gt;</u> 90%angle of myoma surface to uterine wall</p></td><td colspan="1" rowspan="1"><p><strong>Type 0:</strong></p><p>pedunculated</p><p><strong>Type 1</strong>: <span>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;          &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</span>submucosal</p><p>&lt;50%</p><p><span>&nbsp;</span>I/mural</p><p>Type 2: more</p><p>50% intramural</p><p>&nbsp;</p><p><strong>Type 3:</strong></p><p>Contact</p><p>Endometrium             <span>&nbsp;&nbsp;&nbsp; </span>intramural</p><p><strong>Type 4:</strong> <span>&nbsp;</span>less </p><p>Than 50%I/m</p><p>&nbsp;</p><p><strong>Type 5</strong>:</p><p><u>&gt;</u> 50% I/m</p><p><strong>Type 6:</strong><span>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;         </span>sub-serosal</p><p>&lt;50% I/m</p><p><strong>Type 7:</strong></p><p>pedunculated</p><p><strong>Type 8:</strong> Others-Broad ligament, cervical</p></td></tr><tr><td colspan="2" rowspan="1"><p><strong><u>Symptoms:</u></strong></p><p>1. Pain: Dyspnea, dragging pain, dysmenorrhea.</p><p>2. Pressure symptoms over bladder and bowel</p><p>3.HMB</p></td></tr></tbody></table>	4	2026-03-04 09:28:11.776967
ae506800-4c11-4af5-a3d2-922d3cb5d5d5	52c2375a-221f-40db-be86-b66990fdd20a	text	<h2><strong><em><u>1.Outpatient Hysteroscopy:</u></em></strong></h2><p><strong><em><u>indications</u></em></strong></p><p><span>•&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>Persist IMB</p><p><span>•&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>Persist Irregular bleeding</p><p><span>•&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>Infrequent Heavy bleeding with OBESE / PCOD</p><p><span>•&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>Taking tamoxifen</p><p><span>•&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>Unsuccessful HMB treatment.</p><p>&nbsp;</p><ul><li><p><span>&nbsp; </span>Under L/A, (with or without oral Analgesia) in women</p></li></ul><p>Who decline<span>&nbsp; </span>S/A, G/A or USG</p><ul><li><p>Endometrial Biopsy is taken @ the time of hysteroscopy</p></li><li><p>Vaginoscopy is added as a standard diagnostic technique (3.5mm or smaller)</p></li><li><p>Facility of see and treat.</p></li></ul><h2><strong><em><u>2.Pelvic USG:</u></em></strong></h2><p><strong><em><u>indications</u></em></strong></p><p><span>•&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>uterus <span>&nbsp;</span>is palpable abdominally</p><p><span>•&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>Pelvic mass</p><p><span>•&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>Obese post patient <span>&nbsp;</span>or where the examination is difficult or inconclusive.</p><p><span>•&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>Larger fibroids</p><h2><strong><em><u>3.Trans Vaginal Scan (TVS):</u></em></strong></h2><p><strong><em><u>indications</u></em></strong></p><p><span>•&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>Significant dysmenorrhea + Heavy menstrual bleeding (HMB).</p><p><span>•&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>Bulky tender uterus, like Adenomyosis.</p><p><span>•&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>Patient refuses or unsuitable then offer Trans abdominal scan (TAS) or MRI</p>	11	2026-03-04 09:11:03.293027
45977b90-a115-489c-928d-71ce6e0f5894	51b95cd6-d5df-4ff6-acdd-8e9ebbee28e5	text		0	2026-05-25 08:45:56.181172
e8d4d0da-c22b-464b-917f-04ea82eb2a22	52c2375a-221f-40db-be86-b66990fdd20a	text	<table class="mm-table" style="min-width: 50px;"><colgroup><col style="min-width: 25px;"><col style="min-width: 25px;"></colgroup><tbody><tr><td colspan="1" rowspan="1"><p style="text-align: center;"><span style="color: rgb(47, 84, 150);"><strong>Non-hormonal</strong></span></p></td><td colspan="1" rowspan="1"><p style="text-align: center;"><span style="color: rgb(47, 84, 150);"><strong>Hormonal</strong></span></p></td></tr><tr><td colspan="1" rowspan="1"><p>NSAIDS</p></td><td colspan="1" rowspan="1"><p>COCP</p></td></tr><tr><td colspan="1" rowspan="1"><p>Transamic acid</p></td><td colspan="1" rowspan="1"><p>Cyclical oral progesterone</p></td></tr></tbody></table><h2><strong><em>Submucosal fibroids:</em></strong></h2><p>Hysteroscopic removal</p><h3><strong><em>Fibroids 3cm or more:</em></strong></h3><p><span>•&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>Refers to specialist care meanwhile offer transamic acid + NSAID</p><p><span>•&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>Consider 2<sup>nd</sup> generation endometrial ablation.</p><p><span>•&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>Consider UAE, Myomectomy or hysterectomy</p><p>Discuss limitations of each.</p><ul><li><p>Pharmacological treatment less effective for fibroids &gt; 3cm</p></li></ul><p><span style="color: rgb(47, 84, 150);"><strong>Pre – Treatment GnRH</strong></span><span>if fibroids are larger&nbsp; causes surgical difficulty or in women waiting menopause.</span></p>	15	2026-03-04 09:13:53.820404
dfcc4222-6ab4-4419-966b-b592a1e3ef40	de882ed5-4ae9-43a0-b80d-d51aae5f6a97	text	<p><span>1.&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>Laparoscopic Myomectomy (rupture 1.2 - 6.8% open 0.4%)</p><p>(due to lack of multi-layer closure)</p><p><span>2.&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>Breach of endometrial cavity</p><p><span>3.&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>&gt;50% Myometrium disruption</p><p><span>4.&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>Large cervical fibroids (incision is given atleast 2cm away from fibroid)</p><p><span>5.&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>Classical c/s with more than 10cm scar</p><p><span>6.&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>Broad ligament fibroids.</p><p><span>•&nbsp; </span>correct dextrorotation in broad ligaments fibroids before giving uterine incision.</p>	27	2026-03-04 10:04:10.596064
ded1f202-fcd6-4471-9765-de9706a1b142	de882ed5-4ae9-43a0-b80d-d51aae5f6a97	text	<p><span>in </span>High-risk Units</p><p><span>1.&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>with no Cervix fibroids</p><p><span>2.&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>Asymptomatic small fibroids</p><p><span>3.&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>CCFHR monitoring</p><p><span>4.&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>Oxytocin infusion 24hours instead of 12hours</p><p><span>5.&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>Ergometrine if no contraindication</p><p><span>6.&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>Balloon Tamponade</p><p><span>7.&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>Uterine packing if sub mucous fibroids</p>	29	2026-03-04 10:05:08.082705
13d25da4-de9c-4dc4-9e7f-a570a980fb28	631e8033-60a7-46e8-8aac-713aad3674c8	heading	Osteoporosis:	18	2026-03-05 07:37:26.344349
bbcd64eb-5555-4328-bdce-79bcc208a595	631e8033-60a7-46e8-8aac-713aad3674c8	heading	Menopause: 	2	2026-03-05 07:17:24.785726
c91a2f1a-7cb1-4e33-b1a8-3c169e2fa9b7	631e8033-60a7-46e8-8aac-713aad3674c8	text	<p>When women has no periods for one ear or more between 45 – 55 years.</p>	3	2026-03-05 07:18:55.111867
28425bfe-48e0-43d6-bba4-61bc750a6033	631e8033-60a7-46e8-8aac-713aad3674c8	diagram	flowchart TD\n\nA[Diagnosis]\n\nA --> B["Age > 45 (No labs)"]\nA --> C["Age 40–45"]\n\nB --> D[Clinical diagnosis based on:]\nD --> E["Amenorrhea 1 year"]\nD --> F["Vasomotor symptoms"]\nD --> G["Symptoms"]\n\nC --> H["Age > 45 yrs"]\nH --> I["FSH > 30 IU"]\nI --> J["Two levels 4–6 weeks apart"]	4	2026-03-05 07:19:14.234771
070c05c7-da20-496a-853a-6908ec0f7bd8	631e8033-60a7-46e8-8aac-713aad3674c8	text	<p>1.&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Testosterone.</p><p>-&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; <span style="color: rgb(47, 84, 150);">consider if HRT alone is not effective.</span></p>	17	2026-03-05 07:37:09.587463
3a11d900-359c-4e15-8e5e-19de7f9147df	dce6694e-93b3-4281-b546-8cb995c03b1d	heading	Risks:	8	2026-03-05 07:48:08.643533
276bfbc9-d352-46fa-a245-80ec0b143460	dce6694e-93b3-4281-b546-8cb995c03b1d	heading	Follow Up:	10	2026-03-05 07:48:42.115764
f5bb4eb0-f40f-49fe-9c71-a381810727e0	dce6694e-93b3-4281-b546-8cb995c03b1d	heading	 REFER TO HEALTH CARE PROFESSIONAL:	12	2026-03-05 07:49:09.781915
3d1cc662-d8fb-4415-9dfe-718761f7ef87	52c2375a-221f-40db-be86-b66990fdd20a	html	<table class="mm-table" style="min-width: 50px;"><colgroup><col style="min-width: 25px;"><col style="min-width: 25px;"></colgroup><tbody><tr><td colspan="1" rowspan="1"><p style="text-align: center;"><strong><em>Organic</em></strong></p></td><td colspan="1" rowspan="1"><p style="text-align: center;"><strong><em>Non-Organic</em></strong></p></td></tr><tr><td colspan="1" rowspan="1"><p><span style="color: red;">P</span><span>&nbsp;&nbsp; </span>Polyp</p></td><td colspan="1" rowspan="1"><p><span style="color: red;">C </span><span>&nbsp;&nbsp;</span>Coagulation</p></td></tr><tr><td colspan="1" rowspan="1"><p><span style="color: red;">A </span><span>&nbsp;&nbsp;</span>Adenomyosis</p></td><td colspan="1" rowspan="1"><p><span style="color: red;">O </span><span>&nbsp;&nbsp;</span>Ovulation disorders</p></td></tr><tr><td colspan="1" rowspan="1"><p><span style="color: red;">L</span><span>&nbsp;&nbsp; </span>Leiomyomas</p></td><td colspan="1" rowspan="1"><p><span style="color: red;">I </span><span>&nbsp;&nbsp;&nbsp;&nbsp;</span>Iatrogenic</p></td></tr><tr><td colspan="1" rowspan="1"><p><span style="color: red;">M </span><span>&nbsp;&nbsp;</span>Malignanacy</p></td><td colspan="1" rowspan="1"><p><span style="color: red;">N</span><span>&nbsp;&nbsp; </span>Not identified</p></td></tr></tbody></table>	3	2026-03-03 07:22:33.499849
daf3797d-bef2-4258-8f9e-2e0cd5d23140	631e8033-60a7-46e8-8aac-713aad3674c8	text	<h2><span><strong><em>Dexa scan</em></strong></span></h2><p><span>-&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span><span style="color: rgb(47, 84, 150);">T-score comparison with 30yr healthy women</span></p><p><span>-&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span><span style="color: rgb(47, 84, 150);">Z-score among same age group</span></p><h2><span><strong><em>T-score</em></strong></span></h2><p><span>-&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span><span style="color: rgb(47, 84, 150);">Normal: -1 to + 1</span></p><p><span>-&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span><span style="color: rgb(47, 84, 150);">Osteopenia: -1</span><span>&nbsp; </span><span style="color: rgb(47, 84, 150);">to -2.5</span></p><p><span>-&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span><span style="color: rgb(47, 84, 150);">Osteoporosis: &lt; -2.5</span></p>	8	2026-03-05 07:32:44.308141
862cf99f-657d-41f7-ac52-fd9f9e2df2e1	025e984c-0ed5-46c5-8825-99318063c146	text	<p><span>-&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>MDT including intervention radiologist</p><p><span>-&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>Mapping by USG/MRI</p><p><span>-&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>Rule out Pregnancy, infection</p><p><span>-&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>Remove IUD</p><p><span>-&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>Written leaflet + consent</p>	4	2026-03-04 09:42:27.333428
fae8400b-81db-4b5b-acbb-b8c6094222fa	de882ed5-4ae9-43a0-b80d-d51aae5f6a97	heading	4.\tCervical 	15	2026-03-04 09:56:58.469047
fa97639c-6b10-43ba-b23f-2c86e62d0af8	52c2375a-221f-40db-be86-b66990fdd20a	text	<table class="mm-table" style="min-width: 75px;"><colgroup><col style="min-width: 25px;"><col style="min-width: 25px;"><col style="min-width: 25px;"></colgroup><tbody><tr><td colspan="1" rowspan="1"><p><span style="color: black;"><strong>Complication</strong></span></p></td><td colspan="1" rowspan="1"><p><span style="color: black;"><strong>1<sup>st</sup> generations</strong></span></p></td><td colspan="1" rowspan="1"><p><span style="color: black;"><strong>2<sup>nd</sup> Generations</strong></span></p></td></tr><tr><td colspan="1" rowspan="1"><p><span style="color: black;">1. Hemorrhage</span></p></td><td colspan="1" rowspan="1"><p><span style="color: black;">3%</span></p></td><td colspan="1" rowspan="1"><p><span style="color: black;">1.2%</span></p></td></tr><tr><td colspan="1" rowspan="1"><p><span style="color: black;">2. Perforation</span></p></td><td colspan="1" rowspan="1"><p><span style="color: black;">1.3%</span></p></td><td colspan="1" rowspan="1"><p><span style="color: black;">0.3%</span></p></td></tr><tr><td colspan="1" rowspan="1"><p><span style="color: black;">3. cervical laceration</span></p></td><td colspan="1" rowspan="1"><p><span style="color: black;">0.2%</span></p></td><td colspan="1" rowspan="1"><p><span style="color: black;">1.1%</span></p></td></tr><tr><td colspan="1" rowspan="1"><p><span style="color: black;">4. Endomeritis</span></p></td><td colspan="1" rowspan="1"><p><span style="color: black;">1.4%</span></p></td><td colspan="1" rowspan="1"><p><span style="color: black;">2%</span></p></td></tr><tr><td colspan="1" rowspan="1"><p><span style="color: black;">5. Hematometra</span></p></td><td colspan="1" rowspan="1"><p><span style="color: black;">2.4%</span></p></td><td colspan="1" rowspan="1"><p><span style="color: black;">0.7%</span></p></td></tr></tbody></table>	28	2026-03-04 09:20:57.717701
5955a551-3c1a-41d9-8991-5a2c9e7940b9	dce6694e-93b3-4281-b546-8cb995c03b1d	heading	CA Breast:	14	2026-03-05 07:49:53.115919
2c6c1261-f032-49e6-93b1-19c019a74ba3	c7578a7b-6acb-48bb-a9f7-9c54c8f23e20	heading	Limitations: 	11	2026-03-04 09:31:28.598133
3aaf73c7-d3bc-425e-bb62-5aff7157a6af	c7578a7b-6acb-48bb-a9f7-9c54c8f23e20	text	<p><span>&nbsp;</span>- surgical plains become obscure.</p><p>- small myomas become less identifiable.</p><ul><li><p><span> </span><strong><em>SPRM:</em></strong> 10mg, reduces blood loss, given in Research setting</p></li><li><p><strong><em>SERM:</em></strong> Tamoxifen, Raloxifene – limited use.</p></li><li><p><strong><em>Aromatase inhibiters:</em></strong> Letrazole – given in Experimental settings.</p></li></ul><p><strong>UPA:</strong> risk of hepatotoxicity</p><p>Effective in fibroid <u>&gt;</u> 3cm</p>	12	2026-03-04 09:31:49.74972
cc34f2f9-bd1f-4bc0-bb8d-ad4f4c2370c7	c7578a7b-6acb-48bb-a9f7-9c54c8f23e20	heading	LFTS:	15	2026-03-04 09:34:29.257288
068a48df-03bc-4434-b081-ad8c917a91a6	c7578a7b-6acb-48bb-a9f7-9c54c8f23e20	text	<p>Arise from single cell</p>	0	2026-03-04 09:27:16.691377
4cb4a81e-8e9d-4547-ba97-12ff377d0070	c7578a7b-6acb-48bb-a9f7-9c54c8f23e20	heading	Risk Factor:	1	2026-03-04 09:26:25.534586
a6d3c567-725c-4c2b-8a69-e237a02b83ba	c7578a7b-6acb-48bb-a9f7-9c54c8f23e20	heading	Classification:	3	2026-03-04 09:27:53.318281
3811e05d-a90a-4b22-8ac4-c54462d1f96c	c7578a7b-6acb-48bb-a9f7-9c54c8f23e20	heading	Treatment: 	5	2026-03-04 09:28:55.849864
360c3167-a1f6-499d-88ac-32d2b68c07df	c7578a7b-6acb-48bb-a9f7-9c54c8f23e20	text	<p><span style="color: rgb(47, 84, 150);">Pharmacological Treatment</span></p><p>&gt; for short term use</p><p><span>&nbsp;</span>&gt; less than 3cm respond to medicine</p><p>&gt;given in PATIENT near menopause, waiting for surgery, Anemia correction.</p>	6	2026-03-04 09:29:13.543136
d33b849d-8559-4b95-a06f-2affdfa2459a	c7578a7b-6acb-48bb-a9f7-9c54c8f23e20	heading	Pharmacological treatment:	7	2026-03-04 09:29:36.327828
6d08cc0e-f624-4ee3-8b57-f2581cc6f0f7	c7578a7b-6acb-48bb-a9f7-9c54c8f23e20	heading	Given: 	9	2026-03-04 09:30:39.580451
f7b81b4c-3662-4ebb-a6ea-cb0096afa234	c7578a7b-6acb-48bb-a9f7-9c54c8f23e20	text	<p>- In Pts near menopause</p><p>- to reduce size</p><p>- to build Hb.</p>	10	2026-03-04 09:31:10.12801
890f99ad-850d-45bc-8040-008f212df000	025e984c-0ed5-46c5-8825-99318063c146	heading	Procedure:	5	2026-03-04 09:42:47.020721
cf9a5338-3ad9-45ae-966d-e9228393d2e9	025e984c-0ed5-46c5-8825-99318063c146	heading	COMPLICATIONS:	7	2026-03-04 09:43:22.037277
480d5f55-6bad-493c-b982-6be7968277d5	025e984c-0ed5-46c5-8825-99318063c146	heading	1. Immediate:	8	2026-03-04 09:43:34.976429
3164108c-4ad1-4c35-9263-841e9ed8696e	025e984c-0ed5-46c5-8825-99318063c146	heading	2. Early complications:	10	2026-03-04 09:44:23.405851
6618238b-938e-4b47-948c-e4ac4d7e9059	025e984c-0ed5-46c5-8825-99318063c146	heading	treatment:	12	2026-03-04 09:45:26.72549
c857e5b9-bdad-4a97-a3ac-c59306133854	025e984c-0ed5-46c5-8825-99318063c146	text	<p><span>-&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>3-5% may require admission</p><p><span>-&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>Analgesics</p><p><span>-&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>i/V fluids</p>	13	2026-03-04 09:45:45.630643
6b084229-ac60-4aa7-a82b-847a094ee56d	025e984c-0ed5-46c5-8825-99318063c146	heading	Pregnancy After UAE:	14	2026-03-04 09:46:16.008297
48f95981-0e03-4edf-a434-786f04133f2d	025e984c-0ed5-46c5-8825-99318063c146	heading	INDICATIONS:	1	2026-03-04 09:40:48.987163
27dbebfa-ddd5-4c37-acba-d391d90622bb	025e984c-0ed5-46c5-8825-99318063c146	text	<p><span><strong>&nbsp;</strong></span><span style="color: rgb(47, 84, 150);"><strong>&gt;</strong> </span>80-90% symptoms control</p><p>&gt;40-70% <span>&nbsp;</span>decrease in volume/size</p>	0	2026-03-04 09:40:31.63609
a54f1838-7f72-4a38-acc5-52a07de0e9de	025e984c-0ed5-46c5-8825-99318063c146	heading	Pre – Treatment Assessment:	3	2026-03-04 09:42:04.718958
cb5eea98-3361-42fa-9cdc-1541b37f2126	025e984c-0ed5-46c5-8825-99318063c146	text	<p><span>-&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>hematoma of Groin</p><p><span>-&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>Thrombosis, Dissection, Aneurysm</p><p><span>-&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>Reaction to contrast media</p><p><span>-&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>pain</p><p><span>-&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>non trargeted embolization</p>	9	2026-03-04 09:44:07.549439
f5264874-29ee-432a-bf29-b28949c2bd63	025e984c-0ed5-46c5-8825-99318063c146	heading	3. Late complications:	16	2026-03-04 09:48:57.182058
330eb45c-912d-4e16-bbd0-3acfed4330ab	025e984c-0ed5-46c5-8825-99318063c146	text	<p><span>&nbsp;&nbsp;&nbsp; </span>beyond 30 days</p><p><span>-&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>Vaginal infection 16%</p><p><span>-&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>Fibroid impaction 10%, more in sub mucosal may require Hysteroscopic retrieval.</p><p><span>-&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>Endometritis 0.5%</p><p><span>-&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>Amenorrhea 1.5- 7%</p><p><span>-&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>Ovarian dysfunction</p><p><span>-&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>Recurrence of symptoms, requiring Hysterectomy 25%</p><p><span>-&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>Sexual dysfunction, improves 26%, Deteriorate 10%, rest unchanged.</p>	17	2026-03-04 09:49:18.347287
d30dd2c5-27ed-4fcd-b1de-167a52e6aa10	025e984c-0ed5-46c5-8825-99318063c146	text	<p><span>-&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>conscious sedation</p><p><span>-&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>Anti-spasmodic+ analgesics</p><p><span>-&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>Vital Monitoring + Recussitation Facilities should be available</p><p><span>-&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>Catheter enters rt femoral artery percutaneously. From Femoral it goes to External iliac artery and then to common iliac Artry. From common iliac it goes to the internal iliac and finally to the uterine artery.</p><p><span>-&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>embolic agent 300-750micrometer</p><p><span>-&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>polyvinyl alcohol is agent of choice</p><p><span>-&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>4 – 5 fr catheter is used.</p>	6	2026-03-04 09:43:04.651937
448543e2-2c59-484a-ac51-f770e0fe31cd	025e984c-0ed5-46c5-8825-99318063c146	text	<p><span>&nbsp;&nbsp;&nbsp; </span>Within 30 days</p><p><span>-&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>UTI</p><p><span>-&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>Vaginal discharge-Self limiting</p><p><span>-&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>Post embolization syndrome</p><ul><li><p>pain, fever, nausea, Malaise</p></li><li><p>increased inflammatory markers, increase TLC</p></li><li><p>Self-limiting 10 days - 2 weeks</p></li></ul><p>Due to release of inflammatory mediators from necrosis of fibroids</p>	11	2026-03-04 09:44:43.774263
5c69bd48-ffa5-4118-8e7c-267ca25d6d74	025e984c-0ed5-46c5-8825-99318063c146	text	<p><span>-&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>Miscarriage</p><p><span>-&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>SGA</p><p><span>-&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>PPH</p><p><span>-&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; increased </span>Caesarian section</p><p><span>-&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>Abnormal presentation.</p>	15	2026-03-04 09:48:02.113882
473faf45-d5f4-49d8-a907-349cdb863538	025e984c-0ed5-46c5-8825-99318063c146	heading	MRgFUS:	18	2026-03-04 09:49:38.454431
d3cc8580-db39-41ce-8c1c-e8f4b3950785	025e984c-0ed5-46c5-8825-99318063c146	text	<p><span>-&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>7-fold re intervention with in 12months.</p><p><span>-&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; increase </span>in size @ 12months.</p><p><span>-&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>less mortality and morbidity.</p><p><span>-&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>less vascular fibroid responds more to this modality.</p>	19	2026-03-04 09:50:05.856971
c85faa29-3d62-43ec-85de-28de7a65c291	de882ed5-4ae9-43a0-b80d-d51aae5f6a97	text	<p><span>-&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>Increase in size more in 1<sup>st</sup> trimester.</p><p><span>-&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>Fibroids in lower segment migrate upwards.</p>	18	2026-03-04 09:58:01.22984
0b697f1c-0feb-4774-b7a1-8ec355ee8f50	de882ed5-4ae9-43a0-b80d-d51aae5f6a97	heading	Effects of Fibroids on Pregnancy:	22	2026-03-04 10:00:35.605721
c8b5ed3f-d80e-44a4-ac73-585e29996502	dce6694e-93b3-4281-b546-8cb995c03b1d	heading	VTE:	20	2026-03-05 07:51:58.439748
b89842b6-5b29-4223-b7a6-a16f4e991ed1	dce6694e-93b3-4281-b546-8cb995c03b1d	heading	Indications:	0	2026-03-05 07:46:28.758509
9dab8d73-4add-479c-b198-9dc15a398c23	dce6694e-93b3-4281-b546-8cb995c03b1d	heading	 BRCA positive + Saplingoopherectomy:	18	2026-03-05 07:51:13.501426
c5756aa0-5342-46f8-a080-992370b82b60	dce6694e-93b3-4281-b546-8cb995c03b1d	text	<p>•&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; HRT if uterus intact otherwise ERT until the age of Menopause.</p>	19	2026-03-05 07:51:26.207826
d08fa4aa-5390-46a1-9e63-75e396b2b15a	dce6694e-93b3-4281-b546-8cb995c03b1d	heading	Women with familial risk of CA Breast:	16	2026-03-05 07:50:22.603329
b223f485-59a4-4d7f-9f5a-06d2b8062011	025e984c-0ed5-46c5-8825-99318063c146	text	<p><span>1.&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>Fibroid with comorbidities contraindicating surgery</p><p><span>2.&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>Jehovah’s witness</p><p><span>3.&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>Fibroid + Adenomyosis (after counselling) causing HMB, pressure symptoms on urinary or gastrointestinal symptoms.</p><table class="mm-table" style="min-width: 50px;"><colgroup><col style="min-width: 25px;"><col style="min-width: 25px;"></colgroup><tbody><tr><td colspan="1" rowspan="1"><p style="text-align: center;"><span style="color: black;"><strong>contraindication</strong></span><span><strong>&nbsp; </strong>&nbsp;&nbsp;</span></p></td><td colspan="1" rowspan="1"><p style="text-align: center;"><span style="color: black;"><strong>Relative Contraindication</strong></span></p></td></tr><tr><td colspan="1" rowspan="1"><p>1. PID</p><p>&nbsp;</p></td><td colspan="1" rowspan="1"><p>1.large I/cavity fibroids risk of cervix occlusion &amp; sepsis</p><p>&nbsp;</p></td></tr><tr><td colspan="1" rowspan="1"><p>2. unconfirmed diagnosis</p></td><td colspan="1" rowspan="1"><p>2.pedunculated sub serosal fibroids requiring laparoscopic retrieval</p><p>&nbsp;</p></td></tr><tr><td colspan="1" rowspan="1"><p>3. Pregnancy</p></td><td colspan="1" rowspan="1"><p>3. Fertility wishes</p></td></tr><tr><td colspan="1" rowspan="1"><p>4. Asymptomatic fibroids.</p></td><td colspan="1" rowspan="1"><p>&nbsp;</p></td></tr><tr><td colspan="1" rowspan="1"><p>5. If not consenting for hysterectomy</p><p>&nbsp;</p></td><td colspan="1" rowspan="1"><p>&nbsp;</p></td></tr></tbody></table>	2	2026-03-04 09:41:05.455321
6f498fe2-943e-4864-aeb3-db648148fb7f	de882ed5-4ae9-43a0-b80d-d51aae5f6a97	heading	3. Hystrectomy: 	4	2026-03-04 09:53:10.631713
8030e461-1f18-4db7-a35c-c0ccce87f5b7	de882ed5-4ae9-43a0-b80d-d51aae5f6a97	text	<p>definitive treatment with maximum satisfaction</p>	5	2026-03-04 09:53:28.241659
83366d4d-d40f-435b-a790-a59612ed47fb	de882ed5-4ae9-43a0-b80d-d51aae5f6a97	heading	Fibroids in pregnancy:	6	2026-03-04 09:53:56.258663
be40d2b4-5fd5-4252-956d-3c06d4b9ee8e	de882ed5-4ae9-43a0-b80d-d51aae5f6a97	text	<p><span>-&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>10.7% in 1<sup>st</sup> trimester.</p><p><span>-&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>More in south Asia, Africa &amp; middle east Subcontinent.</p>	7	2026-03-04 09:54:14.410719
e69d877c-e8d6-4f9e-8202-0107ca23b651	de882ed5-4ae9-43a0-b80d-d51aae5f6a97	heading	Fibroid complications in pregnancy:	8	2026-03-04 09:54:30.334919
b42f924d-2ab0-41e3-9fab-2fd8bae367b7	de882ed5-4ae9-43a0-b80d-d51aae5f6a97	heading	1.\tIntramural:	9	2026-03-04 09:54:43.119078
130d3ce3-9c4a-4975-b7ce-b0bfcb8b6602	de882ed5-4ae9-43a0-b80d-d51aae5f6a97	text	<p><span>•&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>PPH-&gt; peripartum Hysterectomy</p><p><span>•&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>Pre – term birth</p><p><span>•&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>Malpresentation if myoma is &gt;5cm</p><p><span>•&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Increased </span>Caesarian section rate</p><p><span>•&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>Retained placenta</p><p><span>•&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>Abruption</p><p><span>•&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>Previa</p>	10	2026-03-04 09:54:56.107958
130d83ac-75ee-4016-bfd4-84b83d8c466f	de882ed5-4ae9-43a0-b80d-d51aae5f6a97	heading	2.\tSubmucus:	11	2026-03-04 09:55:22.742649
061c5adb-05a7-4afe-88d0-aea5bc412cda	de882ed5-4ae9-43a0-b80d-d51aae5f6a97	heading	Effect of pregnancy on Fibroids:	17	2026-03-04 09:57:47.41203
564e4d70-d84f-47fa-b5a9-17995904f90a	de882ed5-4ae9-43a0-b80d-d51aae5f6a97	heading	Consultant led ANC:	19	2026-03-04 09:59:30.52585
d9f49bcd-ce9d-41f9-83dc-3161446538ff	de882ed5-4ae9-43a0-b80d-d51aae5f6a97	heading	indications	20	2026-03-04 09:59:46.507864
5ad639af-967e-4e86-8df3-e8d114427b7e	de882ed5-4ae9-43a0-b80d-d51aae5f6a97	text	<p><span>-&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>Fibroid &gt; 3cm</p><p><span>-&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>Adjacent to placenta</p><p><span>Cervical fibroid</span></p>	21	2026-03-04 10:00:09.265151
be276563-9a59-4dda-bc78-f2c7d2f071f7	de882ed5-4ae9-43a0-b80d-d51aae5f6a97	heading	Antenatal Myomectomy Indications:	24	2026-03-04 10:01:23.246011
fc52c5c5-f9ae-4010-a6a3-b50be1c347eb	de882ed5-4ae9-43a0-b80d-d51aae5f6a97	text	<p><span>1.&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>For severe pain</p><p><span>2.&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>Rapidly enlarging fibroids</p><p><span>3.&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>Fibroid &gt;5cm</p><p><span>4.&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>Torsion of pedunculated fibroid</p><p>1<sup>st</sup> and 2<sup>nd</sup> trimester most suitable time &amp; it <span>decreases the </span>risk of peri partum hysterectomy.</p><p><strong>Risks:</strong> rupture, Caesarian section.</p><p><strong>Recommended: in</strong> Canadian Guideline.</p>	25	2026-03-04 10:02:48.968928
489a45bd-49bd-4a70-b9a8-5ac1d61bfe6d	de882ed5-4ae9-43a0-b80d-d51aae5f6a97	heading	Indication of Elective caesarian section in previous myomectomy:	26	2026-03-04 10:03:53.265281
1982adf6-0d55-4044-872f-a0b8da1b5604	de882ed5-4ae9-43a0-b80d-d51aae5f6a97	heading	vaginal delivery: 	28	2026-03-04 10:04:37.501951
78dc4f56-354a-4ea1-9008-d4e8d240f4b0	de882ed5-4ae9-43a0-b80d-d51aae5f6a97	heading	1. hysteroscopic myomectomy: 	0	2026-03-04 09:51:39.219081
a6d73bcf-09cd-419f-918a-9410544de7a8	de882ed5-4ae9-43a0-b80d-d51aae5f6a97	heading	2. open/ Laproscopic Myomectomy:	2	2026-03-04 09:52:14.113013
5684823e-5392-4648-b827-a858384a568d	631e8033-60a7-46e8-8aac-713aad3674c8	heading	SERM:	22	2026-03-05 07:44:22.782113
2c2dad6c-7c1c-48ed-9efe-a8bd89606d11	631e8033-60a7-46e8-8aac-713aad3674c8	heading	 Vaginal Estrogen Deficiency:	20	2026-03-05 07:43:59.498307
b70a4345-4976-4485-8d43-c6ca82c26b92	dce6694e-93b3-4281-b546-8cb995c03b1d	text	<p>-&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; HRT can be given.</p>	31	2026-03-05 07:56:03.621947
62b7166a-feca-4c3f-a91e-955275ba87b7	dce6694e-93b3-4281-b546-8cb995c03b1d	heading	PERSONAL HISTORY OF VTE:	28	2026-03-05 07:55:20.002187
43814668-5f7a-4156-8b28-c8a56a854afc	dce6694e-93b3-4281-b546-8cb995c03b1d	heading	DIABETES:	30	2026-03-05 07:55:53.665019
505e5fcf-d09a-45e6-af5d-bbeec6f2d3df	de882ed5-4ae9-43a0-b80d-d51aae5f6a97	heading	Myomectomy @time of Caesarian Section: 	30	2026-03-04 10:05:47.635391
3fffce1c-efe1-4cb7-83c8-e6501c295757	631e8033-60a7-46e8-8aac-713aad3674c8	text	<p>1.&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Vaginal estrogen (offer)</p><p>even patients are on HRT to improve local symptoms.</p><p>-&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; <span style="color: rgb(47, 84, 150);">Consider even if systemic HRT is Contraindicated.</span></p><p>-&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; <span style="color: rgb(47, 84, 150);">No relief</span>&nbsp;increase <span style="color: rgb(47, 84, 150);">Dose after advice from expert</span></p><p>-&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; <span style="color: rgb(47, 84, 150);">No endometrial thickness monitoring is required with vaginal estrogen.</span></p><p>2.&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Lubricants:</p><p>-&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; <span style="color: rgb(47, 84, 150);">For local dryness along with estrogen.</span></p><p>3.&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; If vaginal estrogen and lubricants are not effective/ not tolerated offer vaginal progesterone.</p><p>4.&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; If vaginal treatment impractical.</p><p>e.g,. disability</p><p>Consider ospemifene oral treatment</p>	15	2026-03-05 07:36:23.025574
420bf138-49a5-4897-b7af-be81b040e8fc	de882ed5-4ae9-43a0-b80d-d51aae5f6a97	text	<p><span>•&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>Sub mucosal intra cavity fibroids. causing HMB, Subfertility or<span>&nbsp; </span>miscarriage.</p><p><span>•&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>Sub mucous fibroids cause</p><p><span>&nbsp;</span>HMB 6-34%</p><p>subfertility 2-7%,</p><p>1-5% asymptomatic.</p><p><span>•&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>ESGE classification is useful for predicting success of hysteroscopic myomectomy.</p><p><span>•&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>Grade O &amp; I =&gt; easily resectable</p><p><span>•&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>Grade 2 =&gt; difficulty, more complications, need experts.</p><p>thickness between myoma and uterine wall up to serosa is an important feature to determine safety.</p><p><span>•&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>Resectoscopic slicing is gold standard for Intra Cavity grade 0.</p><p><span>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>Grade 1 &amp; 2 no prover technique.</p><p><span>•&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>Myolysis and cryomyolysis =&gt; more <span>adhesions</span>.</p>	1	2026-03-04 09:51:57.250292
db674ad9-937d-4535-9058-799b19c14f19	de882ed5-4ae9-43a0-b80d-d51aae5f6a97	text	<p>techniques to reduce intraoperative blood loss.</p><p><span>-&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>GnRH Analogues</p><p><span>-&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>SPRM</p><p><span>-&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>Vasopressin</p><p><span>-&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>tourniquets</p><p>Open =&gt; for multiple fibroids.</p><p>Laparoscopy =&gt; for single fibroid.</p>	3	2026-03-04 09:52:37.426068
25c262cc-1e1e-4ae1-808e-b83e948e520d	de882ed5-4ae9-43a0-b80d-d51aae5f6a97	text	<p><span>•&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>Malpresentation</p><p><span>•&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>Failure of head to descend.</p>	16	2026-03-04 09:57:31.960113
97121965-13e9-4e25-b7f0-cf37088c7c59	dce6694e-93b3-4281-b546-8cb995c03b1d	text	<p><span>•&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>Venous thromboembolism: 8 times more.</p><p><span>•&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>Cancer Breast: 8 times more (risk with combined Hormones Replacement Therapy)</p><p><span>•&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>Stroke: 7 times more<span>&nbsp; </span>risk, increases with age.</p><p><span>•&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>MI: 6 times more<span>&nbsp; </span>risk with combined Hormones Replacement Therapy.</p><p><span>•&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>Cancer ovary: 1.5 times</p><p><span>•&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>CA endometrium: estrogen Replacement Therapy</p><p><span>•&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>Dementia: &gt;65yrs old</p><p><span>Gall Bladder Disease.</span></p>	9	2026-03-05 07:48:32.569195
0325d607-a949-473d-bcd6-38d9de853941	dce6694e-93b3-4281-b546-8cb995c03b1d	text	<ul><li><p><span> </span>Menopausal symptoms + C/I to HRT (Cancer breast).</p></li></ul><p><span>•&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</span>Troublesome S/E</p><p><span>•&nbsp;&nbsp;&nbsp;&nbsp; </span>No improvement with HRT.</p><p><span>•&nbsp;&nbsp;&nbsp;&nbsp; </span>Uncertainty about suitable option.</p>	13	2026-03-05 07:49:23.801218
0f74ff39-29eb-49e1-8bbf-1acb9ef0a424	51b95cd6-d5df-4ff6-acdd-8e9ebbee28e5	heading		1	2026-05-25 08:46:22.582127
ab9112b7-3f6e-487b-b087-15381f883281	de882ed5-4ae9-43a0-b80d-d51aae5f6a97	text	<p><span>-&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>10 -30% develop complication</p><p><span>-&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>More complication with fibroids &gt; 200cm3</p><p><span style="color: rgb(47, 84, 150);"><strong><em>Pain</em></strong></span><span style="color: red;"><strong><em>:</em></strong></span> &gt;5cm in 2<sup>nd</sup> &amp; 3<sup>rd </sup>trimester.</p><p><span style="color: rgb(47, 84, 150);"><strong><em>Red degeneration</em></strong></span></p><p><span><strong><em>&nbsp;</em></strong></span><span style="color: black;"><strong><em>treatment</em></strong></span></p><p><span>-&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Analgesics</span></p><p><span>-&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>Paracetamol</p><p><span>-&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp;</span>opioids</p><p><span>-&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>NSAIDs can be given for maximum 48 hours.</p><p><span style="color: rgb(47, 84, 150);"><strong><em>Pressure symptoms:</em></strong></span></p><p><strong>Miscarriage:</strong> 14% compared to no fibroid 8%, more in fibroids of body of uterus.</p><p><strong>Fetal Anomalies:</strong><span style="color: red;"> </span><span>&nbsp;</span>Rare</p><p><span>&nbsp;</span>Dolichocephaly, torticollis, limb reduction</p><p><strong>SGA:</strong> Serial growth scan recommended as SFH is not reliable</p><p><strong>MRI:</strong> For rapidly growing fibroids</p>	23	2026-03-04 10:00:53.572936
82b66caf-e26a-4728-8ef6-227fb64e5f60	631e8033-60a7-46e8-8aac-713aad3674c8	text	<p></p><table class="mm-table" style="min-width: 50px;"><colgroup><col style="min-width: 25px;"><col style="min-width: 25px;"></colgroup><tbody><tr><td colspan="1" rowspan="1"><p><span style="color: black;"><strong>Estrogen replacement therapy ERT</strong></span></p></td><td colspan="1" rowspan="1"><p><span style="color: black;"><strong>Hormone replacement therapy HRT </strong></span> <span style="color: black;"><strong>combined estrogen + progesterone</strong></span></p></td></tr><tr><td colspan="1" rowspan="1"><p>No uterus</p></td><td colspan="1" rowspan="1"><p>With uterus</p></td></tr></tbody></table><p>1.&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; HRT: offer as 1<sup>st</sup> line until contraindications</p><p>2.&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; SSRI, SNRI, clonidine</p><p><span style="color: rgb(47, 84, 150);">Don't offer as 1<sup>st</sup> line</span></p><p>3.&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Black cohosh + isoflavins</p><p><span style="color: rgb(47, 84, 150);">No safety data but can improve symptoms.</span></p>	11	2026-03-05 07:34:51.207486
fcc77a63-b21d-4327-ac23-af2d724b07b4	dce6694e-93b3-4281-b546-8cb995c03b1d	text	<p><span>•&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>1<sup>st</sup> visit</p><p><span>&nbsp;</span>after 3months to check efficiency.</p><p><span>•&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>Thereafter - Annually.</p>	11	2026-03-05 07:49:03.225006
31d8bff9-4f8c-4df3-8325-876333a2a365	631e8033-60a7-46e8-8aac-713aad3674c8	text	<p>Interval leading to menopause, anovulatory cycle</p><p><span>•&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span><strong><em><u>Climacteric:</u></em></strong> period between Reproductive to non-reproductive life.</p><p><span>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>It includes Menopause.</p><p><span>•&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span><strong><em><u>POF:</u></em></strong><span style="color: red;"> </span><span>&nbsp;</span>&lt; 40years</p><p><span>&nbsp;</span>turner syndrome, Fragile X, Autoimmune Disorders, idiopathic.</p><p>1% of women experience POF</p><p><span>•&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span><strong><em><u>Early menopause</u></em></strong> &lt; 45 years between age of 40 – 45 yrs.</p><p><span style="color: rgb(47, 84, 150);">Decreased</span> <span style="color: rgb(47, 84, 150);">E and P =&gt;</span>&nbsp;&nbsp;&nbsp; FSH pulsitility</p><p><span style="color: rgb(47, 84, 150);">Decreased E and P =&gt; </span>Menopausal symptoms more in 1<sup>st</sup> year.</p><p>After 1-year estrogen production starts from non-ovarian source leading to reduced symptoms.</p>	1	2026-03-05 07:16:55.567022
ea16bebe-9dfc-4b2d-ba45-74c6bfec0cdd	631e8033-60a7-46e8-8aac-713aad3674c8	text	<p>1.&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; HRT (consider)</p><p>-&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; <span style="color: rgb(47, 84, 150);">To improve mood</span></p><p>2.&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; CBT (consider)</p><p>-&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; <span style="color: rgb(47, 84, 150);">No role of SSRI, SNRI to ease low mood.</span></p>	13	2026-03-05 07:35:30.011116
02bcd59d-4698-4948-8fc6-aadc7338fe6b	631e8033-60a7-46e8-8aac-713aad3674c8	text	<p>1.&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Prophylaxis</p><p>-&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; <span style="color: rgb(47, 84, 150);">HRT</span></p><p>-&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; <span style="color: rgb(47, 84, 150);">Raloxifene SERM</span></p><p>-&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; <span style="color: rgb(47, 84, 150);">Tibolone with GnRH analogue </span> <span style="color: rgb(47, 84, 150);">if given for &gt; 6months.</span></p><p>2.&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Therapeutic</p><p>-&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; <span style="color: rgb(47, 84, 150);">Bisphosphate + Calcium 1.5g + vitamin D 400 - 600 daily.</span></p><p><strong>1st line:</strong> Alendronate if T score is <u>&lt;</u> <a target="_blank" rel="noopener noreferrer nofollow" class="mm-link" href="http://2.5.it">2.5.it</a> inhibits osteoporosis</p><p><strong>2nd line:</strong> Risedronate &amp; Etidronate if  T score is - 2.5 - 3 or Alendronate is Contraindications.</p><p><strong>3rd line:</strong> Strontium Ranolate (2g/day Hs) &amp; Raloxifene if T - score is - 2.5 - 4 or Age <u>&gt;</u> 54.</p><p><strong>4th line:</strong> teriparatide</p><p>&gt;40-50% discontinue t/m after 1yr.</p><p>&gt;65-75% after 2yrs.</p>	19	2026-03-05 07:38:23.35892
aad5b021-0c39-435a-892d-c74bada80093	dce6694e-93b3-4281-b546-8cb995c03b1d	text	<p><span>•&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>HRT can be given for short duration.</p><p><span>•&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>Offer ERT.</p>	17	2026-03-05 07:50:52.672176
3e2ce27b-3338-4b76-a653-a8f42eb6dc40	dce6694e-93b3-4281-b546-8cb995c03b1d	text	<p>-&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Refer to Hematologist</p><p>•&nbsp; FH of VTE</p><p>•&nbsp; Hereditry Thrombophilia</p><p>-&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; consider Transdermal route in Patients with high risk of venous thromboembolism (VTE) including BMI &gt; 30.</p>	21	2026-03-05 07:51:28.781867
d01c33e6-e6f8-4440-ac0f-2c4996be774f	dce6694e-93b3-4281-b546-8cb995c03b1d	text	<p><span>•&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>Vasomotor symptoms, Vaginal dryness,</p><p><span>•&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>C/I:</p><ol><li><p><a target="_blank" rel="noopener noreferrer nofollow" class="mm-link" href="http://1.CA">CA</a> Breast</p></li></ol><p>2. Personal history of VTE (oral).</p>	1	2026-03-05 07:46:38.333947
d06b2f34-804f-4af7-bfcf-58503072320d	dce6694e-93b3-4281-b546-8cb995c03b1d	text	<p><span>•&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp;</span>Max 5yrs.</p><p><span>•&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp;</span>&gt; 5 years=&gt; individualized decision.</p><p><span>•&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp;</span>POF=&gt; Contraception or HRT up to age of Menopause</p>	7	2026-03-05 07:48:02.247142
209b04e6-c455-4d38-ab64-56301ae218bd	1ec05f17-3698-4528-b414-f33f8f9e0c2b	heading	•\tCauses and treatment: 	2	2026-03-05 08:59:59.562108
860d7b05-0362-4ba2-90fe-d37b13b3b773	dce6694e-93b3-4281-b546-8cb995c03b1d	text	<p><span>•&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>Don't offer HRT, soy, clover, Cohosh, Vit<span>&nbsp; </span>E.</p><p><span>•&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>Vasomotor symptoms: offer SSRI (but not to those who are taking tamoxifen).</p><p><span>•&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>Venlafaxine is offered.</p>	15	2026-03-05 07:50:15.930622
0511fcf5-7143-4f4c-8869-b6fd4a924ec6	126fe5cf-71e2-4469-8a89-2bf0498f7cc5	heading	•\tOvarian Cancer:	0	2026-03-05 07:57:51.568551
951d7589-5e77-47ee-acf0-1634ed33f0bd	126fe5cf-71e2-4469-8a89-2bf0498f7cc5	text	<p>(avoid)</p>	1	2026-03-05 07:58:00.820006
cc372a65-43ec-41ef-bf80-43a15bccd135	dce6694e-93b3-4281-b546-8cb995c03b1d	text	<p><span>1.&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>Estrogen Replacement Therapy.</p><p><span>2.&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>Combined Hormones Replacement Therapy.</p><p><span>•&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>Sequential combine therapy SCT</p><p><span>&nbsp;</span>given in Perimenopause,</p><p><span>&nbsp;</span>estrogen - whole cycle, progesterone- 10-14days</p><p><span>•&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>Continuous combined Therapy CCT</p><p>Given in Menopause</p><p><span>&nbsp;</span>Estrogen and Progesterone continuously</p>	3	2026-03-05 07:47:07.623652
106709fa-cbaf-4ad2-b9f2-755c175d8708	dce6694e-93b3-4281-b546-8cb995c03b1d	heading	HRT ADVICE BEFORE SURGERY:	24	2026-03-05 07:53:46.64136
d2183bbb-400c-4efe-85df-dbba4bd44fb4	dce6694e-93b3-4281-b546-8cb995c03b1d	text	<p><span>-&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>Stop before elective surgery.</p><p><span>-&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>No need to stop if Thromboprophylaxis is taken.</p>	25	2026-03-05 07:54:10.033882
7d1b366d-87d5-40ef-8daa-ba5f54f68887	dce6694e-93b3-4281-b546-8cb995c03b1d	heading	RISK OF VTE INCREASES:	26	2026-03-05 07:54:26.434547
20176f9f-e0b3-43fc-9d1d-125d6961a588	dce6694e-93b3-4281-b546-8cb995c03b1d	text	<p><span>1.&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>with conjugated equine E(Premarin) as compared to valerate.</p><p><span>2.&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>With pregnane derivative progestogen as compared to Micronized.</p>	27	2026-03-05 07:55:04.218078
757c169a-32b1-4770-9abe-eb73b4bf34b6	dce6694e-93b3-4281-b546-8cb995c03b1d	text	<p>-&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; C/I of oral HRT.</p><p>-&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; if needed then transdermal route is prefferd along with Anti-coagulant Thromboprophylaxis.</p>	29	2026-03-05 07:55:44.613529
9c541f15-5d2b-4648-b3b7-d9f6f5137a1a	6f36db59-1cc0-4586-8c6a-1c8bb00a8e0c	heading	1.\tCauses:	1	2026-03-05 08:57:18.217432
748269fd-53b7-4b29-91ba-ad4e3d45ffbc	126fe5cf-71e2-4469-8a89-2bf0498f7cc5	heading	•\tEndometrial Cancer:	2	2026-03-05 07:58:10.403053
df40cfb0-8dba-4eb2-813f-568d54eb8bf4	126fe5cf-71e2-4469-8a89-2bf0498f7cc5	text	<p><span>Type 1: Stage 1 and 2</span></p><p><span>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp;E only if no chance of malignant focus</span></p><p><span>Type 1: Stage 3 and 4 avoid.</span></p><p><span>Type 2: Avoid.</span></p>	3	2026-03-05 07:58:23.550929
023d8887-a226-41a7-9c3a-6dc38d8b9420	126fe5cf-71e2-4469-8a89-2bf0498f7cc5	heading	•\tCervical Cancer: 	4	2026-03-05 07:58:38.02883
e4e2653a-6198-4ce0-9f40-65fba1dff16d	126fe5cf-71e2-4469-8a89-2bf0498f7cc5	text	<p><span>•&nbsp; </span><span style="color: rgb(47, 84, 150);">sequamous cell carcinoma</span></p><p><span>-&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>stage 1 and 2</p><p>Continuous combined therapy (CCT) or Estrogen (according to status of uterus)</p><p><span>-&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>stage 3 &amp; 4 – Avoid.</p><p><span>•&nbsp; </span><span style="color: rgb(47, 84, 150);">Adenocarcinoma (avoid)</span></p>	5	2026-03-05 07:58:52.743161
f70578f9-cb20-4dc8-a9be-5ce3ac8616a2	6f36db59-1cc0-4586-8c6a-1c8bb00a8e0c	heading	2.\tManagement:	3	2026-03-05 08:58:06.730445
3b5e666c-bd6a-4c38-9b40-da36e0aa8d2d	126fe5cf-71e2-4469-8a89-2bf0498f7cc5	heading	•\tVaginal + vulval Cancer: 	6	2026-03-05 07:59:09.187548
a8fc0868-f4ca-48e9-818c-49b95c3f72a5	6f36db59-1cc0-4586-8c6a-1c8bb00a8e0c	text	<p><span>Incidence = 10%.</span></p>	0	2026-03-05 08:57:10.271998
190173aa-24df-463f-ae01-c10394653a22	126fe5cf-71e2-4469-8a89-2bf0498f7cc5	text	<p><span>•&nbsp; </span>Seq cell = Estrogen or CCT.</p><p><span>•&nbsp; </span>non seq – avoid</p>	7	2026-03-05 07:59:23.538963
f7163397-b32b-4f44-8628-5758f717f78c	6f36db59-1cc0-4586-8c6a-1c8bb00a8e0c	text	<p><span>-&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 90% benign</span></p><p><span>-&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 10% malignant</span></p><p><span>-&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Atrophic vaginitis/ Endometritis = 75%</span></p><p><span>-&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; HRT = 20%</span></p><p><span>-&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Polyps = 12%</span></p><p><span>-&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Hyperplasia = 10%</span></p><p><span>-&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; CA = 10%</span></p><p><span>-&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Prolapse</span></p><p><span>-&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Evaluation</span></p><ul><li><p><span> </span><span style="color: rgb(47, 84, 150);">Local examination</span></p></li><li><p><span>&nbsp;</span><span style="color: rgb(47, 84, 150);">TVS</span></p></li><li><p><span style="color: rgb(47, 84, 150);">Endometrial Biopsy if ET &gt; 5mm</span></p></li><li><p><span style="color: rgb(47, 84, 150);">Hysteroscopy</span></p></li></ul>	2	2026-03-05 08:57:35.502154
43bc2ee2-5460-4299-8eec-e68d82bfb7bb	6f36db59-1cc0-4586-8c6a-1c8bb00a8e0c	text	<p><span>1.&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Endometrial thickness&lt; 5mm =&gt; Endometrial atrophy – No t/m required</span></p><p><span>2.&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Atrophic vagina: local E &amp; vaginal moisturizers.</span></p><p><span>3.&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Polyps + Submucosal-Fibroids =&gt; Hysteroscopic resection and Biopsy</span></p><p><span>4.&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Hyperplasia – Hysterectomy</span></p><p><span>5.&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Malignancy =&gt; refer to oncologist.</span></p><p><span>6.&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Polyp</span></p><p><span>&gt;remove if symptomatic or more than 1cm</span></p>	4	2026-03-05 08:58:25.467859
ed9153d3-59b6-42f0-bf26-8035e73de055	1ec05f17-3698-4528-b414-f33f8f9e0c2b	heading	IBS	7	2026-03-05 09:02:35.224686
c167540d-20bf-46e7-bb18-a502a7380dd1	1ec05f17-3698-4528-b414-f33f8f9e0c2b	heading	Investigations:	9	2026-03-05 09:03:32.006233
44294460-4483-4b3e-90d5-1e7afb1d6d15	1ec05f17-3698-4528-b414-f33f8f9e0c2b	text	<p><span>-&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>Co-Dydramol</p><p><span>-&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>paracetamol</p><p><span>-&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>LUNA.</p>	12	2026-03-05 09:05:26.455172
cda2440f-7690-4895-9347-15bafabd179a	1ec05f17-3698-4528-b414-f33f8f9e0c2b	heading	•\tDefinition: 	0	2026-03-05 08:59:38.454713
f5dcce3d-ce4e-4ae1-ab41-1b8d60b29336	1ec05f17-3698-4528-b414-f33f8f9e0c2b	text	<p><span>Constant pain in lower Abdomen or pelvis of @ least 6months duration not occurring exclusively with menstruation or intercourse and not related to pregnancy.</span></p>	1	2026-03-05 08:59:43.999029
b0a0fa80-764c-4f3c-b42f-c18ab51601e9	1ec05f17-3698-4528-b414-f33f8f9e0c2b	text	<p><span>-&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; <strong><em>Hormone related</em></strong></span></p><p><span>&nbsp;t/m is OCPs for 3 -6 months before offering laparoscopy</span></p><p><span>-&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; <strong><em>Pelvic congestion</em></strong></span></p><p><span>-&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; t/m is progestogen, GnRH analogue</span></p><p><span>-&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; <strong><em>Endometriosis/Adnomyosis</em></strong> - progesterone, GnRH analogues, Danazol, Mirena, COCP.</span></p>	4	2026-03-05 09:00:15.327283
0c583ccb-2511-40ca-b1be-0085a07035e8	1ec05f17-3698-4528-b414-f33f8f9e0c2b	heading	Adhesions:	5	2026-03-05 09:01:05.915635
ec2d7c64-1ef9-4b3b-b96f-af5bf997188a	1ec05f17-3698-4528-b414-f33f8f9e0c2b	text	<p><span>-&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Fine Adhesions:</span></p><ul><li><p><span> No role of adhesiolysis</span></p></li></ul><p><span>-&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Dense Adhesions:</span></p><ul><li><p><span>Adhesiolysis improve pain</span></p></li></ul><p><span>-&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Trapped ovary syndrome &nbsp;suppression with GnRH &nbsp;&nbsp;analogues or ophrectomy</span></p><p><span>-&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Residual ovary syndrome suppression with GnRH analogues or oophorectomy.</span></p>	6	2026-03-05 09:02:10.402348
7b78b16a-ff0b-4e14-920f-a17664f1213b	1ec05f17-3698-4528-b414-f33f8f9e0c2b	text	<p><span>-&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>STI <span>&nbsp;</span>screen in all sexually active women</p><p><span>-&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>Chlamydia, Gonorrhea screen if suspicions of PiD</p><p><span>-&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>TVS – Endometriosis, Adenomyosis/</p><p><span>-&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>Laparoscopy – 1/3 or ½ r negative, done if t/m fails.</p><p><span>-&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; <strong>&nbsp;</strong></span>CA-125: Old women &gt; 50yrs history of bloating early satiety and pelvic pain <span>&nbsp;</span>of &gt; 12 episode/year.</p>	10	2026-03-05 09:04:16.045234
d63de386-d70d-45e8-afe3-2e72efa4aff6	1ec05f17-3698-4528-b414-f33f8f9e0c2b	heading	Treatment:	11	2026-03-05 09:04:24.786258
0e205ed2-2fed-4034-8591-52d706db448b	1ec05f17-3698-4528-b414-f33f8f9e0c2b	heading	•  Cyclic pain:	3	2026-03-05 09:00:52.562987
eb93c947-ac59-40b4-b74a-0ec9ef56005a	dc104b3f-ed6a-4f1f-8046-73c069161cb6	text	<p><span>•&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Incidence = 40%.</span></p><p><span>•&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Severe PMS = 5 – 8%.</span></p>	0	2026-03-05 09:07:40.679991
1e78a859-7070-4a94-a694-50f7654d1a85	1ec05f17-3698-4528-b414-f33f8f9e0c2b	text	<p><span>-&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>50% of CPP t/m Diet + Antispasmodics mebaverine HCL.</p><ul><li><p><strong>interstitial cystitis:</strong></p></li></ul><p><span>-&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>38 – 84%</p><ul><li><p><strong>Musculoskeletal:</strong></p></li></ul><p><span>-&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>Spasm of pelvic floor muscles, Tender Synovioiliac Joint or pubic symphysis.</p><ul><li><p><strong>Nerve entrapment:</strong></p></li></ul><p><span>-&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>3.7% after C/S, Pfannenstiel incision.</p><p><span>-&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>Pain Persist beyond 5 weeks – Gabapentin, Amitriptyline</p><ul><li><p><strong>Psychological factors:</strong></p></li></ul><p><span>Child abuse.</span></p>	8	2026-03-05 09:03:02.403761
2f893548-dda2-4e96-a90c-00654d917c9a	dc104b3f-ed6a-4f1f-8046-73c069161cb6	heading	1.\tPsychological Symptoms:	1	2026-03-05 09:07:46.19056
bb5c0c18-aeda-4204-8c7f-2a57e3b2e885	dc104b3f-ed6a-4f1f-8046-73c069161cb6	text	<p>Depression, irritability, loss of interest, mood swings, loss of confidence – due to serotonin + GABA receptors.</p>	2	2026-03-05 09:08:05.144681
9422e372-7615-4a58-9f54-7919181451ce	dc104b3f-ed6a-4f1f-8046-73c069161cb6	heading	2.\tPhysical symptoms:	3	2026-03-05 09:08:44.045102
6820515e-83e0-4fab-a36d-ef2076717d38	dc104b3f-ed6a-4f1f-8046-73c069161cb6	text	<p>Belatedness, Mastalgia</p><p>More in luteal phase.</p><p><span><strong><u>Etiology:</u></strong></span></p><p><span style="color: rgb(47, 84, 150);"><strong>Two theories</strong></span></p><p><span>1.&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>women with PMS progesterone levels are same but increased sensitivity.</p>	4	2026-03-05 09:08:25.808616
b02f508d-a3cc-48f7-94f7-4e45bec89a31	dc104b3f-ed6a-4f1f-8046-73c069161cb6	heading	2.      Neurotransmitters	5	2026-03-05 09:09:23.573216
9b72b3dc-33b5-4285-a492-36a9acf3c7ee	dc104b3f-ed6a-4f1f-8046-73c069161cb6	heading	Diagnosis:	6	2026-03-05 09:10:31.590432
2b21d3e1-0e59-4cb1-84df-b6d9049b491a	dc104b3f-ed6a-4f1f-8046-73c069161cb6	text	<p>-&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp;<span style="color: rgb(47, 84, 150);">serotonin receptors r sensiti</span></p><blockquote><h3>-&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 📌📍📊🏷️✅❎🔚🔜1️⃣2️⃣3️⃣6️⃣7️⃣9️⃣🔟↕️↔️↩️↪️⤴️GABA levels r <strong>modulated by Allopregnanolone</strong> ⬆️) in PMS allopregnanolone is&nbsp;decreased.</h3></blockquote>	7	2026-03-05 09:09:39.418201
bcdac350-b895-4fe1-bc51-6be3ba884ca2	dc104b3f-ed6a-4f1f-8046-73c069161cb6	text	<p>symptoms diary over 2 months before starting treatment</p><p>if inconclusive =&gt;trial of GnRH Analogues A for 3 months for definitive diagnosis</p>	8	2026-03-05 09:11:03.217685
47f2dd9f-7745-43b5-b759-68b70aaa195b	126fe5cf-71e2-4469-8a89-2bf0498f7cc5	diagram	 %%{init:24px}%%\ngraph TD\n    A[This text will be larger] --> B[And this too]\n    B --> C[Even titles and labels grow]flowchart TB\n\nA[Unscheduled Bleeding on HRT]\n\nA --> B[First 3 months: common]\nB --> C[If >3 months → workup]\nC --> D[History, exam, HRT type]\n\nD --> SCT\nD --> CCT\n\n\n%% LEFT COLUMN\nsubgraph SCT["SCT"]\ndirection TB\n\nS1[Determine bleeding]\n\nS1 --> S2[Heavy prolonged withdrawal]\nS1 --> S3[Breakthrough bleeding]\n\nS3 --> S4[TVS check ET]\n\nS4 --> S5["ET ≥7 mm"]\nS4 --> S6["ET <7 mm"]\n\nS5 --> S7[Endometrial biopsy]\n\nS7 --> S8[Treatment]\n\nS8 --> S9[↑ Progesterone dose]\nS8 --> S10[Early P-phase bleed → ↑ P]\nS8 --> S11[E-phase spotting → ↑ E]\nS8 --> S12[Irregular → change regimen]\nS8 --> S13[Painful → change P]\n\nS6 --> S14[Observe]\n\nend\n\n\n\n%% RIGHT COLUMN\nsubgraph CCT["CCT"]\ndirection TB\n\nC1[Check duration]\n\nC1 --> C2["<6 months"]\nC1 --> C3["≥6 months"]\n\nC2 --> C4[Reassure]\n\nC3 --> C5[TVS]\n\nC5 --> C6["ET ≤5 mm"]\nC5 --> C7["ET >5 mm"]\n\nC6 --> C8[Atrophic endometrium]\nC7 --> C9[Biopsy]\n\nC8 --> C10[Treatment]\n\nC10 --> C11[Low-dose estrogen]\nC10 --> C12[↑ or change progesterone]\n\nC10 --> C13[Other options]\n\nC13 --> C14[Stop HRT]\nC13 --> C15[Mirena]\nC13 --> C16[Ablation / referral]\n\nC3 --> C17[TVS indications]\n\nC17 --> C18[Bleeding after 6 months]\nC17 --> C19[Bleeding after amenorrhea]\nC17 --> C20[Early bleed in high-risk]\n\nC3 --> C21[Hysteroscopy indications]\n\nC21 --> C22[Multiple episodes]\nC21 --> C23[Focal lesion on TVS]\nC21 --> C24[High ET]\nC21 --> C25[Incomplete TVS view]\nC21 --> C26[High risk hyperplasia/CA]\n\nend	8	2026-03-05 08:29:54.727044
0c9f857a-96a6-41ef-8318-632e91046260	dc104b3f-ed6a-4f1f-8046-73c069161cb6	html		9	2026-03-06 13:18:28.744438
98a3138e-d8cc-4391-9865-9c3f240ee6e3	4d4ecf5d-7535-46ca-b9ff-8f4b19de7353	text		0	2026-05-25 08:28:31.212087
9cdc5887-1461-4c73-822f-f1b9c65df801	51b95cd6-d5df-4ff6-acdd-8e9ebbee28e5	text		2	2026-05-25 08:46:40.335849
72a270c2-1a51-4040-8c26-507b5ea21242	451cca65-ae17-4959-bfd9-043a725fa698	text	<p><span style="color: rgb(34, 34, 34);">There is no clear demarcation between clinical (e.g. medication error) and non-clinical (e.g. falls off a trolley) risk management and it is preferable to take a holistic view of patient safety. However, strategies to prevent errors happening again may have the same or different pathways.</span></p><p><span style="color: rgb(34, 34, 34);">This remains a basic framework to begin examination of an incident.&nbsp;Typically, actions should be considered across 3 levels.</span></p><p><span style="color: rgb(34, 34, 34);">1.<strong>How engaged are you in your unit's risk management programs?</strong></span></p><p><span style="color: rgb(34, 34, 34);"><strong>2.How many patient safety incidents have you been involved with in the last 6 months?</strong></span></p><p><strong>3.&nbsp;</strong><span style="color: rgb(34, 34, 34);"><strong>In how many of these incidents did you complete an incident form? What happened to the form and what feedback did you receive?</strong></span></p>	3	2026-06-01 08:02:30.035888
18488a94-f7b9-4b11-a9b0-3cb4cb9d2caf	9ffb1679-4328-47c6-b6c8-df01cc2337ed	text	<p><span style="color: rgb(34, 34, 34);"><strong>But clinical effectiveness also needs to encompass broader, qualitative aspects of care:</strong></span></p><p>•&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; <span style="color: rgb(34, 34, 34);">Holistic care</span></p><p>•&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; <span style="color: rgb(34, 34, 34);">Continuity of care</span></p><p>•&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; <span style="color: rgb(34, 34, 34);">sensitivity to the personal needs of the patient.</span></p>	2	2026-06-01 07:49:36.264474
d199f37b-490a-4e98-a68f-5612e1fa3651	9ffb1679-4328-47c6-b6c8-df01cc2337ed	text	<p><span style="color: rgb(34, 34, 34);">Understanding these aspects of patient care forces us to recognize the diversity of patients. Not just in terms of gender, ethnicity or sexuality but also capacity, social background and acknowledging previous experiences. This enables us to personalize care and integrate clinical effectiveness with patients' previous experiences. This is the basis of person-centered care ('what matters to you' rather than 'what’s the matter with you'). Clinical governance therefore needs to foster and promote this side of care as integral to the improvement of services and is likely to achieve better outcomes. &nbsp;Ultimately therapies are only of value if patients accept and believe in them. Finding the right prompts is the key to reaching an agreement with patients and is most likely to result in successful therapies.</span></p>	3	2026-06-01 07:50:19.998311
2f70f67a-22f2-444c-956e-c0ea2e175d6c	358587df-8f59-4495-9488-56031c7dbed1	text	<p><span style="color: rgb(34, 34, 34);">is defined by the RCOG as 'a quality improvement process that seeks to improve patient care and outcomes through systematic review of care against explicit criteria and the implementation of change'.</span></p>	0	2026-06-01 07:53:45.31017
0cfdecc9-d1b6-4aa2-a5de-67d061bee571	451cca65-ae17-4959-bfd9-043a725fa698	heading	Basic questions addressed by risk management:	1	2026-06-01 07:59:12.913977
30d47e4e-57c8-4ff2-b1c8-403414873fd6	358587df-8f59-4495-9488-56031c7dbed1	text	<p><span style="color: rgb(34, 34, 34);">The aim of audit is to ensure clinical practice is continuously monitored and that deficiencies in relation to set standards of care are remedied</span></p>	2	2026-06-01 07:54:25.664142
ec02c9f7-89f8-4fba-9602-e360ecf69747	594220af-32d7-4d00-98ad-a2c733d4be33	text	<p><span>•&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Understanding of the learner’s speciﬁc needs</span></p><p><span>•&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Understanding of the educational targets and mandates from national organizations</span></p><p><span>•&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Clinical and surgical competence</span></p><p><span>•&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Possession of knowledge</span></p><p><span>•&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Organizational ability</span></p><p><span>•&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Good time management</span></p><p><span>•&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Ability to use different teaching methods appropriately</span></p><p><span>•&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Ability to guarantee patients’ privacy, dignity and safety</span></p>	1	2026-06-01 08:37:18.821371
fe4aacb8-ceee-453e-987e-d5833e59610c	358587df-8f59-4495-9488-56031c7dbed1	text	<p><span style="color: rgb(34, 34, 34);">Criterion-based clinical audits assess local clinical performance against agreed standards, implement changes to clinical practice in order to enhance performance, and then reassess performance. This is a cyclical quality improvement process. Clinical audit usually assesses one or more of the following domains:</span></p><p>•&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; <span style="color: rgb(34, 34, 34);">Structure (organization or provision) of care</span></p><p>•&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; <span style="color: rgb(34, 34, 34);">Process of care</span></p><p>•&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; <span style="color: rgb(34, 34, 34);">Outcome of care.</span></p>	3	2026-06-01 07:54:43.877696
1d6e3d47-62f1-42ca-8af7-4a505c774178	358587df-8f59-4495-9488-56031c7dbed1	heading	The audit cycle	4	2026-06-01 07:55:20.441304
47e016af-83cb-4482-84bc-9d3ac779e149	358587df-8f59-4495-9488-56031c7dbed1	text	<p><span style="color: rgb(34, 34, 34);">Audit can be considered to have five principal steps, commonly referred to as the audit cycle (Figure 1):</span></p><p><span style="color: rgb(34, 34, 34);">1. Selection of a topic</span></p><p><span style="color: rgb(34, 34, 34);">2. Identification of an appropriate standard</span></p><p><span style="color: rgb(34, 34, 34);">3. Data collection to assess performance against the prespecified standard</span></p><p><span style="color: rgb(34, 34, 34);">4. Implementation of changes to improve care if necessary</span></p><p><span style="color: rgb(34, 34, 34);">5. Data collection for a second, or subsequent, time to determine whether care has improved.</span></p>	5	2026-06-01 07:56:01.137819
90cc2add-1952-4e65-9965-8e456bee902d	358587df-8f59-4495-9488-56031c7dbed1	text	<p><span style="color: rgb(34, 34, 34);">Audit projects require a multidisciplinary approach with the involvement of stakeholders (including consumers or users of the service provided) and the local audit department at the planning stage. Good planning and resources are also necessary to ensure its success.</span></p><p><span style="color: rgb(34, 34, 34);"><br></span></p><p><span style="color: rgb(34, 34, 34);">&nbsp;</span></p><img class="mm-inline-image" src="/uploads/content-images/1781531256126-759f4448-d7aa-4c5a-90f6-18f3750748cc.png">	6	2026-06-01 07:57:00.595646
d0d64817-b6d3-43f2-b7e0-f30cef141c36	95a94798-0d07-48c4-8238-f06aa0c591d5	text	<p><span><strong>Mini clinical exams : Mini – cex &nbsp;</strong></span></p><p><span>-&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; supervised learning event tool evaluating a clinical encounter with patient to provide feedback on Skills essential for good clinical care e.g. history examination, clinical <strong>reasoning.</strong></span></p>	2	2026-06-01 08:44:46.469985
4389e8f2-2fdc-4a1b-80a1-ba92f1168ae1	358587df-8f59-4495-9488-56031c7dbed1	text	<p><span style="color: rgb(34, 34, 34);">Aspects of the structure, processes and outcomes of care are selected and systematically evaluated against explicit criteria. Where indicated, changes are implemented at an individual, team or service level and further monitoring is used to confirm improvement in healthcare delivery."</span></p>	1	2026-06-01 07:53:45.32962
4faffda8-640e-4aa2-927c-d0b871b1618f	451cca65-ae17-4959-bfd9-043a725fa698	heading	Risk register	4	2026-06-01 08:11:03.396166
02b2c0ea-0fe6-4b61-9f85-2905726da769	524a24bc-11d0-4940-b38b-7510f98c20ef	text	<p><span>Happy: tell us</span></p><p><span>Enquiry: let us help you</span></p><p><span>Unhappy: let us resolve together</span></p>	4	2026-06-01 08:20:19.048381
171e05c2-637e-4f02-af68-b475a02fa10b	524a24bc-11d0-4940-b38b-7510f98c20ef	heading	Pts complaints:	5	2026-06-01 08:20:58.544861
f48335f5-7b2f-479f-a58f-b00fe3b5232c	524a24bc-11d0-4940-b38b-7510f98c20ef	text	<p>Pts complaints:</p><p><span><strong><u>1.PALS:</u></strong></span></p><p><span>•&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Pts lodges their complaints at local level</span></p><p><span>•&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Majority of complaints are resoled locally</span></p><p><span>•&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; If not satisfied then refer to ombudsman</span></p><p><span><strong><u>2.Ombudsman</u></strong></span></p><p><span>•&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Parliamentary health services</span></p><p><span>•&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Undertake independent investigations to complaints that has not been settled at the local level.</span></p>	6	2026-06-01 08:21:23.005134
f61d78d8-d874-4e63-96d8-0ec040588528	451cca65-ae17-4959-bfd9-043a725fa698	text	<p><span style="color: rgb(34, 34, 34);">1.All risks should have an action plan</span></p><p><span style="color: rgb(34, 34, 34);">2.Each unit should have risk register best in electronic form</span></p><p><span style="color: rgb(34, 34, 34);">3.Shortage of staff and equipment must be mentioned in register before starting the shift</span></p>	5	2026-06-01 08:11:32.335456
75e87bf5-3e74-4312-847f-caecfeb69108	451cca65-ae17-4959-bfd9-043a725fa698	text	<p><span style="color: rgb(34, 34, 34);">Healthcare is considered by many to be most the complex industry in the world. Despite major efforts, acute admission to hospital still retain a 10% chance of an adverse event. There remains a magnitude of difference in the reliability of healthcare processes when compared to processes within the airline industry or nuclear industry.</span></p><p><span style="color: rgb(34, 34, 34);">Risk is the uncertainty surrounding events and their outcomes. All our activities carry some risk and risk is inherent in every activity.&nbsp;</span></p>	0	2026-06-01 07:58:46.128698
d207a022-2947-477c-9715-f66316932d62	524a24bc-11d0-4940-b38b-7510f98c20ef	heading	Patient advisory liaison services PALS 	1	2026-06-01 08:19:20.507444
f4eadd56-7586-4d84-b94b-37c19f8716eb	524a24bc-11d0-4940-b38b-7510f98c20ef	text	<p><span style="color: rgb(34, 34, 34);">Pts and public can be engaged in a variety of ways</span></p><p><span>•&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Patient advisory and liaison services</span></p><p><span>•&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Quantitative pts surveys (questionnaires)</span></p><p><span>•&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Qualitative pts surveys (depth interview, focus groups)</span></p><p><span>•&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Pts stories and diaries/observational studies</span></p><p><span>•&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Workshops and conferences</span></p><p><span>•&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Consultation with pt representative and group</span></p><p><span>•&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Pts forums, council and panels</span></p><p><span>Pt representative committee and group</span></p>	0	2026-06-01 08:19:00.40329
becc671c-4793-42cb-a7de-36949facb3cd	524a24bc-11d0-4940-b38b-7510f98c20ef	text	<p><span>Where pts can enroll their complaints</span></p><p><span>Whether they are annoyed, pleased or need inquiry</span></p>	2	2026-06-01 08:19:30.052312
a01d5ca8-3609-4a5e-84c6-33df42edc296	524a24bc-11d0-4940-b38b-7510f98c20ef	heading	PALS statement	3	2026-06-01 08:19:55.995801
1232b4aa-5b81-4272-8439-e46aeffcb8c8	f988c7af-2d0e-47aa-b1a6-ac3a9ec374b6	heading	Advantages and the disadvantages of Maternity Dashboard.	4	2026-06-01 08:25:57.348103
f0e27681-9a00-45b3-b66a-f8723d0537a6	f988c7af-2d0e-47aa-b1a6-ac3a9ec374b6	heading	Responsibilities for filling the maternity dashboard.	2	2026-06-01 08:24:56.122467
6b88cef3-4e11-41a4-aa6a-538ed371f393	451cca65-ae17-4959-bfd9-043a725fa698	heading	Root cause analysis:	6	2026-06-01 08:12:40.446734
dc147b8a-b9c1-4b17-aea8-315d3a0a020c	451cca65-ae17-4959-bfd9-043a725fa698	text	<p>1.identify incident and take decision to investigate</p><p><a target="_blank" rel="noopener noreferrer nofollow" class="mm-link" href="http://2.select">2.select</a> members of investigation team</p><p>3.gather data (record, interview, protocols)</p><p>4.determine chronology of incidents</p><p>5.identify care delivery problems (unsafe act, failure to act, incorrect decision)</p><p>6.identify contributing factors (lack of supervision, inadequate training)</p><p>7.device an action plan</p>	7	2026-06-01 08:13:11.065086
4115f6af-73c2-4e06-9528-c5d94096e723	451cca65-ae17-4959-bfd9-043a725fa698	heading	Risk management process\n	8	2026-06-01 08:16:30.035003
a3561102-3cc6-443e-ba20-3f8486554f81	f988c7af-2d0e-47aa-b1a6-ac3a9ec374b6	text	<p><span>Benchmarking is defined as a setting standard and they are compared with the performance and it can be monitored via clinical indicators.</span></p><p><span>Maternity Dashboard is a tool that can be employed to monitor the implementation of principles of the clinical governance on the ground.</span></p><p><span>&nbsp;It can be used to benchmark the activity and monitor the performance against the standards agreed locally for the maternity unit on a monthly basis</span></p><p><span>Principles of the CAR Dashboard, which provides contemporary information about the amount of fuel in the tank, speed, state of the battery, temperature of the engine, so that appropriate action can be taken before the car breaks or slows down.</span></p><p><span>Contemporary information about resources, clinical activity, risk management issues, user views, and so on, thus enabling early identification of the deviation from agreed goals and initiating timely and appropriate action to be taken to avoid patient safety incidents and to improve clinical care.</span></p><p><span>&nbsp;Individual maternity units should set local thresholds for each of the parameters monitored, as well as upper and lower threshold.</span></p>	0	2026-06-01 08:23:02.44388
5d7dfbd3-93a3-490d-9914-4a33e9bf9217	f988c7af-2d0e-47aa-b1a6-ac3a9ec374b6	text	<p><span><strong><em><u>The goal</u></em></strong> is to use a traffic light system,</span></p><p><span>•&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; <strong><u>&nbsp;</u></strong></span><strong><u>green</u></strong> when the goals are met (within the lower threshold)</p><p><span>•&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span><strong><u>amber</u></strong> when the goals are not met (above the lower threshold but still within the upper threshold.) It indicates action is needed if one has to avoid entering the red zone.</p><p><span>•&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; <strong><u>Red</u></strong> when the upper threshold is breached, here it requires immediate action from the highest level to maintain safety and restore the quality.</span></p><p><span>Parameters to be included are clinical activity, workforce, clinical outcome, risk incidents, complaints, or the patient satisfaction surveys.</span></p>	1	2026-06-01 08:23:11.633613
c4418760-b1d9-454c-a97f-a3eac86cc8e1	f988c7af-2d0e-47aa-b1a6-ac3a9ec374b6	text	<p><span>&nbsp;The primary objective is maternity dashboard is to ensure continuous improvement in the clinical care with clearly defined mechanisms and named individual responsible identified to deal with these issues as they arise.</span></p><p><span>The score card also provides information to establish trends such as increase in the number of caesarean sections requires an input from obstetrician, labour ward, clinical lead, third and the fourth degree, perineal tears, patient complaints.</span></p><p><span>Since it is important for someone with a clinical risk perspective to be responsible for maternity dashboard, such a person could be the risk manager, lead midwife for the risk working closely with the lead consultant for the labour ward. It is also shared with consumer representative in the Labor Board Forum and maternity Services liaison committees.</span></p>	3	2026-06-01 08:25:08.126239
3ab65373-0cdb-422d-a11b-006904770c32	f988c7af-2d0e-47aa-b1a6-ac3a9ec374b6	text	<p><span>It improved the overall quality of care by informing the health providers about the performance</span></p><p><span>&nbsp;to stimulate the comparisons between other maternity units to identify the areas for the further improvement.</span></p><p><span>It helped to understand how processes for delivering the health care services are designed to meet patient quality and operational requirements, including the best practice requirements.</span></p><p><span>Helped to design and deliver the processes are coordinated and tested to ensure the smooth delivery of maternity care.</span></p><p><span>The only disadvantage is that we consider it as another paper exercise. To avoid this pitfall, it is important to modify the Maternity Dashboard to suit local needs.</span></p><p><span>&nbsp;</span></p>	5	2026-06-01 08:26:09.694608
3fa79c27-957c-40c8-be7d-fda50d134502	4dc9b993-9478-4088-80c5-3996d53748b8	text	<p><span>•&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Meeting with educational supervisor within 2 wks of induction</span></p><p><span>•&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Review e log and current competencies</span></p><p><span>•&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Set achieveable goals</span></p><p><span>•&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Add educational goals</span></p><p><span>•&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Record meetingon induction/appraisal form</span></p>	0	2026-06-01 08:42:38.735834
bd346de5-f17f-4429-a96c-3251873805d1	4dc9b993-9478-4088-80c5-3996d53748b8	text	<p><span><strong><u>APPRAISAL</u></strong></span></p><p><span>•&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; is done after a duration like one year after induction to assess that goals are achieved or not</span></p><p><span>•&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Purpose is to test competences</span></p><p><span>•&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; once per year , continuous process</span></p><p><span>•&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; informal meeting between apraiser and apraisee on a mutually agreed time</span></p><p><span>•&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; both open and closed questions</span></p><p><span>•&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; apraisee should submit development plan 7-14 days before meeting</span></p><p><span>•&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; purpose is to ensure safe practise for licence and ARCP</span></p><p><span>•&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; apraiser is a good negotiator and listener</span></p><p><span>•&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; time distribution is 70/30</span></p><p><span>•&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; documented and record is kept</span></p><p><span>•&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; confidential but not legally protected</span></p>	1	2026-06-01 08:42:46.881771
89a44e91-be6e-4f6c-8e5c-c1e01374e708	594220af-32d7-4d00-98ad-a2c733d4be33	heading	Enthusiasm for teaching	0	2026-06-01 08:37:10.688416
77862d3e-8489-4597-b7ec-66413350e5b2	594220af-32d7-4d00-98ad-a2c733d4be33	heading	Types of teaching methods	2	2026-06-01 08:37:40.332202
8a349285-7d12-4de5-94b4-fad5d0f27153	594220af-32d7-4d00-98ad-a2c733d4be33	text	<p><span><strong><u>Lectures:</u></strong></span></p><p><span>Only 5% retention rate</span></p><p><span>Most clinicians are comfortable</span></p><p><span>Notes of a teacher becomes the notes of a student</span></p><p><span>Useful only in early stages of carrier</span></p><p><span>Don’t promote clinical thinking and deep learning</span></p><p><strong><u>Problem base learning:</u></strong></p><p>50% retention rate</p><p>Teacher is a facilitator and make sure that everyone take part</p><p>Includes case base discussions and problem-based discussions</p><p><span><strong><u>&nbsp;1-minute preceptor:</u></strong></span></p><p><span>This is a ﬁve-step process that can be carried out in minutes 15 with the purpose of structuring teaching opportunities that arise in the clinical environment. This is an example of a teaching method that demands a good rapport between the teacher and the learner(s). The teacher must make the learner feel secure and allow the voicing of opinions, whether they are correct or in correct.</span></p><p><span>The ﬁve steps are:</span></p><p><span>commitment</span></p><p><span>justiﬁcation</span></p><p><span>application</span></p><p><span>positive reinforcement</span></p><p><span>correction of mistakes</span></p><p><span><strong><u>Schema activation:</u></strong></span></p><p><span>•&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Recall of background concepts and knowledge</span></p><p><span>•&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; For ST1 /ST2 trainees</span></p><p><span>•&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp;For instance, it is quite reasonable for a clinical teacher to expect specialist trainees in year 1 to understand the anatomy of the vagina and cervix. These learners would have been taught the basic anatomy in medical school. The teacher would activate recall of basic facts and concepts prior to enhancing learning. An example would be the task of providing a tutorial to specialist trainees in years 1 and 2 on of genitourinary prolapse. The clinical teacher would initially apply schema activation to revise the learners’ knowledge of pelvic ﬂoor anatomy which had been taught years before but the knowledge of which is essential to all the learners in the group.</span></p><p><span><strong><u>Schema activation:</u></strong></span></p><p><span>•&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Recall of basic concepts</span></p><p><span>•&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Mostly for ST1/ST2</span></p><p><span>•&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Revision of pelvic anatomy and physiology</span></p><p><span><strong><u>Schema reﬁnement:</u></strong></span></p><p><span>•&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; This is a useful method for teaching more advanced learners. In this technique the learners are encouraged to apply basic concepts, clarify their understanding and solve clinical problems.</span></p><p><span><strong><u>Snowballing:</u></strong></span></p><p><span>•&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; This is a useful technique to employ if the teacher is unsure of the current level of knowledge or skills of the learners.</span></p><p><span>•&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Teacher starts with basic knowledge but with time knows that understanding and knowledge of learner is high leading to increased intensity of information provided by teacher</span></p><p><span><strong><u>Simpliﬁed procedural hierarchy :</u></strong></span></p><p><span>•&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; It is the most basic form, in which there is a demonstration by the teacher to the learner or learners. There is no demand for assessment, evaluation or feedback</span></p><p><span>•&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; In simple words telling the learners how to do something</span></p><p><span><strong><u>Complex procedural hierarchy</u>:</strong></span></p><p><span>•&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; In this technique a hierarchy is involved which develops over several encounters and over a signiﬁcant time span.&nbsp;&nbsp;&nbsp;&nbsp;</span></p><p><span>•&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp;In one example a consultant asks a trainee to assist in the operation of total abdominal hysterectomy. After several such operations, during which the educational experience of the trainee consists of observing surgical techniques, there is a rapport between the consultant and the trainee. The consultant would then ask the trainee to describe the operation in order to ascertain that they have grasped the steps, techniques and use of instruments that are vital to a safely conducted operation. The consultant then assists the trainee in the procedure.</span></p><p><span><strong><u>Brainstorming:</u></strong></span></p><p><span>•&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Spontaneous group discussions to produce ideas and ways of solving the problems</span></p><p><span>•&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Promote clinical and critical thinking in learners who are @ early stages in carrier</span></p><p><span>•&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Flip cards</span></p><p><span>•&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Example; teacher asking measurement of cervical length by TVS is a valid screening tool for detecting preterm labour. learners are divided into small group having their </span><a target="_blank" rel="noopener noreferrer nofollow" class="mm-link" href="http://tasks.one"><span>tasks.one</span></a><span> group discuss pathophysiology of PTL one discusses about anatomy and one discuss reliability and the 4<sup>th</sup> group discuss comparison with pelvic examination.</span></p><p><span><strong><u>Directly observed procedures and feedback:</u></strong></span></p><p><span>•&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; It has 3 steps</span></p><p><span>1.observe</span></p><p><span>2.inform</span></p><p><span>3.advice</span></p><p><span>•&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Like pessary insertion, iucd insertion</span></p><p><span>&nbsp;</span></p><p><span><strong><u>Doughnut round:</u></strong></span></p><p><span>•&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Rapid sharing of ideas</span></p><p><span>•&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Recalling information, showing anecdotes or offering opinions</span></p><p><span>•&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Before brainstorming.</span></p><p><span><strong><u>Gold fish bowl:</u></strong></span></p><p><span>•&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 4-5chairs in inner circle that is the fish bowl consisting of speakers</span></p><p><span>•&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Remaining audience in the outer circle that are listeners</span></p><p><span><strong><u>Delphi method:</u></strong></span></p><p><span>•&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Panel of experts discussing something</span></p><p><span>•&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Mainly question answer session</span></p><p><span><strong><u>Vicarious learning:</u></strong></span></p><p><span>•&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>Learning from observing the consequences of another person’s behavior and adjusting their own.</p>	3	2026-06-01 08:38:06.811385
5449f1f4-75fc-4394-a9b5-b3fddbd20a24	95a94798-0d07-48c4-8238-f06aa0c591d5	text	<p><span><strong>Workplace based assessments</strong></span></p><p><span>-&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; evaluate progression through training, they link teaching learning, and assessment in a structured way.<br>&nbsp;Workplace based assessments identify your strengths and weaknesses.</span></p>	0	2026-06-01 08:43:28.702559
892c1734-d565-4d2d-a2e6-ca22e239e7c9	95a94798-0d07-48c4-8238-f06aa0c591d5	text	<p><span><strong>OSATS:</strong> Objective Structured Assessment of Technical Skills</span></p><p><span>A validated assessment tool to assess competency in a particular technique for a procedure fundamental to obs and gynae.</span></p><p><span><strong>Formative assessments</strong></span></p><p><span>-&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; assessment for learning used to provide feedback (mini-cex and CBD, OSAT)</span></p><p><span>-&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; record all formative OSATS in portfolio</span></p><p><span><strong>Summative Assessments</strong>:</span></p><p><span>-&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Assessment of learning to demonstrate competence in a clinical situation, e.g. OSATS</span></p><p><span>-&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Formative and summative are not interchangeable, must b declared in advance either its formative or summative</span></p><p><span>-&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 3 summative OSAT per procedure before doing it independently</span></p><p><span>-&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; One annual OSAT till CCT</span></p><p><span><strong>Formative assessments</strong></span></p><p><span>-&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; assessment for learning used to provide feedback (mini-cex and CBD, OSAT)</span></p><p><span>-&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; record all formative OSATS in portfolio</span></p><p><span><strong>Summative Assessments</strong>:</span></p><p><span>-&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Assessment of learning to demonstrate competence in a clinical situation, e.g. OSATS</span></p><p><span>-&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Formative and summative are not interchangeable, must b declared in advance either its formative or summative</span></p><p><span>-&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 3 summative OSAT per procedure before doing it independently</span></p><p><span>-&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; One annual OSAT till CCT</span></p><p><span><strong><u>Examples/comparison of formative and summative OSAT</u></strong></span></p><table class="mm-table" style="min-width: 50px;"><colgroup><col style="min-width: 25px;"><col style="min-width: 25px;"></colgroup><tbody><tr><td colspan="1" rowspan="1"><p><span><strong>Formative assessment</strong></span></p></td><td colspan="1" rowspan="1"><p><span><strong>Summative</strong></span></p></td></tr><tr><td colspan="1" rowspan="1"><p><span>Feed back</span></p></td><td colspan="1" rowspan="1"><p><span>Pass/fail, completion of training</span></p></td></tr><tr><td colspan="1" rowspan="1"><p><span>Supervised learning</span></p></td><td colspan="1" rowspan="1"><p><span>Assessment of performance</span></p></td></tr><tr><td colspan="1" rowspan="1"><p><span>Annual job appraisal</span></p></td><td colspan="1" rowspan="1"><p><span>Theory test</span></p></td></tr><tr><td colspan="1" rowspan="1"><p><span>peer observation</span></p></td><td colspan="1" rowspan="1"><p><span>MRCOG 1,2,3</span></p></td></tr><tr><td colspan="1" rowspan="1"><p><span>Mock OSCE</span></p></td><td colspan="1" rowspan="1"><p><span>MRCOG OSCE</span></p></td></tr><tr><td colspan="1" rowspan="1"><p><span>Induction interview</span></p></td><td colspan="1" rowspan="1"><p><span>Job interview/recruitment interview</span></p></td></tr></tbody></table>	3	2026-06-01 08:45:29.549644
bf619087-3d1e-4db3-bed5-f69e63f00d9e	259577e9-5acd-4b6b-99a6-21ec4c50b261	text	<p><span>Is formal meeting, there will be at least 3 panel members who are appointed by the<br>Deanery's specialty training committee.”<br>Either your postgraduate dean or training program director will be on the panel.<br>The panel will review the evidence on your portfolio including workplace-based assessments, audits and projects</span></p><p><span><strong>ARCPP Outcomes</strong>:<br>&nbsp;<strong><em>Outcome 1:</em></strong></span></p><p><span>-&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Evidence is satisfactory, indicating successful transition into the next training year</span></p><p><span><strong><em>Outcome 2:</em></strong></span></p><p><span>-&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; If there are any deficiencies in training areas of poor performance the panel will</span></p><p><span>&nbsp;</span></p><p><span>recommend outcome 2, which is a recommendation for targeted training to help address the issue. <br>&nbsp;If you complete this targeted training successfully there’ll, be no delay to CCT</span></p><p><span><br>&nbsp;<strong><em>Outcome 3:</em></strong></span></p><p><span>-&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; if 2 panel identifies that you need a formal additional Period of training they will <br>&nbsp;recommend an outcome 3</span></p><p><span><strong><em>&nbsp;Outcome 4:</em></strong></span></p><p><span>-&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; if there is insufficient and sustained lack of progress despite having up to a year the |panel will recommend outcome 4 and release you from the training program</span></p><p><span>&nbsp;</span></p>	0	2026-06-01 09:35:59.425682
716a8319-cd82-48c2-8606-aeb37f2b78f1	95a94798-0d07-48c4-8238-f06aa0c591d5	text	<p><span><strong>Clinical based discussion: CBD</strong></span></p><p><span>-&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; tool for supervised learning events based on a trainee’s management of&nbsp;&nbsp; patient and provides feedback on clinical reasoning, decision making and applied medical Knowledge in relation to patient care.</span></p>	1	2026-06-01 08:44:28.487676
411daf8e-869e-4d70-b02b-0e39540c41b2	95a94798-0d07-48c4-8238-f06aa0c591d5	text	<p><strong>NOTES:</strong></p><p>-&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Non-technical skills for surgeons This is the cognitive and interpersonal skills, e.g. to see and making leadership team working. The tool provides a framework and terminology for giving feedback under the following headings. Situational Awareness, Decision Making, Communication, Teamwork, Leadership</p><p></p><p><strong>Norm reference assessment:</strong></p><p>•&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; A norm-referenced assessment is&nbsp;a type of standardized test that ranks test-takers against a peer group (norm group)</p><p>•&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Students are compared to each other</p><p>•&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Fixed no of students fail each year</p><p>•&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Candidates ability influence standard</p><p>•&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Standards are not known in advance</p><p><strong>Criterion reference standard</strong></p><p>•&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; evaluates a student's knowledge and skills against fixed, predetermined standards or learning objectives, rather than comparing them to peers.</p><p>•&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Failure rates vary</p><p><strong>&nbsp;</strong></p>	4	2026-06-01 08:47:33.121905
b522eb20-fea7-44e0-9dcc-b5f325e966e1	5781eae1-5283-4b6e-8153-2313e29501a6	text	<p><span>•&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Learning from own experience</span></p><p><span>•&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; <strong><u>Kolb’s reflective practice</u></strong></span></p><p><span>is&nbsp;a four-stage, continuous, experiential learning model where knowledge is created through transforming experience</span></p>	0	2026-06-01 09:37:05.695762
e184d824-25ce-4fc2-8e82-bc5801c11267	7fed75f0-8cf4-4815-ac45-ba31b34bd30f	text	<p><span style="color: rgb(34, 34, 34);">Appraisal and assessment are often confused but are quite different processes. Each has a different role for training and should be kept separate whenever possible.</span></p><p><span>•&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Appraisal assists learning informally:</span></p><p><span>-&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span><span style="color: rgb(34, 34, 34);">primarily intended for the appraise</span></p><p><span>-&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span><span style="color: rgb(34, 34, 34);">encourages open informal dialogue</span></p><p><span>-&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span><span style="color: rgb(34, 34, 34);">establishes learning goals&nbsp;and suggestions on how to achieve these</span></p><p><span>-&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span><span style="color: rgb(34, 34, 34);">&nbsp;addresses the concerns supportively</span></p><p><span>-&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span><span style="color: rgb(34, 34, 34);">guides the appraise throughout the year.</span></p><p><span>•&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Assessment formally tests learning has been achieved:</span></p><p><span>-&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span><span style="color: rgb(34, 34, 34);">tests that competencies have been met against a predetermined (minimum) standard</span></p><p><span>-&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span><span style="color: rgb(34, 34, 34);">required for&nbsp;continued&nbsp;safe practice,&nbsp;progression to the next stage of training&nbsp;and a license to work independently in the form of ARCP or 'exit interview'.</span></p><p><span style="color: rgb(34, 34, 34);">&nbsp;</span></p><p><span style="color: rgb(34, 34, 34);">In practice, appraisal includes some element of assessment, as it is important that clinical standards are maintained throughout the year so as to maintain patient safety. The educational supervisor (appraiser/trainer) is responsible for ensuring that a trainee does not cause harm.&nbsp;</span></p><p><span><strong>&nbsp;</strong></span></p><p><span><strong>Revalidation</strong></span></p><p><span style="color: rgb(34, 34, 34);">is a process of relicensing that allows continuation in clinical practice. This applies to all doctors, specialist trainees and certified specialists.</span></p><p><span style="color: rgb(34, 34, 34);">It aims to ensure quality improvement in patient care through personal and professional development.</span></p><p><span style="color: rgb(34, 34, 34);"><strong>Revalidation sets out to:</strong></span></p><p><span>•&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; assure patients and public, employers and other health care professionals that licensed doctors are up to date and fit to practice</span></p><p><span>•&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span><span style="color: rgb(34, 34, 34);">test concordance with principles and values set out in Good Medical Practice</span></p><p><span>•&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span><span style="color: rgb(34, 34, 34);">evaluate revalidation portfolio of supporting information over a five-year cycle.</span></p><p><span style="color: rgb(34, 34, 34);">&nbsp;</span></p><p><span style="color: rgb(34, 34, 34);"><strong>Appraisal for revalidation</strong> aims to enable doctors to:</span></p><p><span>•&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; discuss their practice and performance with their appraiser in order to demonstrate that they continue to meet the principles and values set out in&nbsp;</span><a target="_blank" rel="noopener noreferrer nofollow" class="mm-link" href="http://www.gmc-uk.org/guidance/good_medical_practice.asp"><span style="color: rgb(2, 100, 203);">Good Medical&nbsp;Practice</span></a><span>&nbsp;&nbsp;and thus to inform the responsible officer’s revalidation recommendation to the GMC</span></p><p><span>•&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; enhance the quality of their professional work by planning their professional development</span></p><p><span>•&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; consider their own needs in planning their professional development</span></p><p><span>•&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; ensure that they are working productively and in line with the priorities and requirements of the organization they practice in.</span></p><p><span style="color: rgb(34, 34, 34);">Most doctors should have no difficulty in demonstrating that they are up to date and fit to practice and should spend almost all their time discussing their continuing professional development and how to improve the quality of their practice by reflecting on their work, challenges, achievements and aspirations and deciding where it is most appropriate to focus their efforts in the coming year.</span></p><p><span style="color: rgb(34, 34, 34);"><strong>The Education Cycle</strong></span></p><p><span style="color: rgb(34, 34, 34);">The cycle for learning and self-development starts with the appraisal and is completed by assessment of progress, which then feeds back into planning for the next phase</span></p>	0	2026-06-01 09:36:46.326182
4d13a544-8a13-41e1-9822-a8f2d2389e67	250ccdc2-184d-4bfe-b1f8-ebd98ae9f550	image	/uploads/content-images/1782427130321-6eb5ed78-15d0-4449-a92a-6f58277d8833.png	0	2026-06-01 16:34:07.342867
bc83b602-d2f3-4526-8724-01227cef3662	9650ce9e-7f49-4a44-a5eb-1c56270bb0ad	text	<h1><strong>Identification:</strong></h1><p><span>•&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>Visual assessment is not sufficient</p><p><span>•&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>Deterioration of vital signs are late manifestation (&gt;1000ml blood loss)</p><h1><strong>Communication:</strong></h1><p><strong><em><u>Minor without shock</u></em></strong><span><strong><em><u>&nbsp; </u></em></strong>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span><strong><em><u>major PPH</u></em></strong></p><p><span>Midwife in charge&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; <strong><u>call</u></strong></span></p><p><span>1<sup>st</sup> grade obstetrician&nbsp; &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;- experienced midwife</span></p><p><span>Anaesthetist staff&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; - Obstetrician middle Grade</span></p><p><span>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;         &nbsp; - Anaesthetist</span></p><p><span>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;          - Haematologist</span></p><p><span>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;           - porters</span></p><p><span><strong>                                                             <u> Alert</u></strong></span></p><p><span>                                                 Consultant obstetrician</span></p><p><span>                                                  And anesthetist.</span></p><h1><strong><u>Resuscitation</u></strong></h1><p><strong><u>Minor obstetric haemorrhage management:</u></strong></p><p><span>•&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>I/V line 14 – G</p><p><span>•&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>20ml blood for</p><p><span>-&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>Blood group and screen</p><p><span>-&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>CBC</p><p><span>-&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>Clotting studies including fibrinogen.</p><p><span>•&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>Vitals every 15min</p><p><span>•&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>Warm crystalloid</p><p><span>•&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>Bimanual examination</p><p>&nbsp;</p><p><br></p><p>Uterus contracted <span>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>not contracted</p><p>&nbsp;</p><p>Shift to OT<span>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>continue Bimanual <span> </span>compression + <span>uterine </span>massage</p><p>&nbsp;</p><p>&nbsp;</p><p>&nbsp;</p><h1>&nbsp;</h1><h1><span>&nbsp; </span><strong>Monitoring and Investigation:</strong></h1><p><span>•&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>Labs</p><p><span>-&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>CBC</p><p><span>-&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>LFT</p><p><span>-&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>RFT</p><p><span>-&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>Coagulation</p><p><span>•&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>Temp monitoring every 15min</p><p><span>•&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>B.P, RR, pulse =&gt;continuous monitoring</p><p><span>•&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>Cross match (4unit of blood + FFP + PLT + cryoprecipitate)</p><p><span>•&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>ECG, O<sub>2</sub> sat</p><p><span>•&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>Foleys' catheter</p><p><span>•&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>Bedside hemoglobin</p><p><span>•&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>Central or Arterial lines (consider)</p><p><span>•&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>Record MEWS chart</p><p><span>•&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>Weigh all swabs to estimate blood loss</p><p><span>•&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>Documentation of Fluid balance, blood, blood products and procedures performed.</p><p><strong><u>Major Obstetric haemorrhage management:</u></strong></p><p><span>•&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>Call for help</p><p><span>-&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>senior midwife</p><p><span>-&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>senior obstetrician </p><table class="mm-table" style="width: 67px;"><colgroup><col style="width: 67px;"></colgroup><tbody><tr><td colspan="1" rowspan="1" colwidth="67"><p><span style="color: rgb(47, 84, 150);">Alert</span></p></td></tr></tbody></table><p><span>-&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>senior<span> </span>anesthetist – senior</p><p><span>-&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>consultant haematologist</p><p><span>•&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<strong><u> </u></strong></span><strong><u>Resuscitation</u></strong> </p><p></p><p>         A, B, C, D,E protocol</p><p><span>-&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;100%&nbsp;&nbsp; </span>O<sub>2</sub> by  mask , 15 lit/min</p><p><span>-&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>Fluid balance initially crystalloid then colloid in order of:</p><p>Crystalloid</p><p>Colloid</p><p>Blood &amp; products</p><p><span>-&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>Blood transfusion</p><p><span>•&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>Blood product transfusion</p><p><span>•&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>Keep warm and flat</p><p><strong>&nbsp;</strong></p><p><strong>&nbsp;</strong></p><h2><strong>Medical treatment </strong></h2><table class="mm-table" style="width: 860px;"><colgroup><col style="width: 860px;"></colgroup><tbody><tr><td colspan="1" rowspan="1" colwidth="860"><p><span style="color: rgb(47, 84, 150);">Mechanical management </span>(Management should be in same order as given below)</p></td></tr></tbody></table><p></p><p></p><p><span>•&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>Uterine massage</p><p><span>•&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>Empty bladder</p><p></p><p><span>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</span></p><table class="mm-table" style="width: 852px;"><colgroup><col style="width: 852px;"></colgroup><tbody><tr><td colspan="1" rowspan="1" colwidth="852"><p><span style="color: rgb(47, 84, 150);">Pharmacological</span></p></td></tr></tbody></table><p>•&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Oxytocin 5/U, I/V, repeat if needed</p><ul><li><p>    Ergometrine – 0.5mg I/V, I/M (by ruling out HTN)</p></li></ul><p></p><p><span>•&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>Oxytocin infusion 40 IU in 500ml</p><p><span>•&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>Carboprost, 0.25mg , I/M every 15min up to 8 times, max 2mg <span>(avoid in asthmatic patients)</span></p><p>I/Myometrial 0.5mg</p><p><span>•&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>Misoprostol, 800 S/L, (take 2.5 hours to contract the uterus).</p><p><span>•&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>Tranexamic acid, 1g, i/v</p><p>&nbsp;</p><p><br></p><p><strong><u>No response</u></strong></p><p><strong><u>Shift to Theatre for EUA:</u></strong></p><p>Is uterus contacted</p><p>&nbsp;</p><p><br></p><p><span><strong><em>&nbsp;&nbsp;&nbsp; </em></strong></span><strong><em>Yes</em></strong><span><strong><em>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </em></strong></span><strong><em>no</em></strong></p><p><strong><em>Clotting </em></strong><span><strong><em>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;1 </em></strong></span><strong><em>=&gt; Tamponade</em></strong><span> 1<sup>st</sup> line</span></p><p><strong><em>Abnormality</em></strong><span>&nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;        surgical management</span></p><p><span>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp;       if atony is the main cause of PPH</span></p><p><span>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;      &nbsp;Used as test as well.</span></p><p><span>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;     &nbsp;positive response.&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</span></p><p><span>&nbsp;</span></p><p><span>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;No laparotomy required.</span></p><p>                                     Removal after 4 – 6hours</p><p><strong>                                          2 =&gt; B – lynch</strong></p><p><span>&nbsp;&nbsp;                                        </span>-<span>&nbsp;&nbsp; </span>25% failure</p><p><span>&nbsp;&nbsp;                                        </span>-<span>&nbsp;&nbsp;&nbsp; </span>No negative impact on fertility.</p><p><strong>                                             3=&gt; Intervention radiology</strong> if available</p><h2><strong><u>Surgical Management:</u></strong></h2><h3><u>* Step wise devascularization</u></h3><p><span>&nbsp;</span>No negative impact on fertility</p><p><span><strong>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; <u>&nbsp;&nbsp;</u></strong></span><strong><u>Order of</u> <u>ligation</u></strong><span>&nbsp;&nbsp;&nbsp;&nbsp; </span>=&gt; 1Uterine artery ligation</p><p>                                                 =&gt;2<sup>nd </sup>uterine artery ligation</p><p>                                                   =&gt; 1-sided ovarian vessels ligation</p><p>                                                  =&gt; 2<sup>nd</sup> sided ovarian vessels ligation</p><p>                                                   =&gt; B/L internal iliac ligation – 39% need hysterectomy</p><h3><u>* Hysterectomy</u></h3><p><span style="color: rgb(47, 84, 150);">2<sup>nd</sup> clinician involved</span></p><p><span style="color: rgb(47, 84, 150);">Early decision</span></p><p><span style="color: rgb(47, 84, 150);">(rupture, Placenta accreta)</span></p><p><span style="color: rgb(47, 84, 150);">Subtotal can b done except (cervical tear, low lying placenta).</span></p><h3><u>*UAE</u></h3><p><span>&nbsp;</span>if available</p><p>High dependency Unit</p><p><strong><u>Clinical incident review PPH &gt; 1500ml.</u></strong></p><p><span style="color: rgb(47, 84, 150);">Documentation</span></p><p><span style="color: rgb(47, 84, 150);">Risk management</span></p><p><span style="color: rgb(47, 84, 150);">Debriefing.</span></p>	4	2026-06-02 06:34:28.157188
a7cadba6-792e-4819-a2c6-0cc5c1773e13	9650ce9e-7f49-4a44-a5eb-1c56270bb0ad	heading	Retained Placenta:	5	2026-06-02 07:33:28.590932
79d88782-be8b-4773-9f17-1a857dfd549a	250ccdc2-184d-4bfe-b1f8-ebd98ae9f550	image		3	2026-06-01 16:36:38.80785
1e053d4b-e452-4a09-b5eb-674ffe72a415	9650ce9e-7f49-4a44-a5eb-1c56270bb0ad	heading	Acute Uterine inversion:	7	2026-06-02 07:35:41.914356
54d6beb4-838f-4e15-bbcd-48af15bcd2bc	9650ce9e-7f49-4a44-a5eb-1c56270bb0ad	heading	Fluid Therapy in PPH:	9	2026-06-02 07:41:00.691873
d2c13d39-8cd8-410d-b6a8-01e499f52bb2	9650ce9e-7f49-4a44-a5eb-1c56270bb0ad	heading	Causes of PPH	1	2026-06-02 06:32:55.689839
4cca000f-6a79-4ab6-a55c-358e57470940	9650ce9e-7f49-4a44-a5eb-1c56270bb0ad	text		2	2026-06-02 06:33:30.418644
dda41d86-032b-43ab-acf6-9996b9d6f4b0	9650ce9e-7f49-4a44-a5eb-1c56270bb0ad	heading	Management of PPH:	3	2026-06-02 06:33:51.803457
983afaa4-3589-4782-9148-d46d413cff61	9650ce9e-7f49-4a44-a5eb-1c56270bb0ad	text	<h1><span><strong>&nbsp;<u>&nbsp;</u></strong></span><strong><u>Primary<sup> </sup>PPH</u></strong></h1><p>Bleeding &gt;500ml within 24 hours of normal delivery and &gt;1000ml after CS</p><p><span>•&nbsp; </span>Minor PPH: 500 – 1000ml</p><p><span>•&nbsp; </span>Major PPH</p><p><span>-&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>Moderate 1000 – 2000</p><p><span>-&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>Severe &gt;2000ml</p><p><span>•&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>Secondary PPH: from 24 hours of delivery to 12 weeks postpartum.</p><p><span>•&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>Most common cause of obstetric haemorrhage</p><p><span>•&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>Identify risk factor antenatally and I/P</p><p><span>•&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>Correction of anemia<span>&nbsp;&nbsp;&nbsp; </span>morbidity after PPH</p><p><span>•&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>Women with risk factor =&gt; delivery in a unit with facility of blood bank</p><p><span>•&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>Shock index = HR/ systolic BP =&gt; early marker of haemodynamic compromise</p><h2><strong><em><u>Prophylaxis of PPH:</u></em></strong></h2><p><span>•&nbsp; </span>Oxytocin</p><p><span>-&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>SVD 10units, I/M</p><p><span>-&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>CS 5 units I/V, no more units are beneficial.</p><p><span>•&nbsp; </span>Uterine – massage routinely – no role in prophylaxis.</p><p><span>•&nbsp; </span>Tranexamic acid; 500 – 1000mg (in C/S in women @ risk of PPH)</p><p><span>•&nbsp; </span>Ergometrine + oxytocin without HTN reduces minor haemorrhage (Given in patient with risk of haemorrhage)</p><p><span>•&nbsp; </span>oxytocin =&gt; routine use</p><p><span>•&nbsp; </span>Ergometrine, Tranexamic acid =&gt; in women with risk factor.</p><p>&nbsp;</p><p>&nbsp;</p>	0	2026-06-02 06:30:40.301275
428e96aa-533e-45bd-81e9-470ab3fd2d34	9650ce9e-7f49-4a44-a5eb-1c56270bb0ad	text	<p><span>•&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>After 30 min of active management</p><p><span>•&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>Manual examination</p><p><span>•&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>Place of clearance</p><p><span>-&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>Present then remove in LR</p><p><span>-&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>absent then remove in OT</p><p>Or no signs of separation , shift to OT</p><p><strong><u>Manual Removal:</u></strong></p><p>1. inform patient</p><p>2. Analgesia</p><p>3. Stop oxytocin and start terbutaline</p><p>4. Empty bladder</p><p>5. Antibiotics</p><p>Be aware of invasion.<span>&nbsp;</span></p>	6	2026-06-02 07:34:00.233415
55ffbdca-c5b5-482b-8c86-c697cecec647	9650ce9e-7f49-4a44-a5eb-1c56270bb0ad	text	<h2><strong><em>Crystalloid:</em></strong></h2><p><span>•&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>up to 2 lit isotonic</p><h2><strong><em>Colloid:</em></strong></h2><p><span>•&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>up to 1.5lit until blood arrive</p><p>avoid hydroxyl starch.</p><h2><strong><em>Blood:</em></strong></h2><p><span>•&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>Immediate O<sup>-ve</sup>, kell<sup>-ve</sup></p><p><span>•&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>Intraoperative cell salvage if available or to Jehovah’s witness</p><p><span>•&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>Switch to group specific</p><h2><strong><em>FFP:</em></strong></h2><p>Testing of coagulation available</p><p>&nbsp;</p><p><strong><em>No </em></strong><span>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span><strong><em>Yes</em></strong></p><p>+ bleeding continues<span>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>- <u>Normal</u>-FFP not</p><p>After blood transfusion<span>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>required, risk of <span>TRALI</span></p><p><span>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>TACO (Transfusion</p><p>4 units of FFP<span>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>related circulatory</p><p>Followed by 12 – 15ml/kg </p><p>of FFP<span>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;                                    &nbsp; </span>overload).</p><p>Till test available.<span>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>-&nbsp;increased<u> PT, APTT </u><span>&nbsp;</span>&gt;1.5</p><p><span>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>of the normal +<span>ongoing</span></p><p><strong><u>Early institution of FFP</u></strong><span>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>haemorrhage.</p><p>in abruption DIC, AF<span>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>15ml/kg of FFP till PT/</p><p>embolism.<span>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>APTT &lt;1.5 of (N).<span>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>Stop FFP when <span>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>PT/APTT normal or</p><p><span>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>bleeding stops.</p><p><strong><u>Ongoing Haemorrhage + Test not Available:</u></strong></p><p><span>•&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>8 units of blood: 2 units of cryo: 1 pool Plt</p><p><span>•&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>6 units of blood: 4 units of FFP.</p><p><strong><u>DIC occurs in followings:</u></strong></p><p><span>•&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>PE</p><p><span>•&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>IUD</p><p><span>•&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>AF embolism</p><p><span>•&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>Severe Infection</p><p><span>•&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>Abruption</p><p><span>•&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>Massive PPH.</p><p>&nbsp;</p><p><strong><u>Plt concentrate</u></strong> – if Plt &lt;75 x 10<sup>9</sup>/l.</p><p><strong><u>Cryoprecipitate:</u></strong> 2 pools if fibrinogen &lt;2g/l</p><p><span>2 pools will</span><strong><u> </u></strong><span>&nbsp;&nbsp;&nbsp;&nbsp;</span>fibrinogen up to 1</p><p>1 pool is taken from 5 donors.</p><p><strong><u>Tranexamic acid:</u></strong> 1g start over 10min then infusion 1g over 8 hours.</p><p><strong><u>Factor vlla:</u></strong> In research setting</p><p><span>•&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>Pre requisite of factor vlla<span>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</span></p><p><span>-&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp;</span>Plt should b at least &gt;20,000<span>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</span></p><p><span>-&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>Temp should be</p><p>Normal</p><p><span>-&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>Acid base/ balance</p><p>normal</p><p><span>•&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>Efficiency is reduced by acidosis, hypothermia and low plt count</p><p><span>•&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>Risk of arterial thrombosis.</p><h2><strong>Therapeutic Goals in PPH:</strong></h2><p><span>•&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>Hb &gt;8</p><p><span>•&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>Plt &gt; 50 x 10<sup>9</sup>/L</p><p><span>•&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>PT &lt; 1.5 times (N)</p><p><span>•&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>APTT &lt; 1.5 times (N)</p><p><span>•&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>Fibrinogen &gt; 2/dl</p><hr>	10	2026-06-02 07:41:24.53335
ab3f9bd8-5c62-460c-981e-579642ec5b10	c4a99f45-fa0e-43c8-b7b6-90ef39b35144	text	<p>Direct cause of maternal mortality</p><p>Incidence = 1 in 10</p><h1>1.Mental health screening&nbsp;&nbsp;&nbsp;&nbsp; <span style="color: white;">MENTAL HEALTH SCREENING</span>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; <span style="color: white;">MENTAL HEALTH SCREENING</span></h1><p>-&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; All women</p><p>-&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; @ booking and @ post-partum period</p><p>-&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Screening is done by</p><p>1. History</p><p>2. Assessment of red flag</p><p>3. Mental state examination</p><p>4. Screening tools</p>	0	2026-06-07 16:45:11.993327
973f02d3-838b-4167-90fe-5bceec0d65ec	9650ce9e-7f49-4a44-a5eb-1c56270bb0ad	text	<p><span>•&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>I/V line + fluids</p><p><span>•&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>Cross match</p><p><span>•&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>Analgesia</p><p><span>•&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>Terbutaline</p><p><span>•&nbsp;&nbsp;&nbsp;&nbsp;1:&nbsp;&nbsp; </span>Manual reduction</p><p>       2: hydrostatic reduction</p><p><span style="color: rgb(47, 84, 150);">        3: </span>abdominal correction<span>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</span></p><p><span>&nbsp;&nbsp;                 </span>- Grasp the round<span> </span>ligaments.<span>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</span></p><p><span>                  &nbsp; </span>- Plication after<span>&nbsp;</span>correction.</p><p><span>•&nbsp; </span>Incident reporting + debriefing.</p>	8	2026-06-02 07:36:07.277529
f7289a32-29e3-4e29-a5ed-8f1a60768fa4	9650ce9e-7f49-4a44-a5eb-1c56270bb0ad	text	<h1><strong><u>Secondary PPH</u></strong></h1><p><strong>Investigations:</strong></p><p><span>•&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>Swabs; to rule out <span style="color: rgb(47, 84, 150);"><strong>Endometritis</strong></span></p><p><span>-&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>HVS<span>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</span></p><p><span>-&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>Endocervical</p><p><span>•&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>USG – to rule out RPOC’S</p><p><span>•&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>Doppler – pseudo aneurysm, AVM</p><p><strong>Treatment:</strong></p><p><span>•&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>Antibiotics – If endometritis is suspected</p><p><span>•&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>ERPC: by senior consultant</p><p><span>-&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>Risk of perforation 1.5%</p><p><span>-&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>Asherman syndrome</p><p><span>•&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>Embolization<span>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>ongoing</p><p><span>•&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>Balloon Tamponade<span>&nbsp;&nbsp;&nbsp; </span>bleeding.</p><p><span>&nbsp;</span></p><p><strong>USG picture of RPOC’S</strong></p><p>Thickened endometrium</p><p>Echogenic mass</p><p>AP diameter of uterine cavity &gt; 25mm.</p><p>&nbsp;</p>	11	2026-06-02 07:59:34.005474
8f1aad96-ab51-45c8-a96f-cfc626ca2849	669a30c3-59e4-449e-b89d-1997522e1808	text	<p>Overall = 2.9%</p><p>Primigravida = 6.1</p><p>Multigravida = 1.7</p><p>Recurrence = 5 – 7%</p><h2><strong>Classification OASIS:</strong></h2><p><span>•&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>1<sup>st</sup> degree: involving vaginal mucosa and/or perineal skin.</p><p><span>•&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>2<sup>nd</sup> degree: involving vaginal mucosa, skin and perineal muscles</p><p><span>•&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>3<sup>rd</sup> degree</p><p><strong>                  a – </strong>external sphincter &lt;50%</p><p><strong>                   b –</strong> &gt;50% of external sphincter</p><p><strong>                   c –</strong> internal sphincter</p><p><span>•&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>4<sup>th</sup> degree – Anorectal mucosa</p><p><span>                -&nbsp;</span>Anal epithelium: 1 – 1.5cm, squamous epithelium</p><p><span>                -&nbsp;</span>Rectal epithelium: columnar epithelium</p><p><span>•&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>Rectal buttonhole injury– sphincter intact – can cause RV – Fistula.</p><h2><strong>Risk Factors:</strong></h2><p><span>•&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>Asian</p><p><span>•&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>Primigravida</p><p><span>•&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>EFW &gt; 4kg</p><p><span>•&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>Shoulder dystocia</p><p><span>•&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>Op – position</p><p><span>•&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>Prolong 2<sup>nd</sup> stage</p><p><span>•&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>Instrumental Birth</p><h2><strong>Identification of OASIS:</strong></h2><p><span>•&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>All women should be examined including P/R especially before suturing</p><p><span>-&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>Explain to women</p><p><span>-&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>Analgesia</p><p><span>-&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>Good light</p><p><span>-&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>Position</p><p>&nbsp;<span>•&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>Endoanal USG – 33% occult can be identified – but not recommended</p><p>Repair by trained or trainee under supervision.</p><p><span>•&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>Repair in OT (in LR can be performed after discussion with obstetrician)</p><p><span>•&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>Avoid figure of 8</p><p><span>•&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>PR examination after repair</p><h2><strong>Prevention of OASIS:</strong></h2><p>1.Episiotomy – no clear role</p><p><span>                    -&nbsp;</span>Mediolateral with instrumental delivery consider.</p><p><span>                    -&nbsp;</span>60<sup>0</sup> angles</p><p>2. Perineal protection @ crowning hands on technique has role in prevention of OASIS</p><p>3. Warm compression during 2<sup>nd</sup> stage can be protective</p><p>4. Perineal message reduces OASIS in primigravida in antenatal period – last months.</p><h2><strong>Technique of suturing:</strong></h2><p><span>•&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>Mucosa – continuous/ Interrupted  3 – 0 polyglactin.</p><p>Knot burying should be done.</p><p><span>•&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>Internal sphincter: mattress/Interrupted<span>&nbsp;&nbsp;&nbsp;</span></p><p><span>•&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>External sphincter:<span>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;By&nbsp;&nbsp; </span><span style="color: rgb(47, 84, 150);">2 – 0 </span><span>&nbsp;</span><span style="color: rgb(47, 84, 150);">polyglactin </span> <span style="color: rgb(47, 84, 150);">or 3-0 PDS</span><span>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp;&nbsp;</span></p><p><span>           &nbsp;&nbsp;</span>Partial injury :End to End<span>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span></p><p><span>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>Complete injury : Overlap <span>&nbsp;&nbsp; &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</span></p><p>Suture Migration 7% <span>&nbsp;</span></p><p><u>Residual EAS defects = 19 – 36%</u></p><p><strong>&nbsp;</strong></p><h2><strong>POST – OP:</strong></h2><p><span>•&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>Broad spectrum antibiotics</p><p><span>•&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>Laxatives for 10 days.</p><p><span>•&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>Bulk forming agents are avoided</p><p><span>•&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>Physiotherapy – beneficial effect</p><h2><strong>Follow Up:</strong></h2><p>QOL Questionnaires &amp; incontinence</p><h2><strong>prognosis:</strong></h2><p>60 – 80% Asymptomatic after 1 year.</p><p>&nbsp;</p><h2><strong>Future deliveries:</strong></h2><p><span>•&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>Prophylactic episiotomy – role is unclear, so done only if clinically indicated.</p><p><span>•&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>Elective CS</p><p><span>-&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>Previous OASIS + symptomatic</p><p><span>-&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>Previous OASIS + abnormal Endoanal USG</p><p><span>•&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>Sustaining further 3<sup>rd</sup>/4<sup>th</sup> degree tear after subsequent delivery 5 – 7%.</p><p><span>•&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>17% worsening symptoms.</p><p>&nbsp;</p>	0	2026-06-02 08:04:34.334258
9b8f0b8b-8497-4001-8078-f1cb04f1b696	70afe946-2149-4948-bb0f-2d48fd2d08f4	text	<p>* Breast infection that occurs in breast feeding women</p><p>* Usually develops within 6 weeks of delivery</p><p>* Commonly by staph aureus</p><h2><strong>Causes:</strong></h2><p><span>•&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>Blocked ducts</p><p><span>•&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>Infrequent emptying</p><p><span>•&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>Cracked or sore nipple</p><p><span>•&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>Incorrect latching</p><p><span>•&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>Stress and fatigue – leading to weak immune system and improper latching</p><p><span>•&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>Hyperlactation – over supply of milk – most common cause.</p><h2><strong>Symptoms:</strong></h2><p><span>•&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>Pain</p><p><span>•&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>Redness</p><p><span>•&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>Swelling</p><p><span>•&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>Fever</p><p><span>•&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>Flue like illness</p><h2><strong>Signs:</strong></h2><p><span>•&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>Tender, hot, red, swollen breast</p><p><span>•&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>Redness often in wedge shape pattern</p><p><span>•&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>Lumpiness of breast</p><p><span>•&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>Engorged with prominent vessels</p><h2><strong>Investigations:</strong></h2><p>1.CBC to rule out infection</p><p>2. Milk for culture and sensitivity</p><h1><strong>Management:</strong></h1><p><strong>General Measures:</strong></p><p><span>•&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>Ice pack while lying on back avoid heat</p><p><span>•&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>Pain relief</p><p>NSAIDS like <strong>ibuprofen</strong> or naproxen</p><p><span>•&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>Supportive bra</p><p><span>•&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>Reverse pressure softening (RPS) place 2 fingers on base of nipple, apply pressure and drag fingers away from nipple. It improves latching by making nipple and areola soft, do it several time a day.</p><p><strong>Breast abscess:</strong></p><p><span>•&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Admit</span></p><p><span>•&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>I/V antibiotics</p><p><span>•&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>Incision + drainage</p><p><strong>Specific Measures:</strong></p><p>1. Antibiotics:</p><p>Flucloxacillin 500mg QID 10 – 14 days.</p><p>OR</p><p>2. Clarithromycin</p><p><span>&nbsp;</span>500mg BD 10 – 14days</p><p>OR</p><p>3. Erythromycin</p><p>250 – 500mg QID 10 – 14 days.</p><p><strong>Prevention:</strong></p><p><span>•&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>Proper feeding technique</p><p><span>•&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>Frequent feeding</p><p><span>•&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>Nipple care by keeping nipples moist and addressing cracks ad sores promptly</p><p><span>•&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>Gradual weaning.</p><p><strong>Breast feeding Education by:</strong></p><p>Specialist midwife or</p><p>Breast feeding nurse.</p>	0	2026-06-02 09:21:00.486103
f0f616b7-9665-450d-b711-5a73fe219d0f	52c2375a-221f-40db-be86-b66990fdd20a	image		33	2026-06-05 07:48:19.006847
e08a1d44-a97a-4821-9c47-cb34ecf0364c	4328293d-d18c-43da-aed5-00d22a4c8b76	text	<h2><span><strong>Less than six weeks postpartum</strong></span></h2><p><span>•&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>Postpartum women who are &lt; 48 hours postpartum can use Cu-IUDs (MEC Category 1).</p><p><span>•&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Breastfeeding women who are &lt; 48 hours postpartum can generally use LNG-IUDs (MEC Category 2).</span></p><p><span>•&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Breastfeeding women who are &lt; 6 weeks postpartum can generally use POPs and LNG and ETG implants (MEC Category 2).</span></p><p><span>•&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Breastfeeding women who are ≥ 4 weeks postpartum can use the progesterone vaginal rings without restrictions (MEC Category 1)</span></p><p><span>•&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Postpartum women who are ≥ 4 weeks </span>postpartum can use Cu-IUDs and LNG-IUDs without restriction (MEC Category 1).</p><p><span>•&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Postpartum women who are ≥ 21 days to 42 days postpartum without other risk factors for venous thromboembolism (VTE) can generally use CHCs (MEC Category 3).</span></p><h2><span><strong>Six weeks to less than six months postpartum</strong></span></h2><p><span>•&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>Breastfeeding women who are ≥ 6 weeks to &lt; 6 months postpartum can use POPs, POIs, and LNG and ETG implants without restriction (MEC Category 1).</p><p><span>•&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Postpartum women who are &gt; 42 days postpartum can use CHCs without restriction (MEC Category 1).</span></p><h3><span><strong>Recommendations against some contraceptive methods</strong></span></h3><p><span>•&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>Postpartum women who are ≥ 48 hours to &lt; 4 weeks postpartum generally should not have an LNG-IUD inserted (MEC Category 3).</p><p><span>•&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Breastfeeding women who are &lt; 6 weeks postpartum generally should not use POIs (depot medroxyprogesterone acetate or norethisterone enanthate) (MEC Category 3).</span></p><p><span>•&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Breastfeeding women &lt; 6 weeks postpartum should not use CHCs (MEC Category 4).</span></p><p><span>•&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Breastfeeding women ≥ 6 weeks to &lt; 6 months postpartum generally should not use CHCs (MEC Category 3).</span></p><p><span>•&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Postpartum women who are &lt; 21 days postpartum and do not have other risk factors for VTE generally should not use CHCs (MEC Category 3).</span></p><p><span>•&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Postpartum women who are &lt; 21 days postpartum with other risk factors for VTE should not use CHCs (MEC Category 4).</span></p><p><span>•&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Postpartum women who are ≥ 21 days to 42 days postpartum with other risk factors for VTE generally should not use CHC (MEC Category 3).</span></p><h2><span><strong>Recommendations on emergency contraception</strong></span></h2><p><span>•&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>Breastfeeding women can use LNG for emergency contraceptive pills (ECPs) without restriction (MEC Category 1).</p><p><span>•&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Women who are breastfeeding can generally use ulipristal acetate for ECPs (MEC Category 2).</span></p>	0	2026-06-07 16:40:31.982903
d3107792-f134-4f4c-9653-3dd53090e364	ae07ff0d-4682-4df5-bd7d-f6067bd7b664	text	<h2><span style="color: white;"><strong>3. VULVAL HAEMATOMA:</strong></span></h2><p>•&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 1:300 TO 1:1000 deliveries</p><p>•&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Rare but fatal condition</p><p>•&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Other hematomas of genitalia</p><p>-&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Paravaginal</p><p>-&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Vulvovaginal</p><p>-&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Sub peritoneal</p><p>•&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Perineal pain is hallmark</p><p>•&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Most hematomas are formed after normal delivery rather complicated deliveries</p><p>•&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Hematoma can result from injury</p><h1><strong>Causes:</strong></h1><p>-&nbsp;&nbsp;<strong><em>Direct:</em></strong></p><p>1. Episiotomy</p><p>2. Vaginal lacerations</p><p>3. Instrumental birth</p><p>-&nbsp;&nbsp;&nbsp;<strong><em>Indirect:</em></strong></p><p>Extensive stretching of birth canal.</p><h1><strong>Risk Factors:</strong></h1><p>Primiparity</p><p>Prolonged 2<sup>nd</sup> stage</p><p>Macrosomia</p><p>Instrumental birth</p><p>Episiotomy</p><p>Use of anticoagulant</p><p>coagulopathy</p><p>Vulvovaginal varicosity</p><p>Hypertensive disorders.</p><p><strong>Non-Obstetric haematomas:</strong></p><p>•&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 0.8% of gynecological problems</p><p><strong>Cause of non-obstetric haematomas:</strong></p><p>•&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Sexual assault</p><p>•&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Fall from height</p><p>•&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Consensual coitus – most common</p><h1><strong>Evaluation:</strong></h1><p><strong><em>History:</em></strong></p><p>•&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; <span style="color: white;">or buttock pain</span></p><p>•&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Severe pain is hallmark, interfere mobility, pain can be perineal <span style="color: white;">abdominal</span></p><p>•&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Intermittent bleeding</p><p>•&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Urinary retention or micturition difficulty</p><p>•&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Difficulty defecations.</p><p>•&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Hemodynamic concerns</p><p>Rule out cause of haematoma.</p><p><strong><em>Examination:</em></strong></p><p>•&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Mostly visible lump as it is restricted by collie’s fascia and urogenital diaphragm</p><p>•&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Tender, fluctuant mass</p><p>•&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Right side is most commonly affected</p><p>•&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; can be up to 15cm and can extend up to groin</p><p>•&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Check HR, RR, B.P and suspected hemodynamic compromise</p><p><strong><em>Investigations</em></strong></p><p>•&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; CBC</p><p>•&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Blood group cross match</p><p>•&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Coagulation screen</p><p>•&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Trans perineal USG – simple, noninvasive, readily available and informative tool. Also useful in follow up and monitoring of patient during expectant management.</p><p>•&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; CT scan</p><p>•&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; MRI if details of hematoma are required</p><p>•&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; MRI angiography to rule out aneurysms.</p><h1><strong>&nbsp;Management</strong></h1><p></p><p><strong><em>Conservative Management&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;      &nbsp; &nbsp; Surgical Management&nbsp;</em></strong></p><p>•&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Small haematoma&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;               &nbsp; 1. Large haematomas &gt;10cm</p><p>•&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Haemodynamically&nbsp;Stable &nbsp;&nbsp;&nbsp;</p><p>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;⬇️&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;                          &nbsp;&nbsp; 2. Haemodynamically unstable.</p><p>1. Analgesia&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</p><p>2. Local compression&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp; &nbsp;                3. Urological symptoms.</p><p>3. Bed rest&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</p><p>4. Ice packs&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp; &nbsp;&nbsp;             4. Neurological &nbsp;symptoms.&nbsp;&nbsp;&nbsp;</p><p>5. Failed conservative treatment&nbsp;</p><p>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;                                           &nbsp;⬇️</p><p></p><p>                                               &gt; Under LA Incision + Drainage</p><p>                                               &gt;Evacuation of clots</p><p>                                               &gt; Ligation of bleeding points</p><p>                                               &gt;Assessment of pressure necrosis (complication of                                                                   haematoma)</p><p><strong><u>Selective arterial Embolization:</u></strong></p><p>Where surgery is not possible</p><p></p><p></p><p></p><h2><strong>Clinical Governance Issues:</strong></h2><p>Document</p><p>Debrief</p><p>Incident report</p><p>Risk management team</p><p>Skills and drills.</p><p></p><p>&nbsp;</p>	0	2026-06-02 08:47:50.514129
53cc50dd-a04b-44df-846b-5fe30319ae73	06c82d3c-6651-48c2-8444-2362025f8f0c	text	<p>Common after child birth</p><p>14.6 – 24.1%</p><p><strong>Risk factors:</strong></p><p><span>•&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>Epidural analgesia</p><p><span>•&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>Prolonged labour</p><p><span>•&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>Instrumental delivery</p><p><span>•&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>Episiotomy</p><p><span>•&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>Primiparous women</p><p><strong>Types:</strong></p><p>&nbsp;</p><p><strong><em>Overt PUR</em></strong><span>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span><strong><em>covert PUR</em></strong></p><p>No voiding within<span>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>- Post void residual</p><p>6 hours of delivery<span>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>volume <u>&gt;</u> 150ml on</p><p>Or removal of <span>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>USG or on</p><p>Catheter<span>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>catheterization.</p><p>                                                         &nbsp;⬇️</p><p><strong>                                                              ASK VESSI questions</strong><span><strong> </strong></span><strong>after voiding to </strong><span><strong>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </strong></span><strong>identify women @</strong></p><p><span><strong>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </strong></span><strong>Risk of retention.</strong></p><p>&nbsp;</p>	0	2026-06-02 09:24:14.114358
50b5d538-338a-4f0e-8f36-d5e765cf654c	c4a99f45-fa0e-43c8-b7b6-90ef39b35144	text	<h1><span>2.  Perinatal mental health services&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span><span style="color: white;">PERINATAL MENTAL HEALTH SERVICES</span></h1><p><strong><u>1. Specialist perinatal mental health services</u></strong></p><p><span>•&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>Specialist<span> </span>perinatal<span> </span>mental<span> </span>health<span> </span>services<span> </span>(PMHS)<span> </span>are<span> </span>concerned<span> </span>with<span> </span>the<span> </span>prevention, detection<span> </span>and<span> </span>management<span> </span>of<span> </span>mental<span> </span>health<span> </span>problems<span> </span>that<span> </span>can<span> </span>complicate<span> </span>pregnancy and<span> </span>the<span> </span>postnatal<span> </span>period.</p><p><span>•&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp;</span>This<span> </span>includes<span> </span>offering<span> </span>pre-conception<span> </span>counselling,<span> </span>caring<span> </span>for women<span> </span>with<span> </span>new-onset<span> </span>or<span> </span>pre-existing<span> </span>moderate<span> </span>to<span> </span>severe<span> </span>mental<span> </span>illness,<span> </span>as<span> </span>well<span> </span>as caring<span> </span>for<span> </span>women<span> </span>with<span> </span>a<span> </span>history<span> </span>of<span> </span>illness<span> </span>who<span> </span>are<span> </span>currently<span> </span>well<span> </span>but<span> </span>who<span> </span>are<span> </span>at<span> </span>high risk<span> </span>of<span> </span>serious<span> </span>mental<span> </span>illness<span> </span>during<span> </span>the<span> </span>perinatal<span> </span>period.</p><p><span>•&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>Promoting<span> </span>the<span> </span>emotional<span> </span>and <span>physical well-being and healthy development of babies and infants, through supporting </span>a<span> </span>secure<span> </span>and<span> </span>attuned<span> </span>relationship<span> </span>with<span> </span>their<span> </span>parents,<span> </span>is<span> </span>central<span> </span>to<span> </span>the<span> </span>care<span> </span>provided<span> </span>by a specialist PMHS.</p><p><span>•&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Specialist perinatal mental health services include specialist community perinatal mental health teams and MBUs.</span></p><p><span>•&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp;</span>Specialist community<span> </span>perinatal<span> </span>mental<span> </span>health<span> </span>teams<span> have the dual role of assessing and treating </span>severe<span> </span>and<span> </span>moderate<span> </span>mental<span> </span>illness<span> </span>with<span> </span>additional<span> </span>complex<span> </span>psychosocial<span> </span>needs<span> </span>or comorbid<span> </span>conditions,<span> </span>as<span> </span>well<span> </span>as<span> </span>assessing<span> </span>and<span> </span>actively<span> </span>supporting<span> </span>the<span> </span>mother-infant <span>relationship.</span></p><p><span>•&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp;Women who need admission in late pregnancy or the postpartum period </span>should be admitted to specialist mother and baby units which are designed and resourced<span> </span>to<span> </span>safely<span> </span>meet<span> </span>the<span> </span>physical<span> </span>and<span> </span>mental<span> </span>health<span> </span>needs<span> </span>of<span> </span>both<span> </span>mother<span> </span>and infant.</p><p><span>•&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp;</span>Each<span> </span>specialist<span> </span>perinatal<span> </span>mental<span> </span>health<span> </span>service<span> </span>should<span> </span>be<span> </span>part<span> </span>of<span> </span>a<span> </span>managed clinical network.</p><p><span>•&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Perinatal mental health problems include a range of disorders and severities, which present in a variety of health settings and are managed by multiple services.</span></p><p><span>•&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp;Some of these services are specifically designed to meet the needs of pregnant and postpartum women and their infants, others care for them as part of a general service.</span></p><p><span><strong><em>a. Service provided by specialist mental health include:</em></strong></span></p><p><span>•&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; specialist community perinatal mental health teams (PMHTs)</span></p><p><span>•&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; specialist in-patient mother and baby units (MBUs)</span></p><p style="text-align: justify;"><span>•&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; adult mental health services (including community and in-patient services and psychological therapy services).</span></p><p><span>•&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Child and adolescent mental health services (CAMHS)</span></p><p><span>•&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; parent-infant mental health services</span></p><p><span>•&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; primary psychological services</span></p><p><span>•&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; general practitioners (GPs)</span></p><p><span>•&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; health visitors and the extended primary care team</span></p><p><span>•&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Children’s services and social care organizations</span></p><p><span>•&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; voluntary/third sector and peer support organizations.</span></p><p>&nbsp;</p><p><strong><em>b. Indication of referral</em></strong></p><p><span>Refer to a secondary mental health service (preferably a specialist perinatal mental health service) for assessment and treatment, all women who:</span></p><p><span>•&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span><span style="color: black;">have or are suspected to have severe mental illness</span></p><p><span>•&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span><span style="color: black;">have any history of severe mental illness (during pregnancy or the postnatal period or at any other time).</span></p><p><span>•&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span><span style="color: black;">If a woman has any past or present severe mental illness or there is a family history of severe perinatal mental illness in a first-degree relative, be alert for possible symptoms of postpartum psychosis in the first 2 weeks after childbirth.</span></p><p><span>•&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span><span style="color: black;">If a woman has sudden onset of symptoms suggesting postpartum psychosis, refer her to a secondary mental health service (preferably a specialist perinatal mental health service) for immediate assessment (within 4 hours of referral).</span></p><p><span>&nbsp;</span></p><p><span><strong>1.&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </strong></span><strong><u>Services provided by specialist community perinatal mental health team:</u></strong></p><p><span>A good specialist community perinatal mental health team will be a member of the Perinatal Mental Health Services. It will assess and manage women with moderate to severe mental illness in the community, who cannot be appropriately treated by primary care services. <strong><em>Responsibilities include:</em></strong></span></p><p style="text-align: justify;"><span>•&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; assessment and care for pregnant and postnatal women with moderate to severe mental disorder who require secondary care mental health services.</span></p><p style="text-align: justify;"><span>•&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; provide pre-conception advice to women who are at high risk of early post-partum major mental illness</span></p><p style="text-align: justify;"><span>•&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; assess and proactively care for women who are well but who are at high risk of a severe postnatal illness</span></p><p style="text-align: justify;"><span>•&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; assess the mother-infant relationship and infant development in the context of maternal mental disorder</span></p><p style="text-align: justify;"><span>•&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; prioritize the management of women on leave, or recently discharged, from MBU care.</span></p><p style="text-align: justify;"><span>•&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Provide a range of evidence-based psychological, pharmacological and psychosocial interventions that are adapted for the perinatal period to treat maternal mental health problems and support the mother-infant relationship, promoting the best outcomes for infant development</span></p><p style="text-align: justify;"><span>•&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; respond in a timely manner and have the capacity to deal with crises and emergencies and assess patients in a variety of settings, including their homes, maternity hospitals and out-patient clinics</span></p><p style="text-align: justify;"><span>&nbsp;</span></p><p><span><strong>2.&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </strong></span><strong><u>MBU:</u></strong></p><p><span>&nbsp;</span></p><p><span><strong><em>a.</em>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </strong></span><strong><em>Services Provided by MBU</em></strong></p><p style="text-align: justify;"><span>•&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; assessment and care for women in late pregnancy and postnatal women (to 12 months) with mental disorder who require in-patient care, accompanied by their infants</span></p><p style="text-align: justify;"><span>•&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; provide care across the range of conditions.</span></p><p style="text-align: justify;"><span>•&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; be able to respond in a timely manner which takes into account the maternity context, needs of the developing infant and alterations to presentations brought about by the perinatal period</span></p><p><span>•&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; ensure that the infant’s health, care and developmental needs are fully met</span></p><p style="text-align: justify;"><span>•&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; assess the mother-infant relationship and infant development in the context of maternal mental disorder</span></p><p style="text-align: justify;"><span>•&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; provide a range of evidence-based psychological, pharmacological and psychosocial interventions that are adapted for the perinatal period to treat maternal mental health problems and support the mother-infant relationship</span></p><p style="text-align: justify;"><span>•&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; offer timely, equitable and comprehensive access such that mothers are not admitted to general adult wards without their baby.</span></p><p><span>•&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; be closely integrated with specialist community perinatal and outreach teams to promote early discharge and continuity of care</span></p><p style="text-align: justify;"><span>•&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; provide advice, support and signposting to partners of women under the care of the service, who may themselves have mental health difficulties, and support the development of the father/partner-infant relationship.</span></p><p style="text-align: justify;"><span>&nbsp;</span></p><p><strong><em>b. Indications of admission</em></strong></p><p style="text-align: justify;">1. Rapidly changing mental state</p><p style="text-align: justify;">2. Suicidal ideation (particularly of a violent nature)</p><p style="text-align: justify;">3. Pervasive guilt or hopelessness</p><p style="text-align: justify;">4. Significant estrangement from the infant.</p><p style="text-align: justify;">5. New or persistent beliefs of inadequacy as a mother.</p><p style="text-align: justify;">&nbsp;</p><p><span><strong>3.&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </strong></span><strong><u>Parent – infant Mental health services:</u></strong></p><p><strong>Services provided:</strong></p><p><span>•&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp;&nbsp;</span>provide<span> </span>therapeutic<span> </span>interventions<span> </span>for<span> </span>parent-infant<span> </span>relationships in pregnancy and the early years.</p><p><span>•&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Good quality parent-infant mental health services should be multidisciplinary teams with expertise in supporting mothers and fathers/ partners/other carers to develop sensitive and attuned relationships with their babies, infants and toddlers, including in the antenatal period.</span></p><p><span>•&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; offer direct support to parents and carers using a variety of evidence-based therapeutic parent-infant interventions</span></p>	3	2026-06-07 16:51:44.82625
fe4b3b37-5029-4a70-8f5f-1ed5fa1ee62c	c4a99f45-fa0e-43c8-b7b6-90ef39b35144	text	<h1>4. Depression</h1><p><span>-&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>During pregnancy 12%</p><p><span>-&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>3 months PP = 13%</p><p><span>-&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>1-year after delivery = 15 – 20%</p><p><span>-&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>Past history and FH<span>&nbsp;&nbsp;&nbsp; </span>es risk 42%</p><p><span>-&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>Bipolar depression – risk of psychosis.</p><p><strong>Diagnostic key words:</strong></p><p><span>•&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp;</span>Lack of interest in friends, life, baby</p><p><span>•&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp;</span>Persistent sadness low mood</p><p><span>•&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp;</span>Don’t improve but worse with time</p><p><span>•&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>Fatigue or low energy.</p><p><span>•&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>Worthlessness and hopelessness</p><p>&nbsp;</p><p><strong>Associated symptoms:</strong></p><p><span>•&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>Sleep disturbance</p><p><span>•&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>Indecisiveness</p><p><span>•&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>Poor or<span>&nbsp;&nbsp;&nbsp;&nbsp; </span>ed appetite</p><p><span>•&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>Suicidal thoughts</p><p><span>•&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>Agitation or slowing of movements</p><p><span>•&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>Guilt or self-blame</p><p><span>•&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>Impaired social or occupational activities</p><p><span>•&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>Poor concentration</p><p><span>•&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>Low self-confidence.</p><p><strong>Post – partum depression:</strong></p><p>Onset: 1<sup>st</sup> 2weeks after birth</p><p>2 peak presentations</p><p>1 @ 2 – 4weeks pp</p><p>2<sup>nd</sup> @ 10 – 14weeks pp</p><p><span>•&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>FH + Personal History of depression = 42%</p><p>Postnatal depression</p><p>Greatest at 6 – 8weeks.</p><p><span>•&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>Only personal depression = 15% chance of PP depression.</p><p><span>•&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>Risk of recurrence in future pregnancies 1:2 – 1:3</p><p><strong>&nbsp;</strong></p><p><strong>Depression Screening:</strong></p><p>1.Feeling down, hopeless, depressed over month</p><p>2.Lack of interest over past month</p><p>&nbsp;    ⬇️ </p><p>&nbsp;1 Or 2 positives</p><p>&nbsp;    ⬇️ </p><p>Full assessment by</p><p><span>&nbsp;</span>Edinberg Postnatal Scale</p><p>Or</p><p>Patient health Questionnaire</p><p><span style="color: black;"><strong>Over the last 2 weeks, how often have you been bothered by any of the following problems:</strong></span></p><p><span>•&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span><span style="color: black;">Little interest or pleasure in doing things?</span></p><p><span>•&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span><span style="color: black;">Feeling down, depressed, or hopeless?</span></p><p><span>•&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span><span style="color: black;">Trouble falling or staying asleep, or sleeping too much?</span></p><p><span>•&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span><span style="color: black;">Feeling tired or having little energy?</span></p><p><span>•&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span><span style="color: black;">Poor appetite or overeating?</span></p><p><span>•&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span><span style="color: black;">Feeling bad about yourself – or that you are a failure or have let yourself or your family down?</span></p><p><span>•&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span><span style="color: black;">Trouble concentrating on things, such as reading the newspaper or watching television?</span></p><p><span>•&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span><span style="color: black;">Moving or speaking so slowly that other people could have noticed?</span></p><p><span>•&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span><span style="color: black;">Or the opposite – being so uneasy or restless that you have been moving around a lot more than usual?</span></p><p><span>•&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span><span style="color: black;">Thoughts that you would be better off dead, or thoughts of hurting yourself in some way?</span></p><p><span><strong>Rating:</strong></span></p><p><span>•&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span><span style="color: black;"><strong>Not at all:</strong>&nbsp;0</span></p><p><span>•&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span><span style="color: black;"><strong>Several days:</strong>&nbsp;1</span></p><p><span>•&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span><span style="color: black;"><strong>More than half the days:</strong>&nbsp;2</span></p><p><span>•&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span><span style="color: black;"><strong>Nearly every day:</strong>&nbsp;3</span></p><p><span><strong>Depression severity</strong></span></p><p><span>•&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span><span style="color: black;"><strong>0–4:</strong>&nbsp;none</span></p><p><span>•&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span><span style="color: black;"><strong>5–9:</strong>&nbsp;mild</span></p><p><span>•&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span><span style="color: black;"><strong>10–14:</strong>&nbsp;moderate</span></p><p><span>•&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span><span style="color: black;"><strong>15–19:</strong>&nbsp;moderately severe</span></p><p><span>•&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span><span style="color: black;"><strong>20–27:</strong>&nbsp;severe</span></p><p><strong><u>Fetomaternal Consequences of Depression:</u></strong></p><p><strong>Mother:</strong></p><p><span>•&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>Relapse</p><p><span>•&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>Poor nutrition</p><p><span>•&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>Suicide</p><p><span>•&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>Drug abuse</p><p><span>•&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>Postnatal depression</p><p><strong>Baby:</strong></p><p><span>•&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>Abortion</p><p><span>•&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>Pre term birth</p><p><span>•&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>LBW</p><p><span>•&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>Low APGAR</p><p><span>•&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>NICU admission</p><p><span>•&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>Breast feeding problems</p><p><strong>Management:</strong></p><p><span>•&nbsp; </span><strong><u>Women not taking any treatment or newly diagnose</u></strong></p><p><strong><em>1. Mild – Moderate:</em></strong></p><p><strong><em>&nbsp;</em></strong></p><p>Refer to</p><p><span>•&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>Local psychology services</p><p><span>•&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>Primary care mental health</p><p>&nbsp;</p><p><span>•&nbsp; </span>Low intensity CBT</p><p><span>-&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>9 – 12weeks therapy</p><p><span>-&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>6 – 8 min sessions face to face or telephonic</p><p><span>-&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>30 – 60min session</p><p><span>-&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>Every week or fortnightly</p><p>&nbsp;</p><p><strong><em>2. Moderate- Severe:</em></strong></p><p><span>•&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>High intensity CBT</p><p><span>•&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>Pharmacological treatment</p><p>SSRI</p><p>SNRI</p><p>TCA</p><p>In case she declines CBT, or CBT is ineffective.</p><p><span>•&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>Combination of CBT and medications if alone CBT or medications are not effective.</p><p><span>•&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span><strong><em>Severe Depression:</em></strong></p><p>Catatonic features, psychotic features</p><p><span>•&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>Switch antidepressants if already taking or</p><p><span>•&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>Augmentation treatment with antipsychotic or mood stabilizers.</p><p><span>•&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>ECT – in severe or life-threatening conditions.</p><p><strong><em>3. Mild depression + Past History of Severe Depression:</em></strong></p><p><span>•&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>TCA</p><p><span>•&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>SSRI</p><p><span>•&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>SNRI</p><p><strong><u>Women taking medications before pregnancy</u></strong></p><p>Mild – moderate<span>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>Moderate<span>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>Severe</p><p>&nbsp;  ⬇️                               ⬇️                                ⬇️   </p><p>Stop gradually<span>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>switch <span>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</span>Don’t stop</p><p>Gradually<span>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp;&nbsp; </span>- <span>Continuous</span></p><p><span>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>and switch to<span>&nbsp;&nbsp; &nbsp;&nbsp;&nbsp;&nbsp;       </span>or</p><p>Facilitated <span>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>- CBT or<span>&nbsp;&nbsp;&nbsp;&nbsp;         &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>- change to</p><p>Self-help<span>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>- Other <span>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>medication</p><p>Medication<span>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>with least</p><p><span>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>is effective <span>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>adverse <span>effects</span></p><p>with <span>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>or</p><p><span>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>lower side <span>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>- <span>Combo </span>of <span>CBT</span></p><p>effect<span>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>(high <span>intensity</span>)</p><p><span>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>and <span>medication&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>or<span>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>- <span>Switch </span>to <span>high&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; intensity CBC.</span></p>	5	2026-06-07 17:06:07.079638
e17e1f6d-26ad-42dd-827c-d85f621a7eb4	ae07ff0d-4682-4df5-bd7d-f6067bd7b664	text	<p></p>	1	2026-06-07 16:22:51.496767
b1e9cd4a-87eb-481c-a0cb-9d92962721ea	c4a99f45-fa0e-43c8-b7b6-90ef39b35144	text	<h1>5. Anxiety</h1><p><span>-&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>13%</p><p><span>•&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>Anxiety disorders include</p><p>1. Generalized anxiety disorder</p><p>2. Obsessive – compulsive disorder OCD</p><p>3. Post Traumatic stress disorder PTSD</p><p>4. Social anxiety disorder</p><p><strong>Assessment of Anxiety disorders:</strong></p><p>GAD – 2 score</p><p>GAD – 7 score</p><p><span style="color: black;"><strong>GAD-2</strong></span></p><p><span>•&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span><span style="color: black;">Over the last 2 weeks, how often have you been bothered by the following problems:</span></p><p><span style="color: black;">1. Feeling nervous, anxious, or on edge? NAO</span></p><p><span>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span><span style="color: black;">2.Not being able to stop or control worrying?</span></p><p><span style="color: black;"><strong>GAD-7</strong></span></p><p><span>•&nbsp; </span><span style="color: black;">Over the last 2 weeks, how often have you been bothered by the following problems:</span></p><p><span style="color: black;">1.Feeling nervous, anxious or on edge?</span></p><p><span style="color: black;">2. Not being able to stop or control worrying?</span></p><p><span>1.&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span><span style="color: black;">Worrying too much about different things?</span></p><p><span>2.&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span><span style="color: black;">Trouble relaxing?</span></p><p><span>3.&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span><span style="color: black;">Being so restless that it is hard to sit still?</span></p><p><span>4.&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span><span style="color: black;">Becoming easily annoyed or irritable?</span></p><p><span>5.&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span><span style="color: black;">Feeling afraid as if something awful might happen?</span></p><p><span style="color: black;"><strong>Scores of:</strong></span></p><p><span>-&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span><span style="color: black;"><strong>5 MILD</strong></span></p><p><span>-&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span><span style="color: black;"><strong>10 moderate</strong></span></p><p><span>-&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span><span style="color: black;"><strong>15 severe</strong></span></p><p><span>•&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; When GAD is used as a screening tool, further evaluation is recommended with the score of 10 or greater.</span></p><p><span>•&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp;woman scores 3 or more on the GAD-2 scale, consider:</span></p><p><span style="color: black;">1.Using the&nbsp;<strong>GAD-7 scale</strong>&nbsp;for further assessment or</span></p><p><span style="color: black;">2.Referring the woman to her GP or;</span></p><p><span>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span><span style="color: black;">3.If a severe mental health problem is </span><span>&nbsp;&nbsp;&nbsp;</span><span style="color: black;">suspected, to a mental health professional.</span></p><p><span>•&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; If a woman scores less than 3 on the GAD-2 scale, but you are still concerned she may have an anxiety disorder, ask the following question:</span></p><p><span style="color: black;"><strong><em>1.</em></strong> Do you find yourself avoiding places or activities and does this cause you problems?</span></p><p><span style="color: black;"><strong><em>2.</em></strong> If she responds positively, consider:</span></p><p><span style="color: black;"><strong><em>3.</em></strong> using the GAD-7 scale for further assessment or referral</span></p><p><span>&nbsp;</span></p><p><span>•&nbsp; </span><strong>Generalized Anxiety disorder:</strong></p><p><span>6.&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>Persistent nervousness</p><p><span>7.&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>Muscular tension</p><p><span>8.&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>Dizziness</p><p><span>9.&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>Palpitation</p><p><span>10.&nbsp; </span>Fear of becoming ill of baby or family members</p><p><span>11.&nbsp; </span>Fear of getting accident.</p><p><span>12.&nbsp; </span>Sweating</p><p><span>13.&nbsp; </span>Light headedness</p><p><span>14.&nbsp; </span>Epigastric discomfort</p><p><span>•&nbsp; </span><strong><u>PSTD:</u></strong></p><p><span>-&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>Flashback</p><p><span>-&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>Hyperarousal</p><p><span>-&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>Psychological distress</p><p><strong>Treatment:</strong></p><p><span>-&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>Only high intensity CBT</p><p><span>•&nbsp; </span><strong><u>OCD:</u></strong></p><p><span>-&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>Obsessive ideas/ thoughts/ images.</p><p><strong>Management:</strong></p><p><span>-&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>As general anxiety</p><p><span>-&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>Inpatient treatment in MBU</p><p><span>-&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>ECT very rarely in resistant OCD or severe cases.</p><p>&nbsp;</p><p><span>•&nbsp; </span><strong><u>Tocophobia:</u></strong></p><p>Morbid dread fear of pregnancy and child birth</p><p><strong><em>Primary:</em></strong> no previous experience of pregnancy</p><p><strong><em>Secondary:</em></strong> develop after traumatic event in previous pregnancy</p><p>Women avoid pregnancy</p><p>Request C/S</p><p>Request termination</p><p>Sexual assault can be contributory factor</p><p><strong>Management:</strong></p><p><span>-&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>Explore fears</p><p><span>-&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>Facilitated self help</p><p><span>-&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>CBT</p><p><span>-&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>Book @ consultant led care</p><p><span>-&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>Midwife counselors</p><p><span>-&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>Develop care plan in collaboration with consultant, midwife and women</p><p><span>-&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>Minimal vaginal examinations</p><p><span>-&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>One – one support and care</p><p>&nbsp;</p><p><strong><u>Social Anxiety Disorder:</u></strong></p><p>Also called social phobia</p><p>Intense fear of being watched by someone or judged by someone</p><p>Treatment is high intensity CBT</p><p>&nbsp;</p><p style="text-align: center;"><strong><u>Treatment of Anxiety Disorders</u></strong></p><p style="text-align: center;"><span><strong><u>&nbsp;</u></strong></span></p><p><br></p><p><strong><em>Mild – moderate</em></strong><span><strong><em>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </em></strong></span><strong><em>mode Severe</em></strong><span><strong><em>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </em></strong></span><strong><em>Severe</em></strong></p><p><strong><em>&nbsp;</em></strong></p><p>- Facilitated self – <span>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>-High intensity<span> &nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>- Switching</p><p>Help<span>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>CBT<span>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp;&nbsp; </span>medication</p><p>- 9 – 12weeks <span>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>- Medication<span>&nbsp;&nbsp; </span>-<span>Augmentation</span></p><p>therapy <span>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>SSRI<span>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>with anti -</p><p>- 6 – 8 sessions<span>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>SNRI<span>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>psychotic and<span>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>TCA<span>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>short term<span>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp;&nbsp; </span>- Combination<span>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; treatment </span>with<span>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>of both.<span>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Benzodiazepine</span></p><p>&nbsp;</p><p>&nbsp;</p><p>Women with anxiety disorder becomes pregnant while taking SSRI, SNRI, TCA – discuss</p><p><span>-&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>Stopping slowly and starting high intensity CBT</p><p><span>-&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>Changing to drugs with least adverse effects</p><p><span>-&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>Continue medication</p><p><span>-&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>Combination of CBT and drugs</p>	6	2026-06-07 17:20:23.235309
1cf550d0-f5d8-4d9c-ab95-b82520a61f49	c4a99f45-fa0e-43c8-b7b6-90ef39b35144	text	<h1>6. Psycosis</h1><p>Psychotic disorders include:</p><p>Bipolar disorders</p><p>Schizophrenia</p><p>Schizoaffective disorder</p><p>Psychotic depression</p><p><strong>Incidence:</strong></p><p>1 – 2/1000</p><p>1 in 4 after delivery</p><p>20 – 30% if bipolar depression history</p><p>Past history of psychosis + FH = 74% BPD</p><p>Past history of postpartum psychosis = 1 in 2</p><p>Severely affected mental illness = 3 – 5%</p><p><strong><u>POST PARTUM PSYCHOSIS</u></strong></p><p>Signs and symptoms</p><p><span>•&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>1<sup>st</sup> signs are nonspecific like insomnia, agitation and odd behavior</p><p><span>•&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>Progression is rapid, a few hours’ late women is considered psychotic and severely disturbed by hallucination, decision, fear perplexity, confusion and agitation.</p><p><span>•&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>Manic symptoms: More in post – partum women mood liability, pressured speech and distractibility.</p><p><span>•&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>Rapidly changing mental state: More in post – partum women</p><p>Onset – usually early in postnatal period</p><table class="mm-table" style="min-width: 50px;"><colgroup><col style="min-width: 25px;"><col style="min-width: 25px;"></colgroup><tbody><tr><td colspan="1" rowspan="1"><p><span style="color: black;"><strong>Postnatal day</strong></span></p></td><td colspan="1" rowspan="1"><p><span><strong>&nbsp;</strong></span><span style="color: black;"><strong>Percentage presented</strong></span></p></td></tr><tr><td colspan="1" rowspan="1"><p>7</p></td><td colspan="1" rowspan="1"><p>50%</p></td></tr><tr><td colspan="1" rowspan="1"><p>16</p></td><td colspan="1" rowspan="1"><p>75%</p></td></tr><tr><td colspan="1" rowspan="1"><p>90</p></td><td colspan="1" rowspan="1"><p>95%</p></td></tr></tbody></table><p>Symptoms may begin from start of labor</p><p><strong>D/D:</strong></p><p><span>•&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>Primary cerebral or systemic disease eclampsia, infection.</p><p><span>•&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>Exogenous toxic substance or hormones, urine drug screen should be carried out.</p><p><span>•&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>Baby blues</p><p><span>•&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>Post – natal depression.</p><p><strong>Diagnosis and management:</strong></p><p><span>•&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>Psychiatric emergency and require assessment by trained psychiatrist within 4 hours.</p><p><span>•&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>Suicidal or infanticide ideas</p><p><span>•&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>Delusional ideas about infant</p><p><span>•&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>1 – 1 care by registered mental health nurse till psychiatric assessment.</p><p><span>•&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>Admit in MBU</p><p><span>•&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>Treatment includes:</p><p><span>-&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>Antipsychotic medication</p><p><span>-&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>Anti-depressants</p><p><span>-&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>Mood stabilizers</p><p><span>-&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>ECT (PPP is particularly responsive)</p><p><strong><u>Prognosis:</u></strong></p><p>Once acute phase is over, women will often benefit from psychotherapy and education</p><p><strong><u>Recurrence:</u></strong></p><p><span>•&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>50% in purpureal period, so it is beneficial to admit in MBU electively</p><p><span><br><strong><br></strong></span></p><p><span>•&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>Non purpureal recurrence = 62%</p><p>&nbsp;</p><p><span>•&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>35 – 65% women with episode of acute PP will develop bipolar disorder.</p><p>&nbsp;</p><p>&nbsp;</p><p>&nbsp;</p><p>&nbsp;</p><p>&nbsp;</p><p>&nbsp;</p><p>&nbsp;</p><p>&nbsp;</p><p><strong><u>Antenatal Care of psychotic disorders:</u></strong></p><p><strong>Pre – conception counselling:</strong></p><p>With specialist</p><p>Aim is to</p><p><span>•&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>Discuss psychiatric care</p><p><span>•&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>Make difficult decisions about stopping, switching or continuing psychotropic medication.</p><p><span>•&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>Care in labour and post – partum period</p><p><span>•&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>Formulate care plan</p><p><strong>MDT – </strong>for maternal mental health include:</p><p>Patient support network/ family</p><p>Perinatal psychiatrist</p><p>Perinatal mental health nurse</p><p>Psychologist social worker</p><p>Midwife</p><p>Health visitor</p><p>Obstetrician</p><p>General practitioner</p><p><strong>Late pregnancy MDT meeting:</strong></p><p>Aim of meeting is:</p><p><a target="_blank" rel="noopener noreferrer nofollow" class="mm-link" href="http://1.To">1.To</a> identify specific triggers and stressors that can cause relapse</p><p>2.Alert each professional about warning signs</p><p>3.Discuss medication during labour and post – natal period</p><p>4.Formulate plan assessment and throughout labour and post – natal period</p><p>5.Discussion about elective MBU admission</p><p>6.Discussion about child care</p><p>&nbsp;</p><p><br></p><p>&nbsp;</p><p><span>•&nbsp; </span><strong><u>Bipolar affective Disorders:</u></strong></p><p>1% of population</p><p>Mean age 17 – 22 years.</p><p><strong>Symptoms:</strong></p><p><span>•&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>Episodes of low mood</p><p><span>•&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>Mania including elation, over activity, increase<span>&nbsp;&nbsp; </span>energy, poor concentration, inflated self-esteem.</p><p><span>•&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>25 – 50% experience PPS</p><p><span>•&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>Relapse risk during pregnancy and PP period.</p><p><strong>Management:</strong></p><p><span>•&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>Relapse prevention by early identification of red flag</p><p><span>•&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>CBT</p><p><span>•&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>Group education therapy.</p><p><span>•&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>Family focused psycho education is helpful when used with medication</p><p><span>•&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>Pharmacological treatment</p><p>Antipsychotics</p><p>Mood stabilizers</p><p>Benzodiazepines</p><p><span>•&nbsp; </span><strong><u>Schizophrenia:</u></strong></p><p><span>•&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>Severe psychotic disorder</p><p><span>•&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp;</span>Interpret reality abnormally by</p><p>&nbsp;</p><p><strong><em><u>Positive symptoms</u></em></strong><span>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span><strong><em><u>Negative Symptoms</u></em></strong><span><strong><em><u>&nbsp;&nbsp;</u></em></strong></span></p><p>- Hallucination<span>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>- Social withdrawal</p><p>- Delusion<span>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>- Ambivalence</p><p>- Elation<span>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>- Apathy</p><p><span>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>- Emotional blunting</p><p><span>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp;</span>Cognitive impairment</p><p><span>•&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>Risk of PPP = 25 – 50%</p><p><span>•&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>High risk of relapse</p><p><span>•&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>May require prophylactic admission to MBU before delivery.</p><p><strong>Treatment:</strong></p><p>Combination of:</p><p><span>•&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>Psycho – education</p><p><span>•&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>Psychological intervention</p><p><span>•&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>Antipsychotic drugs</p><p><span>•&nbsp; </span><strong><u>Schizoaffective disorders:</u></strong></p><p>Treated by combination of</p><p><span>-&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>Antipsychotic</p><p><span>-&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>Mood stabilizers</p><p><span>Anti-depressants<br></span></p>	7	2026-06-07 17:22:31.404773
4c670b76-fd23-4928-bd59-8a80e883640b	c4a99f45-fa0e-43c8-b7b6-90ef39b35144	text	<p><strong><u>Mental Health History:</u></strong></p><p><span>•&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span><strong>Rapo Building:</strong></p><p>By introductory sentences like pregnancy, delivery and taking care of baby can be difficult in women’s life and it’s common to feel low or upset. Most women are hesitant to speak about their feelings, fears and condition.</p><p><span>•&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span><strong>Exploratory Questions:</strong></p><p><span>-&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>Over past month</p><p><span>-&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>How are you feeling recently?</p><p><span>-&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>Feeling down, hopeless, depressed</p><p><span>-&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>Lack of interest</p><p><span>-&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>Bonding with child</p><p><span>-&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>Life events like broken relationship</p><p><span>-&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>How she is coping.</p><p><span>•&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span><strong>Past history of mental illness</strong></p><p><span>-&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>Diagnosis</p><p><span>-&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>Treatment taken</p><p><span>-&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>Any self-harm in the past</p><p><span>-&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>Harm to others in the past</p><p><span>•&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span><strong>Family history:</strong></p><p><span>-&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>FH of psychotic illness</p><p><span>-&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>Diagnosis and treatment taking</p><p><span>•&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span><strong>Social History:</strong></p><p><span>-&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>Drug abuse</p><p><span>-&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>Smoking</p><p><span>-&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>Financial issues</p><p><span>-&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>Contact with GP to know more about social and personal circumstances.</p><p><span>•&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span><strong>Personal History:</strong></p><p><span>-&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>About schooling</p><p><span>-&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>About relationships</p><p><span>-&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>Sexual employment</p><p><strong><u>Assessment of Red Flag:</u></strong></p><p><span>•&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span><strong>Self-harm:</strong> Suicide</p><p><span>-&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>Have you experienced thought that life is hopeless or not worth living?</p><p>&nbsp;</p><p><span style="color: rgb(47, 84, 150);"><strong><em>Positive</em></strong></span></p><p>&nbsp;</p><p><span>-&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>Ask about any plan she have made</p><p><em>Have you thought about hurting yourself?</em></p><p>&nbsp;</p><p><span style="color: rgb(47, 84, 150);"><strong><em>Positive</em></strong></span></p><p><span>-&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>Ask about her intentions to act on these plans</p><p><em>When you think you might go through these plans?</em></p><p>&nbsp;</p><p><span style="color: rgb(47, 84, 150);"><strong><em>Positive</em></strong></span></p><p><span>-&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>Check about protection she has</p><p><em>What has stopped you, acting on these plans?</em></p><p><span>•&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span><strong>Harm to others:</strong></p><p><span>-&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>Have you ever thought of hitting your child or partner?</p><p><span>-&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>Have your ever thought <span>that your</span> baby or partner are reason for your condition and they shouldn’t be with you?</p><p><strong><u>Mental State Examination:</u></strong></p><p>Assess following states and describe as you notice</p><p><strong>1.Speech:</strong></p><p><u>Rate</u>: Fast, slow, variable.</p><p><u>Rhythm:</u> Flowing, disjoined</p><p><u>Volume:</u></p><p><u>Tone:</u></p><p><u>Coherency:</u></p><p><u>Relevance:</u></p><p><strong>2. Mood</strong></p><p>Subjective mood vibration (awful doctor)</p><p>Objective mood: low, manic, mixed</p><p>Affect: min to min change of emotions.</p><p><strong>3. Thoughts</strong></p><p>Delusional thoughts</p><p>Thought disorder</p><p>Obsessional thoughts</p><p>Compulsion</p><p>Anxieties</p><p>Self-harm and harm to others</p><p><strong>4. Perceptions:</strong></p><p>Hallucinations: Auditory, Visual, Tactile.</p>	2	2026-06-07 16:49:49.90493
023d6d1e-f23c-444b-b8f9-39ede710bc40	c4a99f45-fa0e-43c8-b7b6-90ef39b35144	text	<h1>3.Baby blues</h1><p><span>•&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>70% women experience</p><p><span>•&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>3 – 10 days after birth, peaking on 5<sup>th</sup> day.</p><p><span>•&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>Improves with time</p><p><span>•&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>Care of baby is not affected.</p><p><strong>Symptoms:</strong></p><p><span>•&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span><strong><em>Symptom triad</em></strong></p><p><span>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;1. </span>Crying, sadness</p><p>               2.&nbsp;Anxiety irritability<span>&nbsp;&nbsp;</span></p><p><span>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;3.&nbsp;&nbsp;</span>sense of inadequacy</p><p><span>•&nbsp; </span>Hall mark – sense of inadequacy</p><p>No Suicidal thought</p><p>No worthlessness or hopelessness.</p><p><strong>Management:</strong></p><p><span>-&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>Self – limiting in 48hours</p><p><span>-&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>Monitoring</p><p><span>-&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>Reassurance</p><p><span>-&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>Support.</p>	4	2026-06-07 16:55:02.160633
94564060-9301-431b-b7bf-2e2756499123	b1c1aa64-a82b-49bf-b379-6c7753bee96e	text	<h2><span><strong>Less than six weeks postpartum</strong></span></h2><p><span>•&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>Postpartum women who are &lt; 48 hours postpartum can use Cu-IUDs (MEC Category 1).</p><p><span>•&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Breastfeeding women who are &lt; 48 hours postpartum can generally use LNG-IUDs (MEC Category 2).</span></p><p><span>•&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Breastfeeding women who are &lt; 6 weeks postpartum can generally use POPs and LNG and ETG implants (MEC Category 2).</span></p><p><span>•&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Breastfeeding women who are ≥ 4 weeks postpartum can use the progesterone vaginal rings without restrictions (MEC Category 1)</span></p><p><span>•&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Postpartum women who are ≥ 4 weeks </span>postpartum can use Cu-IUDs and LNG-IUDs without restriction (MEC Category 1).</p><p><span>•&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Postpartum women who are ≥ 21 days to 42 days postpartum without other risk factors for venous thromboembolism (VTE) can generally use CHCs (MEC Category 3).</span></p><h2><span><strong>Six weeks to less than six months postpartum</strong></span></h2><p><span>•&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>Breastfeeding women who are ≥ 6 weeks to &lt; 6 months postpartum can use POPs, POIs, and LNG and ETG implants without restriction (MEC Category 1).</p><p><span>•&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Postpartum women who are &gt; 42 days postpartum can use CHCs without restriction (MEC Category 1).</span></p><h2><span><strong>Recommendations against some contraceptive methods</strong></span></h2><p><span>•&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>Postpartum women who are ≥ 48 hours to &lt; 4 weeks postpartum generally should not have an LNG-IUD inserted (MEC Category 3).</p><p><span>•&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Breastfeeding women who are &lt; 6 weeks postpartum generally should not use POIs (depot medroxyprogesterone acetate or norethisterone enanthate) (MEC Category 3).</span></p><p><span>•&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Breastfeeding women &lt; 6 weeks postpartum should not use CHCs (MEC Category 4).</span></p><p><span>•&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Breastfeeding women ≥ 6 weeks to &lt; 6 months postpartum generally should not use CHCs (MEC Category 3).</span></p><p><span>•&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Postpartum women who are &lt; 21 days postpartum and do not have other risk factors for VTE generally should not use CHCs (MEC Category 3).</span></p><p><span>•&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Postpartum women who are &lt; 21 days postpartum with other risk factors for VTE should not use CHCs (MEC Category 4).</span></p><p><span>•&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Postpartum women who are ≥ 21 days to 42 days postpartum with other risk factors for VTE generally should not use CHC (MEC Category 3).</span></p><h2><span><strong>Recommendations on emergency contraception</strong></span></h2><p><span>•&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>Breastfeeding women can use LNG for emergency contraceptive pills (ECPs) without restriction (MEC Category 1).</p><p><span>•&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Women who are breastfeeding can generally use ulipristal acetate for ECPs (MEC Category 2).</span></p><p><span>&nbsp;</span></p><p><span>&nbsp;</span></p>	0	2026-06-09 06:17:17.98611
5bbc8163-b032-44e4-82ee-773c4e68f0c4	c4a99f45-fa0e-43c8-b7b6-90ef39b35144	text	<p></p><table class="mm-table" style="min-width: 50px;"><colgroup><col style="min-width: 25px;"><col style="min-width: 25px;"></colgroup><tbody><tr><td colspan="1" rowspan="1"><p style="text-align: center;"><span style="color: black;"><strong>Mental state</strong></span></p></td><td colspan="1" rowspan="1"><p style="text-align: center;"><span style="color: black;"><strong>Screening tool</strong></span></p></td></tr><tr><td colspan="1" rowspan="1"><p>&nbsp;</p><p>&nbsp;</p><p>Depression</p></td><td colspan="1" rowspan="1"><p><span>•&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>Depression screening questions</p><p><span>•&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>Edinberg postnatal depression scale</p><p><span>•&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>Patient health questionnaire PHQ</p></td></tr><tr><td colspan="1" rowspan="1"><p>Anxiety</p></td><td colspan="1" rowspan="1"><p>G AD – 2</p><p>G AD – 7</p></td></tr><tr><td colspan="1" rowspan="1"><p>Psychosis</p></td><td colspan="1" rowspan="1"><p>Red flag presentation</p></td></tr></tbody></table>	1	2026-06-07 16:48:48.249772
bba3e59d-730b-45ec-84b2-f62e9cfa5298	c4a99f45-fa0e-43c8-b7b6-90ef39b35144	text	<h2>8. Eating disorders in pregnancy</h2><p><span>•&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>6 – fold<span>&nbsp;increase </span>in perinatal mortality</p><p><span>•&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>Association with psychiatric disorder</p><p><span>•&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>Relapses in pregnancy</p><p><span>•&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>Fetal growth abnormalities</p><p><span>•&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>Feeding problems</p><p><span>•&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>anorexia has highest mortality among all psychiatric disorders.</p><p><strong>Management:</strong></p><p>1. Discuss healthy eating and its benefits</p><p>2.Offer support regarding nutrition</p><p>3.Psychological intervention</p><p>4.Growth scans</p>	8	2026-06-09 06:09:11.097748
2655d3f6-c9b2-4385-9a5c-d97aa771558c	c4a99f45-fa0e-43c8-b7b6-90ef39b35144	text	<h2>9. Sleep disorders</h2><p><strong>Discuss:</strong></p><p>Sleep hygiene</p><p>Avoid caffeine</p><p>Reduce bedtime activity</p><p>Healthy bed timing</p><p><strong>Medication:</strong></p><p>Promethazine in severe or chronic sleep problem</p>	9	2026-06-09 06:11:31.809393
87a56c46-66e0-479a-a401-bef21534f8e4	c4a99f45-fa0e-43c8-b7b6-90ef39b35144	text	<h2>10. Drug misuse</h2><p><strong>Alcohol:</strong></p><p><span>•&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>If suspected use AUDIT test</p><p><strong><em>AUDIT test: </em></strong>Is a 10-item screening tool developed by WHO to assess alcohol consumption, drinking behaviors and alcohol related problems.</p><p><span>•&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>Offer detoxification</p><p><span>•&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>Manage in collaboration with mental health and substance misuse services</p><p><span>•&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>Anomaly scan</p><p><span>•&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>Identify risk of accidental overdose</p><p><span>•&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>Offer treatment and support after child birth</p><p><span>•&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>Neonatal assessment to rule out congenital abnormalities and neonatal adaption syndrome.</p>	10	2026-06-09 06:14:00.276315
d4e667bf-70b0-4558-8e6a-658a81d49af2	bc603598-f547-4662-8699-64dadefba36a	text	<ul><li><p style="text-align: left;"><span>&nbsp;&nbsp; </span>Cardiac arrest 1/12500 pregnancy</p></li><li><p style="text-align: left;"><span>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>Commonest cause haemorrhage 45%, AF embolism 13%, Anaesthesia 3%, Trauma 3%</p></li><li><p style="text-align: left;"><span>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>Alternative name resuscitative hysterotomy</p></li><li><p style="text-align: left;"><span>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>Infant survival after PMCS = 69% Maternal survival 54%, 78% survive with moderate impaired neurological functions.</p></li><li><p style="text-align: left;"><span>&nbsp;&nbsp;&nbsp;&nbsp; </span>Aortocaval compression by uterus reduces venous return by 60%</p><h2 style="text-align: left;"><strong>Initial Resuscitation:</strong></h2></li><li><p style="text-align: left;"><span> </span><strong>Airway</strong>: by small tube to avoid failed intubation</p></li><li><p style="text-align: left;"><span>&nbsp; </span><strong>Breathing</strong>: High flow O<sub>2,</sub> 10 – 15l/min – detrimental to fetus but required for mother.</p></li><li><p style="text-align: left;"><span>&nbsp; </span><strong>Circulation</strong>: CPR 30:2, i/v line, fluids</p><p style="text-align: left;"><span>&nbsp;&nbsp;&nbsp;&nbsp; </span>Compression @ rate of 100/min with 2 rescue breaths after intubation ventilation @    rate of 100/min</p><p style="text-align: left;"><span>&nbsp;&nbsp; </span>In heavier Breast apply defibrillator pads anterior &amp; posterior pericardium</p><p style="text-align: left;"><span>&nbsp;&nbsp;&nbsp; </span>Uterus displacement up off and over</p><p style="text-align: left;"><span>&nbsp;&nbsp;&nbsp;&nbsp;</span>Cannula 16g I/V in upper body if failed use<span>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>intraosseous access.</p><h2 style="text-align: left;"><strong> PMCS</strong></h2></li><li><p style="text-align: left;"> indicated if gestational age is &gt; 20weeks after 4min of ineffective resuscitation.</p></li><li><p style="text-align: left;">Performed in Labour room/ ER</p></li><li><p style="text-align: left;">Without anesthesia</p></li><li><p style="text-align: left;">Equipment needed</p></li><li><p style="text-align: left;"><span>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>Curved 10n<sup>0</sup> blade over scalpel.</p></li><li><p style="text-align: left;"><span>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>2/3 ligature/ clamps.</p><p style="text-align: left;"><span><u>Abdominal Incision</u></span></p></li><li><p style="text-align: left;"><span>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>Preferably midline</p></li><li><p style="text-align: left;"><span>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>Easy approach</p></li><li><p style="text-align: left;"><span>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>Rapid entry</p></li><li><p style="text-align: left;"><span>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>Exploration of abdominal viscera is done if suspected visual injury</p></li><li><p style="text-align: left;"><span>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>Transverse – if clinician is not well trained or familiar with midline incision.</p><p style="text-align: left;"><span><u>Uterine incision</u></span></p></li><li><p style="text-align: left;"><span>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>20 – 28 weeks – vertical incision avoiding bladder</p></li><li><p style="text-align: left;"><span>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>&gt; 28 weeks – Transverse incision</p></li><li><p style="text-align: left;"><span>&nbsp; </span>Vertical incision more rapid with more chances of bladder injury.</p><p style="text-align: left;"><span><strong>&nbsp;&nbsp;&nbsp;&nbsp;</strong><u>Placenta:</u></span></p></li><li><p style="text-align: left;">Deliver or leave in situ</p></li><li><p style="text-align: left;">Pack the incised uterus and cover abdomen</p><p style="text-align: left;"><strong><u>Management after resuscitation is complete/ Successful:</u></strong></p></li><li><p style="text-align: left;"><span>&nbsp; </span>Shift to OT</p></li><li><p style="text-align: left;"><span>&nbsp; </span>General Anesthesia</p></li><li><p style="text-align: left;"><span>&nbsp; </span>Closure of uterus;</p></li><li><p style="text-align: left;">Vertical incision by 3 layered closure</p></li><li><p style="text-align: left;">  1<sup>st</sup> layer; –figure of 8 by 2 stitches.</p></li><li><p style="text-align: left;">  2<sup>nd</sup> and 3<sup>rd</sup> interrupted</p></li><li><p style="text-align: left;">  suture type; number 1 polyglactin</p></li><li><p style="text-align: left;"><span>&nbsp; </span>Transverse incision; close as per routine</p></li><li><p style="text-align: left;"><span>&nbsp; </span>Secure hemostasis and close abdomen</p></li><li><p style="text-align: left;"><span>&nbsp; </span>Placement of non-suction drain.</p></li><li><p style="text-align: left;"><span><strong>&nbsp; </strong></span>Pack the abdomen &amp; close with few sutures and remove pack after 24 hours in OT.</p><p style="text-align: left;"><strong><u>Management when Resuscitation is unsuccessful</u></strong>:</p></li><li><p style="text-align: left;"><span>&nbsp; </span>Stop resuscitation – decision is made by attending senior consultant team (obstetrician, Anaesthetist, ER staff)</p></li><li><p style="text-align: left;">Agreement of all staff is must.</p></li><li><p style="text-align: left;"><span>&nbsp; </span>Inform coroner</p></li><li><p style="text-align: left;"><span>&nbsp; </span>Leave devices inside if postmortem is required</p><p style="text-align: left;"><strong><u>Recommendations for post mortem:</u></strong></p></li><li><p style="text-align: left;"><span> </span>All devices like catheter, tube, I/V line should be in situ @ the time of disclosure of death to attendants</p></li><li><p style="text-align: left;"><span> </span>Leave placenta in situ, uterus un sutured, abdomen open</p></li><li><p style="text-align: left;"><span>&nbsp;</span>pack and do the dressing of the abdomen.</p></li><li><p style="text-align: left;"><span> </span>Clear documentation of all events of PMCS in notes.</p><p style="text-align: left;"><strong><u>Neonatal care</u></strong></p><p style="text-align: left;"><strong><u>Debriefing </u></strong>of relative and staff.</p></li></ul>	0	2026-06-09 06:22:37.653849
9b7ea93f-8b78-4c84-bf4f-0c89d5f7a7ae	992f9097-aac3-4b30-8c85-2d93c2e41038	text	<p>-&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 1/5 pregnancies need IOL</p><p>-&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 2/3 give birth without intervention</p><p>-&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 15% need AVB</p><p>-&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 22% end up in C/S</p><p>&nbsp;&nbsp;&nbsp; Most women go into labour by 42 weeks</p><p>&nbsp;@ 38 weeks all women should be offered information regarding</p><p>1. Risk of pregnancies that last longer than 42 weeks.</p><p>2. Expectant management</p><p>3. Membranes stripping</p><p>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Method</p><p>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; benefits of spontaneous labour</p><p>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Uncomfortable, pain</p><p>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Possible bleeding</p><p>IOL between 41 – 42 weeks</p><h2><strong>Information giving before IOL:</strong></h2><p>1. Reason</p><p>2. When, where, how</p><p>3. Support, pain relief</p><p>4. Alternative to IOL</p><p>5. Risk/ Benefits of IOL</p><p>6. what if IOL fails</p><h2>Indications of IOL</h2><p>1. prolong pregnancy IOL between 41 – 42 weeks exact timing according to patient’s wishes patient who decline =&gt; after 42 weeks</p><p>CTG + Amniotic Fluid =&gt; twice/ week</p><p>2.&nbsp; PPROM</p><p>&nbsp;&nbsp; Before 37 weeks expectant management, to prolong till 37 weeks. In case of fetomaternal indications offer IOL</p><p>3. PROM</p><p>24 hours after ROM offer IOL</p><p>4. Previous CS – PG E<sub>2</sub>/ expectant according to women wishes, explain risk of rupture and emergency CS</p><p>5. Maternal request @ or after 40 weeks =&gt; under special conditions</p><p>6. Breech – Not recommended</p><p>7. Severe IUGR + compromise NR</p><p>8. History of precipitated labor – not routinely offered.</p><p>9.&nbsp; IUD</p><p>🎯Patient physically well, &nbsp;&nbsp;No infection,&nbsp;&nbsp;No bleeding</p><p>&nbsp;&nbsp;&nbsp; Offer a choice of expectant/ IOL by mifepristone ,misoprostol or FPG E<sub>2</sub></p><p>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</p><p>🎯Unwell <u>+</u> bleeding <u>+</u> infection or Ruptured membranes</p><p>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; IOL is recommended</p><p>IUD + previous CS =&gt; risk of rupture, reduce dose of MISO</p><p>•&nbsp; Fetal macrosomia =&gt; Discuss</p><h2><strong>Methods:</strong></h2><p>1.&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Sweeping of Membranes = Adjunct to IOL</p><p>-&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; primigravida = 40 – 41weeks</p><p>-&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Multigravida = 41 weeks</p><p>-&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; additional sweeping can be done if patient don’t go into labor.</p><p>2.&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Bishop = <u>&gt; </u>8 =&gt; Favorable</p><p>3.&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Misoprostol, Mefipriston =&gt; IUD only</p><p>4.&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; PG E<sub>2</sub></p><p>-&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Tablets – 3mg&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 6 hourly, 2 doses</p><p>-&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; GEL – 2mg&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 6 hourly, 2 doses.</p><p>-&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Pessary – 20mg =&gt; 24 hours – 1 dose</p><p>5.&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Amniotomy + syntocinon =&gt; only if risk of hyper stimulation</p><h2><strong><u>IOL @ older women:</u></strong></h2><p>Age @ delivery beyond 35 years&nbsp;&nbsp;&nbsp;increased from 8 – 20% and @ 40 years 1.2 – 3.6%</p><p><strong>Risks increase&nbsp;&nbsp;&nbsp;with age:</strong></p><p>1.&nbsp; APH – PPH</p><p>2.&nbsp; Abruption</p><p>3.&nbsp; PTL</p><p>4.&nbsp; Post dated</p><p>5.&nbsp; Unexplained S.B</p><p>6.&nbsp; DM</p><p>7.&nbsp; HTN</p><p>8.&nbsp; IUGR – LBW</p><p>9.&nbsp; Previa</p><p>10.&nbsp; &nbsp;&nbsp;CS and OVB</p><p>11.&nbsp; Neonatal Mortality – 1.3time.</p><p>•&nbsp; SB @ Term</p><p>-&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &gt; 40 years – 2/1000</p><p>-&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &lt; 40 yeas – 1/1000</p><p>So, IOL @ 39 – 40 weeks if age <u>&gt;</u> 40 years</p><p>•&nbsp; Discussion with women</p><p>-&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; SB @ 41 weeks</p><p>-&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 35 years – 0.75/1000</p><p>-&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 40 years – 2.5/1000</p><p><strong><u>CEFM vs Intermittent in IOL</u></strong></p><p>-&nbsp; No difference in CP and perinatal mortality</p><p>-&nbsp; ½ the chances of neonatal seizures&nbsp;</p><p>-&nbsp; icreased Risk of C/S</p><p>-&nbsp; increased Risk of AVB</p><p><strong><u>Setting and timing of IOL:</u></strong></p><p>•&nbsp; Morning time – high patient satisfaction</p><p>•&nbsp; OPD/ In patient</p><p>&nbsp;</p><p>&nbsp; If support is in place</p><p>&nbsp; Continuously audited.</p><p>&nbsp;</p><h2>&nbsp;Monitoring</h2><p>&nbsp;</p><p>Before induction&nbsp; &nbsp; After Induction</p><p>&nbsp;⬇️ ⬇️</p><p>- CTG &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; -<strong> CEFM</strong></p><p>&nbsp;-&nbsp; Bishop&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp;once contractions&nbsp;&nbsp;&nbsp;&nbsp;</p><p>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp;Begun</p><p>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; <strong>- Bishop </strong>24 hours after pessary.</p><p>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;6 hours after&nbsp;Gel/Tablets or when&nbsp;contractions begun.&nbsp; &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Normal/ Reasoning FHR</p><p>⬇️</p><p>Intermittent monitoring</p><h2><strong>Outpatient IOL:</strong></h2><p><span style="color: rgb(47, 84, 150);"><em>Return to hospital if:</em></span></p><p>Contractions begun or</p><p>No contractions after 6 hours</p><h2><strong>Pain relief:</strong></h2><p>Induced labour is more painful</p><p>•&nbsp; Offer variety of pain relief</p><p>-&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Self – coping</p><p>-&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Simple Analgesia</p><p>-&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Continuous supports</p><p>-&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Epidural</p><p>-&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Water Birth</p><p>&nbsp;<strong><u>Prevention &amp; management of complications:</u></strong>&nbsp;</p><p>🎯Uterine Hyper&nbsp;Stimulation&nbsp;:Tocolysis&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</p><p>🎯 Failed IOL&nbsp;&nbsp;:Discussion after evaluation either repeat IOL or c section&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</p><p>🎯 Cord&nbsp;prolapse&nbsp;:Avoid amniotomy at high head and avoid pushing</p><p>🎯 Uterine rupture: emergency laparotomy&nbsp;</p><p>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</p><p>&nbsp;</p><p>&nbsp;</p>	0	2026-06-09 06:44:23.550291
0910727e-89bf-4780-9fc0-fab886a8982f	23d86197-82bb-4f65-8742-9eaff7f540f6	text		0	2026-06-09 07:46:46.06173
7b7771e7-dd92-406a-afce-b495146bc161	9ffb1679-4328-47c6-b6c8-df01cc2337ed	text	<p><span style="color: rgb(34, 34, 34);">In practice, <strong><em>it means:</em></strong></span></p><p>•&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; <span style="color: rgb(34, 34, 34);">Adopting an evidence-based approach in the management from patient (evidence from randomised controlled trials, meta-analysis and systematic reviews)</span></p><p>•&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; <span style="color: rgb(34, 34, 34);">Changing practice, developing new protocols or guidelines based on experience and evidence if current practice is inadequate</span></p><p>•&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; <span style="color: rgb(34, 34, 34);">Implementing NICE guidelines, National Service Frameworks and other national standards to ensure optimal care - these should be appropriately disseminated and implemented in clinical practice, and compliance can be monitored by means of clinical audit</span></p><p>•&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; <span style="color: rgb(34, 34, 34);">Clinical audit can be seen as a tool for driving clinical effectiveness.&nbsp;</span></p>	1	2026-06-01 07:48:57.621033
1763a255-314a-49f6-8daf-139a9891eff8	451cca65-ae17-4959-bfd9-043a725fa698	image	/uploads/content-images/1781531501040-382f58ed-e930-4c7d-b81e-9391b3a7fdaa.png	12	2026-06-15 13:50:49.026634
88607813-2a24-4d58-8e06-a4a4a7f82913	451cca65-ae17-4959-bfd9-043a725fa698	heading	Obstetrics:	13	2026-06-15 13:53:09.692981
9912c503-7961-4c27-a3ad-534c411d520d	451cca65-ae17-4959-bfd9-043a725fa698	image	/uploads/content-images/1781531632386-0137a525-be09-4910-b97e-00a5de3b3971.png	14	2026-06-15 13:53:39.363331
1da5cc62-b289-4891-b1f7-3c83aba5876c	20944d53-c138-45a9-a769-c48bd4229f0f	text	<p>Clinical Governance is defined as a framework through which NHS organizations are accountable for continuously improving the quality of the services and safeguarding standards of the care by creating an environment in which excellence in the clinical care will flourish.</p><p>&nbsp;<span style="color: rgb(34, 34, 34);">Traditionally, clinical governance has been described using 7 key pillars:&nbsp;</span></p><p>•&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; clinical effectiveness and research&nbsp;</p><p>•&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; <span style="color: rgb(34, 34, 34);">clinical audit&nbsp;</span></p><p>•&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; <span style="color: rgb(34, 34, 34);">risk management&nbsp;</span></p><p>•&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; <span style="color: rgb(34, 34, 34);">education and training&nbsp;</span></p><p>•&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; <span style="color: rgb(34, 34, 34);">patient and public involvement (PPI)</span></p><p>•&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; <span style="color: rgb(34, 34, 34);">information management&nbsp;</span></p><p>•&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; <span style="color: rgb(34, 34, 34);">staff management.&nbsp;</span></p><p><span style="color: rgb(34, 34, 34);">The various elements of clinical governance, when brought together,&nbsp;acquire the ability to improve the efficiency of systems</span></p>	0	2026-06-15 13:40:43.703368
968fb951-cae9-4c25-ae75-8ee6513ef514	9ffb1679-4328-47c6-b6c8-df01cc2337ed	image	/uploads/content-images/1781531975749-a399b961-bcf9-4387-8c0e-788b5865c0a1.jpg	4	2026-06-15 13:59:25.322994
5a76e23b-e792-425e-9b91-e135a557cc4d	451cca65-ae17-4959-bfd9-043a725fa698	text	<table class="mm-table" style="min-width: 50px;"><colgroup><col style="min-width: 25px;"><col style="min-width: 25px;"></colgroup><tbody><tr><td colspan="2" rowspan="1"><p style="text-align: center;"><span style="color: rgb(65, 109, 129);">Questions addressed by risk management</span></p></td></tr><tr><td colspan="1" rowspan="1"><p style="text-align: center;"><span style="color: rgb(0, 23, 71);"><strong>Question</strong></span></p></td><td colspan="1" rowspan="1"><p style="text-align: center;"><span style="color: rgb(0, 23, 71);"><strong>Answer</strong></span></p></td></tr><tr><td colspan="1" rowspan="1"><p><span style="color: rgb(34, 34, 34);">What could go (or went) wrong?</span></p></td><td colspan="1" rowspan="1"><p><span style="color: rgb(34, 34, 34);">Risk identification</span></p></td></tr><tr><td colspan="1" rowspan="1"><p><span style="color: rgb(34, 34, 34);">What are the chances of it going wrong and what would be the impact?</span></p></td><td colspan="1" rowspan="1"><p><span style="color: rgb(34, 34, 34);">Risk analysis and evaluation</span></p></td></tr><tr><td colspan="1" rowspan="1"><p><span style="color: rgb(34, 34, 34);">What can we do to minimize the chance of this happening or to mitigate damage when it has gone wrong?</span></p></td><td colspan="1" rowspan="1"><p><span style="color: rgb(34, 34, 34);">Risk treatment - the cost of prevention is compared with the cost of getting it wrong</span></p></td></tr><tr><td colspan="1" rowspan="1"><p><span style="color: rgb(34, 34, 34);">What can we learn from things that have gone wrong?</span></p></td><td colspan="1" rowspan="1"><p><span style="color: rgb(34, 34, 34);">Risk control; sharing and learning</span></p></td></tr></tbody></table>	2	2026-06-01 07:59:22.900797
77df57b4-bc77-4740-b8a4-d181adae2036	451cca65-ae17-4959-bfd9-043a725fa698	image	/uploads/content-images/1781531429998-cb7f6191-6610-4f3c-8b73-fbabb6c2d12d.png	9	2026-06-15 13:50:22.190613
77f4296c-78f7-46d3-a125-71a43b91a41f	451cca65-ae17-4959-bfd9-043a725fa698	heading	Incident reporting  indication:	10	2026-06-15 13:52:04.880038
8148b36d-5ae8-49b9-837b-831fcd481546	451cca65-ae17-4959-bfd9-043a725fa698	heading	Gynaecology:	11	2026-06-15 13:52:40.490202
226a28c5-b9ab-4e67-bc6e-0e940e9cc5f8	9ffb1679-4328-47c6-b6c8-df01cc2337ed	text	<p><span style="color: rgb(34, 34, 34);">means ensuring that everything you do is designed to provide the best outcomes for patients ensuring that the right person does:</span></p><p>•&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; <span style="color: rgb(34, 34, 34);">The right thing (evidence-based practice)</span></p><p>•&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; <span style="color: rgb(34, 34, 34);">In the right way (skills and competence)</span></p><p>•&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; <span style="color: rgb(34, 34, 34);">At the right time (providing treatment/services when the patient needs them)</span></p><p>•&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; <span style="color: rgb(34, 34, 34);">In the right place (location of treatment/services)</span></p><p>•&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; <span style="color: rgb(34, 34, 34);">With the right result (clinical effectiveness/maximizing health gain).</span></p><p><span style="color: rgb(34, 34, 34);">The best available evidence, clinical skills and patient preferences are combined to achieve optimal processes and outcomes.</span></p>	0	2026-06-01 07:48:36.586577
5e4ab459-b244-4b1a-9322-b8f3764cdc23	20944d53-c138-45a9-a769-c48bd4229f0f	image		2	2026-06-23 06:36:51.850568
1a30067e-c55e-4259-9e16-cbf0b7df4c29	ae07ff0d-4682-4df5-bd7d-f6067bd7b664	text		2	2026-06-23 08:19:05.745664
b5b80c3b-9ed4-408f-b0b2-d494c35999a0	ae07ff0d-4682-4df5-bd7d-f6067bd7b664	text		3	2026-06-23 08:19:05.983142
76f2016e-a7c3-4ba4-bb7e-e429712ec093	250ccdc2-184d-4bfe-b1f8-ebd98ae9f550	text	<p>Text block testing by dr faisal</p>	1	2026-06-25 22:39:00.529831
66aea617-a0ab-4e8d-ad11-71f0135bd67c	250ccdc2-184d-4bfe-b1f8-ebd98ae9f550	text	<table class="mm-table" style="min-width: 50px;"><colgroup><col style="min-width: 25px;"><col style="min-width: 25px;"></colgroup><tbody><tr><th colspan="1" rowspan="1"><p>table 1</p><ul><li><p>hi dkjajknackjnslkdc</p></li><li><p>dskjfnjknvckjen</p></li><li><p>hjnekjfnref</p></li><li><p>fkjnkjenfkjref</p></li></ul></th><th colspan="1" rowspan="1"><p>table 2</p><ol><li><p>jalkdewklnxlkwd</p></li><li><p>djnewjkdnkjewndlkewnd</p></li><li><p>hbdkjwndkjnewd</p></li><li><p>kdbjewndkjnewkjdn</p></li><li><p>dlknlkwemdkw</p></li></ol></th></tr></tbody></table>	2	2026-06-25 22:39:13.978634
c52e530a-2571-4b90-8b28-95e04be608c1	250ccdc2-184d-4bfe-b1f8-ebd98ae9f550	text	<p></p>	4	2026-06-23 19:03:55.582851
\.


--
-- Data for Name: content_reports; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.content_reports (id, user_id, content_type, content_id, report_type, description, status, reviewed_by, reviewed_at, created_at) FROM stdin;
8aa81289-9f28-4256-aa1a-ed49329ba37e	61bd4894-7aa4-437b-bcb2-285bdc034994	topic	52c2375a-221f-40db-be86-b66990fdd20a	other	Error at the table\n	resolved	demo-user-001	2026-04-17 18:13:35.194	2026-03-05 11:53:39.195677
9f9c6e3f-360a-49b8-93ca-a10cb44a1646	61bd4894-7aa4-437b-bcb2-285bdc034994	topic	c7578a7b-6acb-48bb-a9f7-9c54c8f23e20	factual_error	Error	resolved	demo-user-001	2026-04-17 18:13:38.229	2026-03-05 11:08:12.413652
34867915-8e55-4095-abd8-af7831d6ed0e	e48a1d49-0a19-4f78-bb27-e8f26279052c	topic	6f36db59-1cc0-4586-8c6a-1c8bb00a8e0c	factual_error	Test	pending	\N	\N	2026-05-09 17:01:20.624048
6b20f6e1-1c44-4c05-bb54-1c0ba8cecb60	51268d4e-a5cf-4e92-948c-0c708d200d48	topic	c293f92b-c305-42f4-b986-2dd110fdd68e	factual_error	mindreader420123@gmail.com	pending	\N	\N	2026-06-16 17:13:34.842199
\.


--
-- Data for Name: coupon_usage; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.coupon_usage (id, coupon_id, user_id, subscription_id, discount_applied, used_at) FROM stdin;
\.


--
-- Data for Name: coupons; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.coupons (id, code, description, campaign_id, discount_type, discount_value, min_purchase_amount, max_discount_amount, applicable_package_ids, applicable_add_on_ids, max_total_uses, max_uses_per_user, current_use_count, valid_from, valid_until, is_stackable, referral_user_id, is_active, metadata, created_at, updated_at) FROM stdin;
db8b1ada-349c-4417-b0d3-381a8525a227	LAUNCH50	50% off launch discount	\N	percentage	50.00	\N	\N	\N	\N	100	1	0	\N	\N	f	\N	t	\N	2026-04-16 17:12:44.37258	2026-04-16 17:12:44.37258
97462046-53ba-4254-aaa2-c7f6e5b23542	TEST-UA2RHL39	\N	\N	percentage	10.00	\N	\N	\N	\N	\N	1	0	\N	\N	f	\N	t	\N	2026-04-16 17:56:37.827104	2026-04-16 17:56:37.827104
1b8b8bce-7c7f-4b57-9254-b3cbfa2059d1	TEST-2XJ8QAAQ	\N	\N	percentage	10.00	\N	\N	\N	\N	\N	1	0	\N	\N	f	\N	t	\N	2026-04-16 17:56:37.827104	2026-04-16 17:56:37.827104
6032cdfa-aabb-4cf1-92a0-574afd4fb572	TEST-GFJK24YK	\N	\N	percentage	10.00	\N	\N	\N	\N	\N	1	0	\N	\N	f	\N	t	\N	2026-04-16 17:56:37.827104	2026-04-16 17:56:37.827104
6985c82e-cdd7-4791-9705-1184ba4637b2	TEST-LYZBRMAX	\N	\N	percentage	10.00	\N	\N	\N	\N	\N	1	0	\N	\N	f	\N	t	\N	2026-04-16 17:56:37.827104	2026-04-16 17:56:37.827104
047d63df-6936-4566-8ea7-4c5dcc78b82b	TEST-3AEUPQJP	\N	\N	percentage	10.00	\N	\N	\N	\N	\N	1	0	\N	\N	f	\N	t	\N	2026-04-16 17:56:37.827104	2026-04-16 17:56:37.827104
\.


--
-- Data for Name: invoice_line_items; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.invoice_line_items (id, invoice_id, type, description, package_id, add_on_id, quantity, unit_price, total, period_start, period_end, metadata, created_at) FROM stdin;
\.


--
-- Data for Name: invoices; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.invoices (id, invoice_number, user_id, subscription_id, status, subtotal, discount_total, tax_total, total, currency, paid_at, due_at, period_start, period_end, coupon_id, notes, metadata, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: manual_payment_proofs; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.manual_payment_proofs (id, user_id, package_id, price_id, status, amount_claimed, currency, payment_method, sender_reference, user_note, proof_image_url, proof_filename, reviewed_by, reviewed_at, rejection_reason, created_subscription_id, created_at, updated_at) FROM stdin;
43d6b0f5-ed07-417c-95d8-a4d9ae1550ed	61bd4894-7aa4-437b-bcb2-285bdc034994	153871ff-16c9-4c1a-a2b0-1606fa830750	ee8dd8d3-3632-4888-9e89-164abd754b77	approved	9.99	\N	\N	\N	\N	/uploads/payment-proofs/1782736803560-419d6a44-7544-4b11-a8fd-17969aa87993.jpg	1782736803560-419d6a44-7544-4b11-a8fd-17969aa87993.jpg	demo-user-001	2026-06-29 12:41:05.566	\N	22826204-3778-49da-883a-feb5844d2263	2026-06-29 12:40:03.89696	2026-06-29 12:41:05.566
\.


--
-- Data for Name: mcqs; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.mcqs (id, topic_id, question, options, correct_answer, explanation, option_explanations, difficulty, "references", tags, is_published, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: package_features; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.package_features (id, package_id, name, description, value_type, value, display_order, feature_key, created_at) FROM stdin;
016ecc17-3f5f-431a-bd3b-d3e389fe1d22	153871ff-16c9-4c1a-a2b0-1606fa830750	Full Content Access	\N	check	\N	0	full_content_access	2026-04-16 17:56:36.725882
72bdcc1b-5212-4799-8b07-9272610c7ba1	153871ff-16c9-4c1a-a2b0-1606fa830750	Unlimited MCQ Practice	\N	check	\N	1	unlimited_mcqs	2026-04-16 17:56:36.785014
\.


--
-- Data for Name: package_prices; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.package_prices (id, package_id, billing_cycle, custom_duration_days, price, currency, original_price, is_active, revenuecat_offering_id, package_version, metadata, created_at, updated_at) FROM stdin;
ee8dd8d3-3632-4888-9e89-164abd754b77	153871ff-16c9-4c1a-a2b0-1606fa830750	monthly	\N	9.99	PKR	\N	t	\N	1	\N	2026-04-16 17:56:36.443901	2026-04-16 17:56:36.443901
45f6e053-1ce0-4210-a340-eaefee86b29d	153871ff-16c9-4c1a-a2b0-1606fa830750	annual	\N	79.99	PKR	\N	t	\N	2	\N	2026-04-16 17:56:36.58043	2026-04-16 17:56:36.58043
cfcd8ece-74f4-4634-9e7d-f50d77b04380	c2456081-c883-4fa2-99dc-c4d0dfeb8229	monthly	\N	4.99	PKR	\N	t	\N	1	\N	2026-04-16 17:57:12.51588	2026-04-16 17:57:12.51588
\.


--
-- Data for Name: password_reset_tokens; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.password_reset_tokens (id, user_id, token, expires_at, used, created_at) FROM stdin;
fa889495-a1a0-478a-95e2-21f449a1a13d	7c45a099-3c4f-4068-8140-8b2f7ffe828e	7b20a01015a11ef7d34d5f776116bfdf383a08dea8397a526a56463fa62c171d	2026-02-19 15:17:37.987	f	2026-02-19 14:17:37.989088
74efe759-a82d-4bb5-b8d7-033514257ee0	51268d4e-a5cf-4e92-948c-0c708d200d48	39e7ba80408e07b387770dd1213d696d057817c9a4b16fab149079351164a3a2	2026-02-25 18:24:43.788	f	2026-02-25 17:24:43.789039
5d054825-514c-4e5b-83a1-51285852fd3b	7c45a099-3c4f-4068-8140-8b2f7ffe828e	c7ffaed49d7b02e305babd32580915500f034798cb16413bd3e4fb6e21d1bc1e	2026-02-25 18:25:46.689	f	2026-02-25 17:25:46.690394
64ecd85e-a4db-47d7-b34e-1239cfe15743	7c45a099-3c4f-4068-8140-8b2f7ffe828e	d42884a07c00fa60c61d2ee4cd3f80c58224ae5ee3e11ab624fa2429f9aeea27	2026-02-25 18:28:00.551	f	2026-02-25 17:28:00.553246
7a36f66a-0661-4d5c-8cb2-d6160e89b96d	51268d4e-a5cf-4e92-948c-0c708d200d48	477852	2026-03-05 01:27:25.898	t	2026-03-05 00:27:25.900799
32a80e21-abeb-4bad-b78f-c0c6fd7120de	51268d4e-a5cf-4e92-948c-0c708d200d48	547976	2026-03-18 22:14:47.71	f	2026-03-18 21:14:47.711499
d78e51b8-e1ec-45ac-ba61-70bbfe7663e5	51268d4e-a5cf-4e92-948c-0c708d200d48	207041	2026-03-18 22:15:03.546	f	2026-03-18 21:15:03.548763
4d376505-31e8-4eb4-92c7-156b9db08e83	63a38ea4-b281-494b-ac6a-8570e0df520a	463188	2026-03-18 22:21:41.306	t	2026-03-18 21:21:41.308336
b288e894-ae5f-49ab-997a-182928808778	63a38ea4-b281-494b-ac6a-8570e0df520a	548467	2026-03-18 22:23:55.333	t	2026-03-18 21:23:55.334236
99068555-0457-499a-b46c-78805806ba7e	51268d4e-a5cf-4e92-948c-0c708d200d48	905500	2026-03-18 22:30:10.636	t	2026-03-18 21:30:10.63752
d8de72f0-7399-4fc3-a50a-312d85b21a16	e28e49cd-8106-4a2d-a274-368a6812627d	879094	2026-05-03 05:17:02.712	f	2026-05-03 04:17:02.743218
d32ad531-db52-49ec-86e5-ab4cbc4aee2f	71ff5b30-cb26-4b18-b259-82e55fcf7a1a	185949	2026-05-03 05:22:32.39	f	2026-05-03 04:22:32.392319
0d1e4bef-1984-4542-9134-f458617b4759	7c45a099-3c4f-4068-8140-8b2f7ffe828e	358783	2026-05-03 05:49:07.404	t	2026-05-03 04:49:07.410539
c3c28426-b0d9-46c3-a131-ffc6978cf1f2	e28e49cd-8106-4a2d-a274-368a6812627d	240560	2026-05-03 05:58:38.054	t	2026-05-03 04:58:38.064705
8a2c6d0e-453e-4dd4-852b-b9654f97666c	7c45a099-3c4f-4068-8140-8b2f7ffe828e	305227	2026-06-16 04:51:35.191	t	2026-06-16 03:51:35.192495
fad5437b-2c32-4af1-9185-e16271ff27f6	2d066c5b-1e17-4330-9c6f-504c080cf66f	405023	2026-06-30 10:41:54.517	f	2026-06-30 09:41:54.520088
804d3d5c-b74b-46cd-9fa9-80cc2e384f1d	2d066c5b-1e17-4330-9c6f-504c080cf66f	335563	2026-06-30 10:44:16.027	f	2026-06-30 09:44:16.028246
\.


--
-- Data for Name: payment_transactions; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.payment_transactions (id, invoice_id, user_id, status, amount, currency, payment_gateway, gateway_transaction_id, gateway_response, failure_reason, failure_code, refunded_amount, refunded_at, refund_reason, metadata, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: quiz_attempts; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.quiz_attempts (id, user_id, topic_id, mode, score, total_questions, correct_count, wrong_count, time_taken, answers, created_at) FROM stdin;
ff5fdf4b-3737-4ea3-9ad5-c6863bf633a3	demo-user-001	\N	random	70	10	7	3	420	[{"mcqId": "mcq-001", "isCorrect": true, "selectedAnswer": "Ampulla of the fallopian tube"}, {"mcqId": "mcq-011", "isCorrect": true, "selectedAnswer": "BP ≥160/110 or end-organ dysfunction"}, {"mcqId": "mcq-021", "isCorrect": true, "selectedAnswer": "Polyp"}, {"mcqId": "mcq-031", "isCorrect": true, "selectedAnswer": "36 hours"}, {"mcqId": "mcq-036", "isCorrect": true, "selectedAnswer": "2 of 3"}, {"mcqId": "mcq-026", "isCorrect": true, "selectedAnswer": "Types 16 and 18"}, {"mcqId": "mcq-041", "isCorrect": true, "selectedAnswer": "Uterine atony"}, {"mcqId": "mcq-007", "isCorrect": false, "selectedAnswer": "35 mmHg"}, {"mcqId": "mcq-028", "isCorrect": false, "selectedAnswer": "Rb"}, {"mcqId": "mcq-038", "isCorrect": false, "selectedAnswer": "30-40%"}]	2026-02-06 11:26:55.219682
3180bdd9-b6d7-4389-aed9-6bf2a77d2d5e	51268d4e-a5cf-4e92-948c-0c708d200d48	\N	exam	40	30	12	18	0	{"mcq-004": {"correct": "hCG", "selected": "LH", "isCorrect": false, "explanation": "Human chorionic gonadotropin (hCG), produced by the syncytiotrophoblast, maintains the corpus luteum and its progesterone production until the placenta takes over at 8-10 weeks."}, "mcq-007": {"correct": "30 mmHg", "selected": "35 mmHg", "isCorrect": false, "explanation": "Pregnancy causes a compensated respiratory alkalosis with PaCO2 ~30 mmHg due to progesterone-stimulated hyperventilation (increased tidal volume)."}, "mcq-010": {"correct": "Hemodilution", "selected": "Hemodilution", "isCorrect": true, "explanation": "Plasma volume increases by 50% while red cell mass increases by only 25-30%, resulting in a dilutional decrease in hemoglobin concentration (physiological anemia)."}, "mcq-012": {"correct": "Delivery", "selected": "Antihypertensive therapy", "isCorrect": false, "explanation": "The only definitive treatment for preeclampsia is delivery. Magnesium sulfate prevents seizures, and antihypertensives control acute severe hypertension, but they do not cure the disease."}, "mcq-013": {"correct": "Leukocytosis", "selected": "Elevated liver enzymes", "isCorrect": false, "explanation": "HELLP = Hemolysis (elevated LDH, schistocytes), Elevated Liver enzymes, Low Platelets. Leukocytosis is not part of the HELLP triad."}, "mcq-015": {"correct": "4-6 g IV", "selected": "4-6 g IV", "isCorrect": true, "explanation": "The standard loading dose is 4-6 g IV over 15-20 minutes, followed by a maintenance infusion of 1-2 g/hour. Monitor for magnesium toxicity: loss of deep tendon reflexes, respiratory depression."}, "mcq-016": {"correct": "6 cm dilation", "selected": "4 cm dilation", "isCorrect": false, "explanation": "Current evidence (Zhang et al., supported by ACOG/SMFM) defines active labor as beginning at 6 cm dilation, replacing the older Friedman definition of 4 cm."}, "mcq-018": {"correct": "Uterine relaxation", "selected": "Cord lengthening", "isCorrect": false, "explanation": "Signs of placental separation: gush of blood, lengthening of umbilical cord, and the uterus becomes firm and globular (contracts, does not relax). Uterine relaxation would indicate a problem, not normal separation."}, "mcq-019": {"correct": "3 hours", "selected": "2 hours", "isCorrect": false, "explanation": "ACOG allows up to 3 hours for the second stage in nulliparas with epidural anesthesia (2 hours without epidural). For multiparas: 2 hours with epidural, 1 hour without."}, "mcq-022": {"correct": "≥45 years", "selected": "≥40 years", "isCorrect": false, "explanation": "ACOG recommends endometrial biopsy for all women ≥45 years with AUB to rule out endometrial hyperplasia or carcinoma. Women <45 with risk factors also warrant biopsy."}, "mcq-024": {"correct": "Coagulopathy", "selected": "Polyp", "isCorrect": false, "explanation": "COEIN represents non-structural causes: Coagulopathy, Ovulatory dysfunction, Endometrial, Iatrogenic, Not yet classified. PALM represents structural causes."}, "mcq-025": {"correct": "Inhibiting fibrinolysis", "selected": "Inhibiting fibrinolysis", "isCorrect": true, "explanation": "Tranexamic acid is an antifibrinolytic that blocks the conversion of plasminogen to plasmin, stabilizing blood clots and reducing menstrual blood loss by 40-50%."}, "mcq-030": {"correct": "9", "selected": "4", "isCorrect": false, "explanation": "Gardasil-9 is the 9-valent HPV vaccine covering types 6, 11 (warts), 16, 18, 31, 33, 45, 52, and 58 (cancer-causing). It prevents ~90% of cervical cancers."}, "mcq-032": {"correct": "14 ± 2 days", "selected": "10 ± 2 days", "isCorrect": false, "explanation": "The luteal phase is remarkably constant at 14 ± 2 days in ovulatory cycles. Cycle length variation is primarily due to variation in the follicular phase duration."}, "mcq-033": {"correct": "Sustained high estrogen levels", "selected": "Rising progesterone", "isCorrect": false, "explanation": "When estradiol from the dominant follicle exceeds 200 pg/mL for approximately 50 hours, it switches from negative to positive feedback on the hypothalamus/pituitary, triggering the GnRH and LH surge."}, "mcq-036": {"correct": "2 of 3", "selected": "2 of 3", "isCorrect": true, "explanation": "PCOS is diagnosed when at least 2 of the 3 Rotterdam criteria are met: (1) oligo/anovulation, (2) hyperandrogenism (clinical or biochemical), (3) polycystic ovaries on ultrasound, after excluding other causes."}, "mcq-038": {"correct": "50-70%", "selected": "30-40%", "isCorrect": false, "explanation": "Approximately 50-70% of women with PCOS have insulin resistance, regardless of BMI. Insulin resistance drives ovarian androgen excess by stimulating theca cell androgen production and reducing hepatic SHBG."}, "mcq-039": {"correct": "5-10%", "selected": "5-10%", "isCorrect": true, "explanation": "Even modest weight loss of 5-10% of body weight can restore regular ovulatory cycles in overweight/obese PCOS patients by improving insulin sensitivity and reducing androgen levels."}, "mcq-042": {"correct": "1000 mL", "selected": "500 mL", "isCorrect": false, "explanation": "The revised (ACOG 2017) definition of PPH is cumulative blood loss ≥1000 mL or blood loss accompanied by signs/symptoms of hypovolemia within 24 hours of delivery, regardless of delivery route."}, "mcq-045": {"correct": "Uterine atony refractory to medications", "selected": "Uterine atony refractory to medications", "isCorrect": true, "explanation": "Intrauterine balloon tamponade (Bakri balloon) is used when medical management fails to control PPH from uterine atony. It is filled with saline (300-500 mL) and applies pressure to the uterine cavity. Success rate is approximately 85%."}, "mcq-048": {"correct": "Cesarean section at 36-37 weeks", "selected": "Cesarean section at 36-37 weeks", "isCorrect": true, "explanation": "Complete (total) placenta previa requires planned cesarean delivery at 36-37 weeks (after confirming fetal lung maturity or administering corticosteroids). Earlier delivery if bleeding is uncontrollable."}, "mcq-049": {"correct": "24-28 weeks", "selected": "16-20 weeks", "isCorrect": false, "explanation": "Universal screening for GDM with a 50g glucose challenge test (GCT) is performed at 24-28 weeks gestation, when insulin resistance is most pronounced due to placental hormones."}, "mcq-050": {"correct": "≥140 mg/dL", "selected": "≥130 mg/dL", "isCorrect": false, "explanation": "A 1-hour plasma glucose ≥140 mg/dL after 50g GCT is considered positive and requires follow-up with a 3-hour 100g OGTT. Some institutions use ≥130 mg/dL for higher sensitivity."}, "mcq-051": {"correct": "Macrosomia", "selected": "Macrosomia", "isCorrect": true, "explanation": "Macrosomia (birth weight >4000g) is the most common fetal complication of GDM due to fetal hyperinsulinemia in response to maternal hyperglycemia. This increases risk of shoulder dystocia and birth trauma."}, "mcq-053": {"correct": "36 hours", "selected": "24 hours", "isCorrect": false, "explanation": "Oocyte retrieval is timed at 34-36 hours after hCG (or GnRH agonist) trigger, just before expected ovulation would occur. This ensures oocytes are mature (MII) but still within the follicles."}, "mcq-055": {"correct": "Inhibition of ovulation", "selected": "Inhibition of ovulation", "isCorrect": true, "explanation": "The primary mechanism of combined oral contraceptives is suppression of the hypothalamic-pituitary-ovarian axis, preventing the LH surge and thus inhibiting ovulation. Secondary mechanisms include thickening cervical mucus and thinning the endometrium."}, "mcq-056": {"correct": "Chlamydia and Gonorrhea", "selected": "Chlamydia and Gonorrhea", "isCorrect": true, "explanation": "Chlamydia trachomatis and Neisseria gonorrhoeae are the most commonly identified causative organisms of PID, though polymicrobial infections are common. BV-associated organisms and anaerobes also contribute."}, "mcq-057": {"correct": "Cervical motion tenderness", "selected": "Cervical motion tenderness", "isCorrect": true, "explanation": "CDC recommends empiric treatment for PID when cervical motion tenderness OR uterine tenderness OR adnexal tenderness is present in a sexually active young woman with no other cause identified. Waiting for cultures delays treatment."}, "mcq-059": {"correct": "Menopause", "selected": "Menarche", "isCorrect": false, "explanation": "Fibroids are hormone-dependent tumors that typically shrink after menopause due to the decline in estrogen and progesterone. This is why GnRH agonists (which create a hypoestrogenic state) can shrink fibroids pre-surgically."}, "mcq-060": {"correct": "110-160 bpm", "selected": "110-160 bpm", "isCorrect": true, "explanation": "Normal FHR baseline is 110-160 bpm. Baseline <110 is bradycardia, >160 is tachycardia. Baseline is determined over a 10-minute window, excluding accelerations, decelerations, and periods of marked variability."}}	2026-02-22 13:45:14.633385
b7ff0710-5b2c-4bae-9965-afb14d1d57a4	demo-user-001	\N	topic	80	5	4	1	200	[{"mcqId": "mcq-021", "isCorrect": true, "selectedAnswer": "Polyp"}, {"mcqId": "mcq-022", "isCorrect": true, "selectedAnswer": "≥45 years"}, {"mcqId": "mcq-023", "isCorrect": true, "selectedAnswer": "LNG-IUS (Mirena)"}, {"mcqId": "mcq-024", "isCorrect": true, "selectedAnswer": "Coagulopathy"}, {"mcqId": "mcq-025", "isCorrect": false, "selectedAnswer": "Inhibiting prostaglandins"}]	2026-02-05 11:26:55.219682
772f45dc-98b3-4c1c-b17b-646574dd904a	demo-user-001	\N	topic	60	5	3	2	300	[{"mcqId": "mcq-036", "isCorrect": true, "selectedAnswer": "2 of 3"}, {"mcqId": "mcq-037", "isCorrect": false, "selectedAnswer": "Clomiphene citrate"}, {"mcqId": "mcq-038", "isCorrect": true, "selectedAnswer": "50-70%"}, {"mcqId": "mcq-039", "isCorrect": true, "selectedAnswer": "5-10%"}, {"mcqId": "mcq-040", "isCorrect": false, "selectedAnswer": "Ovarian cancer"}]	2026-02-07 05:26:55.219682
0e526486-04b1-4b6c-bd57-170c12274faa	demo-user-001	\N	topic	100	5	5	0	150	[{"mcqId": "mcq-011", "isCorrect": true, "selectedAnswer": "BP ≥160/110 or end-organ dysfunction"}, {"mcqId": "mcq-012", "isCorrect": true, "selectedAnswer": "Delivery"}, {"mcqId": "mcq-013", "isCorrect": true, "selectedAnswer": "Leukocytosis"}, {"mcqId": "mcq-014", "isCorrect": true, "selectedAnswer": "≥34 weeks"}, {"mcqId": "mcq-015", "isCorrect": true, "selectedAnswer": "4-6 g IV"}]	2026-02-04 11:26:55.219682
eb5579b1-5795-4866-8295-f2d808d8a557	51268d4e-a5cf-4e92-948c-0c708d200d48	\N	topic	33	3	1	2	0	{"mcq-046": {"correct": "Painless bright red bleeding", "selected": "Painless bright red bleeding", "isCorrect": true, "explanation": "Placenta previa classically presents with painless, bright red vaginal bleeding in the late second or third trimester. Unlike abruption, there is no uterine tenderness or contractions."}, "mcq-047": {"correct": "Absolutely contraindicated", "selected": "Recommended for diagnosis", "isCorrect": false, "explanation": "Digital vaginal examination is absolutely contraindicated in suspected placenta previa as it may disrupt the placenta and cause catastrophic hemorrhage. Diagnosis is made by transabdominal and transvaginal ultrasound."}, "mcq-048": {"correct": "Cesarean section at 36-37 weeks", "selected": "Vaginal delivery at 39 weeks", "isCorrect": false, "explanation": "Complete (total) placenta previa requires planned cesarean delivery at 36-37 weeks (after confirming fetal lung maturity or administering corticosteroids). Earlier delivery if bleeding is uncontrollable."}}	2026-02-24 14:31:20.394134
8c136401-0752-48c1-bd40-1e36af9eacbb	61bd4894-7aa4-437b-bcb2-285bdc034994	\N	topic	67	3	2	1	0	{"mcq-046": {"correct": "B", "selected": "B", "isCorrect": true, "correctText": "Painless bright red bleeding", "explanation": "Placenta previa classically presents with painless, bright red vaginal bleeding in the late second or third trimester. Unlike abruption, there is no uterine tenderness or contractions.", "selectedText": "Painless bright red bleeding"}, "mcq-047": {"correct": "B", "selected": "C", "isCorrect": false, "correctText": "Absolutely contraindicated", "explanation": "Digital vaginal examination is absolutely contraindicated in suspected placenta previa as it may disrupt the placenta and cause catastrophic hemorrhage. Diagnosis is made by transabdominal and transvaginal ultrasound.", "selectedText": "Optional"}, "mcq-048": {"correct": "B", "selected": "B", "isCorrect": true, "correctText": "Cesarean section at 36-37 weeks", "explanation": "Complete (total) placenta previa requires planned cesarean delivery at 36-37 weeks (after confirming fetal lung maturity or administering corticosteroids). Earlier delivery if bleeding is uncontrollable.", "selectedText": "Cesarean section at 36-37 weeks"}}	2026-02-25 13:07:20.959254
f3dc7e88-1712-4e53-8281-fb263b0d35a6	demo-user-001	\N	topic	80	5	4	1	180	[{"mcqId": "mcq-001", "isCorrect": true, "selectedAnswer": "Ampulla of the fallopian tube"}, {"mcqId": "mcq-002", "isCorrect": true, "selectedAnswer": "Day 6-7"}, {"mcqId": "mcq-003", "isCorrect": true, "selectedAnswer": "Prevents polyspermy"}, {"mcqId": "mcq-004", "isCorrect": true, "selectedAnswer": "hCG"}, {"mcqId": "mcq-005", "isCorrect": false, "selectedAnswer": "Ovary"}]	2026-01-31 11:26:55.219682
a24443b0-022d-4ce4-8afd-5228818e150e	demo-user-001	\N	topic	60	5	3	2	240	[{"mcqId": "mcq-006", "isCorrect": true, "selectedAnswer": "30-50%"}, {"mcqId": "mcq-007", "isCorrect": true, "selectedAnswer": "30 mmHg"}, {"mcqId": "mcq-008", "isCorrect": false, "selectedAnswer": "Normal renal function"}, {"mcqId": "mcq-009", "isCorrect": true, "selectedAnswer": "Increased protein C"}, {"mcqId": "mcq-010", "isCorrect": false, "selectedAnswer": "Iron deficiency"}]	2026-02-01 11:26:55.219682
21040e54-90d4-4360-be0e-7902cc175430	61bd4894-7aa4-437b-bcb2-285bdc034994	\N	topic	60	5	3	2	0	{"mcq-026": {"correct": "B", "selected": "B", "isCorrect": true, "correctText": "Types 16 and 18", "explanation": "HPV types 16 and 18 are high-risk oncogenic types responsible for approximately 70% of all cervical cancers. Types 6 and 11 cause genital warts (low-risk).", "selectedText": "Types 16 and 18"}, "mcq-027": {"correct": "B", "selected": "B", "isCorrect": true, "correctText": "21", "explanation": "ACOG/ASCCP guidelines recommend starting cervical cancer screening at age 21 with Pap smear, regardless of age of sexual debut. Starting earlier may lead to unnecessary procedures.", "selectedText": "21"}, "mcq-028": {"correct": "B", "selected": "B", "isCorrect": true, "correctText": "p53", "explanation": "HPV E6 protein binds to and promotes degradation of p53 via ubiquitin pathway. HPV E7 protein inactivates Rb. Together, these disable cell cycle checkpoints allowing uncontrolled proliferation.", "selectedText": "p53"}, "mcq-029": {"correct": "C", "selected": "B", "isCorrect": false, "correctText": "Chemoradiation", "explanation": "Stage IB2-IIA (bulky tumors >4 cm) are treated with concurrent chemoradiation (cisplatin-based chemotherapy with external beam radiation + brachytherapy). This has shown superior outcomes compared to radiation alone.", "selectedText": "Simple hysterectomy"}, "mcq-030": {"correct": "D", "selected": "B", "isCorrect": false, "correctText": "9", "explanation": "Gardasil-9 is the 9-valent HPV vaccine covering types 6, 11 (warts), 16, 18, 31, 33, 45, 52, and 58 (cancer-causing). It prevents ~90% of cervical cancers.", "selectedText": "4"}}	2026-02-25 15:34:28.230662
3fc0cf9e-9c68-4583-9ff1-f6cb4dbf0f55	51268d4e-a5cf-4e92-948c-0c708d200d48	\N	topic	20	5	1	4	0	{"mcq-006": {"correct": "30-50%", "selected": "100%", "isCorrect": false, "explanation": "Cardiac output increases by 30-50% during pregnancy, peaking at 28-32 weeks, due to increased stroke volume and heart rate."}, "mcq-007": {"correct": "30 mmHg", "selected": "40 mmHg", "isCorrect": false, "explanation": "Pregnancy causes a compensated respiratory alkalosis with PaCO2 ~30 mmHg due to progesterone-stimulated hyperventilation (increased tidal volume)."}, "mcq-008": {"correct": "Renal impairment", "selected": "Normal renal function", "isCorrect": false, "explanation": "Due to the 50% increase in GFR during pregnancy, normal serum creatinine drops to 0.5-0.8 mg/dL. A value of 1.0 mg/dL, while normal in non-pregnant women, suggests renal impairment in pregnancy."}, "mcq-009": {"correct": "Increased protein C", "selected": "Increased protein C", "isCorrect": true, "explanation": "Protein C levels remain relatively unchanged in pregnancy. Protein S decreases, fibrinogen increases, and there is a physiological leukocytosis — all contributing to the hypercoagulable state."}, "mcq-010": {"correct": "Hemodilution", "selected": "Folic acid deficiency", "isCorrect": false, "explanation": "Plasma volume increases by 50% while red cell mass increases by only 25-30%, resulting in a dilutional decrease in hemoglobin concentration (physiological anemia)."}}	2026-02-22 13:44:24.264295
88ccecd3-d5dd-4e35-9ebb-d336bffcc758	61bd4894-7aa4-437b-bcb2-285bdc034994	\N	topic	40	5	2	3	0	{"mcq-006": {"correct": "B", "selected": "B", "isCorrect": true, "correctText": "30-50%", "explanation": "Cardiac output increases by 30-50% during pregnancy, peaking at 28-32 weeks, due to increased stroke volume and heart rate.", "selectedText": "30-50%"}, "mcq-007": {"correct": "C", "selected": "B", "isCorrect": false, "correctText": "30 mmHg", "explanation": "Pregnancy causes a compensated respiratory alkalosis with PaCO2 ~30 mmHg due to progesterone-stimulated hyperventilation (increased tidal volume).", "selectedText": "35 mmHg"}, "mcq-008": {"correct": "B", "selected": "B", "isCorrect": true, "correctText": "Renal impairment", "explanation": "Due to the 50% increase in GFR during pregnancy, normal serum creatinine drops to 0.5-0.8 mg/dL. A value of 1.0 mg/dL, while normal in non-pregnant women, suggests renal impairment in pregnancy.", "selectedText": "Renal impairment"}, "mcq-009": {"correct": "C", "selected": "B", "isCorrect": false, "correctText": "Increased protein C", "explanation": "Protein C levels remain relatively unchanged in pregnancy. Protein S decreases, fibrinogen increases, and there is a physiological leukocytosis — all contributing to the hypercoagulable state.", "selectedText": "Decreased protein S"}, "mcq-010": {"correct": "B", "selected": "A", "isCorrect": false, "correctText": "Hemodilution", "explanation": "Plasma volume increases by 50% while red cell mass increases by only 25-30%, resulting in a dilutional decrease in hemoglobin concentration (physiological anemia).", "selectedText": "Iron deficiency"}}	2026-02-25 13:07:47.857163
\.


--
-- Data for Name: recent_activity; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.recent_activity (id, user_id, topic_id, viewed_at) FROM stdin;
fc3bf2d8-d0a1-4ce0-ac68-b7381d20a3df	8285d5db-4b8a-4dc7-81a2-091bd1ae4488	631e8033-60a7-46e8-8aac-713aad3674c8	2026-05-15 12:05:32.483498
4de6274c-873a-42c4-84fd-ee357e3f8739	7f79450a-4fa6-4b62-ad06-ca377f583d83	de882ed5-4ae9-43a0-b80d-d51aae5f6a97	2026-05-06 05:01:23.343
bc07d5c2-b103-43f4-8303-e3a857ee72b4	1c8e320e-a700-466a-a555-3023fd1bfa4a	631e8033-60a7-46e8-8aac-713aad3674c8	2026-05-15 12:16:27.52921
e2282fde-ac24-45b2-89f0-b062265cca4b	7f79450a-4fa6-4b62-ad06-ca377f583d83	631e8033-60a7-46e8-8aac-713aad3674c8	2026-05-06 05:01:50.499
4fd4d0ec-e813-49db-b5e4-3c9338812eba	8285d5db-4b8a-4dc7-81a2-091bd1ae4488	1ec05f17-3698-4528-b414-f33f8f9e0c2b	2026-05-15 13:01:43.29978
aa092c0e-d970-454c-bbe2-9679ba145f24	8285d5db-4b8a-4dc7-81a2-091bd1ae4488	dce6694e-93b3-4281-b546-8cb995c03b1d	2026-05-15 13:02:04.172
b2c6b934-007f-4ab8-b0a8-b41ee6978827	8285d5db-4b8a-4dc7-81a2-091bd1ae4488	de882ed5-4ae9-43a0-b80d-d51aae5f6a97	2026-05-15 13:02:18.008081
e43f50a6-c488-4aba-9e65-8fe917da8f44	735bdeea-5488-4e95-8e28-b1a6bc9f182c	dce6694e-93b3-4281-b546-8cb995c03b1d	2026-05-21 07:22:01.317713
d8073375-7d57-4302-aec0-dc5d22589db9	735bdeea-5488-4e95-8e28-b1a6bc9f182c	126fe5cf-71e2-4469-8a89-2bf0498f7cc5	2026-05-21 07:22:16.42026
deb76855-e70a-4fc5-a3e7-31b0c41ed7c2	735bdeea-5488-4e95-8e28-b1a6bc9f182c	c7578a7b-6acb-48bb-a9f7-9c54c8f23e20	2026-05-21 07:22:27.212059
5e2c1a7d-a087-4860-adb3-c06b03220283	61bd4894-7aa4-437b-bcb2-285bdc034994	dce6694e-93b3-4281-b546-8cb995c03b1d	2026-05-24 17:43:18.299
3464fe05-3a15-4766-9e96-fa148e3b37c3	61bd4894-7aa4-437b-bcb2-285bdc034994	de882ed5-4ae9-43a0-b80d-d51aae5f6a97	2026-05-24 17:43:41.522
3c956721-2971-4461-9470-bbdbd3ab559b	61bd4894-7aa4-437b-bcb2-285bdc034994	1ec05f17-3698-4528-b414-f33f8f9e0c2b	2026-05-24 17:50:02.512
8782f9be-2b58-45ee-93b5-ee13ecd5167f	61bd4894-7aa4-437b-bcb2-285bdc034994	c7e89b30-8c2c-480e-ad57-b3cbf17f4f46	2026-05-27 07:02:32.590737
77591cc0-2e51-4ce9-b3c9-8e5bb3c55e9c	61bd4894-7aa4-437b-bcb2-285bdc034994	ac9ca58f-c1fd-41c9-b22b-f2bccc750897	2026-05-27 07:02:49.783088
a89f3df3-a0f5-4999-951d-293872c5b453	61bd4894-7aa4-437b-bcb2-285bdc034994	51b95cd6-d5df-4ff6-acdd-8e9ebbee28e5	2026-05-29 08:51:48.904
b1a06ada-3f2d-4cf9-8912-a741ae5237da	61bd4894-7aa4-437b-bcb2-285bdc034994	9b5ca856-c888-487c-bf5e-0a5f4fa0652e	2026-05-29 14:04:36.277975
e95bac04-9778-4c75-a6f1-1ee807fd78a5	61bd4894-7aa4-437b-bcb2-285bdc034994	025e984c-0ed5-46c5-8825-99318063c146	2026-05-29 14:04:45.533
74c896e8-caa5-4b96-8d0a-53893df5fb9e	demo-user-001	340afd9c-033b-4ef4-ad27-fe5bbcfc19d7	2026-05-29 19:32:11.714321
64dfb6ac-f767-4e01-a858-8eb6197a2103	demo-user-001	b0a2a729-9dcf-4b84-a987-e361f78d59c0	2026-05-29 19:32:17.571502
d192a048-b969-4b8b-a8ad-3fe9c1626cc3	demo-user-001	096b7cdc-b92c-4118-81fb-eaea8d5bc526	2026-05-29 19:32:20.850185
3eabff08-aba1-475a-b6ee-477114d8315f	51268d4e-a5cf-4e92-948c-0c708d200d48	52c2375a-221f-40db-be86-b66990fdd20a	2026-03-05 09:53:14.184
3ae68e84-f830-4302-9fe2-cea5b10e2773	demo-user-001	56cd36b6-ca5e-4279-936a-59303b867db5	2026-05-29 19:37:14.694589
69d1f9e7-86bd-45d4-af59-bceb440b4ff7	e48a1d49-0a19-4f78-bb27-e8f26279052c	6f36db59-1cc0-4586-8c6a-1c8bb00a8e0c	2026-05-09 17:00:54.062
38df7f33-5865-4c72-9c4a-53861f72bbf2	e48a1d49-0a19-4f78-bb27-e8f26279052c	126fe5cf-71e2-4469-8a89-2bf0498f7cc5	2026-05-09 17:01:43.613419
37bc07e1-8c03-4aad-a82b-9e6e5b4ef696	51268d4e-a5cf-4e92-948c-0c708d200d48	dce6694e-93b3-4281-b546-8cb995c03b1d	2026-03-05 09:55:46.192
02d96f44-a461-480c-9cb2-52fe2bce6b70	51268d4e-a5cf-4e92-948c-0c708d200d48	025e984c-0ed5-46c5-8825-99318063c146	2026-03-05 10:28:07.055
ae2934eb-e381-4615-b67e-91dd70e5b0b9	e48a1d49-0a19-4f78-bb27-e8f26279052c	1ec05f17-3698-4528-b414-f33f8f9e0c2b	2026-05-09 17:04:18.767
539331dd-81ee-40ef-b82e-089f31a563b8	e48a1d49-0a19-4f78-bb27-e8f26279052c	c7578a7b-6acb-48bb-a9f7-9c54c8f23e20	2026-05-09 17:04:51.593
29fdc581-a655-4b66-8528-f5d5a55af4fd	e48a1d49-0a19-4f78-bb27-e8f26279052c	025e984c-0ed5-46c5-8825-99318063c146	2026-05-09 17:05:02.543
04f77a20-292b-4337-9a25-03a0f47de2c8	e48a1d49-0a19-4f78-bb27-e8f26279052c	de882ed5-4ae9-43a0-b80d-d51aae5f6a97	2026-05-09 17:05:12.337
bf59a099-3ffd-4c17-b933-caa719ad0340	e48a1d49-0a19-4f78-bb27-e8f26279052c	dce6694e-93b3-4281-b546-8cb995c03b1d	2026-05-09 17:05:21.615
89a1b793-78ab-46d4-bd3b-dc52df5e10a8	e48a1d49-0a19-4f78-bb27-e8f26279052c	dc104b3f-ed6a-4f1f-8046-73c069161cb6	2026-05-09 17:06:08.961
c71bb56e-5381-4951-a191-3a80da1ca87f	7f79450a-4fa6-4b62-ad06-ca377f583d83	dc104b3f-ed6a-4f1f-8046-73c069161cb6	2026-05-10 06:37:43.656
52f8e511-e0b7-45fa-86f8-7ebd97b1037b	7f79450a-4fa6-4b62-ad06-ca377f583d83	dce6694e-93b3-4281-b546-8cb995c03b1d	2026-05-10 06:40:01.155
ca0976ee-6fda-4356-9117-00a832d366cd	61bd4894-7aa4-437b-bcb2-285bdc034994	126fe5cf-71e2-4469-8a89-2bf0498f7cc5	2026-03-20 05:40:25.72
4a225e89-4c01-47f2-8b9c-fbbd6ee9feab	61bd4894-7aa4-437b-bcb2-285bdc034994	6f36db59-1cc0-4586-8c6a-1c8bb00a8e0c	2026-03-20 05:40:53.489
87a251b5-5001-4435-97f3-b74ce2974eb3	7f79450a-4fa6-4b62-ad06-ca377f583d83	126fe5cf-71e2-4469-8a89-2bf0498f7cc5	2026-05-13 04:01:07.599
f05f4ea9-fb10-44ed-bd59-b0a1d1cdff73	51268d4e-a5cf-4e92-948c-0c708d200d48	c7578a7b-6acb-48bb-a9f7-9c54c8f23e20	2026-04-16 15:09:31.598
ab3ab6b4-f7d0-4808-8837-087724e5cecc	51268d4e-a5cf-4e92-948c-0c708d200d48	de882ed5-4ae9-43a0-b80d-d51aae5f6a97	2026-04-16 15:11:01.618
51353cc3-f3ce-4985-a211-d734b862669f	7f79450a-4fa6-4b62-ad06-ca377f583d83	6f36db59-1cc0-4586-8c6a-1c8bb00a8e0c	2026-05-13 14:31:48.711
4c2a8e93-0132-401c-8a16-e7069f0a1ca5	473e5d03-a90f-4573-8eda-3c1e36c2951d	52c2375a-221f-40db-be86-b66990fdd20a	2026-04-17 17:33:39.327
aeab9ecb-3a0a-4059-a2be-0721a5f301c4	7f79450a-4fa6-4b62-ad06-ca377f583d83	1ec05f17-3698-4528-b414-f33f8f9e0c2b	2026-05-14 06:02:45.491
9a3b22d0-d844-40ec-bec4-9b77dc690433	5d13b898-19a9-4d4d-9cd0-d0fd7d5d5746	631e8033-60a7-46e8-8aac-713aad3674c8	2026-05-03 04:42:43.706
b46c9bef-9698-4a92-95a5-0794d50e1dad	7f79450a-4fa6-4b62-ad06-ca377f583d83	025e984c-0ed5-46c5-8825-99318063c146	2026-05-04 08:16:52.724
6dca6bbe-873c-4b33-8c41-6252b2c680f9	7f79450a-4fa6-4b62-ad06-ca377f583d83	52c2375a-221f-40db-be86-b66990fdd20a	2026-05-05 04:16:54.179
1f291f17-6f11-43d6-8cc5-68d8a07f7362	7f79450a-4fa6-4b62-ad06-ca377f583d83	c7578a7b-6acb-48bb-a9f7-9c54c8f23e20	2026-05-05 04:17:38.991
899e8155-4fc6-4a91-bfc0-df6ad67dcec2	51268d4e-a5cf-4e92-948c-0c708d200d48	15c1919a-8a04-48ae-aa30-3f131d9fea90	2026-05-31 14:54:14.702185
594747ac-80b4-447b-9738-bef60821fde4	51268d4e-a5cf-4e92-948c-0c708d200d48	126fe5cf-71e2-4469-8a89-2bf0498f7cc5	2026-05-31 14:54:19.104
c299c110-24ba-4482-9adc-7e7195d21243	51268d4e-a5cf-4e92-948c-0c708d200d48	009da997-ea38-448c-b043-ff3aefbbbeeb	2026-05-31 14:55:52.152513
bbd6e6be-0206-4fa2-9560-979bf071ce31	61bd4894-7aa4-437b-bcb2-285bdc034994	4d4ecf5d-7535-46ca-b9ff-8f4b19de7353	2026-06-02 03:16:06.956
4f752d30-ea00-4181-afd3-721398afcade	61bd4894-7aa4-437b-bcb2-285bdc034994	dc104b3f-ed6a-4f1f-8046-73c069161cb6	2026-06-02 03:18:54.269
ae7354dd-f6b1-4b34-9652-b39c6d5f1208	61bd4894-7aa4-437b-bcb2-285bdc034994	631e8033-60a7-46e8-8aac-713aad3674c8	2026-06-06 02:49:48.61
4961b9f2-f5e6-445a-a21d-f9f5a0254e3b	61bd4894-7aa4-437b-bcb2-285bdc034994	c7578a7b-6acb-48bb-a9f7-9c54c8f23e20	2026-06-15 13:20:45.315
29ada509-1885-4a35-b2dd-d6000252d9e2	61bd4894-7aa4-437b-bcb2-285bdc034994	52c2375a-221f-40db-be86-b66990fdd20a	2026-06-01 16:41:58.526
c246722c-9bd9-4abd-9a53-7148a62c5d48	61bd4894-7aa4-437b-bcb2-285bdc034994	250ccdc2-184d-4bfe-b1f8-ebd98ae9f550	2026-06-01 16:43:01.198389
839651fe-e51e-4810-ad88-6495e7268c96	61bd4894-7aa4-437b-bcb2-285bdc034994	451cca65-ae17-4959-bfd9-043a725fa698	2026-06-02 03:13:15.6773
1095eb8b-285d-4b7c-ab22-a9a8e2418f85	61bd4894-7aa4-437b-bcb2-285bdc034994	259577e9-5acd-4b6b-99a6-21ec4c50b261	2026-06-02 03:14:14.107553
3b1a4ba7-43cb-4a84-be4b-fa9b473252a4	61bd4894-7aa4-437b-bcb2-285bdc034994	7fed75f0-8cf4-4815-ac45-ba31b34bd30f	2026-06-02 03:14:22.160331
e2d14795-08b4-478a-a49e-44b350ed6d99	61bd4894-7aa4-437b-bcb2-285bdc034994	5781eae1-5283-4b6e-8153-2313e29501a6	2026-06-02 03:17:05.611114
00e4401c-1156-4429-aec5-2173ae4c1586	61bd4894-7aa4-437b-bcb2-285bdc034994	594220af-32d7-4d00-98ad-a2c733d4be33	2026-06-02 03:17:24.746
35a3eb6d-d495-4adb-8cb4-267ed34f8ca3	51268d4e-a5cf-4e92-948c-0c708d200d48	51b95cd6-d5df-4ff6-acdd-8e9ebbee28e5	2026-06-04 10:06:53.153502
cf0e4438-6ad5-4d7a-9931-fc4f71538464	51268d4e-a5cf-4e92-948c-0c708d200d48	699010a2-e498-4e40-a2a7-9cd5dc2076c0	2026-06-04 10:29:02.051
88a42f90-bd56-496a-ba9b-485831dbbe3e	51268d4e-a5cf-4e92-948c-0c708d200d48	4d4ecf5d-7535-46ca-b9ff-8f4b19de7353	2026-06-04 10:29:11.328
b0d6cc45-13d3-4cec-b188-6a3c55a0aa65	61bd4894-7aa4-437b-bcb2-285bdc034994	ebad03aa-d0cc-4cd6-a66b-6d90073459aa	2026-06-06 02:49:43.816504
63e50c95-0051-4627-ad57-62598fb7604b	61bd4894-7aa4-437b-bcb2-285bdc034994	358587df-8f59-4495-9488-56031c7dbed1	2026-06-15 14:00:09.302
62f86c0c-67c1-4b97-ab65-500d4354b34c	51268d4e-a5cf-4e92-948c-0c708d200d48	62eb7bb2-f22a-469e-9a1c-668f4bd38122	2026-06-16 17:12:32.44
45da4fbe-0600-4618-b993-2fd4bd2fd44c	51268d4e-a5cf-4e92-948c-0c708d200d48	c293f92b-c305-42f4-b986-2dd110fdd68e	2026-06-16 17:12:44.329394
83100f1c-7c72-40b8-863d-c5d0bc65a880	51268d4e-a5cf-4e92-948c-0c708d200d48	33c1071b-5ae8-4cd4-88aa-eb02042d7f19	2026-06-16 17:16:22.903
1d284c58-b2b2-4027-9cb5-4ae0bc74b8b4	61bd4894-7aa4-437b-bcb2-285bdc034994	9ffb1679-4328-47c6-b6c8-df01cc2337ed	2026-06-23 06:42:56.184
c89d4106-38ec-419f-9ef4-755c0fd3ef8e	61bd4894-7aa4-437b-bcb2-285bdc034994	20944d53-c138-45a9-a769-c48bd4229f0f	2026-06-23 06:42:58.468
10dbfbe0-c65f-4d29-adb7-ba0296c97ca9	61bd4894-7aa4-437b-bcb2-285bdc034994	ae07ff0d-4682-4df5-bd7d-f6067bd7b664	2026-06-23 19:39:34.616903
2978aa89-8c97-4977-a758-3c4f33e8f62d	51268d4e-a5cf-4e92-948c-0c708d200d48	8ce2600e-2961-4eb5-8f96-319235e03173	2026-07-05 19:11:29.26715
8797d3d0-219b-496d-a8d5-1f8ed2d8abbb	51268d4e-a5cf-4e92-948c-0c708d200d48	250ccdc2-184d-4bfe-b1f8-ebd98ae9f550	2026-07-05 19:14:37.424
\.


--
-- Data for Name: review_schedule; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.review_schedule (id, user_id, mcq_id, ease_factor, "interval", repetitions, next_review_at, last_reviewed_at, created_at) FROM stdin;
\.


--
-- Data for Name: scratch_code_batches; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.scratch_code_batches (id, prefix, book_id, duration_days, total_codes, description, is_active, created_by, created_at) FROM stdin;
\.


--
-- Data for Name: scratch_codes; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.scratch_codes (id, batch_id, code, status, redeemed_by, redeemed_at, created_at) FROM stdin;
\.


--
-- Data for Name: subscription_add_ons; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.subscription_add_ons (id, subscription_id, add_on_id, quantity, price_at_purchase, is_active, activated_at, canceled_at, created_at) FROM stdin;
\.


--
-- Data for Name: subscription_audit_logs; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.subscription_audit_logs (id, subscription_id, user_id, performed_by, action, previous_status, new_status, details, source, ip_address, created_at) FROM stdin;
c24085bd-7206-44d3-a15f-b5c1f6cd5910	aaab5980-50fa-46a9-a489-3acca5789a85	demo-user-001	demo-user-001	created	\N	trialing	{"hasTrial": true, "trialDays": 7, "packageName": "Premium Plan", "billingCycle": "monthly", "priceAtPurchase": "4.99"}	api	\N	2026-04-16 17:57:12.617247
9073049e-9b9a-438d-8c02-575ee2eab01b	aaab5980-50fa-46a9-a489-3acca5789a85	demo-user-001	\N	canceled	trialing	trialing	{"reason": "Testing cancel flow", "immediate": false, "effectiveAt": "2026-05-23T17:57:12.589Z"}	api	\N	2026-04-16 17:57:13.43433
81936048-8a04-414a-849b-7d514603d181	22826204-3778-49da-883a-feb5844d2263	61bd4894-7aa4-437b-bcb2-285bdc034994	demo-user-001	created	\N	trialing	{"hasTrial": true, "trialDays": 14, "packageName": "1 Year Plan", "billingCycle": "monthly", "priceAtPurchase": "9.99"}	admin	\N	2026-06-29 12:41:05.263206
6d89beeb-1cdf-4573-82a5-1d7a347dd95f	aaab5980-50fa-46a9-a489-3acca5789a85	demo-user-001	\N	expired	trialing	expired	{"note": "Manual backfill: subscription had lapsed by current_period_end but was never auto-expired (no periodic expiry job existed). Applied to match the new expiry-aware getUserActiveSubscription self-heal logic.", "gracePeriodEndAt": "2026-07-08 17:16:44.55041+00"}	system	\N	2026-07-05 17:16:44.55041
\.


--
-- Data for Name: subscription_packages; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.subscription_packages (id, name, slug, description, short_description, icon_url, status, is_visible_to_users, display_order, trial_days, trial_requires_payment_method, grace_period_days, max_subscribers, version, metadata, revenuecat_product_id, created_at, updated_at) FROM stdin;
51e5ce4b-df65-4436-a138-cea54f736e38	3 Months Plan	3-months-plan	3 Months Plan	\N	\N	active	t	0	0	f	0	0	1	\N	\N	2026-04-16 17:12:44.221389	2026-06-25 21:10:31.886
c2456081-c883-4fa2-99dc-c4d0dfeb8229	6 Months Plan	6-months-plan	6 Months Plan	\N	\N	active	t	1	7	f	3	0	2	\N	\N	2026-04-16 17:12:44.283363	2026-06-25 21:11:23.014
153871ff-16c9-4c1a-a2b0-1606fa830750	1 Year Plan	1-year-plan	1 Year Plan	\N	\N	active	t	5	14	f	5	0	3	\N	\N	2026-04-16 17:56:36.363541	2026-06-25 21:12:09.086
\.


--
-- Data for Name: subscriptions; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.subscriptions (id, user_id, package_id, price_id, status, trial_start_at, trial_end_at, activated_at, current_period_start, current_period_end, canceled_at, cancel_reason, cancel_at_period_end, paused_at, resumed_at, expired_at, grace_period_end_at, failed_payment_count, last_payment_failed_at, next_retry_at, billing_cycle, price_at_purchase, currency, coupon_id, discount_amount, external_subscription_id, payment_gateway, package_version_at_purchase, metadata, created_at, updated_at) FROM stdin;
22826204-3778-49da-883a-feb5844d2263	61bd4894-7aa4-437b-bcb2-285bdc034994	153871ff-16c9-4c1a-a2b0-1606fa830750	ee8dd8d3-3632-4888-9e89-164abd754b77	trialing	2026-06-29 12:41:05.131	2026-07-13 12:41:05.131	\N	2026-07-13 12:41:05.131	2026-08-12 12:41:05.131	\N	\N	t	\N	\N	\N	\N	0	\N	\N	monthly	9.99	PKR	\N	\N	\N	manual	3	\N	2026-06-29 12:41:05.134894	2026-06-29 12:41:05.134894
aaab5980-50fa-46a9-a489-3acca5789a85	demo-user-001	c2456081-c883-4fa2-99dc-c4d0dfeb8229	cfcd8ece-74f4-4634-9e7d-f50d77b04380	expired	2026-04-16 17:57:12.589	2026-04-23 17:57:12.589	\N	2026-04-23 17:57:12.589	2026-05-23 17:57:12.589	2026-04-16 17:57:13.42	Testing cancel flow	t	\N	\N	2026-07-05 17:16:44.55041	2026-07-08 17:16:44.55041	0	\N	\N	monthly	4.99	PKR	\N	\N	\N	revenuecat	2	\N	2026-04-16 17:57:12.592698	2026-07-05 17:16:44.55041
\.


--
-- Data for Name: topics; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.topics (id, chapter_id, title, description, "order", is_published, author, source, "references", last_reviewed_at, created_at, updated_at) FROM stdin;
92b5ee8b-32bf-4ab1-ab61-b1df07b92017	a326891f-f3d2-4e76-b1ae-5b0064dea77e	Types of incontinence		0	t		\N	\N	\N	2026-05-25 06:53:38.230287	2026-05-25 06:59:31.868
56cd36b6-ca5e-4279-936a-59303b867db5	a326891f-f3d2-4e76-b1ae-5b0064dea77e	Over active bladder		1	t		\N	\N	\N	2026-05-25 06:54:05.188208	2026-05-25 06:59:32.337
d5701748-bc01-4636-be5c-6337cabf92ad	a326891f-f3d2-4e76-b1ae-5b0064dea77e	Sensory urgency 		2	t		\N	\N	\N	2026-05-25 06:54:53.929664	2026-05-25 06:59:33.203
025e984c-0ed5-46c5-8825-99318063c146	dbec251c-b50c-408b-85ca-5a92d99980ed	UTERINE ARTERY EMBOLIZATION		2	t		\N	\N	\N	2026-03-04 09:40:27.015978	2026-03-04 09:51:15.505
126fe5cf-71e2-4469-8a89-2bf0498f7cc5	dbec251c-b50c-408b-85ca-5a92d99980ed	HRT AFTER GYNAECOLOGICAL MALIGNANCY		6	t		\N	\N	\N	2026-03-05 07:57:31.332804	2026-03-05 09:06:20.438
1ec05f17-3698-4528-b414-f33f8f9e0c2b	dbec251c-b50c-408b-85ca-5a92d99980ed	CHRONIC PELVIC PAIN		8	t		\N	\N	\N	2026-03-05 08:59:11.895983	2026-03-05 09:06:24.575
096b7cdc-b92c-4118-81fb-eaea8d5bc526	b108a79f-5d9c-4839-9074-3534616914a4	Ovarian cyst in post menopausal women		3	t		\N	\N	\N	2026-05-25 06:46:17.217154	2026-05-25 06:52:35.18
52c2375a-221f-40db-be86-b66990fdd20a	dbec251c-b50c-408b-85ca-5a92d99980ed	HMB		0	t		\N	\N	\N	2026-03-03 07:16:38.237001	2026-05-24 17:40:52.624
631e8033-60a7-46e8-8aac-713aad3674c8	dbec251c-b50c-408b-85ca-5a92d99980ed	Menopause and management 		4	t		\N	\N	\N	2026-03-04 10:29:44.387663	2026-05-25 06:36:29.133
c293f92b-c305-42f4-b986-2dd110fdd68e	b3afd200-5f4f-49b1-a607-ae1abb2be1a7	Vaginal discharge 		0	t		\N	\N	\N	2026-05-25 07:00:51.543049	2026-05-25 07:24:59.384
4d4ecf5d-7535-46ca-b9ff-8f4b19de7353	b63ab97b-1ade-4083-b1be-be75c5f1ae67	Fertility problems , assessment and treatment 		0	t		\N	\N	\N	2026-05-25 06:38:15.724733	2026-05-25 06:43:45.701
8ab6127d-19ed-4463-9137-39aa09066ffb	b63ab97b-1ade-4083-b1be-be75c5f1ae67	Ovarian hyper stimulation syndrome 		9	t		\N	\N	\N	2026-05-25 06:43:27.491439	2026-05-25 06:43:56.198
fe2bfa7e-a245-4af1-9412-473ce84b6529	b63ab97b-1ade-4083-b1be-be75c5f1ae67	Endometriosis 		10	t		\N	\N	\N	2026-05-25 06:43:41.413859	2026-05-25 06:43:57.239
33c1071b-5ae8-4cd4-88aa-eb02042d7f19	b3afd200-5f4f-49b1-a607-ae1abb2be1a7	Genital infections and their treatment 		1	t		\N	\N	\N	2026-05-25 07:01:16.609456	2026-05-25 07:24:59.725
c3a8e5d9-562d-4135-bf83-3f34cecf365d	b3afd200-5f4f-49b1-a607-ae1abb2be1a7	Pelvic inflammatory disease		2	t		\N	\N	\N	2026-05-25 07:01:37.762876	2026-05-25 07:25:00.327
b680bc1d-ab12-46a8-9aae-585622199795	b3afd200-5f4f-49b1-a607-ae1abb2be1a7	Genital conditions and their management 		3	t		\N	\N	\N	2026-05-25 07:02:00.785146	2026-05-25 07:25:04.767
366627fc-eb8c-4d7d-af71-39a0a33abf28	b3afd200-5f4f-49b1-a607-ae1abb2be1a7	Anogenital warts		4	t		\N	\N	\N	2026-05-25 07:02:33.033523	2026-05-25 07:25:06.224
697f3290-8b41-42be-a3b1-6b03f11a7994	b3afd200-5f4f-49b1-a607-ae1abb2be1a7	Abortion clauses		5	t		\N	\N	\N	2026-05-25 07:02:53.354634	2026-05-25 07:25:07.213
c778b357-ffc3-4d34-9e2e-372aef90fee8	b3afd200-5f4f-49b1-a607-ae1abb2be1a7	UK Medical eligibility criteria UKMEC		6	t		\N	\N	\N	2026-05-25 07:03:26.888216	2026-05-25 07:25:08.428
e544276a-50cc-442e-a43a-5e90febca300	b3afd200-5f4f-49b1-a607-ae1abb2be1a7	Combined hormonal contraception		7	t		\N	\N	\N	2026-05-25 07:03:58.182935	2026-05-25 07:25:09.947
f79681ee-aa0a-4e81-a507-b97640de5aad	b3afd200-5f4f-49b1-a607-ae1abb2be1a7	Progesterone only pills		8	t		\N	\N	\N	2026-05-25 07:04:19.033064	2026-05-25 07:25:10.8
006062a0-1498-4d27-a636-d4c839ce668f	b3afd200-5f4f-49b1-a607-ae1abb2be1a7	Progesterone only injectable contraception 		9	t		\N	\N	\N	2026-05-25 07:04:55.298162	2026-05-25 07:25:12.554
4fbcd90e-d6d1-4d31-bcd3-2aa6188305f7	b108a79f-5d9c-4839-9074-3534616914a4	CA Endometrium		10	t		\N	\N	\N	2026-05-25 06:50:21.468823	2026-05-25 06:52:30.034
ed1f2732-e99d-4c85-b4ac-3f5088eec343	b108a79f-5d9c-4839-9074-3534616914a4	Endometrial hyperplasia 		9	t		\N	\N	\N	2026-05-25 06:49:53.609592	2026-05-25 06:52:30.668
0aad86d2-58c1-4310-8162-7b866d1157a6	b108a79f-5d9c-4839-9074-3534616914a4	Ovarian cancer		8	t		\N	\N	\N	2026-05-25 06:49:34.405855	2026-05-25 06:52:31.064
61bf142e-54a0-4575-985d-441a89305f45	b108a79f-5d9c-4839-9074-3534616914a4	Risk reducing surgery in women at risk of epithelial tumors		7	t		\N	\N	\N	2026-05-25 06:49:21.111306	2026-05-25 06:52:32.284
31f98154-6c8b-477c-b580-dd6fccdf9052	b108a79f-5d9c-4839-9074-3534616914a4	Ovarian masses in children and adolescents 		4	t		\N	\N	\N	2026-05-25 06:46:53.856177	2026-05-25 06:52:34.784
9c84da32-6d75-4182-907e-3825bc8bea9e	b108a79f-5d9c-4839-9074-3534616914a4	Suspected ovarian masses in pre menopausal women		2	t		\N	\N	\N	2026-05-25 06:45:42.065635	2026-05-25 06:52:37.722
f38932c9-6944-4977-8748-4bef336a81da	b108a79f-5d9c-4839-9074-3534616914a4	Ultrasound appearance of different cysts 		1	t		\N	\N	\N	2026-05-25 06:45:00.319897	2026-05-25 06:52:38.338
c57c867b-20a8-48c3-be7a-a309354e8e91	b108a79f-5d9c-4839-9074-3534616914a4	Tumor markers 		0	t		\N	\N	\N	2026-05-25 06:44:34.424688	2026-05-25 06:52:39.014
a16d3e81-af62-4b93-b434-18b6741d9e26	b3afd200-5f4f-49b1-a607-ae1abb2be1a7	Problematic bleeding with hormonal contraceptives 		13	t		\N	\N	\N	2026-05-25 07:08:21.717048	2026-05-25 07:25:19.013
62eb7bb2-f22a-469e-9a1c-668f4bd38122	b3afd200-5f4f-49b1-a607-ae1abb2be1a7	Barrier method of contraception 		14	t		\N	\N	\N	2026-05-25 07:08:48.359989	2026-05-25 07:25:20.31
47e51734-ae91-4b54-9a38-9b9ebbe0a63f	b3afd200-5f4f-49b1-a607-ae1abb2be1a7	Intrauterine contraception 		15	t		\N	\N	\N	2026-05-25 07:09:18.1128	2026-05-25 07:25:21.68
b1ea04fc-ddec-49af-9178-bc51a250338c	b3afd200-5f4f-49b1-a607-ae1abb2be1a7	Male and female sterilization 		16	t		\N	\N	\N	2026-05-25 07:09:55.959668	2026-05-25 07:25:23.149
016a1ed0-a333-4e84-946d-0e2779331f46	b3afd200-5f4f-49b1-a607-ae1abb2be1a7	Quick start contraception 		17	t		\N	\N	\N	2026-05-25 07:10:16.480231	2026-05-25 07:25:24.66
318f7429-4792-4bf8-a948-92d22ed71a32	b3afd200-5f4f-49b1-a607-ae1abb2be1a7	Contraception for young population 		19	t		\N	\N	\N	2026-05-25 07:13:07.768642	2026-05-25 07:25:27.545
0aeb33ca-776f-4dd3-8fe4-cd879ebc52b0	b3afd200-5f4f-49b1-a607-ae1abb2be1a7	Contraception in over weight and obese women		20	t		\N	\N	\N	2026-05-25 07:13:54.657297	2026-05-25 07:25:29.52
c3acc2dc-d239-4777-bd73-037beafbbda5	b3afd200-5f4f-49b1-a607-ae1abb2be1a7	Contraception failure		21	t		\N	\N	\N	2026-05-25 07:14:14.755024	2026-05-25 07:25:31.212
a6c8b5fa-ab50-4d0d-bdb1-ca0fe4f6bc31	bacaf815-66ec-4a41-afcb-6f178b8e4a87	Uterine perforation 		6	t		\N	\N	\N	2026-05-25 07:37:56.647053	2026-05-25 07:48:11.122
7be2cc15-53f3-44e9-bb80-4bcae28a27dc	bacaf815-66ec-4a41-afcb-6f178b8e4a87	Surgical safety checklist 		7	t		\N	\N	\N	2026-05-25 07:38:16.52066	2026-05-25 07:48:11.905
bc3525ef-c84c-494e-aa6f-ad0db374bb40	bacaf815-66ec-4a41-afcb-6f178b8e4a87	Outpatient hysteroscopy 		8	t		\N	\N	\N	2026-05-25 07:38:39.028341	2026-05-25 07:48:13.317
e2b390f7-41f9-40bc-8582-2175ebb9713a	bacaf815-66ec-4a41-afcb-6f178b8e4a87	Steps of abdominal hysterectomy 		9	t		\N	\N	\N	2026-05-25 07:39:05.943737	2026-05-25 07:48:14.292
1eeae14d-911e-47ab-9d9d-6f03aa3d32a8	bacaf815-66ec-4a41-afcb-6f178b8e4a87	Steps of vaginal hysterectomy 		10	t		\N	\N	\N	2026-05-25 07:39:24.050577	2026-05-25 07:48:15.47
36543a67-f443-4587-a15c-eeca9409e894	bacaf815-66ec-4a41-afcb-6f178b8e4a87	Steps of evacuation		11	t		\N	\N	\N	2026-05-25 07:39:46.135542	2026-05-25 07:48:16.881
90deb252-c4bd-4530-aead-7c88471362b1	bacaf815-66ec-4a41-afcb-6f178b8e4a87	MVA		12	t		\N	\N	\N	2026-05-25 07:39:57.755318	2026-05-25 07:48:17.921
3a9a3b9e-65d9-4484-99b8-0d07a9f2669b	bacaf815-66ec-4a41-afcb-6f178b8e4a87	Steps of anterior repair		13	t		\N	\N	\N	2026-05-25 07:40:17.43363	2026-05-25 07:48:19.086
02539645-a323-4379-8a12-b938ffd1258b	bacaf815-66ec-4a41-afcb-6f178b8e4a87	Steps of posterior repair		14	t		\N	\N	\N	2026-05-25 07:40:36.908484	2026-05-25 07:48:19.921
c7578a7b-6acb-48bb-a9f7-9c54c8f23e20	dbec251c-b50c-408b-85ca-5a92d99980ed	UTERINE FIBROIDS		1	t		\N	\N	\N	2026-03-04 09:26:12.521797	2026-03-04 09:40:00.997
de882ed5-4ae9-43a0-b80d-d51aae5f6a97	dbec251c-b50c-408b-85ca-5a92d99980ed	SURGICAL TREATMENT OF FIBROID		3	t		\N	\N	\N	2026-03-04 09:51:22.978259	2026-03-04 10:08:55.094
e6feef9c-123b-4f94-a88e-363928e6ad79	a326891f-f3d2-4e76-b1ae-5b0064dea77e	Stress urinary incontinence 		3	t		\N	\N	\N	2026-05-25 06:55:31.373614	2026-05-25 06:59:36.961
dce6694e-93b3-4281-b546-8cb995c03b1d	dbec251c-b50c-408b-85ca-5a92d99980ed	HRT		5	t		\N	\N	\N	2026-03-05 07:46:09.672835	2026-03-05 09:06:18.841
6f36db59-1cc0-4586-8c6a-1c8bb00a8e0c	dbec251c-b50c-408b-85ca-5a92d99980ed	POST MENOPAUSAL BLEEDING		7	t		\N	\N	\N	2026-03-05 08:56:48.840369	2026-03-05 09:06:22.208
ebad03aa-d0cc-4cd6-a66b-6d90073459aa	a326891f-f3d2-4e76-b1ae-5b0064dea77e	Urinary retention		4	t		\N	\N	\N	2026-05-25 06:55:51.129447	2026-05-25 06:59:40.628
3fb406ec-becd-4743-aed5-293304c8fab5	a326891f-f3d2-4e76-b1ae-5b0064dea77e	Bladder pain syndrome 		5	t		\N	\N	\N	2026-05-25 06:56:09.863045	2026-05-25 06:59:42.064
64cc3319-26e3-434b-9138-fe7d7d0226a3	a326891f-f3d2-4e76-b1ae-5b0064dea77e	Urethral diverticula		6	t		\N	\N	\N	2026-05-25 06:56:36.464764	2026-05-25 06:59:43.887
dc104b3f-ed6a-4f1f-8046-73c069161cb6	dbec251c-b50c-408b-85ca-5a92d99980ed	PMS		9	t		\N	\N	\N	2026-03-05 09:07:11.135361	2026-03-06 13:14:52.137
8c0a6a24-6aec-4e85-b74c-547a6e95ee5a	a326891f-f3d2-4e76-b1ae-5b0064dea77e	Recurrent UTI		7	t		\N	\N	\N	2026-05-25 06:57:01.062494	2026-05-25 06:59:45.787
93449ff0-81dc-4af5-8730-28d68ba5925d	a326891f-f3d2-4e76-b1ae-5b0064dea77e	Pelvic organ prolapse 		8	t		\N	\N	\N	2026-05-25 06:57:18.178542	2026-05-25 06:59:47.504
a3d3307e-d67a-4324-9958-84f3e478379d	a326891f-f3d2-4e76-b1ae-5b0064dea77e	Vault prolapse 		9	t		\N	\N	\N	2026-05-25 06:57:34.093737	2026-05-25 06:59:48.618
5662f871-1949-4f64-afd0-4ee8eedc7eb6	b3afd200-5f4f-49b1-a607-ae1abb2be1a7	Progesterone only implants 		10	t		\N	\N	\N	2026-05-25 07:06:34.583966	2026-05-25 07:25:14.197
b0a2a729-9dcf-4b84-a987-e361f78d59c0	b3afd200-5f4f-49b1-a607-ae1abb2be1a7	Emergency contraception 		11	t		\N	\N	\N	2026-05-25 07:06:51.176841	2026-05-25 07:25:15.87
9b5ca856-c888-487c-bf5e-0a5f4fa0652e	b63ab97b-1ade-4083-b1be-be75c5f1ae67	Artificial reproductive technique, procedure review		1	t		\N	\N	\N	2026-05-25 06:39:00.815249	2026-05-25 06:43:46.379
51b95cd6-d5df-4ff6-acdd-8e9ebbee28e5	b63ab97b-1ade-4083-b1be-be75c5f1ae67	Fertility preservation 		2	t		\N	\N	\N	2026-05-25 06:39:38.868285	2026-05-25 06:43:46.948
340afd9c-033b-4ef4-ad27-fe5bbcfc19d7	b3afd200-5f4f-49b1-a607-ae1abb2be1a7	Drug interactions with hormonal contraception 		12	t		\N	\N	\N	2026-05-25 07:07:35.009883	2026-05-25 07:25:17.504
6bab467c-8a2a-4d8b-9338-0b644334624c	b3afd200-5f4f-49b1-a607-ae1abb2be1a7	Contraception for women above 40 years of age		18	t		\N	\N	\N	2026-05-25 07:11:10.589392	2026-05-25 07:25:26.128
ac9ca58f-c1fd-41c9-b22b-f2bccc750897	b63ab97b-1ade-4083-b1be-be75c5f1ae67	Assessment of infertile male		3	t		\N	\N	\N	2026-05-25 06:40:03.391502	2026-05-25 06:43:47.697
226d3f1d-49b6-4215-af72-8bf4d386ee3d	b63ab97b-1ade-4083-b1be-be75c5f1ae67	Unexplained sub fertility 		4	t		\N	\N	\N	2026-05-25 06:40:45.360562	2026-05-25 06:43:49.669
5429ab08-e367-42be-981a-75919d51e8e6	b63ab97b-1ade-4083-b1be-be75c5f1ae67	Tubal tests and tubal surgery		5	t		\N	\N	\N	2026-05-25 06:41:22.264038	2026-05-25 06:43:50.133
99b1e0a9-60bd-4eb0-a911-570f96d324a4	b63ab97b-1ade-4083-b1be-be75c5f1ae67	Management of sub fertile couple		6	t		\N	\N	\N	2026-05-25 06:41:56.815049	2026-05-25 06:43:51.539
061c139e-f370-4c4d-8032-7e68e68edf98	b63ab97b-1ade-4083-b1be-be75c5f1ae67	Early ovarian aging		7	t		\N	\N	\N	2026-05-25 06:42:21.900015	2026-05-25 06:43:53.046
695fd8c5-65af-4a07-bdf8-afb67f7f42cf	b63ab97b-1ade-4083-b1be-be75c5f1ae67	Long term consequences of PCOD		8	t		\N	\N	\N	2026-05-25 06:42:50.097856	2026-05-25 06:43:55.308
e730265c-3042-48e5-9b02-386b1f2629ac	b108a79f-5d9c-4839-9074-3534616914a4	CA Vulva		14	t		\N	\N	\N	2026-05-25 06:52:15.498105	2026-05-25 06:52:27.172
7582eeff-80c4-488b-9beb-64dac57524fe	bacaf815-66ec-4a41-afcb-6f178b8e4a87	Obtaining valid consent		0	t		\N	\N	\N	2026-05-25 07:34:22.505443	2026-05-25 07:48:04.327
8f8f1c76-4248-45ae-a6e1-1e547ac93360	bacaf815-66ec-4a41-afcb-6f178b8e4a87	Caesarean section		1	t		\N	\N	\N	2026-05-25 07:34:48.201632	2026-05-25 07:48:04.643
009da997-ea38-448c-b043-ff3aefbbbeeb	b108a79f-5d9c-4839-9074-3534616914a4	Pre malignant lesions of vulva		13	t		\N	\N	\N	2026-05-25 06:52:00.678259	2026-05-25 06:52:27.855
c7e89b30-8c2c-480e-ad57-b3cbf17f4f46	b108a79f-5d9c-4839-9074-3534616914a4	CA Cervix		12	t		\N	\N	\N	2026-05-25 06:51:34.659604	2026-05-25 06:52:28.282
746dce12-309b-465e-959e-55f209bda77f	bacaf815-66ec-4a41-afcb-6f178b8e4a87	Preventing entry related gynaecological laparoscopic injuries 		2	t		\N	\N	\N	2026-05-25 07:35:32.802313	2026-05-25 07:48:05.214
15c1919a-8a04-48ae-aa30-3f131d9fea90	bacaf815-66ec-4a41-afcb-6f178b8e4a87	Urinary track injuries during laparoscopy and their prevention		3	t		\N	\N	\N	2026-05-25 07:35:49.131196	2026-05-25 07:48:06.426
62425119-0192-4c3b-bcbc-6faa09e2ecae	bacaf815-66ec-4a41-afcb-6f178b8e4a87	Surgical nerve injuries		4	t		\N	\N	\N	2026-05-25 07:36:10.223793	2026-05-25 07:48:08.312
64cea85a-0089-4b91-a842-3b7238c6817e	bacaf815-66ec-4a41-afcb-6f178b8e4a87	Vascular injuries during surgery 		5	t		\N	\N	\N	2026-05-25 07:37:33.951218	2026-05-25 07:48:09.665
ebe28a85-2fd4-4b11-9997-6355b277c282	b108a79f-5d9c-4839-9074-3534616914a4	Pre malignant lesions of cervix and cervical screening		11	t		\N	\N	\N	2026-05-25 06:51:13.904046	2026-05-25 06:52:28.739
fee1f915-9fef-4013-a893-e9222a6d39b4	b108a79f-5d9c-4839-9074-3534616914a4	Borderline ovarian tumors		6	t		\N	\N	\N	2026-05-25 06:48:19.008789	2026-05-25 06:52:32.649
fd82ab80-b6ed-45ad-9e3d-faf210b0224a	b108a79f-5d9c-4839-9074-3534616914a4	Adnexal masses in pregnancy 		5	t		\N	\N	\N	2026-05-25 06:47:57.394761	2026-05-25 06:52:33.072
120c0469-0c47-4e82-abb9-26e2351d04db	bacaf815-66ec-4a41-afcb-6f178b8e4a87	Use of surgical drains		15	t		\N	\N	\N	2026-05-25 07:41:55.698924	2026-05-25 07:48:21.361
6ecb13ca-9d1d-4898-9e51-b8f381a80b49	bacaf815-66ec-4a41-afcb-6f178b8e4a87	Laparoscopic myomectomy 		17	t		\N	\N	\N	2026-05-25 07:45:07.56592	2026-05-25 07:48:23.491
f4344202-4daa-4199-838b-d9c7e4c729e8	bacaf815-66ec-4a41-afcb-6f178b8e4a87	Laparoscopy in pregnancy 		18	t		\N	\N	\N	2026-05-25 07:45:21.119137	2026-05-25 07:48:24.135
45bbcd5b-01ca-4442-b683-0cf15e90ad6f	bacaf815-66ec-4a41-afcb-6f178b8e4a87	Issues around vaginal vault closure 		19	t		\N	\N	\N	2026-05-25 07:45:45.807621	2026-05-25 07:48:25.659
7c60191e-b16a-4043-9001-7aa96deab103	bacaf815-66ec-4a41-afcb-6f178b8e4a87	Laparoscopy in urogynaecology		20	t		\N	\N	\N	2026-05-25 07:47:35.298175	2026-05-25 07:48:27.66
e8fa0cb3-53c4-458f-b5aa-8b55a1b991fe	bacaf815-66ec-4a41-afcb-6f178b8e4a87	Surgical smoke		21	t		\N	\N	\N	2026-05-25 07:47:54.952951	2026-05-25 07:48:28.267
e485d0e5-5293-4078-8809-9692e244af8d	5640d3cf-5c87-4b49-8b8a-8948ad6ad905	Gestational trophoblastic diseases		3	t		\N	\N	\N	2026-05-25 07:50:27.079272	2026-05-25 07:52:05.331
85b212a7-355f-4c2a-8175-e5d1cdb11080	5640d3cf-5c87-4b49-8b8a-8948ad6ad905	Diagnostic algorithms of intrauterine and ectopic pregnancy 		2	t		\N	\N	\N	2026-05-25 07:49:38.351616	2026-05-25 07:52:05.806
699010a2-e498-4e40-a2a7-9cd5dc2076c0	5640d3cf-5c87-4b49-8b8a-8948ad6ad905	Ectopic pregnancy 		1	t		\N	\N	\N	2026-05-25 07:49:03.760384	2026-05-25 07:52:06.203
438f1d73-bdd9-4ce7-afbc-b4734c091bdb	5640d3cf-5c87-4b49-8b8a-8948ad6ad905	Recurrent pregnancy loss		0	t		\N	\N	\N	2026-05-25 07:48:52.705305	2026-05-25 07:52:06.613
250ccdc2-184d-4bfe-b1f8-ebd98ae9f550	5640d3cf-5c87-4b49-8b8a-8948ad6ad905	Amniocentesis and CVS		6	t		\N	\N	\N	2026-05-25 07:51:59.642598	2026-05-25 07:52:03.614
6959d14c-bb89-45b6-9fa7-efe1ecbbfad1	5640d3cf-5c87-4b49-8b8a-8948ad6ad905	Evolution in down syndrome screening and CCFDND		5	t		\N	\N	\N	2026-05-25 07:51:43.568024	2026-05-25 07:52:04.362
73e4b8e9-97b8-4522-bdbc-60664f4b2b47	5640d3cf-5c87-4b49-8b8a-8948ad6ad905	Management of nausea and vomiting in pregnancy 		4	t		\N	\N	\N	2026-05-25 07:50:51.946869	2026-05-25 07:52:04.807
99b47941-82f2-4a74-96b5-829c905c42c4	bacaf815-66ec-4a41-afcb-6f178b8e4a87	Post operative complications 	Haemorrhage \nHaematoma \nWound dehiscence \nThromboprophylaxix in gynaecology\nDVT\npelvic abscess\nAnaesthesia complications \nVisceral injuries\nUrinary tract complications \nBowel complications \nAcute colonic pseudo obstruction after c section	16	t		\N	\N	\N	2026-05-25 07:42:12.999115	2026-05-25 08:02:32.381
f988c7af-2d0e-47aa-b1a6-ac3a9ec374b6	2ce2539d-223c-45e5-90a0-272afedff9e3	Maternity dashboard		5	t		\N	\N	\N	2026-06-01 07:18:40.568862	2026-06-01 07:18:40.568862
20944d53-c138-45a9-a769-c48bd4229f0f	2ce2539d-223c-45e5-90a0-272afedff9e3	What is clinical governance		0	t		\N	\N	\N	2026-06-01 07:16:42.493234	2026-06-01 07:57:59.845
9ffb1679-4328-47c6-b6c8-df01cc2337ed	2ce2539d-223c-45e5-90a0-272afedff9e3	Clinical effectiveness		1	t		\N	\N	\N	2026-06-01 07:17:08.811194	2026-06-01 07:58:04.257
358587df-8f59-4495-9488-56031c7dbed1	2ce2539d-223c-45e5-90a0-272afedff9e3	Clinical audit		2	t		\N	\N	\N	2026-06-01 07:17:26.964219	2026-06-01 08:27:20.652
451cca65-ae17-4959-bfd9-043a725fa698	2ce2539d-223c-45e5-90a0-272afedff9e3	Risk management		3	t		\N	\N	\N	2026-06-01 07:17:45.345342	2026-06-01 08:27:25.543
524a24bc-11d0-4940-b38b-7510f98c20ef	2ce2539d-223c-45e5-90a0-272afedff9e3	Patient and public involvement PALS		4	t		\N	\N	\N	2026-06-01 07:18:17.462888	2026-06-01 08:27:29.22
594220af-32d7-4d00-98ad-a2c733d4be33	7d80628c-5d83-46e9-922d-ab659f7c0768	Teaching methods		0	t		\N	\N	\N	2026-06-01 08:28:21.507166	2026-06-01 08:28:21.507166
4dc9b993-9478-4088-80c5-3996d53748b8	7d80628c-5d83-46e9-922d-ab659f7c0768	Induction interview/Apparaisal		1	t		\N	\N	\N	2026-06-01 08:29:03.697438	2026-06-01 08:29:03.697438
95a94798-0d07-48c4-8238-f06aa0c591d5	7d80628c-5d83-46e9-922d-ab659f7c0768	Work base assessment tools		2	t		\N	\N	\N	2026-06-01 08:29:31.087076	2026-06-01 08:29:31.087076
259577e9-5acd-4b6b-99a6-21ec4c50b261	7d80628c-5d83-46e9-922d-ab659f7c0768	ARCP		3	t		\N	\N	\N	2026-06-01 08:29:47.188221	2026-06-01 08:29:47.188221
7fed75f0-8cf4-4815-ac45-ba31b34bd30f	7d80628c-5d83-46e9-922d-ab659f7c0768	Appraisal vs Revalidation		4	t		\N	\N	\N	2026-06-01 08:30:13.793576	2026-06-01 08:30:13.793576
5781eae1-5283-4b6e-8153-2313e29501a6	7d80628c-5d83-46e9-922d-ab659f7c0768	Reflection		5	t		\N	\N	\N	2026-06-01 08:30:30.17454	2026-06-01 08:30:30.17454
669a30c3-59e4-449e-b89d-1997522e1808	b8a054ef-e541-4d49-9bae-02c41ef8eb92	3rd and 4th degree perineal tear		1	t		\N	\N	\N	2026-06-02 05:56:50.658896	2026-06-02 05:56:50.658896
ae07ff0d-4682-4df5-bd7d-f6067bd7b664	b8a054ef-e541-4d49-9bae-02c41ef8eb92	Vulval haematoma		2	t		\N	\N	\N	2026-06-02 05:57:18.867863	2026-06-02 05:58:41.312
70afe946-2149-4948-bb0f-2d48fd2d08f4	b8a054ef-e541-4d49-9bae-02c41ef8eb92	Post partum mastitis		3	t		\N	\N	\N	2026-06-02 06:01:03.149051	2026-06-02 06:01:03.149051
06c82d3c-6651-48c2-8444-2362025f8f0c	b8a054ef-e541-4d49-9bae-02c41ef8eb92	Post partum urinary retention PUR		4	t		\N	\N	\N	2026-06-02 06:04:12.5933	2026-06-02 06:04:12.5933
c4a99f45-fa0e-43c8-b7b6-90ef39b35144	b8a054ef-e541-4d49-9bae-02c41ef8eb92	Maternal mental health	1. Mental health screening\n2. Perinatal mental health services\n3. Baby blues\n4. Depression\n5. Anxiety\n6. Psycosis\n7. Psychotropic drugs and their effects on pregnancy and lactation\n8. Eating disorders\n9. Sleep problems\n10. Drug misuse	5	t		\N	\N	\N	2026-06-02 06:25:18.479227	2026-06-02 06:25:18.479227
4328293d-d18c-43da-aed5-00d22a4c8b76	b8a054ef-e541-4d49-9bae-02c41ef8eb92	Post partum contraception		6	t		\N	\N	\N	2026-06-02 06:27:45.741654	2026-06-02 06:27:45.741654
b1c1aa64-a82b-49bf-b379-6c7753bee96e	b8a054ef-e541-4d49-9bae-02c41ef8eb92	Maternal mortality		7	t		\N	\N	\N	2026-06-02 06:29:15.478613	2026-06-02 06:29:15.478613
c7957bdf-9cd1-4ab8-99a9-ba170eff34a7	b8a054ef-e541-4d49-9bae-02c41ef8eb92	MBRRACE		8	t		\N	\N	\N	2026-06-02 06:29:35.159537	2026-06-02 06:29:35.159537
9650ce9e-7f49-4a44-a5eb-1c56270bb0ad	b8a054ef-e541-4d49-9bae-02c41ef8eb92	Post partum haemorrhage		0	t		\N	\N	\N	2026-06-02 05:55:40.864166	2026-06-02 06:30:00.466
8ce2600e-2961-4eb5-8f96-319235e03173	28f5de83-fd41-4bdc-994f-c06c795a88a9	Intrapartum care of healthy normal pregnancies	1. Types of birth setting\n2. Pain relief during labour\n3. 1st stage of labour\n4. 2nd stage of labour\n5. 3rd stage of labour\n6. Retained placenta\n7. Post partum haemorrhage\n8. Care of the women after birth	0	t		\N	\N	\N	2026-06-07 17:35:21.899156	2026-06-07 17:35:21.899156
6c89e07a-ec1e-4def-ac42-e6b2ede03088	28f5de83-fd41-4bdc-994f-c06c795a88a9	Neonatal care and resuscitation		1	t		\N	\N	\N	2026-06-07 17:36:00.98233	2026-06-07 17:36:00.98233
e3b4e100-df3c-4448-8819-9259329e7197	28f5de83-fd41-4bdc-994f-c06c795a88a9	Fetal monitoring during labour		3	t		\N	\N	\N	2026-06-07 17:47:52.510873	2026-06-07 17:47:52.510873
9b6c66b5-b975-4976-aab0-8b669e665d08	28f5de83-fd41-4bdc-994f-c06c795a88a9	ECV 		4	t		\N	\N	\N	2026-06-07 17:48:14.981681	2026-06-07 17:48:14.981681
c79f2b67-796c-48b5-9d38-c447ff896df9	28f5de83-fd41-4bdc-994f-c06c795a88a9	Breech presentation		5	t		\N	\N	\N	2026-06-07 17:49:05.976611	2026-06-07 17:49:05.976611
92e1f445-5002-413d-8a33-e14ed7bd126b	28f5de83-fd41-4bdc-994f-c06c795a88a9	Intrapartum care of women with existing medical conditions and obstetric complications	1. Heart disease\n2. Asthma\n3. Women on long term systemic steroids\n4. Bleeding disorders\n5. Sub arachnoid haemorrhage or AV malformations of the brain\n6. Renal disease\n7. Obesity\n8. Women with obstetric complications or no antenal care\n9. Pyrexia\n10. Sepsis\n11. Intra partum haemorrhage\n12. Breech in labour\n13. Large for gestational age babies\n14. Women with no antenatal care\n15. Previous C/S\n16. Labour after 42 weeks of pregnancy \n	2	t		\N	\N	\N	2026-06-07 17:47:22.388527	2026-06-07 17:50:15.961
20c65258-1d41-4e72-9bdb-fe3039899c8c	28f5de83-fd41-4bdc-994f-c06c795a88a9	Pre term labour		6	t		\N	\N	\N	2026-06-07 17:51:01.756621	2026-06-07 17:51:01.756621
950fee0f-0427-4206-bf67-4b235f2f68da	28f5de83-fd41-4bdc-994f-c06c795a88a9	Pre PROM		7	t		\N	\N	\N	2026-06-07 17:51:20.204049	2026-06-07 17:51:20.204049
16328fca-4d8d-4aa0-839a-3fdf001f8d72	28f5de83-fd41-4bdc-994f-c06c795a88a9	Vaginal birth after c section		8	t		\N	\N	\N	2026-06-07 17:51:47.891596	2026-06-07 17:51:47.891596
1753e412-9ad4-45ba-be24-7347a796715f	28f5de83-fd41-4bdc-994f-c06c795a88a9	Shoulder dystocia		9	t		\N	\N	\N	2026-06-07 17:52:15.889712	2026-06-07 17:52:15.889712
dacb9f6f-63f2-4d9e-bae9-aa63692d25ae	28f5de83-fd41-4bdc-994f-c06c795a88a9	Cord prolapse		10	t		\N	\N	\N	2026-06-07 17:52:37.409406	2026-06-07 17:52:37.409406
23d86197-82bb-4f65-8742-9eaff7f540f6	28f5de83-fd41-4bdc-994f-c06c795a88a9	Assisted vaginal birth 		11	t		\N	\N	\N	2026-06-07 17:53:17.258733	2026-06-07 17:53:17.258733
bc603598-f547-4662-8699-64dadefba36a	28f5de83-fd41-4bdc-994f-c06c795a88a9	Perimortum C/S		14	t		\N	\N	\N	2026-06-07 17:54:33.77911	2026-06-07 17:54:33.77911
992f9097-aac3-4b30-8c85-2d93c2e41038	28f5de83-fd41-4bdc-994f-c06c795a88a9	Induction of labour		13	t		\N	\N	\N	2026-06-07 17:54:09.486592	2026-06-09 07:39:13.436
993577fb-3767-49dd-8160-92a3e03e2066	28f5de83-fd41-4bdc-994f-c06c795a88a9	Maternal collapse		12	t		\N	\N	\N	2026-06-07 17:53:49.524683	2026-06-09 07:39:56.757
\.


--
-- Data for Name: user_progress; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.user_progress (id, user_id, topic_id, is_completed, completed_at, created_at) FROM stdin;
42068196-09fb-440c-b9d9-aa254a153c6a	51268d4e-a5cf-4e92-948c-0c708d200d48	52c2375a-221f-40db-be86-b66990fdd20a	t	2026-03-05 00:29:31.572	2026-03-05 00:29:31.574931
ef0c1b6c-1310-42ae-a7dd-ce5963a4f95c	51268d4e-a5cf-4e92-948c-0c708d200d48	dce6694e-93b3-4281-b546-8cb995c03b1d	t	2026-03-05 09:55:45.864	2026-03-05 09:55:45.865025
ee859c87-3cae-422c-bb41-5a8582862cfa	61bd4894-7aa4-437b-bcb2-285bdc034994	dce6694e-93b3-4281-b546-8cb995c03b1d	f	\N	2026-03-05 11:22:57.289688
ee62aa27-a3cf-41be-af50-9433cbe5d096	61bd4894-7aa4-437b-bcb2-285bdc034994	c7578a7b-6acb-48bb-a9f7-9c54c8f23e20	t	2026-03-06 05:03:29.631	2026-03-06 05:03:29.632664
ed86ba62-d9c0-41ab-a3b6-e0848443ff8c	51268d4e-a5cf-4e92-948c-0c708d200d48	c7578a7b-6acb-48bb-a9f7-9c54c8f23e20	t	2026-03-19 00:14:37.521	2026-03-05 00:29:37.461073
6263d39a-b54e-401b-aa76-ce696ab6e9cd	473e5d03-a90f-4573-8eda-3c1e36c2951d	52c2375a-221f-40db-be86-b66990fdd20a	f	\N	2026-04-17 17:33:39.729497
b33508c0-f454-4766-9ede-44dd212155ca	5d13b898-19a9-4d4d-9cd0-d0fd7d5d5746	631e8033-60a7-46e8-8aac-713aad3674c8	t	2026-05-03 04:42:42.777	2026-05-03 04:42:42.778285
e78a7485-79bd-4883-8db6-d33eb1b36444	7f79450a-4fa6-4b62-ad06-ca377f583d83	025e984c-0ed5-46c5-8825-99318063c146	t	2026-05-04 08:19:49.386	2026-05-04 08:19:49.398112
03cb87b5-fe7f-4279-86c2-c8a533878634	7f79450a-4fa6-4b62-ad06-ca377f583d83	52c2375a-221f-40db-be86-b66990fdd20a	t	2026-05-05 04:16:53.963	2026-05-05 04:16:53.963967
341bdd5c-3880-457b-839c-f4b7132b6531	7f79450a-4fa6-4b62-ad06-ca377f583d83	c7578a7b-6acb-48bb-a9f7-9c54c8f23e20	t	2026-05-05 04:17:38.71	2026-05-02 11:38:18.170117
f5a8fae1-3bcf-41d3-816f-668ff3906ed6	7f79450a-4fa6-4b62-ad06-ca377f583d83	de882ed5-4ae9-43a0-b80d-d51aae5f6a97	t	2026-05-06 05:01:22.674	2026-05-06 05:01:22.675359
d8624be6-22dd-4ff0-a83e-eccfaf6029d6	7f79450a-4fa6-4b62-ad06-ca377f583d83	631e8033-60a7-46e8-8aac-713aad3674c8	t	2026-05-06 05:01:49.987	2026-05-05 04:18:19.317911
c339821e-541e-4556-9b7e-e79adc160086	7f79450a-4fa6-4b62-ad06-ca377f583d83	6f36db59-1cc0-4586-8c6a-1c8bb00a8e0c	t	2026-05-09 11:22:41.568	2026-05-07 06:05:10.887145
0bad320b-318a-4f43-a581-f50c5b4b6ed4	7f79450a-4fa6-4b62-ad06-ca377f583d83	1ec05f17-3698-4528-b414-f33f8f9e0c2b	t	2026-05-09 11:22:50.307	2026-05-08 04:56:11.198769
c9a542e6-6e4a-4cce-9a01-c32f3014d6f1	e48a1d49-0a19-4f78-bb27-e8f26279052c	dc104b3f-ed6a-4f1f-8046-73c069161cb6	t	2026-05-09 17:03:02.948	2026-05-09 17:03:02.948412
0462b069-8036-4563-a5a3-cea5471237d4	e48a1d49-0a19-4f78-bb27-e8f26279052c	1ec05f17-3698-4528-b414-f33f8f9e0c2b	t	2026-05-09 17:04:18.115	2026-05-09 17:02:23.10506
1593da61-389b-4bd7-9005-ceab3e5fefbf	e48a1d49-0a19-4f78-bb27-e8f26279052c	c7578a7b-6acb-48bb-a9f7-9c54c8f23e20	t	2026-05-09 17:04:50.706	2026-05-09 17:04:50.712207
d09c6a5c-b3b9-43e1-ac98-2aec979cd7bf	e48a1d49-0a19-4f78-bb27-e8f26279052c	025e984c-0ed5-46c5-8825-99318063c146	t	2026-05-09 17:05:01.46	2026-05-09 17:05:01.489444
97425902-36ad-4d0f-b55d-05bcab827c95	e48a1d49-0a19-4f78-bb27-e8f26279052c	de882ed5-4ae9-43a0-b80d-d51aae5f6a97	t	2026-05-09 17:05:11.78	2026-05-09 17:05:11.782904
7f9c515c-a228-476f-9f3c-6312464d821c	e48a1d49-0a19-4f78-bb27-e8f26279052c	dce6694e-93b3-4281-b546-8cb995c03b1d	t	2026-05-09 17:05:21.036	2026-05-09 17:05:21.037513
b023979a-1b41-4ac7-8b36-533109948657	7f79450a-4fa6-4b62-ad06-ca377f583d83	dc104b3f-ed6a-4f1f-8046-73c069161cb6	t	2026-05-10 06:37:43.402	2026-05-03 14:19:05.089965
0dabe95d-aeb9-4816-8465-d9a1e2541253	7f79450a-4fa6-4b62-ad06-ca377f583d83	dce6694e-93b3-4281-b546-8cb995c03b1d	t	2026-05-10 06:40:00.853	2026-05-10 06:40:00.874683
eff1c326-c00e-4c1d-ab32-6e611af6762d	7f79450a-4fa6-4b62-ad06-ca377f583d83	126fe5cf-71e2-4469-8a89-2bf0498f7cc5	t	2026-05-13 04:02:03.705	2026-05-07 06:03:02.160508
2427e956-2000-4fe5-9e25-0eb8e3b9ddb5	61bd4894-7aa4-437b-bcb2-285bdc034994	52c2375a-221f-40db-be86-b66990fdd20a	f	\N	2026-03-05 11:53:17.531407
de58778a-092e-44b4-a48e-be3200718593	61bd4894-7aa4-437b-bcb2-285bdc034994	594220af-32d7-4d00-98ad-a2c733d4be33	t	2026-06-02 03:17:24.546	2026-06-02 03:17:24.546708
\.


--
-- Data for Name: user_sessions; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.user_sessions (id, user_id, device_id, device_label, platform, user_agent, ip_address, refresh_token_hash, is_active, created_at, last_seen_at, expires_at, revoked_at, revoked_by, revoke_reason) FROM stdin;
91aa3582-ea9a-4d59-8965-4636bb7b5a41	51268d4e-a5cf-4e92-948c-0c708d200d48	mm-1780567591259-85bb126d62e3f8	Android device	android	okhttp/4.12.0	39.63.232.178	c4868dfaa2075c5c9c70072a45319abca77d8d5ef84e5873e7d2d18d22e05384	t	2026-06-12 17:14:23.896193	2026-06-12 17:14:52.111	2026-07-12 17:14:23.894	\N	\N	\N
ee293b57-a41e-4fed-ba9e-1e873d7d4c8c	61bd4894-7aa4-437b-bcb2-285bdc034994	mm-1781578692787-99405fb4bf0788	Android device	android	okhttp/4.12.0	39.63.161.95	920fd6f3cfea815f363ede96edb7f68bee3ba02438fa5633c4d50b129116960e	f	2026-06-16 03:32:16.608438	2026-06-16 03:37:41.581	2026-07-16 03:32:16.606	2026-06-16 03:45:20.675	\N	device_limit_kick_oldest
7ac6d331-c1f2-4a5f-8afa-c42092e309b5	61bd4894-7aa4-437b-bcb2-285bdc034994	52857923bee187c8e8a3567d75d65325	\N	\N	okhttp/4.12.0	39.60.93.209	0c0cd3c530b7d6dc450e255c444e882c1f6c727a6b8734e7a3909c685e3a7aff	f	2026-06-06 02:49:35.91477	2026-06-07 03:37:15.41	2026-07-06 02:49:35.91	2026-06-16 03:29:18.389	\N	device_limit_kick_oldest
e70ec869-a841-458c-a662-74eff0f99695	61bd4894-7aa4-437b-bcb2-285bdc034994	mm-1781529619949-053cc64c3e87bb8	Android device	android	okhttp/4.12.0	39.60.92.245	90c4a57cd6c3e4ae7143c77bc29227a4ec25dd42ac3b431b765fd522143b099e	f	2026-06-15 13:20:20.036872	2026-06-15 14:00:26.48	2026-07-15 13:20:20.033	2026-06-16 03:29:18.389	\N	device_limit_kick_oldest
246a1a8b-d496-4810-902e-c176584aece9	61bd4894-7aa4-437b-bcb2-285bdc034994	mm-1781578692787-99405fb4bf0788	Android device	android	okhttp/4.12.0	39.63.161.95	fa7759c017c868d1463af61d028fd47186ae65fc4cdbc3aac36234bcc593f462	f	2026-06-16 02:58:12.555461	2026-06-16 03:19:25.079	2026-07-16 02:58:12.539	2026-06-16 03:19:25.08	\N	user_logout
b71e2b52-816e-49cd-9ce3-1ac5e0ed3bb7	61bd4894-7aa4-437b-bcb2-285bdc034994	mm-1781578692787-99405fb4bf0788	Android device	android	okhttp/4.12.0	39.60.95.133	a70009c84b3d5b5f047151659cb34d4fc7a4913ea29ff2da969e752175048602	f	2026-06-18 17:47:49.521575	2026-06-18 17:47:56.247	2026-07-18 17:47:49.52	2026-06-23 06:42:05.086	\N	same_device_replaced
b560f15b-553c-4f65-b73e-67d581b64ecc	51268d4e-a5cf-4e92-948c-0c708d200d48	70ba59fc4dbeb338a81dffb47f8c7ad0	\N	\N	okhttp/4.12.0	2001:4860:101e:fe00:5d6f:621:f373:fc8a	ceb9cfbb2de7eeb77681575be5081675a4d1442a6b35ca970120a9741b18db10	t	2026-06-16 17:15:30.947175	2026-06-16 17:16:22.901	2026-07-16 17:15:30.945	\N	\N	\N
be9de646-924b-4208-8e4c-743ab14bf8c9	demo-user-001	admin-eaa22ea9-cb49-4cb9-957c-c3723865f835	Admin web browser	web	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36 Edg/148.0.0.0	182.191.114.181	715930f7b6d3be3779dff651290e58960ed493f9190e4f7e3840e65dedb853b8	t	2026-06-04 06:22:43.837163	2026-06-05 07:48:18.949	2026-07-04 06:22:43.833	\N	\N	\N
2b7e6053-423a-4041-be1d-e9668495d45d	51268d4e-a5cf-4e92-948c-0c708d200d48	mm-1780567591259-85bb126d62e3f8	Android device	android	okhttp/4.12.0	39.63.241.242	570b8605879ffa86b05c2dc9d2730a48e4406b707ab7726c05dbf88a2b964691	f	2026-06-04 10:06:32.131499	2026-06-04 19:22:00.176	2026-07-04 10:06:32.13	2026-06-12 17:14:23.863	\N	same_device_replaced
e43f760b-79bd-4ed6-83c5-358c8c7d9ca8	51268d4e-a5cf-4e92-948c-0c708d200d48	60e09cea45966848635e6006efde9cad	\N	\N	okhttp/4.12.0	104.237.171.16	613d3fe236dca6caf724b6555bcd8227664e5dc7db4d78f0e3655111b9dbb9eb	f	2026-06-13 02:13:38.063103	2026-06-13 02:14:54.896	2026-07-13 02:13:38.059	2026-06-13 02:14:54.9	\N	user_logout
ebbd0c32-48b0-489d-a388-e49415cdf9ee	demo-user-001	admin-20685753-8702-4f5c-8f14-56f5b0f2aa4b	Admin web browser	web	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36	39.60.93.209	4d7c40bea754f3e2ca0bb0271f02af9b8b1a3dd663cf50a9a9deec933452273a	f	2026-06-06 07:13:55.880329	2026-06-09 07:46:46.048	2026-07-06 07:13:55.878	2026-06-15 13:28:31.283	\N	same_device_replaced
cab5bbf2-fa49-4c6a-902b-077c51cf8c3b	61bd4894-7aa4-437b-bcb2-285bdc034994	fd9381f23976d407299915200ffe9e19	\N	\N	okhttp/4.12.0	39.63.161.95	68136fbd6b81d61cbb666aea221d627885d01b51111fa7a616cb42d3de9cf971	f	2026-06-16 03:45:20.639051	2026-06-16 03:45:21.982	2026-07-16 03:45:20.621	2026-06-18 17:47:49.55	\N	device_limit_kick_oldest
d4df9c55-f418-4d0a-ab54-26e1a1cd02cb	61bd4894-7aa4-437b-bcb2-285bdc034994	mm-1781578692787-99405fb4bf0788	Android device	android	okhttp/4.12.0	39.63.161.95	b1efd88aaeaad1a4e89be2bc46c7f6ebb653a132ab2eda2dfab26f67a278cc21	f	2026-06-16 03:19:45.395354	2026-06-16 03:31:07.261	2026-07-16 03:19:45.394	2026-06-16 03:31:07.261	\N	user_logout
e066bbf2-58cc-49ab-8752-e26ba31d79fb	61bd4894-7aa4-437b-bcb2-285bdc034994	mm-1781578692787-99405fb4bf0788	Android device	android	okhttp/4.12.0	101.53.246.1	f9e8f743611e4db87fb08120ba45d4bf64bd7f0a0207c2f17aa0bbbc53aad2c5	f	2026-06-23 06:42:05.119732	2026-06-23 06:46:38.23	2026-07-23 06:42:05.116	2026-06-23 19:39:21.926	\N	same_device_replaced
a61c51f7-1dbc-4100-a9ca-33dcaf7fe5cc	51268d4e-a5cf-4e92-948c-0c708d200d48	60dedef7ea44cc9de54d3063e5049f9e	\N	\N	okhttp/4.12.0	104.237.171.16	b1f2926749072fcb77719743c0c2e1fab4f067bb4975e0399587ad256d149f16	t	2026-06-13 02:15:17.869792	2026-06-13 02:16:40.761	2026-07-13 02:15:17.868	\N	\N	\N
8784fa22-b3b9-4377-b434-85ffe82ccf82	demo-user-001	admin-20685753-8702-4f5c-8f14-56f5b0f2aa4b	Admin web browser	web	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36	39.60.92.245	3c44d783228a2422998f3155369413cd7337f69d885584de5a2584c98cfc036a	f	2026-06-15 13:28:31.365801	2026-06-15 14:10:53.76	2026-07-15 13:28:31.36	2026-06-23 06:26:41.217	\N	same_device_replaced
feeb7872-76ba-418f-833a-7cb146dabaf2	61bd4894-7aa4-437b-bcb2-285bdc034994	mm-1781578692787-99405fb4bf0788	Android device	android	okhttp/4.12.0	39.63.161.95	60e4a7d49a06a6c24557ac3e0c289ac852549c43a2b8f3c4c9b87c5d38173f17	f	2026-06-16 03:31:16.291036	2026-06-16 03:32:07.505	2026-07-16 03:31:16.28	2026-06-16 03:32:07.505	\N	user_logout
c2e23612-b533-4ac5-bac9-2844bf9cd895	7c45a099-3c4f-4068-8140-8b2f7ffe828e	mm-1781581877671-0f460d275e6a078	Android device	android	okhttp/4.12.0	39.63.161.95	296ffd0c76f60bc38230e976372584bdde2987ef3645bd3c8645200c2aaed964	t	2026-06-16 03:53:10.972676	2026-06-16 03:58:55.562	2026-07-16 03:53:10.971	\N	\N	\N
e10fbed8-fe67-4f92-8f3d-8d4735d249b4	51268d4e-a5cf-4e92-948c-0c708d200d48	82cb4d131fbe11d7ee3421b0a15c849e	\N	\N	okhttp/4.12.0	2001:4860:101e:fe00:ee29:5cda:8e6d:145e	62c05c26dd38b43462b1eb8245330098a13779536a395ff31efdb0f877ed73fe	f	2026-06-16 17:12:20.212387	2026-06-16 17:14:49.687	2026-07-16 17:12:20.191	2026-06-16 17:14:49.687	\N	user_logout
54d2185f-118a-46cf-8756-3789314bfdc4	demo-user-001	admin-20685753-8702-4f5c-8f14-56f5b0f2aa4b	Admin web browser	web	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36	101.53.246.1	cea985a73bd39fb2bca0b8a62c478a94d92fdb9c89d5dd1bb1d4f41bee3749f3	t	2026-06-23 06:26:41.27218	2026-06-23 08:26:02.851	2026-07-23 06:26:41.263	\N	\N	\N
7432ee6d-91ba-486e-b55f-0eef27c0a8ba	61bd4894-7aa4-437b-bcb2-285bdc034994	mm-1781578692787-99405fb4bf0788	Android device	android	okhttp/4.12.0	39.60.92.152	67d6ec9319a552951c51f71af803820fbba81fbe40d4e17eee7759ae0e52a5f1	f	2026-06-23 19:39:21.992196	2026-06-23 19:39:34.607	2026-07-23 19:39:21.984	2026-06-26 18:55:50.767	\N	device_limit_kick_oldest
fc83bf45-a5ba-4cdf-b4ee-209cca936363	demo-user-001	admin-7f736c43-e3ca-4651-ae1e-af0042a3dca5	Admin web browser	web	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36	39.60.92.245	b9f5bce66eea70a816f072e6dfe8e2db88d324f99e682934f323a04f8f6a6878	f	2026-06-15 13:21:41.900806	2026-06-21 06:26:34.598	2026-07-15 13:21:41.898	2026-06-29 12:38:40.08	\N	same_device_replaced
55099fc7-f6cd-44fa-b5e0-c4c6bff9cbd2	51268d4e-a5cf-4e92-948c-0c708d200d48	26a5f4fe757fd302783691528387e06d	\N	\N	okhttp/4.12.0	43.224.129.132	8297a0be49263967c8b7268c3e1ed76871bfebdc51e4979dd899c835dcb43727	t	2026-06-25 14:13:46.976323	2026-06-25 14:14:31.8	2026-07-25 14:13:46.974	\N	\N	\N
7fc0a16b-bd22-45e3-bb9d-a6da33d934ae	51268d4e-a5cf-4e92-948c-0c708d200d48	mm-1782430273337-c4955805640e58	Android device	android	okhttp/4.12.0	2407:d000:603:f68b:acf5:a68e:87b:5e46	354e6635279d36b73800f92253512d3ac248e53fdbc43d8a2de9fcfde33e918a	t	2026-06-25 23:31:14.647916	2026-06-25 23:31:26.648	2026-07-25 23:31:14.644	\N	\N	\N
f3815d9d-f0eb-4c1b-8d3d-77f8e306e68e	51268d4e-a5cf-4e92-948c-0c708d200d48	mm-1782320773216-bfa4c5ba820d5	Android device	android	okhttp/4.12.0	2407:d000:603:f68b:38f5:2343:6c6d:e565	531b84eb108aca5bfdd8d37d6856b870d3cd7b2900102565cf138ac97266ce42	t	2026-06-24 17:06:15.407901	2026-06-24 17:06:56.99	2026-07-24 17:06:15.392	\N	\N	\N
54ba8cec-4dcf-45e8-9016-24a570b553c3	51268d4e-a5cf-4e92-948c-0c708d200d48	86aee1e20c229b86c033bc423cbf2906	\N	\N	okhttp/4.12.0	92.126.155.68	1bd4f770f9f8b363b7d6835e52229181b5f319e46407cc366c3ea5479b10876a	f	2026-06-26 02:45:59.150862	2026-06-26 02:49:18.971	2026-07-26 02:45:59.149	2026-06-26 02:49:18.972	\N	user_logout
899ab6e7-4aff-4cf7-b1a2-d82701881fc8	51268d4e-a5cf-4e92-948c-0c708d200d48	mm-1782421999102-e6ffe452e1657	Android device	android	okhttp/4.12.0	2407:d000:603:f68b:acf5:a68e:87b:5e46	81bfa62551063c00963712d64f68dcd0a5553730c506dfeb57a05d1402350084	t	2026-06-25 21:13:21.044008	2026-06-25 21:14:15.448	2026-07-25 21:13:21.029	\N	\N	\N
0b00bbad-773f-4728-ba34-40b4794defdf	demo-user-001	admin-1f3dbd2e-f3f4-4bb7-9aa6-c6a3aa1f503c	Admin web browser	web	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36	2407:d000:603:f68b:4010:87f8:38a6:2b80	bfbc6e1dde75c8ed62cbf0d48dce92a66462238873b46855b204ce932cda19d1	t	2026-06-22 17:55:42.359556	2026-06-25 22:40:18.442	2026-07-22 17:55:42.356	\N	\N	\N
34beb610-1c18-4578-859c-04a11b1bbe22	51268d4e-a5cf-4e92-948c-0c708d200d48	mm-1783278672782-b1528f865176d8	Android device	android	okhttp/4.12.0	2407:d000:603:f68b:ee50:f99c:6855:9afc	d8d2115a6869f709ef6f38185769930c6b5cc83dbe355ec8b849a768bda6d360	t	2026-07-05 19:11:14.338502	2026-07-05 19:15:34.415	2026-08-04 19:11:14.335	\N	\N	\N
0836fd1e-bac3-400c-bc52-9b36e84a05de	51268d4e-a5cf-4e92-948c-0c708d200d48	a554faa169f241f18597259f8f5f2e20	\N	\N	okhttp/4.12.0	43.224.129.132	4b3dc428cb7c62a1108a5aa545d23028a5b57b06b223931a4a3de1c43576cc40	f	2026-06-25 14:11:03.687722	2026-06-25 14:13:23.066	2026-07-25 14:11:03.678	2026-06-25 14:13:23.068	\N	user_logout
770263d5-ad10-4106-8529-5c08ba492ca0	51268d4e-a5cf-4e92-948c-0c708d200d48	31e80f8671cc89bdde4ae8ed3484c8d3	\N	\N	okhttp/4.12.0	149.255.152.133	683eaadf540899892b9833301b8d4a6fa00738d88d05a620e210060a9d1dbf12	t	2026-06-25 13:43:49.964196	2026-06-25 13:46:24.188	2026-07-25 13:43:49.961	\N	\N	\N
dfb2bd2d-d993-43a1-b728-86c312249651	61bd4894-7aa4-437b-bcb2-285bdc034994	mm-1782500150438-4e939a6fbeb978	Android device	android	okhttp/4.12.0	39.60.81.75	6dd96f583e85cbc63d8f6abc3018db24105bc42f1f91702ef7aec893a34e41d0	f	2026-06-26 18:55:50.726093	2026-06-29 12:43:12.926	2026-07-26 18:55:50.723	2026-06-29 12:43:12.926	\N	user_logout
48164d41-c821-43fb-a0f0-2dc38688ae97	51268d4e-a5cf-4e92-948c-0c708d200d48	2423c406b022bec7a73356255d97a105	\N	\N	okhttp/4.12.0	2a00:79e1:2400:2801:ed33:fd22:5a15:b385	8018b9386711e58b5d27866e0659a69539c09a4cec92ca6ca82990ce80d6be49	t	2026-06-29 05:09:21.526188	2026-06-29 05:09:54.443	2026-07-29 05:09:21.482	\N	\N	\N
648b8bba-2a5b-4e27-b5dc-6c2607d5462b	61bd4894-7aa4-437b-bcb2-285bdc034994	mm-1782500150438-4e939a6fbeb978	Android device	android	okhttp/4.12.0	39.63.182.233	65d6f37f92e1e3803b381ae7f4c095d50d1d3f5ab5adc41912804c7b3e60b191	t	2026-06-29 12:43:22.130108	2026-06-29 12:44:06.108	2026-07-29 12:43:21.987	\N	\N	\N
d25b6b1f-03f1-4646-b318-6a056ecad0b5	demo-user-001	admin-7f736c43-e3ca-4651-ae1e-af0042a3dca5	Admin web browser	web	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36	39.63.182.233	b7e071227318bf3d5b6ab43a5151821fc3feb3a33e0ee85bb2fb2a73fc167c7a	t	2026-06-29 12:38:40.161161	2026-06-29 12:41:07.123	2026-07-29 12:38:40.144	\N	\N	\N
\.


--
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.users (id, email, password, name, role, subscription_status, subscription_plan, subscription_expires_at, created_at, is_email_verified, email_verification_token, email_token_expires_at, phone_number, is_phone_verified, phone_verification_token, phone_token_expires_at, is_active, deactivated_at, deactivation_reason, deletion_requested_at, deletion_status, avatar_url, device_limit_override_enabled, device_limit_max) FROM stdin;
71ff5b30-cb26-4b18-b259-82e55fcf7a1a	drfarzanamuneer@gmail.com	$2b$12$jCyPiPahTl4MRVUZKvPea.KTNLikmUF2crqW6AsJedLKLzNSh59UO	Farzana	student	none	\N	\N	2026-05-03 04:20:14.355115	f	137284	2026-05-03 04:35:14.332	\N	f	\N	\N	t	\N	\N	\N	none	\N	f	\N
5d13b898-19a9-4d4d-9cd0-d0fd7d5d5746	drasifali6176@gmail.com	$2b$12$cWGUVaqTth.MRyRQ.g.Sfu9BYJ6/b2JuggANsaqnHqkhuw2BHh5Yq	Asif	student	none	\N	\N	2026-05-03 04:31:20.077249	t	\N	\N	\N	f	\N	\N	t	\N	\N	\N	none	\N	f	\N
2133353d-addc-40da-a210-be870797de8d	khalidkhanafridi484@gmail.com	$2b$12$aTGv/ytx6c0Ia0/1nMK.BuJGZRWnvnsYNlMj2qmF9bjape9iIG0BO	Khalid Khan	student	none	\N	\N	2026-05-16 07:00:10.501902	t	\N	\N	\N	f	\N	\N	t	\N	\N	\N	none	\N	f	\N
e28e49cd-8106-4a2d-a274-368a6812627d	drfarzanamuneer1@gmail.com	$2b$12$TKlSkKR.sMCQoU2WUDjQw.CpU4rYP9qaBSwoag.CKk5Wv70YdUugC	Farzana Muneer	student	none	\N	\N	2026-05-03 04:14:36.254401	t	\N	\N	\N	f	\N	\N	t	\N	\N	\N	none	\N	f	\N
e48a1d49-0a19-4f78-bb27-e8f26279052c	abeerakainat1@gmail.com	$2b$12$Hmn0abCPyFPg0CpuvACxFuG.hb2.f1qHcD7gsntFTYN25IZJqTk3i	Abeera Kainat	student	none	\N	\N	2026-05-09 16:43:18.33374	t	\N	\N	\N	f	\N	\N	t	\N	\N	\N	none	\N	f	\N
63a38ea4-b281-494b-ac6a-8570e0df520a	reset-e2e-20260319-212132@maternalmind.local	$2b$10$aruarw63FKgsXV8y8XCgXu.9KKzMLOKRgEv8s8gASRTFHPwI7bY.a	Reset Flow Test	student	none	\N	\N	2026-03-18 21:20:47.419668	t	\N	\N	\N	f	\N	\N	t	\N	\N	\N	none	\N	f	\N
51268d4e-a5cf-4e92-948c-0c708d200d48	mindreader420123@gmail.com	$2b$10$yNbdJxHF5KVLYu2jSo2j3O1n3VYlGZK59FqNSbIi9U56mfODl9DVK	Dr. Faisal Maqsood Anwar	student	active	quarterly	\N	2026-02-07 16:13:48.926097	t	406508	2026-02-07 16:28:48.923	\N	t	\N	\N	t	\N	\N	\N	none	\N	f	\N
735bdeea-5488-4e95-8e28-b1a6bc9f182c	su72172@gmail.com	$2b$12$.4gmxOwE5lXmzUhGl5XMP.S0IiQdKyMiPPmOndCStY8pjnLzGNDya	Sana Ullah	student	none	\N	\N	2026-05-14 09:31:47.664212	t	\N	\N	\N	f	\N	\N	t	\N	\N	\N	none	\N	f	\N
040f6153-ec47-41a7-9b0f-d3c6f7b9cd5d	muzammilali2755@gmail.com	$2b$12$KPbtvx4dGmVZqtAlcxuaGuW/CXTMHpPdvZktcDKw0rXuxoISL1FaO	Muzammil	student	none		\N	2026-05-08 17:14:56.866051	t	159448	2026-05-08 17:29:56.864	\N	f	\N	\N	t	\N	\N	\N	none	\N	f	\N
412ed3e2-e62d-4a4a-8d11-e91175a84a77	aamirsohail6702@gmail.com	$2b$12$pANDjCqkp3vkV6f8.tZ/fOLCiGhk3C6DGvkQLVPuRlhHcHJQM8aOK	Amir Sohail	student	none		\N	2026-05-14 09:45:44.667448	t	461096	2026-05-14 10:00:44.666	\N	f	\N	\N	t	\N	\N	\N	none	\N	f	\N
473e5d03-a90f-4573-8eda-3c1e36c2951d	e2e.test.1776446869103@maternalmind.com	$2b$12$qxW9FWTE966PZeF8gc9g6eM2TotsBMUnkbQ39T0rR.wYpVe.b0jiW	E2E Test Student	student	none	\N	\N	2026-04-17 17:27:51.286876	t	592437	2026-04-17 17:42:51.276	\N	f	\N	\N	t	\N	\N	\N	none	\N	f	\N
7f79450a-4fa6-4b62-ad06-ca377f583d83	aminabatool836@gmail.com	$2b$12$qkIPmbjdCwaGmcqeVRbav.42jHOBIOW/AUV3aaw0CnAJfkIMIUOSO	Amina	student	none	\N	\N	2026-05-02 10:59:23.463532	t	\N	\N	\N	f	\N	\N	t	\N	\N	\N	none	\N	f	\N
1c8e320e-a700-466a-a555-3023fd1bfa4a	altafhussain806959@gmail.com	$2b$12$b.HyJ87r2w.9a7N4vBTQ8.cBiMsEowEWVjlZpTkhfmTbhdWRmGuo.	Altaf Hussain	student	none	\N	\N	2026-05-15 05:14:45.054448	t	\N	\N	\N	f	\N	\N	t	\N	\N	\N	none	\N	f	\N
2d066c5b-1e17-4330-9c6f-504c080cf66f	sm3983394@gmail.com	$2b$12$sDnA5.4Z7ZZ2937m9q2W1.gkzTpJ0x1PGb2PCZXAI/WUSTL43otgW	Sher Muhammad	student	none	\N	\N	2026-05-15 05:58:15.617861	t	\N	\N	\N	f	\N	\N	t	\N	\N	\N	none	\N	f	\N
8285d5db-4b8a-4dc7-81a2-091bd1ae4488	rafibjr22@gmail.com	$2b$12$A9bx6UUJu0i6lyV0gZJn2OTq5E7WSNoBq4Ymy3n.bqUm.RcrSCRkO	Jan Rafi	student	none	\N	\N	2026-05-15 12:04:44.070748	t	\N	\N	\N	f	\N	\N	t	\N	\N	\N	none	\N	f	\N
85fa5837-b9b1-4e69-991a-eeec0affc10f	abdulrehmanusama786@gmail.com	$2b$12$HeEHDIj.L0PxwEVMBBeQ5.EmdHokTP/pRUgaZyEpeabRcvSNB0ZKC	ABDUL Rehman	student	none	\N	\N	2026-05-15 18:42:06.375602	t	\N	\N	\N	f	\N	\N	t	\N	\N	\N	none	\N	f	\N
7c45a099-3c4f-4068-8140-8b2f7ffe828e	doctorasifali786@gmail.com	$2b$12$svkpXSwp2fmkSY6xo0Zq8eDPiO4Ld1pCJMrDvIaQ39NWOQPn21TOS	Asif Ali	student	active	quarterly	\N	2026-02-19 09:23:30.22577	t	357647	2026-02-19 09:38:30.223	\N	t	\N	\N	t	\N	\N	\N	none	data:image/jpeg;base64,/9j/4AAQSkZJRgABAQAAAQABAAD/4gHYSUNDX1BST0ZJTEUAAQEAAAHIAAAAAAQwAABtbnRyUkdCIFhZWiAH4AABAAEAAAAAAABhY3NwAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAQAA9tYAAQAAAADTLQAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAlkZXNjAAAA8AAAACRyWFlaAAABFAAAABRnWFlaAAABKAAAABRiWFlaAAABPAAAABR3dHB0AAABUAAAABRyVFJDAAABZAAAAChnVFJDAAABZAAAAChiVFJDAAABZAAAAChjcHJ0AAABjAAAADxtbHVjAAAAAAAAAAEAAAAMZW5VUwAAAAgAAAAcAHMAUgBHAEJYWVogAAAAAAAAb6IAADj1AAADkFhZWiAAAAAAAABimQAAt4UAABjaWFlaIAAAAAAAACSgAAAPhAAAts9YWVogAAAAAAAA9tYAAQAAAADTLXBhcmEAAAAAAAQAAAACZmYAAPKnAAANWQAAE9AAAApbAAAAAAAAAABtbHVjAAAAAAAAAAEAAAAMZW5VUwAAACAAAAAcAEcAbwBvAGcAbABlACAASQBuAGMALgAgADIAMAAxADb/2wBDAA4KCw0LCQ4NDA0QDw4RFiQXFhQUFiwgIRokNC43NjMuMjI6QVNGOj1OPjIySGJJTlZYXV5dOEVmbWVabFNbXVn/2wBDAQ8QEBYTFioXFypZOzI7WVlZWVlZWVlZWVlZWVlZWVlZWVlZWVlZWVlZWVlZWVlZWVlZWVlZWVlZWVlZWVlZWVn/wAARCAQABAADASIAAhEBAxEB/8QAGwAAAgMBAQEAAAAAAAAAAAAAAQMAAgQFBgf/xABJEAABAwIDBQQIBQMDAgUEAQUBAAIDBBESITEFE0FRYSIycYEUI0JSkaGxwQZi0eHwFTNyJEPxU4IWNHOSoiVEY7IH0jVUwib/xAAZAQEBAQEBAQAAAAAAAAAAAAAAAQIDBAX/xAAnEQEBAAICAgIDAQADAQEBAAAAAQIREiEDMRNBIjJRYQRCcYEzQ//aAAwDAQACEQMRAD8A9gooou7zJdRS3RRFSyiCNkRFFLKIqIKKIqIKcUUAspZRWQVspZWVUEURsogCisgqAoipbogrZFRFRAspZWUQVUVkFVBFGyiIiFkVFEABFRRALKWRspZBFFLKIqKKWUsgCKllEVFFZBAFFZRAECidFAgCKiKgFlLKX6IoAiohZAVELdEbIIpboooipZRRFALIqKKCIWRUsgiiiNkAHFRFSyCWRQRQBRQIoAoohZAVFLIoAihZGyCIKcUUARUsoEARUUsiopZRWOiCqsgFLIIoipZALIqWRUAURsogFkVFEAsiooiigiogiiKCCKBGylkERsgioCoooqBZFQKWUEVlVEKCWRUUVUAioooiKKKIoKXRQRBUQURURUUQBGyiKgCiKgQYFFFF2ckUUUQSyl1FEVFLKKA5oJZBXQUAUUVkFbIWRUsgiCKCIKiCiAqKWUsgiARsoqiKIIoaRBFCyKgRUURUsooggKiiiCWQRVkFEVFZBVRWUUFVZVUQSyshZFAFEVEUEVFEEQspZFBEPHRFRBLKWUt0RsoBZRGylkEUUsjZAFEbKIAorKIKqKIooKWRUQRRRRBAooigiiilkEUUsogiiiiCKKIogKIqWRQUsrKWQVRRUUEOiARspZBFFLKIJZSyllEEsEVFFFRFCyioKFlEUEUUsogFkbIoIIopfoiiIpZRRRUsooogiNlNEUEUUUQRFFRQRRRRFRRBRAVFEDoiCogFLIoqKIIChZFRQSyKiiCKKIWQiIqKIMCiiC7OaIoIqCKKKIIooogCIKllLIJdHJCyiKJ0QCl1FAbKWRQQSyCN0boKqBWRsgrZSyNlEFbKWVlFRVRGylkQFFZCyCqKKlggCitZSygrZFGyiqohZFRBFFLIWQFRCyKCKIIoIhZFRQRRRRBFFFEERQRsihZWQsogNlFAigFkVFLKAIqWQsgiiNlLIAojZSyAKWRUsnQiiiNlQFEVLKAKWRROiAWUUCKAWURUQSyiiiKiiiigFkbKKIIoopZURTyRRQRA6KWRsgARQRsoAjZRRVERQUUUVELIoIooogiiigQRRRGyAKI2UsgCNkVEEUsoooIoorIoIqql80RZBFRFRRA6KBBDooFFLIJZSyKKgFuiiiKCKKBRBEEVEEUUURUUUQRWBRXVV0cgUUUQRRFRAFEbKWQBRRRAVLKDVWQUUV1EFVFZRAEUDogEFlLoWURRuighdBZRC6iAqKt1LoDdRRRALKWVgpZAEUbKWQBRGyKCqiNlLIioRRshZRUUsjZRAELKyiIqorWUsqKoo2Usgr5oo2UsgFkVLKWRQRUUsoCFFFFBEbIKW6KqspZVRQFRBRBLKWUupdAFFLqIiIhSyllFFRCyllQVFFERFFFEVFLKKIIgipZBFEVFECylkbI2RQClkVEAspZFTwQRQKKIJZFAK3BAEArAKWUAURsgqIojZSyAKKyiAWQRRUAsoiogFuiKilkEUUseSlkVFLooIIooogilkbKIIiohZAVFFFALIqKIRFEVEUEUEUEUQRRUUUUREUUUQRRRRFc9FBFdHJFFEEBUsgogiiiKCKKKIAioogiiiiCyqpZE6IoKBEKIJdRRFBFFEUAURVbICopZSyCKKWUQC6N1FEBuiHKtkVOjte6lrqil1BayICqHKwcmqdDZDCFLo3Cq9K2UsrXUsoKoWVkVRWyllZBTdRLKWRQCqhZRG6KIqpZWsFLIqtuiNkbKWQVsorKWRFUQpZQBFRRFRQRRVsoqIpdRDVBL+PkuTtLbsdM/dQWll0Jvk3+dFNv7S9Dp9202lkvnyH8+68e6RxINiR8PquOeevTv4/Hvuu6NrVczj64jo3K3ktMO0Klo/uOd4m689FM8PGTfMhdCGWQjuA/9wXk8nkse7Dw42dvT0m0Gz2a8YH6ZaH9FtXmonuwXdC667WzqoVEeDHicznxC6+Lzcuq83n/4/H8o1qWUUXreJLKKXUVVLKKIqAInRFBUQKKKKC180bqoRuioVLKKKCIK1kERFEbKWQBEKWRQEBAqAo3UUEFcKWQUsijZTCgFlFLKWVEUUspZALI2UUsoDZFVujdAPJFRC6AoIqIAjZQKIJfopZFRAFEVPBAEVFLIqIqKIqIKWQQFFQKIIFFFERFFFESIooojSKKKWQc9RRRdHJFFFEERupZBBFFEbeKCXQUUQRRFSyKil0FEFjoqoqIAiFFLIIpwVlEFQjdFRBLqXUUUEsoooipcKCyllEEspZSyiAqXUUQRRRRAVEFEFjogEFEFkLoIqIN1LoWRVEJQURRUQujZBAbo3VUUBRVVEFrKW6IXUxFBZCymLwUuoIojcKIKoqKWQVVjopZCyAIXR1UA7Q8VUjxH4mqCdsSRtGJzQ1rR5A/dcWR0hPbc2P8AyP6L0H4uoZY5vS4f7MlhIRwNsl5F5y5dSV5M/b6Hiv4toLCc6tg8iuhSlgGW0IieAc0rgh+XLyK1U7cQ/uN8wvNnHpwv09PTvqBYsnhmHJklvquns2pPp0bJY8D3Atva1/1XlWQvwZRtkHOI9oL0X4YiqJHOmlJNO3KPF73G3ks+LH8jz3WHb0xUQUX1J6fHvsVFFFREVEUEQupZRBLo3QupdFWUQUUBRAVQrBAbKWURuoB5Io3QRUQsrKIK4UbKyNkFEboqWCgrdFSylsvNVQURspZAEEbKIyCl1FPNBLKI2RsgFlFLKIJZQ6KWUsioFEVEUEVLKIiKKWURRUQUQFRBGyIiiFkUVFFFLKIillFEAsioiggClkVEARQRQc1RRRdWEUURQRRRRERRRRFRRSyigCKiiCKIooKqKyqgIRUQQFVVkDogh0UCgUugKiiiKiiiiCKKIoAigigCiKiIAURUUEUUUsqIopZRFRRSyiIl0VEEVZRVUQWQuh5I3QS6KiAQG6iF0bIIooooIrKqPwVEuooogl1LooKA3UugogllUjlqrIWUCqiGOpifFLG10b8nNP3C8H+Ivw2Nnv37ZgYHHIPd2m+R18R8F7irr6ajF5pWg+4NT5Lxu2nQ/iLaUIgY5pZ2HOJuLdRz1XLOx38e488xtOCA6Rt/Fdihi2c4AOnja4/mP1Wmt2BDs6ifVYzgZ37gXueSyxbXpmizKVxsO84B3y/ReTLt9Dx3TubL/D8VRLv3Txy07TkIjm7x/l16iNjWANYzC1osAvIbG2hS0kxkhia1zm2e0Gx8bL09LtGnqh2ZAHH2Xarv4OMeX/kTO/8AjUjZS3PRRenceLVl7SyillFRFZBRAUFLKBAVELIooIoIqA2UsgogsEELo3RRujdC6Kgl0QUEUUQVFEDogN1LoKBRFkbIAqIo2CCl0EUUEVEZCyFlZBFTRS6iiIl1LI2RsioogjdFBBS6KMpZRRBVURsgoiCogioJdRRRBFFFEVFEboIIoiioqqisoiBdRFRURRRRBzrIWUuj5Lo5ooooEVFFFLqCKKKIiKKKWVEUUUQRFFRBFEFEBVUVEECKCKKiillEEQRsjZAFEbIgKAKI2UsgqornRVsgiiiiol1FFEEUUUQRRRRBFFFEEUUUQRRFFALIoIoAigigiAUCKCKXUUUEUuoogiiilkEUvZGyzT11NTf3Z2gjhe7vks7k9rJb6abqLi1H4gaLinjv+aTIfBcifadZVAtIkeL2s04WrF8k+m549+3panalLTGxeXPHstzP6BcKu27UT3ZTtLBpaPtOPieCwwtNrVDQHabtuTQOpVcYe7cxNweWXwXK52ukxkKLJJ5cOJzpHahvad5nguxsugbRiNr2iMG7r8Fq2XQMiaH27RGZPHxKzbUrWyVTaRrMUIJbK48+S4Z5b6dsIz19Qat0ZZhdSNJa4OGRPMjkuLV7HcyUyUrwYnC8TSePFt+a60LfQ53QvZjjIuHE98c04wNZ/p3OO5fm0jW3A+IWcemrf4822GUBznRPjwd4kXwlaoNouicA870D2jn8119zK2XAQDLbLlIFiqNlQSO9IjDmNI7bWcCOP6rpva8q6tFtyQWax4laRbDy+Oa79LWxzxjMNkOrb8eV18+noZ6eQBg3zCLtkb3laLadRBZriHAZ2fqF0xtjGWOOT6OovK7P/EosGSPA6PNx8eC79NtGCewDyx59lxtfwOi7Y5yvPl4rGtWVRnpmpZbctWe1kEFFQQpdC6l0FkVW6l0BUQRsgiCNlLKCIqIWQFFSyCNDdG6F0boDdS6F0boCCpdDNRQFFBRFFBRRERRRRERFC6iNJdS6iiIiiiiAqKKIiKKKIoIoIoqKIIoiKWUUuoIpZG6l0EsopdBUWUVVEUUFFEBuigigiiiFkHOCKii6OYIqKIIgiooIoooqIooogiiiigsgiogCiF1ZURCyIUuoIoooioCigoiCiq3UuirKWQuogiiiiCKXUUQRRSyiIiiiiCKKKIIooogiiKlkAURsggKlkEUAURsigCiKiCKKKIJZBH4+SpJKyJhfJI1jR7TiAPioa36WUsuLWfiWmidgp279/PRvx1XBrdr1M8gdLUPFz2YYyQPh9yudzkdcfFa9fVV9NTNJklaSM8DTc/Bcyf8AEsbW+qjIbxdJl/PiudDs2WRodPIImWvZvadn10QZsmmEhs105995vb7LlfLt1njkUk25PWvLYnSTDlH2WeB0v80l1NVydnEyG/ujER5rptijgbhFr8gL28lR4xnM2txbp/ysbta6jDBRRUx7xnmOr3ZkfYLWQQSb4RzQbNEGbxpuCcuZVHOfJm4WbwYNSrGSKirja8QtBxnQWOa62y6F39yTNxOtvkslPs51VUiSUuaxo7IBXZklbQQ3kN26NBPHks55ai4zbPtGd1PHKKaxIAxhurAdSFzn00MbN+ADBJlI1ugPMK7cVLWvc+0jZrvDj7QOo8k3AIXujPap5Gksv82n7LljHW9EGLfR7nGN7HnG/gR+h0KMErZ4HQzPZG5uhPsO5IGN8cu4GbmjFC4+0OSVNTtnPpcLQ6VrbPadXAe14rbJsbZ6kmKd7I5W9xp4O6/ZBjjvN6AWzR9mVh1P7/ZMiJqo7xZ1DBpxeP2VagOlb6TG0OljFpAPaZzHgobR8TWFrWOtC/tRn/pnks9mskOOIXd/cjPyI6c0ynijhYbF0lPJ2c9WnkU7dgyMGMF4HqpODxxCsqOXW7NvLipCHgi5ZxZ+yxGaeieNAHaB3cK7e4FHKaqnaWsJ7YGrD+hT5Yo52b5kbHg5yRcPEfda2u2Sj27JA4WkkFz3D2mHw4hd2l27DILTt3RPtNOJpXl6zZmGPf07XPYTnzZ+oWUx1VK0vyDT7be74FbmX8S445e30WOVkrA6N4e08QbhXsvn9HtWSE3uYne8zj4rv0X4hlLfXRtmb7zNV0nk/rnl4fvF6FRYINt0U0wiJdG45We0j56LoDXS2dl0mUvpxuNnsEUVFWQsiooioihZWsioFMkFZQBSyKlkQEVEUNAoiigACllPJFRUQRUsqqKXUsp5oJcKKWCllBFEULKiKIqIAiooiB5qKI3QRRRS6yIodFLqKgBFRRUBSyiiKKiF1FAVELqKAqKXUQG6Cl1LoCiqqKiyiF0EHORURXVzRRRBBAioooIooogiigURUUUUQRS6iiCKKKIDdRBS6CyiiCAqKKBERRRRFRRRRBEboKIDdRBS6INlELoqKiiiiCKKKIiKKKXQRRS6iKiKCiAooKIIFFEVAFLJNRVQUrQ6eVkQ4X1+Gq5lR+JKZhtC0yE+042H6rNyk9tzC12hqs1TXU1I0umlDfy3uT5LzdZtiqlc0mpETSc42DMjoBms7YZai72sbGw+3Le58lyvl/jpPFr26NX+JnZilja0e/Ln8lx3embTfie98vJzjZo8E+np42SFoiM7x7TjkPDgFsebR45rkDRkeQ+PErnc7XWTGMcey4i4CR2MjVseTfMrcykiYACzIaRtFh+6vA4TMxBrmRjK5GH5KSyvjYTDEHDQuLrLKbUlpzKLyHAwewDqqRb1pLGnDD+a+K/RRkz54mOwGO973GfkFYF7MsQdbpmPNEXAaBdwJKRM57ngMs5vPPLqi94aCZHX6KMG8GJwydoOSsiUgvjYTjeBzcP5ZXgAnkwsNm6Z8eiXMxk7mwNwuk8O6Oa7FBQMjjGJpOV8Vs/Fat1CTbXTRtpqcvebMaLk9AuPVTO2jUSwTMDAe1AT8j5p+1KgTSGhJLWvae31voPDiscDHPb6PIy1RCewD82n7LhvlXbWjIZRV0/o0j7Paci7VhHDzV6ScyN9Gn7IaLW9oFJmYA9tXG24OUnQ6Apk7DOG1ELS6Ros5o1eOa3pnZz4y/8A085DXM7kg08uizEvgmdJe0kf91nEjg4fdaIntrYxCSRIO7JyPI9FGU++Y6F+dVH3XP1cPdPRAowlpNVS3YdZI26jq3pzTWyZ76AdvvSAceo+6z08/ormNa7Cwk4S72ObCmyNbTf6mIepcc+TDyPiqgSRshaZ2MxUsmUkTfYP6cuqADcqaV5Mbu1HINR1CDYXQ1AqnOxwSG2Hg3oVeWIMO6xEwO7UUh1aeSilwF1NK+CRpdbJw4OB4jpzQc52z5RKxxMDj2X8WnkfsrPBnaIJLRTx9w8P3BVaecAujfF2R2Xxu+h+yI0bsk+k0bbm93wj6hZXMBZJKxl4zfeRDhzLenNXLX0b2zROLoCbh3u9CmCVlU909FH62L+61vHwQc2TZsG6x0/ZY72hwKwVAqqKdrXRFzXC7ZYzhK7gY1rXz0zAW/7sXu87dOajXtABdHvoH5EH2fH7LcyVyY9qG4xsBA55H48V2aDbb422bIC3/pya+SzT7LgfHexMLjk/2mHkei5MlBVw1Bie3eMtdrz7SNb37e9pNq09TZt92/TC7IHwK2jPRfOIKqWncWPJIGrXaj9l3aDbE8QAY4yx6YCDceS6TyWe3LLw77j1SKwUm1qapGEuET+IJ4+K3i5ANzbmF0mUs6cLhcfaBFSyi0yN0VW6gKLFr+SiCKKl1FFEBuiqBG6A3RVbqXQG6KF1EBRQQWRZRC6l1QUFFLhQFRC6CCyF1FFURFVupdVRuigooIihdRAUFFLhUS6l1FFAVEELoCoopdAVEL9FEBUUUQBG5UCiCKXUQCDnqKKLo5oigogsogiioooooIooogiiiiCKKKIIopdRBLKKKIIooogsoqqyoiCKqoDfoihdFBFFEEQVFFEXtFLqKIIoohwQFRRRBEUEUEUQv1UUUVEFhrNr0lESJJWuf7rMypbIslreDmqyzRwMxSytY3W7iF5HaX4gq6ggUpMDL6N1KWG1FS0SOiIPF8xt8BqVyy8snp2x8X3XfqdvwRkinY+oceIFh8Vx6rbG0Kl2Bjt3fLBDm7zOqyPkZE0mdxDQMTmA4bjyzT4ZZ54rUkApIiLB7xa/Wy53O10444qegud25pA0nXFm5Fuyw/OWWQxjg04fl+62U9KIhixPml4yPz+HIeCu8D2hj6fqua7JhbBTtwUsYPMs+5V9w+U3mddvu6D90RAZHAhtjriHZstN2sbhIxEeXy+6uk2DYmhmFnDnoFR0Y/8AUl4Eiwb/ADmhJJMZm9nscbHMKx65dGmw8yiKsaWt7Tt47Uu0A/RB7gTYjeO4C32VW7y59YMGt7adLKEhgLGCzjmbHM+JQZXxx00T5ZJ3DD2u0/IE8LqU1RJVMBZHu2kd4jM+AUdTCV4dNaUMNwD3B/8A1FODjYmJ1m8ZCMz4KiWZHk8Z6Yb3v+qVO/s9o4G8Bf7rLUVMdLPiY273DPW5W6hp3zAPlZ2jm1g0HXxVZOoKYQ5tie7Ee0eH6rpVdQyGKOGJ+GSYYWOPs9U5gZTU+Mjuju5XJ5Lzj5DUBleew6J5a4Dg05Zea45Xk644/a9JE6opDSvcWVcTjYnXFrbwKuIxujVQYt/H/cDjckcfMJlY0iVu0YtTZs32d/Oiu4hsjatgxNflJbQX4+asmltKfLEDvLYoZwWua05A206JMMslJVbhxwyDNjwe+OBH0+K07hsbjCCRTT5sPFpHDxGqTLC+pYY8hVwdw3yPNvgfqtMGVFoalk8WUU+nQjULZJeeFtVELSt7w6c1hpHtqqd1PITZ472mFw08FahqnQSuZI0Ne04ZGHQFAyrZG5rqgglklhMBqOTkuCUYjBUtBjcLOw6PHMLU5gpqjFYmnkyF/mCslVSShm6aWytF3QSHhzagu0+jSGCf1lO8dkj2hz8ULAP9CmcXRvzjeNT1HXmjRTR1kBgl7B4OOrD+iErSx24qOw9jrxvHs8iOYPFaEDXY/Q6nCJo/7cvAjp0SJWPqJCcO5q2ZYXaPHI/Za3ubVNEMxEE8R7DncP2KAaatphk9XVxd0OObh16clELo6gOa6NzbsPZew8DxuqNDtlTB8RJgcew4+z0KqWGoeQ31NW3LtZY+jv1TqZ4qI3xSMJPdfE7K/MEfdRo6UCVpq6O2MZvjaMz1HVZmhrQZ6drS0/3ItQ3nbmOaS4y7OlxDHuyezJy6H8y1sjMjPSqN1pScT2NH0+6BbQISJYu3Ae9G7Vo69FHFkUZlYN7Tu70Z9g9VW7jimpQ0TN/uRNyuOJH3S4pcAdLAy51fEMyP8eYVBqqWOogD83Qn2/aYev8ALLlSU09NIC0GVnBzLkjxH3XZg7F5qbMe3CM7eCc2Fs7S+DInvR8D4KxN6ceOrLiGygn84Ixjz/VdOj2hVw9qB+/YP9ttmu82nI+RVJqSKpBY+0c/CTj4OHHxXHqg6inMbxgeNCND1Rve/b2NH+IIJ3YJRupB3hxHi3VdWORkrccbw5p5ZheCi2k2VgirImzDRrwbPHgRmtcFVMx4FHUB4/MSHN6X4+a3PJYxfFL6e0RXnoPxDJC4R7QgLDoCcr9b6FdmlraeqbeKRrjy4hdMc5XHLx2HooWUXRzFRC6iAo3VeCnBAbqXQCKA3UugoirXUuqo3QWuoq3RWQSogpdUWQVboqgqIKIJdS6iigKKrdS6gsogigF1EEVQUFFLhAVFFEARUUQBRFRAL89EVFEEuogigKCiiDnqKHRALowKl1FFBFFFEEUUUQRRRRAbqDTzURQRRRAICpbooFEEQRUQRRRRBFFFEEVlVRFWUQQGqKKh0RQRECKiiKiiCF0FlFW6l0FlFVG4AudAptNbFT4+Sw1u16SiZjkkDreywYj+i49X+J5XN/0tOGA6Ofmfgs3ORueO16Vz2saXuc1rGjvOyHxXJrPxBTwktgYah/5ch8V5+WaqrnWLnTvJw2OjevILbT0AZH6/CX+0GjTyXG+X+Os8Unsmp2htHaF2sJaw5FkeWXU8VWHY124p34Sc7DMrbEJIpcMUmOIm7m2yHgnSdo2Jw9AfuuOWVrrNT0zMbT0TS1sfbte+pPxS5pJHsxSP9Hi4HUnyTDJG15DGl0hGozWWrlhiYXVOOQ2Hq23wjxPFIi9HHC6R24hxv1Mzji8r8FvDRiBf238uA/nVIhqY3UrZASyN+bWgZrRFHiF3XY06NHePigjiHnDrbgFN3YdrTklyVTIJWRGNzQfaGiu2XGfVXP5kCzC5pxvlcG8uiY29uyC1p4jihM4RYSRjJOgH2VC92INvn7t/uqyuchmBf3QcvEpEuDegu7buAvYDy4oPdicOJHsqwjib2pbOPXP+eSILrlriLyEaZ5Dpf9FnZVl8pgdTPY73RnflnwWoMfJqTHFw5n9EmUuhOCniaQc3OvbPx4lUMsBZ0pFxo2+Q/dKl9ZqWtbwRYGFwdUSx3BvhDrt8+aVU1EIie4OEgAJDBqengtSCNiMpwwYcI1fxv9yu9Q0xhiBkfvL+0RbyyXlabbj4XAiiyB1LgurUbciliayN2AuIx31txHiuXk26YYDtGslftKnHdpiC6MjQnjfqrSNa2Z1rinqWHTmciFkftGmfSOhLnFwN4nEaO/4U/qVPLRmKSS7m5sNsgeSzMW7Kds4zxPlpKwNeGNDCRpI0jvfZWpo/RaiShqCXssbH328CkyVkMlPGcdp4smD3m8WlXqa2mlp2HeYaiHJt7i7TqCts8adEzJ9BK4NLO1HJw6WVXAkNkxFs9Pk5nFw436jVJnr4pYI3xOvPGbZ5XHEEqPrY3VEczHWeRaVpGvI9UThTKiONrfS4wMD7GUDmdHDx4q096in9Iay0zB6xvvN5+SpT1tNDLIwnFSuFhfO4OoIWdlYymqPVS44x3Xn2mnmqcb/HUpJY6indBLcsIyI5pJkLZvQJiL3vjF+zycPuudPVNjnf6NhdG4hwxZYDxBH0WuWtp6mmaXzEVMfdPPofsocKrXxvi3k+7vPFnIGjvN94LZTSDaVKxj3BssYykPLqso2pEyBt5PWX7GVx4eCS4x09QJqWS7H5uiLrGM8R4IcavWNE9qOQ7qpGUcnu9D0KZTsZPGGNbuayHIh3HofqFeZ9NVNa+SVjZYR2HcD0PVB74qiMTNkZHVRjK+jxyd15Kpxq1TGKqH0qEEVUItIzi8D7hVaDU4ZGWbVsGt7CQdevJW9Izjqojhmb2Xt4u6+P2VZgxjvSIMmv77Bq08x0Q1Wlr218LmPA3tiCw5B3QhYYXSUspfEDYd5hPaYByHEdVoaBUHexHDUNGmm8H6oF3pJbMx2CqZlc+0OR5FQ0vI5kpbUUrg2fUsHtdQlOaC70iksJW5yRNyv1akbndzenU4w2Nnx+4eY6LeQKpj6ml7FS3NwGpCDCS2SX0ik/uHvxty82q74I6xvqy6GfhhyY7x5FFrN+TNTDDUjvxjLFbiORVCd/fBZlUR3ODrfdWJYYyPfs7wZUR9mz+PQj7ohrKr1dYxzJY8hIe8B+iXHI2pGCUujkbljtn5jimuIJEFTdrhm2RudwrtNaYa7ZIc67LRzW7JHdkHVcq0rC4SwyRlnec0ZD7r0eK3qKlvZ1a4cuYVDE5tg4i+jJRqfFXk125cG1Z4QInEVMJ9h4xC3itcM1DMbxSvopvdObL+H/AAl1FBE9xc68FQeMZycOnBYpaOoiaezvGj3QcXw/RTTUy/r0TdpbSoWAvYauK2TmDEPhr9V09n7ahq4/WYYXjUYgR+3mvEU+0JqU2hlcLat1HmF1aatpNoNIqGiKZouXg4bjx18k5ZYplhMntAQ4BzSC08WlFeappquhH+mJqIBowizrdOB8l1aPbNPUjA71Mg1Dv1XXHyyuGXisdBRQZgEZjW4Ki67l9OWrBQUUuqCogiigEVEEBRuhdS6AqIKIDdRBRZERUuggKl1LoKgo3UUREUQRRUUUQQFRS6iAqIXUUFkELqILIXQUQWUVbooCoogqIigog56KzNr6R3/3Ufx/VOY9jxdrw5vMFa3GdVdBTx0Rsm4aqKKWUTYiiiioiillFFRFBFVBUUUQRBFBFFC6igQRG6iAQG6iil0EUUUQRRRRERWVVEVFFFLoIgjdVcQ1pLjYAXJ5KBU9XBT5yytZ4nP4arDNt+njNomPmPQW/f5Lym0nTnbEksb2yUxkLrhwz+/Fa4pKYX3jpXcbBwF/uuGed+now8cs3XTn21Uyf2gyEfE/O/0WSRlVVA72RzhzefpdZpK4xn/TNiiHEhpe5Nj2yGMsWh7/APqOI/gXG3Kusxk9I3ZBk/vSEjkGm5HgujT0NPTADAAdAXG5XN/rnZI7A63KzO2s97w/eFtsrAIO9kA7C0W5mwARjcyUYsTZAeDDlkvOS7Wc8EPlcWkWIJ1Cy+nxxsDWYmtHstyAU0cXqZphFYOLWng3EPqkSSwvHraljuG7YbN8+a8tUVrX3OY80G1rcldGnqxX07mYS5jSdc+XglzVNKAccgeeADbrzjq5oHD5JTtpdVF4/wBeip9pwQgl9O8yXyN+HilHbMrC4y4HMJs0BuEt8+K887af8zS5K58gb3srcFrRqPSQ7UDnXkgjI4BxKVLWGWoEznG7TdrbnC3yXnTVu/Oh6U63dKaOnpJq5zxcvb5AJB2jOw2bKbacFw21LybBuZ8FfBO7O4Hmr6NR1J9oTshcGTv7RucJyWf0yXDbevI01OiwSbxosZBY58Uq5t/cHzVTp1WVYt2i/wCJVhWN6jPVcjtAE70BBpL8zILeCmjp2TWNPFU9IxXt9ly+wNZL/BVNnSMETrE5aqcV3G4zWvoEt1Xbz6p9NsWSVt5X2JyCzVtJ6FKA9mIey7mnW9bde5F2VQ935lX9MHBqz7twidJ6M8s1J5KlnlmLcPwjMmycU56bG1mWWXwRfXdm2SxF2BocYnhp0Kjn5ZxPAPFOK842xVxigazoVP6g7mufvWA2c11kwBpYXCKQgC5Nk4nONn9R8fgrN2h/l8Fzmuhd7D0WyU7nW3b8tVOB8kdA7SHN/wAlU7Rvxf8AJc90tOHWwOCIlpzl+qvA+SVtbW45mHPJwOadJWgvNm5fFYWyU7Mw1wNuaBkgcbgvupcVmcbfTP5kmNqxb91zS+H3vmmxyU1u3r4pxOcbvS7eww/9ygrrf7f/AMgue58Fh23g8roAREf3XqcTnHRdXdk9nh7ylLtDDvCXYcwsLo6feAF7y3Q6JggpsLcMpF1dHKV0v6qP+p9VYbVsP7g+JXLayA3u8hwzBuquji0DiDzus6Xcddm1XC5EgBHG6q7aZc8yCQYuJJzXHdT5XEvyVfR3H/cHzWpGbY7D9quOst/NLi2k9059flY+Wa5Lqdw/3B80YogDhMnaPIJo3HfdtWXCGmruBwyQG1ZAM6m45ZLkCkJ/3s/NX9CI/wB0fNRrp1XbVJH91h8go7axNvWM5aBcd0GH22/AqzKVj2Z1LGG/dsiajoS1ccrw5xZjHt2WaombLE6MPYcZDdOa5dSdzNu8WLqArGnfJGHNffoFuRjlPp7iLaIieIzm1mVloMtNWA4u9wJyd5HVcDYsMf8ATwSXMe43J4H9lokikiBIYZAeLcvl+i81usnaY8se3ZhqKilfakmFQy+bCRcfb6LqUu2Y5A1lQx9PIcu0MivHUe0yxziDcuOJ111Itpxysc2UYmn2H6Lrj5NOOXglevBDmBzTcHiCivN0lQYxio58HOGTNvkV0W7ahZI2Oqa6B78gfZK74+WV5c/DZ6dNRBrhI0Pa4OB0IKK6yyuNll1UupdRRURRRC6AqKIILKIKICopfwQQWugoggKiCiAqKKIIjdBRQFRS6l1RLqXQRugKCiKCKKKIIoha6KCKXUUQRRRS6g8CWRNe127JadcLjmtD9wGndieM6gA/BZ6qM0cUkzu0GWJsdE0RPc1rwezhuOgK823fS1NM57sJqJ478b/qqNr6uOR2KV5wm1rajyQcxljeVp/yBVQ97XBjojK1xsHtOnkmzToU+1J3b3eyPZy7JyWlu0iwAumsG8Cw/FcaZssgtd4tpx+aMBfKw+sOHQsJIuU3V1HY/rLcJs9h8QUv/wAQOFrw3HMXXONLHG4CU9g5Bw7VioymAaHRTxy2BOFxLfJWZVnjHWG3obOxsw24XC2x1ofAJRG7Ce0LEaLy7ahpmbDK10bnWwl1iNOB4J8hfDgwOc6N3EcOmWS1zpwjqt/EFG6TA7etdqeynDbVCTYz4T1BXn3kyxjDI8Oab25/FWbCXgF17dFfkrPCPRt2jSOFxVR26lNZUQyf25Y3+DgvJSh8EuDE8t62zV42vpmbyJzXFxxYRYjy6K/Inxx67XQoryzayofIxu6aW3vk3j4p8slUWOAEsZsRkeKvyf0+P+PRIrz8W0y0dt8guOqP9VlBsZHX4XA/RX5Ynx13rKWXnv65Mx7WmWO35m/oU1u3pQ4B0UTm3tdpKvyROFdxRcZ+3jFIxppsZfkMJ4+YTm7Z7WF1HM25A1arzica6aKwv2tTRsJkxsy4t/RWi2rSSkYJDpfNp0TnDjWxRJZWU7zlMwnhmmB7T7TPiFeUTVEIqdk8R8QpZXc+jQKIkIEKgXXM/ETXnY05izLLOIHIOzst09THTM3k0rI2jmQFwq/8U07WuZTM3pd2cTsh8NVi2NY415CSuDS4dsDjqlent4fQp1bE+pjEQaDYdmzcx8lkj2LVOydZn5dSfJctS/b1ctLmtJ0xqhrHdfkmjYz2D1s1+TWqzNiSPF3OLG8Lqai82b0h7uNvNUdM6+cma2u2XEwC98Ohcns2LC4BxOR0KnScnL3xdnvcglmW4HbXUl2bFm2JgNtXFUZsXHwt4/zJWcWblXMMrR7V1BI2+t/iu7FsNgNwzEbakZDyTm7Mhi0YHO52CW4ruvPidjf+FN6ZCMEZNui9C7Z7L3e0tHTioaEvaWtjwN4NaMypyi7rzskzibBhaQrg1Do77s2+q9FFs6BgubPdrh4DxRfQyTzNbZrm+408PFOUTby/rQ7JmfNMggqZruazLmvV/wBMY0BrmCw4DJo8SmCmY0BpuOXZz8gnP/EeRNDVPd3Vd0VThAJGEZXXq3UrACHCzD7LdT4qRUoBuWteRk23Dw5pzHlm7NqSMcrsPFo4lBmy5pJQMevNe09Ejb2pGXy0Kz1MUszfVMaANBZXmjy0uyw0hkZe5+h8UW7HkYLyPI6DVenjphHGLNaHnUhH0YE3eLkfzNOVRwYdkR3D5QLahoOZ8eS2UezIDKHCMC2ls1qmcGu3cZ7T8v3XSo4WtjHazGixllY6+PHlSpGbphBbY8T16Livghrq8NkxmNpwX+pXbqqhrpIoywnE4NIHIHMpG1KcU+0Y6kAYKrtA8A4ahccb3t6PJlqaaNm0bIg+jlGIOBYeo5rJSUrIqo0szA7AS1wPFvD5LpxOdLE2TV8WRHMJW124JoK5pydaOQ9fZP1+SduG2R2yorS0bgQ11zG869FmhoI6mkkgezDUA9noR+q7xa6ppBJEfWxi4HMclhqGhsjKxgyf2X9HcD5rO6105MGz4JwWStwk3APulO2bDuZ9zMztDJzeq2SxASioPdebO6HgmVcZkibURi8sIs8e8Oa3Ky5tbsqOkrmmNvqpDiaeXMIVmzIuxVxx2aezKOR4HzXaYwbRoXRvdgk1YRpfgQkUtm4oZxYd2Rqcqjm1Ow4amlE8DLSRjts94c1nOy4nwCphZZ8f9xg4jmPDiuzBN6DO+KR5Jbm0+8OBsmvh3Egq4Ltgk1acgw8vAq8r/V05cOy6aupt28YZNWP5FZabZ0cU5ZNC3EDZzTzXVlj9DrWvDbQynEwn2eYKfMwVodLELTx6j/qN/ZN1HFn2JBTVTXOaXUsp7JPs8wVX+hwU9TglJkgmHYeNf+Qu9E6KendDNlE7jxaeazRxHtUVTk292vHycE5Zf0ceLY8dPVbiYB9s2v4OB4jokV2xG00onju6nJz/ACnkV6Q075m+jSWjqIc433yI/Q/VCkma1r4ahlx3Xxu49CrM8kcJuwoatjXMcWP4ho1HNKbsERT7qZxIByscnDmD4LtyQP2fLG9ji6B2cch18D1WyaEVsLXRWY/2CdAeXgVedXTzFTsQ01QwmRzoJSN246dQeqtJsQCQObO8QPyDiM2HkV3ojHUUz6aoa8C9ntHeaeBCzQYqWqdS1bWuuMiO7I3mE50cU7CqWy7t04ZfuuJ7LuoPJUdsepBLWvO+H+2Ra/h1XqZI2saGTuLqd3ceNW/uj6OAWMnIF845Rqp8tXi8g3Z1RIXNbJZw9k6rXSbNY6UMmfKDobHMLv1NE57+yy1QBfo8fqktYyoyLsE7fa435FX5LUcmp2FLBKC6pduXHsyD+a81jk2dURSWkkNvZLTkR0PJerppB2qapj7JGbXZX6hVqaFrY8EpdLTHuPGRaeHgfkp8lHEotksmJbLNJGSMIPC6sdgVEc9pp8F+6W8RzW3cmleMeEsPckHdPTx5rrU72zQ7mUkg6O4tTnR5Gq2RUQS4net5W5dEqNwDjkQ4ZEFezZSsazcTjsXxNw/ULn7Q2MyW7ZAGk9ybgfFamW/Zy05dNWbu2ZZxuBf5HJdGKs3lrt3g/JcHzbr8FypNlzQN9WS9w1Y7j1Cz7wte5uERvGoPBS+PGuuPlehfDBVBwa2zvfBzH3WPcSMee1vWDLs6rPTVghGOV2O3dYT8yVthq2vN25PORa51h5Fc747HaZyr0872GzHd3PCciPJdI7SZgDZYrtcLFuG/nmuc98E3ZnYWu69l3kliCZty2XeAZtacyR48FidNdV6WneY2iSklMYNjhvdv7LRFtzA/BW05h4iVvajPiV5KGsDH2DjC/UtOV/sV0W7WlZHZwxE9dV0x8lxcM/DMvT2McjJGB7HNcHDIghWXl4KuN7A+GU079SLWz8NCunTbSmjbaoa2Ue/Frb/FejDy79vJn4LHVUulQVEdQ28cgd0sbjxum2zXaWX04WWdChdFRUC6l0UFAVEFFRLo3QUQG6l0FLoDdFBRBFLqIoAooooIigogKiiiAoqt1EFlFVRBZC6CiAqIKIOS5kUgd6tpPJzBZJbRh1yKelJ5Bv3WrA8DJwvfLVIYIt6f9R2r5txleN6g9DoJBiEMTXnIgEjND0SnpyG4bcRaT9U+/as4Ym+8g5pLxgs0e64DPqqFS0bZSLOfG/mHDTwWKo2QXSbxlfKx7RxYLfBdOVoLCHx4svYQjsYfV4nWGjzeygwN2U6WPtSMe48d3bzWZ+yjHIA58eC/auuzESwFrmYCc7hF2R77324EA/FNjiybIc2z6ftHiwkW8VRmz6yJ2MRZjPJwK7bS17XDc4fzZKNZKGnEC/wsrtHEqIqiTDjpy4E5hoH1SXUDhm5k0fMWuu6BGO5vWZ3F768E0lxbmx/iPqmxwGRPipty5jyALA20usjhg7bJHtI4YfkvVNIIu2S/O4zVN5G2R7JACHWOTez5ps08vHNLKba9eKhNVEQxkj7HPQr07oYODYwRobKos4YZYzi5g3urs08++lkjDC7EA4a80yF8sbGhjrtbweAV1X0ccri2ZszADcZ6K42bE9pcyWUi2l2/dTZpx6rG+IsmjjwkYbhKexzGuAks3CCDb5rsP2RG84sUrbC5uBn8EDsdogLDMSWCwJadOSu0cdjsTO09jiONrFM9IAcyPUyOtcErYNjF4xxzRvBztmLKf0iQPJa9mIEcRkmwKad1KHPIikF87u06q1ZO6phtFG1rh2g8EXt+iu/Z0lZCWziNssehba5SDsuoZ/s4nAZC4zHJNqSKg7gskixPw23mXxS2VJ3QdvH3GYDb2T/RJGMJNHK0u4Bt7dUlz44mkvkGlsDr3VT2tFU1EjCGYnOAuThv5pgq5nWcJMjrmRay5hrHU5DqVhY/Ts5LLPLJKC6eQAHM4nK7a4f13J9rbl12zzuIFyGHEEqXa20JC0b4xNI1OtvFc2kY6aGV8bCWNFgTcXPRdKlpopImmqDpHa7s6DkLfqryOOMc6Z++l7MctTKdXEFw+JV4dnbxwdVENIOTI/uuyYxG21hGzg0AKjQTcRMwA+0s2n/jG2hggs5pcy2dmkqOpZH9qIiNp1LtStwjY03w72TnyVsOPNx6W0t5qbRijhYBhYMTxqVb0UE3fmeS2nBG3T5fy6RJjk7pwN5kHNRWKqeWlrIo2Oz+Hko2Bz83jEbaA6LWI2tByy580IY3TXL4zGwaC+qqENgb7DcTuLuSr6OynYTLJixG/JbwBbDG3LnyU3TPcbK/3uSiuc6na9+IS7rMceHgtcUbQ07oZcXnilVMBL2mJkcrr5gjJbAcItZr5LaN0HTqgSKYOJLkHhou2O9xrotIYXD1hv05JIo2B5lOJoPUm/kgSyn1Ol9SB9Ff0ZkTgXOc1x9kHXxTMErpsWOzALAEaq5i54gfdGp6ojKGTzT4t6I42+yNSmZl2GEFxGrkI9nRiUzPxD8gJwnxW1sYDbNs1vCyDI6lDmlrmXcRYlMjjMcYa3FkjM1rwYsAItmRp8uKDMLIxHFnh1N72+KA2a3N+Z5D7LOynlMxkkmfuzkI0S2YzN3b3ONxcEC3xWq4YLNNjxctRmkvjDW64Tw0+qxvfI5jxL3Ro7mtshDM3jT2efisZeah5Fy1gyAAtZaJ3dL0Oy5JbyPyHAdE+pPo7DfTRMoQ6GXEXutbMEjNZdqt38fpMMl2Qvs5o5Hj8Vwzu3qxnGL1lLFFFBVM0PZf48PutLoztDZkkA/u2xxu5OH8sr0zBV7Okg0L22aOo4/Fc6hrnslwsjO9BsRyUkYt207GqRIxo4OFnfRaJadksFRs+V1mvacJ+nzXOqIpaDaW8e1jYqglzMGgdftNXYJFVTsmHfjz8v5mtMuVsapkDGtkdhewlkg5EarRu44a+eF+cUwxX5X1S66EQ1jKtuUVQbSdHjQ+YWidpqaLeNHrYO0B+XiFLF2S1jcTqWcFwaLOtxvoUad7qaYwyOBezukaEHQjoUzD6XTh0bvWxjQe2OSjmGsp24bCeMEx8jzHiohUjPRJ2Ss/sPN239k+6fsjtCPGxtZGztDKQc+qdRvZU07oZLhpFjbVp5+KWJfQXuhnZcOyA4O8OiqEVFOKqjEkY9dEOxbiOITdnTsqIjBIOw4WJ4gpcMZpakHC4Rl3YJ18Cq1sAp5RUMPqnntAeyeaps58LSH0NUf8T9HBZ6OaSlqNxLlKw5jpwK6GEVlICABNCOyTxWOeM1sDZYhaqiywnVw5FRVNpUgjc2oZ/Zee0B7JTo4jVU26BG9aLxOPHops+rbIx0Eo7Lsng/AqNY6kqdyTeM5sd0VZGNvp1PYdiqhyF/m0pNTTitHpETSaqIYZI3ayAc/zBa6lmK1ZCLSN/utHtfmCqbvArab+4M5Gjj+YIqlG+GqgdTTAmF4ztqHdFkZvdn1LqaXC4nNp9l45rTLDvG+l0gu8ZyRjjzI+6s/c7TpREZA2Vv8AafyPLwKqF1FMa0tqIRaqYO006Sjr1HBUlp27QpTDJ2JGdx51YeR6FVoqkskMMoLZGGxbxH7LbPEZ8U0Q9c0docHjn4qKwbPnJa+iq2EObk9vHoQtYZf/AEs56xyD6j7qkkDa1gc14ZUsya45E9HI08zZmejVI3UjDlcZsP6JpVmPBeaaru23dcNfEdEmrp3iQWw763Zf7Mo69f5yTZmn+xUDA5ubJBmD4dEYJ+16PVRk20adfEKIxAx1TTHMDHI3IH2mHl4KkXpNLWbuqs5hGQHcI6LoV1Dis9pAPsTcT+V3RJimEzTT1kbm4eBOY6hUSogAjccO8pX95p9k9UgNdRBr8WOE9x7tfA9VqYX0j7PIdE7IP9lw5HqrGFpic+Nu9gd34ncOvggvFVMljDX3LDx4gp7haPdzNxwP0P8AOK5D4XUrTNE4vg6ntN8V0KGrD2kPF2HVqITV0TcAD3OLPYkGrTwXOqtmMqLMqWdrD2ZWaO8Dz6LuzncxH1e9hf2bnID/AC68lRg3LA4je07tMWVjyP2VmQ8hU7LqaN2gmiOjuPgkskwnCAGuHA5L2UkVm7xvrITqDw6EfdYKjZUFXGXNZdvEcR4LczWXThsrCRge3eM4tcLhaqd8E1mx1JppPdl7TPiMx81gqtnVNJIA4h8Jya48Oh6pLQ+M9tuFy1cZW5m7U7Z4WE1NOZICP7kYD2n9PNKjbDL/AOWndEOQz+RySaDaM1M68cjxc5jgfJdQP2fXC9TCIpD/AL8GTvP/AIXPg6TyKbuWNpLS2cDPs5H4IQ7RdC/sSOY8asfl8kJaGpDxJQVUdbG3/bvhf8DkVmO0onO3NbEGvB7j25hc+FdZnK7ce12OAE8Y5YgupSbVa0gb/Gw6tee0PBeUMUEoJhk3RIybe4PkuhQ7ErqqPeMlhBBwm5N/otYXJyzwx917WOQSMDmuxNI15qyRRU/otJFFe+FuZ5ninL2T0+dl7G/VRBQLSCooogil1FLlQRWVbqXQFS6F1EBKl0LqILKKt1LoLKXQUQFRBS6AqXUUQRRC6l0BUUUQRS6il0HkTtqSOLCJJi62WK2ngpDtWWUgts48MbQsUu6AdieCORvorxBsdOWx7t4aMLTJqOXkvLp6HTdtCpGEmNjm37RA/dSo2oAGFsTC/PIhc6GWBzCJC+J57zc8v2VJ3wOs+KYYhqCTmppdto228RY/R4x8R8k6m2zvQAacG+XH7hcqKQS4WTnC3QEHT4rfT07os2bqdp98gEfAK6GmLacMJdjY/M3sCMuid/VqVwtheP8AtCwVkL3dpsW7eBe7QHAqsTajdWjqqdxto5tj4KDpCupi0h0gDdO1GhHVURZvI6nA113N7wC5FS2rsLxteOOGyRSMLIGxk5tu0DlmcldJt6FtVTPjLfSIDw71ii2aBtwKhhdwG8XIjpPSWuw7trhqHDVZaqAwyBstE09QTmppXpRJwEQPDKTVQktkJaX4LZjIrzAMUBG+jkibiJEkfat48ltmcHRbyGQDejIfcJpduwJWPBGZB4YVdsNmAFgvpp+i88+Kpjic8SiwzOE5qsVVNh7FZIDrnf4KaHea1mIuEzQeWeSY5t2uvG21s7Oz8VzGyVs1EZGOjeXNxYXZu8stVlbtauLBiDQT7RZmE0m3fiBMTRG4O/yKEQADiI3gXzAJsCuNDtyR8ZbNTsMoNyc236rRHta8bjuRbXJ9uaaV0RjLSSwMN+BN7KhcMd95bnjauafxBTtiOJkrpNA1puPisDtvVc3YhDYxmLkXI+OSaamO3fbNE1ri50LGA620WCs23TNcGwsdM++RjcbBecqJscmOWV8rxqFVoq5rimp3G+QufvokXjp1p9q1U1xvPR2D3TY/FcqZ0T5C1m8mlOZawYiVsptiOdZ9fNvD/wBJmTR4nVdCJ0NJ6hsW44AAWv1W05SOfHs2pkBL8NOw272Z+Ca3ZtLS+sl9e7gZMz5Dgt80ZnaALi2YdZVFICwjN5IsXF33+yjFuyGP35LGymNoGTW5v/QIvkZQFrd2Gh5zczP49VrhpWQtAZGGjlb52/VQFrZMmY5fAJsUNRExjJJHAF2hdkiHtl7hMjeJbkPirujxm9Rp7oRka8x4Wdgjui324IKluVicIWCUtpzjZjl7V3uuThC1RwyBoNRJjPIBMczEA09lpyAGd1AqOaOaNssZxD3iNFdjQ65NyBxdwVhGyPLJvQanxVajeGIsjYLEZNKCwc05g71x0A4I4A/OaTPhGDf/AJVKZm6jw2awe0Qg1gleHRR4yMt4Rogc4tY3tdgcG21WaobLJFaJwiZqHE/y60hgae0N7Ly5JLpJWPJli3hd3WDgijRNldDheGtsbYgNeuacC1hbG0Xc7K9r/NAyENGPNx0jHBFpfIL92/BBZ2FnfzPjolOzze5rWu06qTRuI7L3YuQGqO7YWAPaMRGZJRkY3MeHbt7SBkXA6JUkglBZFYO964V2UjAAcO7j4iwF0WCGbCGjGIzlw+aotCxzWDePxnmW5fD7qzhnY5Dx180XOsezmeOuQSoJjKX4YngtNhi0VFiLA4uy36pUjbgF1mt4aZplTAyRl5336A6JIp24A3NsY04E/ooLsGXY7vG2XzUc8M0sT72lktjWxsLIhZl7k3P0VJntjbeQf9vXmtxmsU7n7w3fcONgL/JbaKEAC/DXxWWJrp5TI82bwC6rSI4yP4FnPLUejw467qu5bUSbsm1wc+QWHZjhC6ajqnANdeNwPHkU+B7nbUIeCwxuw4eirtemYzaTKiwLJxmDzGX0suEbzyJoo3b/AHUr+47CQDkbJ20aUUVfHUQt7E2RH5xx+CRVNEFVHPGOxUagaB4/b7rqlg2jsySEd+12n8w0W3LZdTF/UNlvjZ/ej7cZ68B5rPsStG7YQey4fUK+y6mzrnIg2P0KyVtKabapY1+CKW8kfx7Q+P2WmXUqY4wZKSZpMEg7JA+B8istDNJBM6KUDHGcDxzW2BxngGIXlizHULFtZpjmhrQbtJEUvjwP86LNWFPmNBXbuNuJhOKPqDwV5i+jqmua2wmN2AcObVqkZ/UKK7cO9YMTD9kiAitpXUzzheO00+6RoECalzoZ21IZgZKbOHuv/dbiBX0mE/3I82lJhLamlkp57i92uA1B/Uarm0slTDUupnu3ckR7Vvab0QdaIMraV0TjhIyB90hc91U+EvpJYcbrlsjOi2VEZYTVR3c24Eo5HgQpVx+k07auNnrGCzx7w/ZWDLSOkoqoMlbrnGb3uFtq4t05tbBof7gHDqPulRgVdLuHu7Qzjf7pTaCow4oZAAR2XNKlRirKYyD06nbeQC8rB7f5h159EyB4q4Ax+QHdeOB6LQ6N2z6gGP8AsuzjJ4cwUqeBkJ9Jgb6u/aYPYJ4joeKSrYZTT7kkOGF0feHRLJ9DqY54ZP8ASyZsI4HkpPAKyESRZVEYyv7Q5FWpJI5acwyNO7dk8DVp/ZVBe30SQVdPlHe8jB7B5jpzWarp2QWrKZtoSbvYPYPMdE9kj6SQxzgHCMnjSRp4pEU/o7scYDqSQ2s7QX4FQXnh/qEIliuKuMZD328j9kql2ixrcT34XXtfiCmPiNDI2aEuNM83aeLT7pS9o0Daoem07byW7cfP8w+6odVNYWmspziA/uNbp4j7qPvWwBzQG1TBdrjo8e6eqOy6lhjw8dDfjzCzVMJoatkkd/R3m7DxB4tKDRTytrITBJ6p7dHHVh/RVkaZvUzDdVEXcceHTwKtURGYGohBdMB2wPbHPxCvGW7QhDd41tQz+26/ZI4goJS1WAvgqGnk9jtFarpLsDmvxR+xKe8zo7okloqfVSExVEeQcdR0I5dVaGqmhfuZGgOHfDtCD9lBWOXA58E7C7S7HHIjmFC11Id9ES6H3hk5vRw+hTKyAVFPezmt9lw70R6dEilmfTv3c2G9rYuEg4kdOaoYGNlIlp3Bjz34rZOHT7pZpo8ZfTXxavi4/wDb+iM9OYz6RSNJGrmDVvXwToXCqb2CI6kDvaB/6FQNpqlrW27LmnVrtD4ovDojv4+3AcnNPs9COI6rOGCd5BtT1LcjiyDv8hz5FMpp3MeWuBZKNWuOduo5ILBpb66lxHi6L2gOY6JT4mzAyUp3cnFgyB8ORT3wnFvqTv6lg/8A9Ukhs0jSS2CQi591x69UVmkuSYpIW745YXDsu8QsUlCcBvC58ftRuzczn4hdh4EoENQ3dvb3XOGbfLkgMniOe7XM7sgzP/C1Kjzztkksc+lfi/I46ea58kzoH7pzHxvGrHDM+XJesqKTtbxgDZToQew/x5FZJGR1Xq6qJwc3K9rOb4dFdktjiQ1ZpvWRm0p9oHu+a6DNtsqWBlfTx1AGhOTh5pFbsXC3Ewuw8JG5jzHBcuWOWkeN+yzTo8ZtPn9lqdt8nrI4tnbRY0OdhnGVzkSfEK7Nn1WzniSmkLhe+K+nTLNeVinNrtfkOS6lFtypprYXgtHsuKxcP41vb09Pt6WKzauE4feGXz0K61LXQVQvFIL8WnVeag2zRVbcMzdxI7slzQCD/OqvPs8uc2Ske0DnFmD4jh5KzPLH253xyvVqq8xFtSuoP77RLGMr2JFvEZ/Fdej21SVLe07dE8Hafou2PklccvFY6CKALXAOa9rgdCCot9OerBUQUuqgqIXUugKl0FLoDdRS6iCIoKICoq3RugKl0FEBvmjwVVEBupdBRAVFLoXQG6Kqoorj/wBNpxL3TiGna4LLW7PoqWMvkEjQTazTp1XSmie6YPjwkcRdSWMyMtJEx4HDJeV6GNuwoC27ZJO0Ba5GirFsJsLrsndbqL2WyF8bpXQsLd40d0HQK7Y33Bzy6hBz5ditL8THxhxbazo/mk/0d7JRZ0TbeyLtuuvLcluKMuAOeeirJE7tOjeRfgg47tn1UL3bqQ4DmDfO/wCipga6qFJMZTPI3EBi1HNdlglLSC8j4KxFpBijZi4OIH8CSq4p2XLE8ERVDgTm0OGiS/Zs8cxfFBK2xvnmSvRyOexjntAc4NJA5lIjqN9CwyxujcQC4X6aK7ZcKofWMaG2lDdOKXhe5t5MVvzAr027jIcMbx9ldjGG7RMcuim1eUjZgfcy2LfFFtt1u3UznYLhsrSCSOFwV6CU1LKuwDH02Hg3O6aTGb42NH/YqPOU9XMwNAlbhN7F4HwTJQ7A1s0Ufa0ewa9V2JKWnkhe6B0eIghryMgeeS5zq+joosEmCpnB7QYPvoPBReOyaWlbJYCYRkeIH/KVWWglY55YbZkFxvbn4rHV7Wkc8xRsFOx2QEeviVkc5rjdznvcdUbnj/rbU7TYQGxx4srXf9lmZUGaNzpSGWdYqropp3bunjxOt/lb7BbKfYILg+rfvHWvgadPPgm16xZxLvJAynhxk5ZfXJbI9kSzEGpkwj/pt1K3x0zomtbDaFg/22DM+JRfXBj8MwLG876qaS5lf0yna0AMLbcBa58Vua3dxhrhgAGQVmuBb6kWBzxfzNAtGr+2UY2U6XhE2556fNZoZBJUlj4nOcMxiGXwW3Bfjhb/ADgszjJHNaAMc3iTqrsaXWAvIS0e63RUxk9xoa3mFTNzgXdog68uipO6q3rRCGEE9pxOnRNhr2Y2nt521ussFG2KbEJZHuGjnusB5DVaxHYAzSC/ILO6GN7yW4nW437I8U2GvqIYbY3m/XX/AIRbUiUer05/usz4HF4AcWRHV3F3mdAqH0htU3cuDohpHa2aI2YeJy6lTO3ZOCPi4qwbhbjnc0H3b5BCVzXss+4YdBlc+CKLbEXY69+Ko+SOL+64Hp7PmUyOJ2AdndR+43U+KpUuZHA9oZZp1IH0CBgc0hri4PPAMOnkiWukzccDeAFrpVLCREN2wxNOrnm7j4ckWQRMkLmNdI85kkn/AIRDuywHg3iUC1pGJzsLTobg3WWubvYXtazev+Q6JNAx8QbEG5t4nQdP+EGvduLs+xHy5+KYLi4aiQ0C73kni77Jcjzh7PZbzN8/JUWviu1mfMqzA1uQ73NJp9+9h3rGxR3yHNCohbUNvcstoQdFFXlqGNdhJEj+RS3Pc3NzAxhyHMqlPSxQEtjDpZDqXHP48AnndQjezlhcONtPJVlGMdLYvu1nBpOqviDThiIcRq7klxzGpYXHFHFfIEZu/ZHN3ZAuB5IM0jp2zh1mPYTbPgnuDn2L8h7p+5+ysRY3Bbf3uSyVEby9r945nidVqIvJLY4Yszz5LnVMgmkEYfiAPa/RVrJHtbhhksDkRb5p1FThrQbdo8bfz+WV9LhjutVGYwxrGsIcTbPmnRzt9NiidmXG9vD90uVlsLrXtY+RSa2n9DraWquQJGZn8wz+hXmyu3sv44te1Y91tOKUGwmb8xl9LJlU5lfs127cx00PrA3w1+SrtUem7K3sOToTit00P6qmw2xt1GJ5Fg4n5LUcCmxiu2XLEw+sb22H8w0Vtj1dww+9x66ELPEHUO0pKcG0QII6tIWepifTbVcxpwxv9bG3z7Q+K3GK6NfF6LtESMyiqO0OjvaH86q20b1OzRLGQamn9Y1t9RxHw+aeYBXbNfG3+4BiYfdI0+Ky7IjiluJBd172vx5IL7JrGuIkxXMguXW0K6FXTxzRyQu/tTjPp/CuC6D+n7QfTg2hPrIv8Tq34rvwSb+ntq9uY8VnJY4mzKuSFzoX2dJE7A4dRktW0GCnnZWxm7Hm0nQ8/NZ9u0xhnjr4m5SdmU/m4H+dFqoyKqmlhkfYPbYAcDzRS6iRge2qj7r7CQ8jwPmkbSjcY2bQiHr4O+PfZx+GqfQYQJaKoGWbHhCnL6epNLJZz26H3gdCqh1HUNfGCRjjlb2h0PBUjMlFWGIuLmDNjveCyOpjs6pEWtLKS6E8jxafsug4en0ZZYb9gvHfnxCqM0rBSVbWsyhlzjPu8wjWsc9orWZSMFpR7w5+SMMkVbSOp5SWEnInVrhohRTmGV0MrcL2ZPHNBsgkiq6UwSm8bxkeR5rLDCaeZzZX3ezJzfeB4rJVQPo5w1r8NNIbs6c2roy0/pNK10YvPE3Ie+OR+yzVjJMDQ1jY2m8L+1GeY5eSbJYXqYxf/qN59R91WMMraV1LIcB70T+RWekBZI9k392PKRh0srBsLI9o0xp7jFa8LzwPJZ6ZzXxvpp43e69nK36ahR8Xor2hp9U7tRu93mEySQbQgM8LT6ZCLPaP9wDiqikMrqec0lUBLBIOy46SDn4hG8mz6kAOJjdnG86np4/ZWjDK+k3L3hrm9pkg4FUpnCoifQ1rS0tyIOreRH1UUurhDyaymZZv+7HxHUdFoppoqynMErS6N4z5+KTTiSgrN1IMz3SPaHMIbQp/RD6TAwbqTUDRjv0KqFl0+zajduOIHNj26OHTqmyNkaPTY4wOL2jTxH3T4GsraLdTlzha5I7zeoVIHy0M4hmLSPYeO68dPuoGSSwVsDJGyBlUO6XHIj3T0/nNZHzNrYxBOHRSMNsd+1Gf0UraP0d3pVO28BN3N/6Z/RMfE3akGKLKqY32vbHIoo0tRJTvMEoD5ALZ914/RWq6eKRgDsXo79Do6N32+6VTgVcO6JdHURXDS7UflPRNp5gwmKaM+7JGfkSqhUT5KNwbI8FvsyDIHoeRTJt3K90lPlNqWAa/oU58QYCyX1tNIMi76O6hY2U5pHGRpL4r9l/FvQ/ZQaWPZXxmOVwZO0WZJx8HdEoNMjtxJ6uePuyO18D0UliE3roP/MgXLRpIP1QFXDUsbHM/BKzIOHeB5HogQ70j00Md2MGvPxC3zU7apwJdglAsL91/j1S3ZlsNTdjh3JG5/DmFAXNO7nbYcHA3xDm0oHMeHgU9S0se3uv4s8FWZ4baGrYWjVr2nXq0/ZMOGeMMmIy7sg4dD0UbIGD0esjL2HTPLxaVAkP3Y3cpEkR7ruB8ORUkia5oLryw8HDvMP8APJSopnRwlpO8pXd17csJ59CkQump+1dskegfw81VPY10GY7cR48PAjgqy7PjnjJiaHA5GI5grQyz2F1O0bwjtROzB8FlgjqcTnbxgcDfd2080R5+s/D5jn3lM4tbftR8R4LNLSSwjG3FIzUuA08V6t7hODHIcE4yEmhHism7Ie2Oa8TzkHcHdbfdb5np5kSEZrZS7RqKV4dHI5vgdVurdih7sTHbmU6Hg5cOaCpbUGCSItkGdx7QWp2vN6ql/EW9FqiFshGeNnZcPNbYqaj2g0yU5Fw7tHuuH6rxsc7ohgLMJ4grXS1slKQ+CTPifss3FuWPR/0yWGUvjqXODR2WnL5roU+38Dgyticx5Fhlr1sVyaLb7JQGVLQ06YiMl0y2KqjxdiaLk/TyWN5Ys3GX268FZBUi8UzHH3Rr8E9eTlo4WHeU85Y6/dPaA8De4Wuj2pVwRnetM7W6kd4fK9l1x8v9cr4v49AostHtGnq29iQB/FrtVqIXWWX05XGy9igogtMjdRC6iAqIXUugKl0LqXQG6N0FEBupdRBAVLoXCKKl1PJC6KgN1EFLoOHVbQmpwJGkSxk2JcLEeXJZht5734fR2fPNYpaVr3YWxyXOnaKpUQSQSMbPG5gtlZ2q8seh0n7Vja8TmmY6X3hqFobtUYMZhwhvVcGeNkrbO31ujk2k9HZGYXyzRuvk61wVUdgfiCAG2h8f1UdteIyg45MxoCCudTUscwwvnDZQbDGwZjmn/wBJkjDnxvjfYXs0kEqaVtk2k0xSFkhDg3IPZqUrZ22RURu9JlibIDbsg2WONwmJZvQ150DhbT6oPpKyM3icx1/5yRXaFXA4k+kQm3RXbURPHfgP/cvPQyVEwN4GOLTxsk1gc9os/cOY65BFrg8CeKGndn7UsToZ4GtDgXgEZj/hay0PF2YCPEZrxzqmngBaWslOlwP1S/SppiGsBjPC3JXSzC17CpqYqSzpJREPdB1HguPtHb8czd1BG6QXBxuyz8FxJXxRG80hLzwBzKfTUtTUC7I2wRH/AHJNVN6bmMntSaeeb+5KQzloPkkwxYw5w7QGd3HCB5lbv6aHTgCTHbMufmPIc10G0bGjtt37wMgc7fZZ7q859ORT0T6kluDEOB7sfx4rpQ7Kja0B4MoHsAWaD909sopmevcSb6WyAWiOpjliOF12cgE0xctk2c0COmjblqAbNC0NZZgMlsPGwsP3VGSSNPqo2BnMqPLiC49sDPERkFWSpa2Bsu7EjQTwRigY9+MRtcfed9kqmbSzzumwh0oyuRn5JtXVTxPG7gxNtcvJ0VGnd2Gf1S3yGM2jZi5km1vMrPBVOqWZMeLHU6J2Wj27w8rfZRQDsd8PrD0yHxVI3vx4XsaOQDuCN55HXeWRQt0GpP6JU4JcGwvc03zbbX9ERpdhGpsBnbQJbp3aRZX42+gWd0bxnO/LgSL+a0QNIZiAsDzzcf0QU3JebyEgnVgOZ80zdtZYOF7aMByH7q+LB2e7f2RmT1Qb6x5As4j4Dx6qhfo934yctddEwEtNmHCOZRcCNe3JwHAIRtcGE1DxiJzaERmmpfTmlhF2g53P3WmkooKJgawF7/iVfeW7LS2NhyBPFMaQ1pucLeJOpQAgv6Z6KkrhG3W590KOnIB3Ywj3ilMdjcRG7GR3nnRAnFUSPxSu3UY0YNStIYcPb7DNQ0alXay2ep986K2K2lieZOniigzJgxdlvBjTmUt7WSvFmYiw5W0H7rI9lNUVGJzzdp1BsXdLLe1he0NALGcGjU+KIViu/C3tv+iuIwztPzdwCZu429lrRdupPD9UmR4ZkwYpOuv/AAgXUuBad4Ra3dKx0fpU0zm3Ipho9xzHgtjYCe3Pn+WysZDI4RxtsB7dtFRUMbDJiDnvkOQaOIVjEXnHUEEDMN4D90TCGjsPdj4uDlL7sBpdjk0F8kRWpuI3EnBllxS6Vs72evd4C2ZHMrQG4u285j5LLVbQigDgHefXkkQ2R7Igb8OX2XNmlNZkCGxtPfH0CuIn1frKjsRaiPifFJqprN3cZtbIALcT/EhYJpLMADG8OBPPxXUYGsjAxXJ0tw6rm008cD2xOjeXOyJstkszYI8Tsw3PTidFy8mT1+LDU3WeeV0FRTx4MLZO1i95devaKnZj3MF3x2laOfP5ErmVUT6jZDZ73mp3Yj/idR9Fs2ZaTJ5ubWtzXORnPL6W2NPjjdE44rjVZWNNBXOiJya7sHmOBVI43UNc+Bpwsjddp5tOi3bXi3kMNXGc47Nefy8/itxzrLt6LswVjBfD2HC3D/lJqGurdnlzGf6inG8jHvN4j4LoU2CtoJKeXs42kDp1XL2ZJJHIMYwvjcWvH1/VahW/ZFU1zWkP7J49CqVbPRdqteOyybtgcne0FjmhNDtJ0bD6qa74fj2m/wA4WXSqLV+zewf9RF22Nv8ALzGSVA2xB6ZQtqoheWDtgfl4j4ZrPsqokkYHB2AfzNO2PU4QGO7bX5Dplmsr43UNe6AG0R7UXVp4fFQdWWFkpkppB6qdtx0P7arlUokpKgwPAxxHCRzHArsRnf0wLT24+00+HD+dFi2q1roGVrD2orNkHNvPyPyUi72XtNuGSOsYcpOzIevAqlW8SQtk7s0Qyb77eI8kylcKmndTyEiJ4LSBwPNJpIWwVRgqAHPYbE8wdHBVGqFzNpUZidkXZtdyPArJSunjqDHOcEkZ7o1JVJIzs6vDL+pf2oj9R5LdVMNVTipiH+ohGbffbx+CoXW04aW10IyvaYDnwcEJ2CrhbNGR6Q0d0/7g/ZXo6pgYGntMfkRz5hYamldTV7W7wmB5xROGpHEeKDfC6OsojFJodHHVp4KlJLJSzbqRtpGnPqOCxVtOKd7KthcISQJGjRjuBHiujF/rqcAZVEYux/vDkoKbRiZFI2piFopdT7jkqZrquNtTAwmqjGbR/uNWimka9j6ednq39l45FZmh1LV7p3YliPZePaBUimRNjrKV0BIDJM2OHsO6JOzmejVBJdgljNizl0T5YWteKiL+2e+xujDzHQo1DTUMFSzOaMesHvtHHyWmSq+H0SZtVCBuHntNGjHfofqmSN9LDZYTeqa27QdHjk7ryT6SRksLoZBiieC1zeYWIwP2dVbouLmntRycXBRV2VUFdCKeUubJfsu9ppHP7oQvlikdDUMD22s9h0cOaZWUjZ8VXTD/AFDbb1o9oe8FG22lS2aQyoZ3HfbwQY5WuoKlpY4ugeLxuPzaV0o3R1lPu5QSw8Rq08/Fc5kjJ6d9HUgxuJ14sPApFPNNTSmGZobKzvdeqDZJUy7Ol3MzGyNdk0juvCXNTGmLaunBMN7uaNYzy8Fsa+KsptzMDY91w1aeB8UiF8uz6rdS4XA5NPCQcx05qKAHp3rI7MqwMichIPzciiA2rGFx3VSzK7sr/ld+qFTAKZ3pVOC6Bxu5vGM8j0KeAyviDmkMqgMnnIOHI9VUClnGB0FRG7CcnsOX8KEt6R4LjjgdkHEZO6Hqq/8AmXYHgsqYxZpORP5SPoU2GZskRhnZdhycw6g/qoMtRTugAqqcl8YzLBqzw5hJqYBXFtRC1vpTRm0f7o/X+clsO8oJwD24nd1/A9PFIqKVsV6mlaSzVzGnNvUdFRIJ2yxbqQkgaEDNp6dVeR5bhp6hokjcezI05eIPApckYrG72FwbVW7TdBIPsUaScODoZm4mDVhysfsqizg+mkG8cXRHuv4HoeRWyOSOSPdTtLoToRq0rNMx0bLPtNSO1J0HR3XkqGN0MeOMvli/+TfFRTZHyUdSGOLZIni4d7Lh16pzqduAyUwLmWs+HX+BVhdHPGGStxNOYF9OoKJikpfXRG8Y9tuRCBIDWtLqe5aMywHNvgeScJmTWxkNcNHgZ+YQc2OpdvI3NgqumTXePIrNPdkgBG5mOuLIO6n9UDqmBr7ekgtd7M0eZt90cHqgyobjZ7L2nLyPNVjqnMGCaPs64H909f3TgRGMcV5Ijk5jhmPEclAiSIxNBeBNAePu/ukywNe0FzDNENCO+xb2tIBkp+032ozmf3CG6Dg6SmOCS1yy+vmkq6ceelhw+ujD6d2QcOHj1XPqNiOaN9RSY2a4CbkLvAslJaAI5fajOhWZ8UkEuOlxYr9qHj/29Fraenmy58Ly2S4PX9Vqpa6amfihkeAdRfJdx0NNtEFsrQyU5EgZea5tVsJ8J9U7DyDtCtbXbp7O2vTNaWviZEXd5zMwfEcF1YWU01pGdkDO7HXaf0XiJIpad1pWOZ+a+R80+kq5qclzHubbO91LhtqPWVOz2OO8ad2/UOaMz5KsNdtGj/uM9IhHI3NvqFzqTb+jZhiPvA5/ALpMrBUSNdDJE4e7fP48FjeWJrbpUu16acBuMQuOVnZZ+K3Akm+fkuHLRU9Tm5hEnGws790A/aNGbxSemQjQHvDouuPm/rll4v47qi5tNtmnlOCUOgk4h3P+c10GuDm4mkFp4grrMpfTjcbPayiCi2yKiCiCIoKIo3UQRREUugp5KKKiF0UEUuoog81LJHMLGUse05OJIWYyb4RAVALmuLrX1FswqT1rGX3j2yNPtseOz5XRgqqNsjHYm6C7W2I018V5tO5pwHsumwWzs4ZKQUsMsdzG5hvbP6+CrU1dLMwMtjJ42K6cO0qVzAN4AORBUHPfTujc68bDxCTHd8ha2fBIDpbULo7TqI5BFZ4IEoJwnK1jfyXMdWUcDyWh8htpe4v4lI1rZElO5speBiJNybqb6OHJ7H3/AMyqyVk1Q8NxCIOOEAZfNWfTRMwt3pkkJtgaLkq7WYA/ajowWwMw9nDiJN/Gyxyzvls6omc4jO111hst1Q0tLBBHpfiStEGzaSjbdzcbuZP3U5N9YvOlz5P7NPJJbSwK0QbKrqmzqiT0WPgBm4+S9AwtAcWM3MYFy+1r9eaZDUUz24myCUjK/VSUuW2Wh2XBT2dDCJJf+o/X9FtcGtPrn4j7oUe+Rw03TORGqswBgy7JPtP1P7KMF2LrdnBHwbzTQGtB4IWtn3fzHVVc0uHYBLuZOSojmsdkWB5HF3BKp6csxHeOkJOpFgFenhfCCamRriTcNAV3ym9ozhv5og4WNze65HBLqJsbLdndnmFGi5NgC7iqva05Pz6aD4oM7KuCJwYzCCTa+X1WgYXEFwxngSMvIfqqSwwyYZJGMAbmDbRObNGI8bcmnO//ACgPnh+CU97W5AXP1UdJduJ72xxnicr+SrvGsNw1xeRkBm49QOCioY3yG7zgZbgEWuawYIQHO6HPzKTK2SbsyPMQOjGntHxPD+ZpFLSzRyuDMbGXyb/MgrB0IwGnG8i/vXGSj5STZnZHvHVVdG2Kxmks48ynMjaGh/dHvE/ZEZJJhC5odC8hx5ap+WAYzgafYAzKu6UDKMZ+9rdQNI7Txcnhr8kGOoopKpvZc6Lr08FqpqZsEYbG9z7DORx4+KYZGRsaZDbokPqXOw2u1nVuZ8AgbhZGS4u3knvHXw8Ep3rHC/aPuhQBztRhB9lpuT+iD4JTIN3NumcWNGXmVUWfHjbhd2ncGjgjT0rYGlziSRwLtFQRvpni0j5S89wjPx6BXfIADibjd7o0b+6BuLK5uG8+P/CVKzex4G5MOpP8zUp5BUR73EH3N7nhZWc8A8T9f+EAp6eKnGKNgDuZ4qz8N8UmWHPMn5pU+LBYPwu6W+SVEyU2xyhwb7Thn4IHPe54OG4b8z5LLvKmBxe4RtbwYBicfE8FpMjWkMDszlqM0btDgCA9/ADggEF5IxJKHMxA5Wsf2VybgBvZYOSJaHD1mfJvJJbCWAukkMgvlpl0VRcuJ7MeTeY5qj2Rltn2NjftKSTsjYS44WgLnl09eeyTFTj27Wv4D7oKz17mPFPCJJb6DiPHonQUYZaWoIle3Me63wHPqmxxw0sYwDCOOebikPADt45z42n2PeVZSsme8uDCA0avPBZaWESPGTrdfqVV8pqpd23ssB0+y61HCGMucwfomV1HXxYb9rsiEcZuOGQ5p7KNsmzJ2DN72kjoRmAl4DU7wtOERtLr8im7DcfRW3N3c/JeW3b0ZXXROyJWSQGN+jm28MrJFE4wThrzmxxY7yyH1Vo4RT7Rezgx+Xgcx9UnabDBtQm3ZqAJGD8w732XTFwyavxBGY2w10eeC0b+oOnz+qbs4vniMUsnYe0jAOSjaqCsopKWY3ErS05aGyz7OMkTjHMLTRmzgePX4KoXC80NU6KV13MdbxHBZtqODNotkax7GVLbn/IftZbduwETQVTNT2HePs/dK2gz0rZL3xi74vWM6gfstQUnDKjZhc0Xmh7bAPn8kdlMjcWSEvLXWOvGyVsjdh4ccw4f8K1LGKOqkozpE67OrTmFUV2i11DtBzGNtiIfF56/NNqPS66j9IkgY2Sn7TDfVvELZtZm/oY6sf3ID2urTqPoVo2U9pYWu7trIMeza5sZbif2Tl4LU2NgqHtaA6J4vhvqDqFxm0Ypdq1FM/RjgW30wHMLvYWupWyMaGuizIHI6qVHHYBRV7oQMmG4P5TouhWxmop21MQJmh1HEt4j9Fl29GTBFXx5OiIbIObD+hV6CqwFpGbHZXRVnsG06AxBw3rBijdyPRY6Cte4+quJBk4cjpZXqBJQVoMQvDIcTDyPEK1W0MwV0PZD8pgOB4OQVqozS1jXhtoZzdv5TxatbWsqoDTvNuMbvdPBWMba+hdC42uOy73SND5Llw1b4muZI3DURnC9nVUbqdwIkpqhl22LJGLLFjoas07nYg3tRv8AeCcWVFRF6QcBe0Zgavbz8kZ4XV1HaOwqIxeJ3PooNFSyOaMVERAlAu4E5kc/FLs3aMLMLwKiLOM8xxC52zYxOWuc7ttNyzryXSnjbTTNqIm2jkNi0aNKlUumqRC8sNhnheHfQq7mugl38JJjJ1dq08j0SdpUxmb6bT3MrB6xg1eOY6jj0R2fVtljwuzGhA0KAytFPIJY/wCy83wn2D7pWtzG11NuXuwvGcbzq08PLgllrWXZIMdPJlccf3CxvkfRzbkkEuzY/wB4cwr7QylqX08pBbgkYbObxH7K1WxkEzaqne3Cc5I+R5joptGlfWUxnhcfSGt7beMg/ZK2TOx7CHgEuFibZkcQmhethFbG2thaHTMHbb74/b+cEl9OK6nG6I3jf7bidPyu5jkmAHZlc1rD6l+cbvqPJWqYRBIKqH+xIfWNHslQcltVMJNyxpa8Gzr94eK7EAFVTmnqHWzvG8eweCRWUwrGiqp2n0lozb/1B16j+cEumqA4YsQy0vwVDIKqSmmdTTNDXDJ44EJVTFJRVrHxv/0r82k8D7pXQqqQbSpQ9gw1UY7J5/lP2WOinbNE+kqGHBoW8Wn9UGqdnpcYqIgfSmDu/wDUHXqOCo0srY95EQyfQg6Ptz68kqN0lFPgktzZI3Rw5jqmzUwkvVUzTvNZI2jM/mH3UENXA2nfHVtO69ocQefilslfTvBDjIx2bJDo8fqrGGLaABNjUN9rUO/QrRFgkhNPUMODQttYg8+hQZZaf/7ml8XxDh1HRAhtYA4OEdQ0d4mweOTvsl1MsuzaxrSew/uTDR3TxT5YBMDPTNaJSLujGjurfuqDDU7kujkbno5jtD4hWEXo7jNSvdJENY9XN8OYSmFlTHupRgcNHjvNPLwS4nPo6oBwwHgW+14IHvjDgZqe19XMH2+6bS1jWgg8cnNOY/dLnaR/qaYHF3nRs+oVQz0xjpYMMdSBmDo/r4qB8tM2xmpL83R6uHUdFTFFWM3VU3Tuvbm5vh06JNNUlrsiWPacxoQVqfE2qaXRgMnt/wBr/wB1Rmko8A3VT6yn9iVvDwP1CjGS0PaL8TD3Xjly8VKWpON0MzAIzk6Nxt4p0ke4aTYz0jsrHLD0P2KC392MyUxaJQLlg4+HJLinFS4gAwztyIOV/Ec+qzyNdSkSRuLoHaO4tPIrVE+OqjAkOCThINT06qaXatTB6Y6z8cUzRYE+10KjQBhjqGlj2jJ/Hy6Jl3N7FS3Tuvbn8Fd1iwNljEsRyDr5D9CoMdZTOlLXh7WSDJso7sg5Hqlx124/09Uw4/cdxHMLaYnwxlwtJT8jw8R90maOGZgL2Omi4G9nReHRalTRM0QMV2RieN2RjIvby4rnT7Ha+MyUBdvNXU5P/wCp59CuoyKSlG+jvLEPaaLOb4hNayOb1kADZDrbQ/uryHj8Ra8te1zJGjuP1B5pkMr4AMBth4r0tTTQVnqqqEl+mP2guZUbAdDcxSuwcHDMDy4LXLbUyWpNvyCzZQJAMhnYhdql2hDVMtFKWyH2XZOHgdCvH1FNNS9qWPLhK3u/Hh4KjKi3AnqFOMq+3unRtqG4ZhvLZXIs9YHQV1IXPop3PaM92eyf0K41JtaohFg8PZydwXYottQTHDI8xc2OF2nzWONnpXQptv2sypZ2rdrD2SPJdWnrIKgXikDjy4jyXImhpaxgL2Bw4EZj46rN/SnNaTTym4Nw12Y8jwW55dOd8cr06i85HtGso+zO12EcH5jycF0YNrskGKVhjFrgk3v4rrPJK53xWOkoFlFdG5pcxr3WzyCyHaE9xhY3D1BXSd+nGyy9uqouV/VJGDNjT8Uxm0w0DGwlx4NV1R0VEmCffNuGOb4pt1FFS6q5zW951vko1zXaOy8UFrqKrnsZk97RyuoXtac3AAjW6D5OdjTCo3XZLuBvwV5tjyQyNabm+mFemrY6eJ3qZpHS8cJuB0vZJbO2RwNS5xwiwBXn516fjcA7KnvlIWnqbLfRelUosa2UtHs+z811G7NkqJZHtAjhJ70uR8h+q3wbPpYXC7PSHjnoPspzamExctsdVXOFg545gZfotDdhhrS6aXD0bmfius95awtuG5dlgWWKabPGxgdfhmbLG9tciabY8JBwhzhzeuhDS01KMMcY3nQKrXk5F178FbujO7R7oIzRjYyEyHDe3QWJVQ1ketr+IuiGSPGQDG83KsDGwOLpJC53DL7IA6F0vfOFnNyUxlNR4nQQtDzq9w7R8FrfN7WgPEi/yWGeCSpeDFibxx3+/wCiDbG+7cbm7vq/vHwQc8uyi+JQjibCwb2TGRzP2UdNwHZb1zugq68QLnku/KP2QY6UjFIN006Nbr5qskzhYMZa/XM/og4SNLSY2kE54nZhUMz1bl/jmSlGogbLunSDFxjacvMrRcuAa1vx+6DY6aC7y1gfxNuKggaXt7LbN+H/ACphbELyPv46eCm8kkzb2R7zh9FTjkN673+SgEmOYZEMYebe15BWYxsd8Iu7nqUiVlTK4OjlHi7RaGkRRgYgXaEtGZKoRNRNqHh1Q6xBvhaM01oZEBGzsflabk+KuGnCXOtGw6jiVllpBLJvIfUkZY76qo1CIA3fZuHrkVYuwjiwHgc3HwCSx7ImhgdvZOds/grGna5wkqLDiGg5+ZQJfEySXEIwSPbdmf3QNPJMA1j3Nb1zJ/RbGxgDkORGdvDkiJmtGGMZcVNjO6hDGj172G9ybrPV7QFLH2Gl9si8lOqg+fs4nO/KEptGwEGcb6Xgy2Q8uaQJZWxPIwu7RF8cmVvALVDZ7fVuxN4vOiq+ghnlbLLEHFuY6dE50uFoEbC5zcg0C1v0WkMDRG0knCD7R1VHVUbXCIPa0ngTr5KlsZBktI/3Qch+quI2ukx4Q5wyxWGSASgFoLpN3GM3dUC6GWMAPaYr3wg5lWkIGVt485W5LJDRQUsu9wgvGgHdb48/FEbCMLRk1rOFksuIHZyHNUkc9zC7MN4DilsqGuGCK7pOIItZUOFm9qQZckDd4B0Zyy/gUBETS6Z4vbUZWVN+JDeNzSOhGfkgk1PHI0b3uj2ckLBrA2EBjRqT/M01rC/OTs34JT70794/tRnL/Hqga2wAu7K3HU/skyyucd3FdzuQ4Il5kBtlHzHFNhhDRicMLfdBzPmpsLipcXbms9w4X7I8uaa84RhHadwHLxRJyyybdYq2qbFZrO045BrdSenNVCK57GnfGbDI3O+llhL5p4y+c9kmzRxd+yY+M4hLU4XSHNsI0Hj1QgZLLPvXWeG6X08FuEm62UFGWtuRrmcl0DJu2G7bXGvRCnlAaN4wMzyss+2oJajZs5gzaw3f4cbfdcMruvZjOMXZCKzY9RKO84Ym/wDbwVNlVZAbu2YgD2j8lt2D6umEf5bLIYDQ1z4Ixk12Jv8AidFiRzyuzdqSW2rCcGAysGf5hn9CqbZidUbKbOz+7Ad5/wBvFP21GZ9mx1TO9Ad5/wBvFWoKiJ1O5kzmhkjbZ8VuMF7HDGGMs7pbbyysmbUj3NfBMO7KMB8Rp91h2fjgLqcm7oXFg8NR8rLq7Rbv9mOkZm9gEg/7dfkrWQlYKrZ88I72G7fLMfNYNlyFzADmHDTyTNnVjnP7Mbi3n1WQtNNtGVmjWvDgPyuzCRf9ZYmGkqpaUHKJ/YP5T3StW0ZQ2Wlqm5tPqnu6HNp+KO2o7GCtj0Hqn+HD53CELW1lDNTONt421uR1v8VuMurR4Z4HQvHZkaWuHjqsmznOglEcmb2OLXeX7JGzK3sBzmkP0cB7w1Tq6QemMlDHN3wtnxcP2y8lA3bsWGelrRp/aeejs2n43+K00EwuWuPZIULRtHZk0N83N7PQ6j5rk0dT2GOec25EdeSDrMawiajlF2EFtuYP7LzlOHUlVLSTdowOt/kOBXdrXvBiqIzyY49eBWHbFIZadm0oXHeQizwPaZx+GqkX22mJtXQOhZ2nN7UZ68Fk2fO17d3KMUUoLXt66I7OfgwPYbADPwKG04DBVtnjyinzH5XjUfzqqgxh9JUmF5uGnsn3gdCl7WhEcrNoR692Yc+R/nROeTVUlwPXwi7RzHEIbOqhUl8UsY3bhZwdx4Ipmz5y1zSNEqtjfR1jDF/ZkOJh5cwlmnds+VsTiXROzjc7Ujkev2XRjwVlKad5sTmx3I8FKOZWxvieK5vdNhO0cDwcPutlLKyeExPzjeMNuR5pcE2EuhlYMQu17DpbiFn3LqGowhxdC44onu1PQ9R9ED4JJKaoMbhaSM4SBxHApe0aYU7hW04G5efWNGjHcx0KfVgywCpiF5Icnt95nH4aqQVYdGMID4nDNruIKDHTD0p/r5CGH2Wn5rXu/wD7SpcCNYZRoOo6LNPTmke17CXwuPqydR+U9eS2MArabdOIEgzY/gPBRdF000lLPu5CQQbYRpZCvp/R3Cvp+4f7rRz94fdZpKrGdxPHgqojZpPEcj9ltoamwLH2LHZOBVQzDFX0piebNcOy73TwKyUcr6aZ1JUsBt2Xg6OB4+CMlK7ZsrSw3pnXwk+yeRT5ofToRbsVMebHcxyP2UGSpids+pa9pd6O8gsdx8D1VaqnD2el07bv/wByMe0Pe/y5rXSyxzROoquOzHZFp1af1WMxy7MrgyXOMn1cg4joqDSVuYcCBY/Dp4Ju0qU1TTXUjXekMHrYhrIOfisG04RBIK2Jlonn1rW6MPAjoVp2dXFpa5hN+FiqJT10E9Puqg3a42Dm6tPAtV2ukoalocRYZtLdHDmEva+zC9p2jQMxPAvJE35uH3Uoa2KvpdzN3Tllq08woNcsQf8A6mnFpNXxt49R90XVUUzGuefWuOEP8OfRZmuloJwySxGrHt0eOnVMraQTxmriZc/7kY//AGCDQN1UQOpahuKN2RHI8wue5s2zKgMe4Fuscoya8fYrbDhqaZrGkNlb3T9ks1dPKx1JVsLs8JYcnNPTl5cE2A4srnbyI4KgC19Mfj15KCWOWN1LVsNhw0LTzvzWSemloHYiXSU7smy6YejuRWtrmV8QjlcGSgdmW3yI5IDGJKJ7SZMUZ7sjPoeqbJCH+upmtE2ro25B3UcjzWBjqiGUw1DG4Rk5jjk4c+qNRvKR8cuM7g92Q6tPI9UVocI6p1w4xVDcg8jI9HD6LM6aSNzoJGGOThiz8xzC0gNq2hzLMqrcdJB+bqo17J27ipa4OboT32eCIvBStnis6V+9GTXuPa8Hcx9FaKSWkkMcreha7Rw8EgbyCWzwLey8Zh3gfsuhHJHXR7qY4HDuv1sgzyw4Gmal9ZER6yF2ZA4+IWQtaz1sJJj1cw5ub4cwtPrqKazhhIOTm8fBXmoYqqdtRT9ioBxGPgeo5IBHVMMNpbPhI55g87oseYPWROMsB5jMdHD7rBU0rnOc6FuCVuboTkHfoVehqXRklvYOjmfZNDqxuaRigxWOZZiz8kl8Ac/e0to5OLNGk9OX0QwCQbylsybUsOh/xXPFQ+pqix0YgkabG+h6HqorcyR28s27Jh3mc0d1HK47pohl9pvA+I4ISOEjmsmZgeMmycf3CTNLgkEVSxzJT3JG5gj7qKe4NcN1UMII0Ojh4HklHHAcRs+PQOGngU5ri+MsqY7NtkQfmCksBhxPhcJGHWwzt1CrI7lswvEAC7JzHd1y4lb+H4pnuNK70afiw9wn+eS7LgHtL6ewkAuYxx/xP2SYp5Ki8c7cOHie83otTLQ8jNFW0s5jqYCHDMEZAjn1TI6iws4Z8ivVSAsOCqjbJCe77vl1Waq2LDOzextxM1sO8P2W+WzlY5tLWyQ/2pHNc3hfVdil26wi1Syzh7bNfNcCp2dJBd9P61nFvELI2pcXbuwa4ahymttctvcxbSglGEOxgm2eR+ByKpNTtqDvKdwYRqALnzb+i8nCQSHvzaM7E8V3KbajC3DP2SNHtPbA8QudwbbRUVFFlIz1ZyLmnE3z5eabFVxytBjeSeunknUL2VLe3OJjwcOy7wPApkmy4HNOFgY698Tcj8sitTO4ueUl9sL8TySforQNkkcd3d1hfLgl1ods4gySOfE42GIaeK17N2hBC11rPx+006Lvj5Y43w33DKc1L7iN5bxN0vBUB2QcXaE5qS1csTrxvxB187DJWpDM7FKH4QCbi+q3K52a6W9HqHgExvt9VmkkfG/Dd7SOHJPm2hM4uYCADkCBosMFOZqiNjpn3J1y8VZUaC58hxOc91hqSrMnkbrJfkCrSSU1NUtp3h7sVg45c0rbcDaSAOjc/E/TonKGr7Y4tlyuGKZ+4YeA7Tv0C0Q0kdNf0cAyHV7jiJ/RPfRtnc18r3AA3sHfI2WhjQ0YIm266rxPbctksp22xyOy5FGaYhmCmZ2ufJXfHY9t2InggbRizuw3XCNSjLNEyofH68MxXyaDe6XuZocT6mY4DmIwLZcltG8ePVsDG+87VKniGB4DsTyLc0F6cuLLxt3TODjqml8cPacQXc3alYIYpIm+tksRoOKbDHJI+8dj/wDkcge575O0SY2Hi7Nx8AowDMxMDzoZHahVmhAjOKTFJb4LNSx1YuHSY2n6INuBrDikdiPJLnqAAAOyOnFHCxuTjid7oP8ACUqSkZKbzd33G6/sgq5xcd2ztPI9nUK8ceAYTfGeWZ8yrta6NoZHGI2e605nxTA0MF35flBzPmoM7JxJO6GGM9jvZfcqCoaybDKx4A9snLwWhxe5vZAjbzKU7dMcDhMsnM5jyCmxHyyPaTEzAy3fcPoNUuGRkoxRnePI1Iv/AMJpjdN/dJDeV1YGOAYWAE8gtQQMOryTbO3JLZLE9t2uxAGwA/l1H45jYnA1Xa5kLey3G8dP5ZBWWnfUsALsDVdrBBGGQt3h54lmO0HPdaRuBufZ5q+OSVvYGBvNNCznDEN4cbuDQch5c0mSSYNMkhIboAM7JjBgLWXxyHzTC1oznd/2oFsLtyX08YLrXLnaqU1ZG4BrnYpeIt9kamoDWG7hHHolw4GMLoWAF2rzl81BpfINZHYRwF9Uo4nBpBMcfIDXyQZJFe+LfycyMh0Vy24LpjZvunh4pIm1cReMMFiOLtR5qxYGxlmbpCMyBmqRVUEpLGSNaG8gnBzrepbZvvHitjJDTvp772qcWcGalaMN22zjZ7o1Pis4dLFPYR70k2x8lrGehxP+iqK2sB7DRw5qsrHyswxv3bRmTYZprsMQu9wJ6pV3y2vdjORGZ/QLI51QyUPDYC8vOWK+S6ETd3G3ePxPAseChLIwbWvwA+yGB8jhlf8AIT2fMrSKSSPlOCPJuhk5eXHxTIqZrRphGp6pjYGs9bM8ueNOTR0H3S5Zi/u2DTxH2CgpNTtkBYO08jjwClJRx04bg7b9S4jIItf2SbODT80iStJl3MYBba2LgD1P2V2rbI5kfPEfMrPg3jryAOPBnBVbSvqHB73lrBmeBP7J7gGNwRAX5arKufVRVTJhNDMcfssbw/VbYjLuWuqXNL+IHd80ueqipi0vOfvAadEl731A7DhHHrj4qshU1bhJuobPkPPQDmeSRHGWEva/HUHV7uA5BEhsQs3sM1JGrkuS1rSOEcfuDV3iukiFve0ktjdjccnO68ltpYcLANeBPRIpIQDvHcO6OS6UYcyOzrHEMzbposZ5ad/Fh91WoaBG4Ybm17Dj4LbskCbZ7mvaW4w4WIzslRGOngfW1Lw1oBtzK0bPqfSDvT2Wu0bbgvNa6536c+geYXNaXdqM4CPA2+y1bYYC2Gp5dh3gcx81z653o21KhjtMpB56/O6201a2up5KeRjgHCwPI8F0k6cWnZ+CSndG7ukWPgVxKSk3NWYJi5zoH4bDlw+VltoKsRH1vYIOY5EI7UDPTY543BzJhhdY8Rm35fRajJVbC2l2mx7MmTt+Y/ay61HOwN3ckgBI05rBXg1Gy2zM70Xb8h+yrssMIDn9snPPgrEKph6HVvhP+y+w8DmPlZJ2/eKqpqiO3rWmI35jT7rXtiExbQjkbpM3D5t/ZGth9N2NKI+/GMbPFuYUUilp37QpXslksx7SMLdL2+yw7Mk3UzQ8WNy1w5EarVsWoaCLE4TmD0S9pRGm2tiGQnAkb/kMnLSe15x6LtGzf7dV6xvRw7wWuoj9J2c/CCXxesbbp+qXVQvrNml0b7zM9YzLRw4fBM2TUtkiD2aOz8OaIpsp0krg4TBjOAGn/Kz7Th9F2oHAZTDeNPJ3tJrGeh7RfBpG444+gPBbdqQOrtm4423mi9Yzy1HmFQmld6RC6B+eViOR4FPoaht3QSi+LIt5dFg2bKwPjlabg6notm0IDHMyqZ3H5P8AHgfNSrGGSE0NUacNvHrE7m3l5LWxzKmmkppD3s2kcCNCmVMX9QoLNyqGC8bvoPNcmjqAXMPtA2cOSgtTmR0zmS+qc02eAnVlO2jqWVMAtDKcx7rv3Wivh3sbayLNzRZ494fsjSPjq6d9NIfVvFgTwKBjTHX0pgkdguLsde+E8FlaXU0pjebOaQlRGSmndE8ESRGxtxHArdVRCspsbQDPEOGhHEKKTtEB0ba5moIEgPEcChEW1FPuJHHAe68nNp4eSFBO3C6GUB8bgQ4HiDlZYJ2zbOqTA9xe0H1b+Lx+o+isRuppHU827c3C+M2PgVmq2Chqmlv/AJWXNn5DxChNVXAu3dnsbk7gRyPXknUkEFXA6GYEsfkRxB5qokdQZ2GnZFvGuGFwOjTzHVK9ZSzhspGJuYd7w5hKAloqkwyWfLFoeEreYXRfGNoUlmkCQdqMngeSlalVkibWFs9g6oYM7e0OfklVjAwGrYRguGy8geBCTRVBgmwZgtNiDqD+i6bg1zHTNa2SNwtLHz5qCUs8dRTuhnGKN4tYarnSCSmnNPKQQ7uyDRw5hZayCWGqbEBihebteeI5eS6zaJlbQGHE8TNvgkJzarYgVkAqKUTwEvmjbYji8deqVBNFXUppaggBouyTi0/ZVoqmSCbBI0tlYcL2j5I7SoAzFV01jG7ORg08QilRyiKR9LUMDy7sFvBw5nouXVwO2bWbouJhk7UTnanoeoXYdC3aNKMFm1DB6snQ9EhoZtOlfR1IcyVuhPeaR9/sqy07JrLMDcxewyS9qbKdTyem0DQQ7N8bfsuXSvlpp3U04DZGcRoRwIXpaCqa5hY/NpyI6JYrHTzxVtMGyHsHRw1YRxCWJpaCpDHkAjNrho8cx0Q2ls99JI6qpBjBzc0e3zP+XPoq00o2pTGCWwA7kje808LdOag0zRMe0VNMLHV8Q4dR05qGJtawPZ2ahoyeTbF0Kxwulo6ncyjdyR+0zMOHMLeIQWukhAzzdGOHUfdBSlqCMUUkYt3XRvGvPEEiroXUxNRTFz4dXN4x/t/CrS075244pf8AUN0Lzkeh6KlDtFzJS03jkbk+M6jxH0KoMconYIpyS3g4at6hUD5KacwVLGOieLWObHjn1T6ula4mppAC7V8DdPFqpDLFVwGCpJw6tcNWnofsgw1lE6mIqKZ7nUupGpj/AFatow1sVg4NqMPYkPHoeiWN/RzNikc3C7uvHdeP1UFL3pqQE53dDxH+PRBamqTG8w1MViNWPyBHMdFofHuhvGEvh5nvN8Ry6pRwV8G5keGSjuSDgeR6JdPUy0k26kbhcOB0cOYUHShqGSx7mez2HQjh4cllqxJQTNI7TTnG/n0UewSdqnyk4s4HwRgk7weC7g6N2iBzSK7DvXCOa2UjdD0cOPikVMBxhkzdzMNJfeHVF0BiBliJki1Idq3x6LTFPHURiKobiZqHcR4IOc4vicGyAsdwc3Q9Qmu3VS0MqMTXWymZr580yrp3wRkSAS0pza4ZAH7FZsBjjxj1ket+LfEfdBoD3Q2grGtdH7D2nLyPNPswx2eN7T8C7It/QrHDODGYy0SxO1jdp4hOYXUzTJATJF7TXjtNHJw5dVKoyMDIiJPXUrsgTkW+I+6TDTeiu38Tt5EPiOjh91sjLXsMlOCbjtxE3J/ZVawsBkpSXO9qMZkeHMKBZiZN6ymOCXUx+94clV+7qXesxxVDcsds/AhQhsrsUFmycYicj/ifsnNEVSC2ouJG+2O8P2VCmudD2ZmB7Dln3XfuqVFNK0CahJdHq5t+239kxwfT+rmaJITo6+R81ZrHtG9pXlwGZF8x5ckRjZGyU9nCyXme6fFc/aWy4as7uZpim4PGp/ZdzBFU5jDHNxI7p8QgWkHdVEQc0afqOSsy0aeGmoq3Z0oa4B0RPZce6U4TkZSNLHEe19l7CakswmwmgI0IzH+QXLm2a18RIYZouubm/qF057J+LlR1UkJBY+x4Fdug/EDwAyoGMcyuJUbNliu6mdvGe4eCyCYsOB4DHcQck6rfKV9Bp56eqYd269xm1x1WGs2TT495FjpZD7UQu3zbp8F5eCrkhsWOI+RXfoPxBoyo7X5hqudx/i6R0NZTi+7NQwe3FmPNq20lRugWuYGxus4i+Xx5rXDJBUDHE8XPu6+aTV7PZUREPBjLst7FkfP90mVidX251VVPjlddlgTkb8EkV1iCCAed9E40dZSZbv0uH8ou4D/H9Fn3ME7rxvEb72LTmAfsV6MPLPtwy8X3G9m3gzCwiAlvEnMpFbtX04R33TQzgCuPU7Ke1zn7vI5hwVqSkDYiC3XwXSca5Xc6r1UEJjPrJXzP5K75MOTjYe6qsEr2gWEd/ZTWRRw9o97nf+WXiekoMkl7owt/nFWbHHHr2noyTB2WK46G3zSQ7G7BHn0GSKvI8nN5sOQ/maqC5+UbbdVf0dpF5n5DggHsibaFgaOfP9UBbTNHbmNz4omS4LY+ykvlDTiec+p1/RAyve3sjds5lBYiMZyOxHxv/wAqk7J5Yw1sjYR1zuPBBmgwdrnJx/ngmMnjBLs7DMucECqSnliveTE08XDtO8Fp/t69geOZSRWxl5YyRoOlyUwBgGN7mnjiUoJkce43COZH2VTZub3XLc7k/wAsqSVILSI3sBtrdZWyxl2OWXekdqzrBvkPumlbDjkNxk06E/ojjZCOyM+JPFZnOlnB3YAadHm9h9yiIXxDG+SxtYuIz+HAK6QySR7zbmMv4FaOBwF3ntH+cEKR+8BLIyGA98jU/VaDKGG0YxuVRmFAHz76aR7WjS5+qfiABZCL9UuTtZyOxH3AkUz5pHuaW4I76nQXRVm0kQkMrxieeC0bs4bvdgYi2QNJbD23DV50Crk993DeO6cFnYBkPdhZb86DGYndkb1/F3JF27BxSOvb2RZDevf2Y22b8E0bVkYwubJNaVzcw2/ZB/VVfG6Wxe0tZwBGfw5J7IWsGOTxzSZ7VOTAANA4LURXEyL1UDfWcmj7pjI3Pzd23choEYoGwssRZupHEnmVbeX7LBZvNUJ9HhY8yvs56u44hmcI4BEjtiwxPScckczRZkhOeEXy+yIcyNzhn2GcuaElVEx26a9mPqQi4OcCZNeDQVjjoaaOYuiiEkpzuXaX+SDVlbHcO6qrjiBtkOaENK4vGJ2L8jRkP1Wh+GNhxC7rWHEjyRP/AAmOC/azHUJjpd2CGWAGp4JMAmAc6aQll8m/v9lckO0sG8wPoikelxySYXPdc5Zg2KMr2xC8jiCe6BxVJWOecELGk6F5PZb4/smxQCHUulnI7xFreCBApjM4SVBdHHwj4n/Ky2sgY4NxizBm1lvmiAA8SSWva1gcvhzUeQ/N/ZbyGvmptUc/GbNLbHLEOCo97Ym2aO17vNVMzSLMLbDiNAqd/t6X480iEvjD3B0tnYTfAeCEjCXguvpkxulk3O5w6+9wWeWdsbXFrw22rluMkVccRALyXyDQg2wrNEx8xa18hcb6uOqXPK+R1y2wOg95MhornFIbk2N88ui16awx3XUp6Z7RfzKvUSFrXhuI3tlbj1StnOmiheyV2MX7Db3Tqms9HDaNkeKSQB0r3aC+dgvNld167+MP2hSNqdil7jifE3eNdfln9ENnVEcRZd9mldGjs+lLTo5pBXDpIN24xu1icWHwBt9lNOO/tb8Rlraijq25tN43+Oo+620F7XZYAHpoU3aNG2s2TM1rPWBuJmWjhmFztlVO9gY/FqMwukYtV2hAP6m4PbibIBI1v1HxWmWgjdQyGBvrGdth8Fp2pHvKRk7e9D9DkVbZ8mJpF9VFI2XKHxOjObSLfFYqe9JUug13LsLf8T3fkjGJKWqlhjOUb7NP5TofgjtWN0U9PO92JsowOPUZt+48lqM10dos3+zS8ZviO9Z5aj4XStlzCzW6tcE/ZcjnQi/HI/NcmSOWkqnU8RIwO7JHI6H4KaIRu/Qq+Wl1EbsTerHLZtSIz7O3oF56f1gHMcfkkbVp542RVkj2uDCGEjQg8+t1q2dKXENc/Iju9FVK2RUi4BOTgpg9Er3RNHqpPWMH/wCw+K57ojs+ukgGkbsTOrTounVH0mjbM0XlgONoHEcR8FWVtoM31Kyoj/uwG/i06/qtezakOA5EBcmOaomkAilbHGRYh2h/ZSHeUVSKd72uY2zmkcWlUWnb6FtF8DcoiccfgdfmupSvbVU74Zcw4G3Tisu2IxVUTKmP+5T9q3NvH9VloHvlwuY/C3UqB0NT6LM6OTJzDhcOnArLtONsdQ2tiHqnm0gtx4HzWzalI1ro6q2JvdefofsniBtbRSU8ur2lp6G2RUUvZdVgdgJ7D/kl1sXodWwjKF2bcvkuXs+aSO8UotNE4se3rxXoWGOuo3U8pAOrTyI0SpGOtYaqlFRH/ehFnD3m8fgl0lYKZwJNmEIUkz6acxuFpGnC4JNbRbiqE7M6d57APsnkfsinVTGsk9KiBELyCW2481piEdfSGnldZwzY/keCNI5jojA/OKQYSFha11HWbt/ejN7j2hwKir0srqacscML2mzm8ka5no87aiPKGY3I9137rXVwmsgFRA3/AFEYsRwkHI/ZZqaRlRTup5v7Txrxa7mqi08B2nSxyRuDKyLNhdob6g+KRSTCGW4YQCe012oPIo0xlppzFIPWMycRxadCFqrYN/C6oiHrGj1rfeHvD7qoVtWk3jPToWnFb1oOp6+P2S9nyvieTI/FG4Ww9E/ZdSQDG8YhoeoKzVURoqkx3vE84ozz5jyWWm2oijMe5c47l+ccnungstNUvhlwTANmac28B+1loppmubuZs4zl4JNfTE2af77f7UnB45H7ING06T02IVNO0+kMbmPfA4FZtnV4F2vcS08+HAo7Prd28Nc21zmL6FK2vSejyemQtAheQZANGH3vA8VWTKukdSSCppv7BNyP+mf0KNRCayL0ukaBVMHaaPbCrQ1sgjfHha9hFiCcjfUITNk2fOySMEMdmw8uhVVnnhbtSmbJE9rKiLJjuR4grPSVbmkxyAskYbOYdQuhJHvQayjbaUZyRD2uo+6y1MLdpN38DgK1gtme90PVNo6tJUtkaY5HHCSLEcDzCxVdJJTzmamZ6xub42+2PeauUKqUjdgFkjMncPJdzZwdURBskrwfZdfuqVQLY9r0eBr2iZv9uQeyf5qslLUTU0xY9pZNHqONuYTaqnkpJjUQNs9uckbfaHvD7rQdxtiDFEQyZo7Lvseios4tqG7+mHb1fE3j1asdVTtr2iSNwhq2A4JBoeh/KpRPNNU4JGGORp7o1/4Wqspz/wCbp+0PbaPqE9Dm0de+OUxSgw1Eesf3HRaJN3Xv3lK283ttHdd4dUuuo2bTgDo3iOpjHq3jj0PRJoKuSKQQTxmGoj1YePUdFr3EboJ2SRmGdpLHZFp1b+6RJvdnVDSXXYSCyRuh8Oq2z04q2GeBtqgatGj/AN1lgqmysdDKzHGcnxuyIP7LCtDmMrHb2AtZU2uR7L/Hqod3Wx+j1IdG9nddbtMPRZXQupnB4cZIT3X2zb0cFuZgqwBIcEoHZk1J6HmorGN5STCKcAH2XDRw5rSQ2o7JOGW2UnHzVpGiRhpq2Mi2jr5f5NKwPbJSPsXiWH2ZBkPA8ig1RbynmG8c5vGwPeCfNTB4MtMLOI7TOB8P0SIZBIzczXc06OB7qS+aSjnEb3ZHuvHHqEGunqi3sajRzHZ/JGSju7fUEjmnV0RzI8D9lOxVNAleGyWsJW6efNLfvaSQYgAR3TwPVEZJoH9t1O20wzdDoD/iFSjqpAS6MWeD5jougJm13ZcCyUaSc+hVJaV5eQQIqkcScnjr1V2LNohJ/qKN5ZNq+HgT+VaIJhM7IiGdut8gf3WKCdzJPdkBsWnL4rZLGK+PFGcFQMrn2vFRQnY2dxv/AKepGl8sfiPusjnvbJu6hu6kGkh4jw4jqmRS3Jpa0Ou3R57zfDorytGEQ1bd9Ae48HTq0oJHUFjSyduKM6cWu6qMDWOJpJC/Bqy9yPA8VRrX0rTiDZ6N2QJ0H+XVBsHo5E9O4ujGdzk5vj0RDLRTkuiIinOrR3T5cCrNqbjdVEdreycgOqJbFWAH+1L7wyB/yH3VZGYhuappbbJr2jP/ALeYQFhc128hcXNHs37Xw5K7WQyPL4SIpdS2+RP2K507ZqaYNewYHZtlaciOQPNboXQztG9aGPGjwc/MJpds9RTMkeSxjoJ+drNd/kPuFzpKWMS7mtp2hxyBPEcwu9Jk0NqASz2ZWpErA6O07N7Acg7S3XoU2mnmazYk8V5aImeLXd3zHgucyb1mFwcxzdWuC9S+GejO8jxzQaggZtH5glzUtHtRo3zAJP8AqDULpMllrjxV0kDg+J7mnou7RbekawCUB9uI1XHrdhy0wDonB7NRdYN66J2GRuC3O9k1Ku3t6fadNVSholEchywninTUcUucsbXHhIDb5heLiqd2L9kk54gMx0XVotuzQC2MPZydqsXD+L/42VtJWQsvRu3rDwcLEfYpTzGMEdRE+nkta/vHmujR7XpaoNbI4RP65Ba5KSOeEtkY2VjvZAFvFSZXE1v2zVNTUMZhp2MZfLE43I/VYovTJHBjXmUHV54HrwXSZRi2KZ1zyCuZmxtwxtaAFWCW0oay9RJe2ZAVYqtzcQwNa0ZBwVJnh5u9xt108kGMxDs9lnvFNC7pd4b6dXKk+8EYMfZPM6lOZGPYzPvFNEIb2pTiPLW6Dm0skkgc50Lo7ZY3nI+a3MijDMTxiPNxy+CrLMHOtGwOt7QGnlwVXZhxkcMs+9ks1TDU37MVnEZB3AJeEZulfiP0UZdw7GG3vOyHxTWRgdp/aIzxP7o8kVjfR78ENcWRn2yOPQJ8cLKaHDd7wB3jqUZ6gMdha10khGQaLn4ckg076jOqs1vCJt7eZ4+CqMEuKR7mU5a9xNy8mzW+LvsFspaNtw6R2/kGeJ4s1vgPuqzbO3kjXQktc32W5ABb4oWwsAkdvHe6O6PLn1WtoIAGVwPzkXA8FcPa1wDW43njr/wsdTEJ3hz5MDW6rRFM0RhsIuNS79+Kypxa45yuLRwaFne15IbD2I+JPFXxXN3jE7h/wqOdwzufZCggPatiD324pUtRHG711jfgNEhuy42VHpMkj22N8IdcIS0wmed1Hd50cXd34rWk21+kNcwO7sQz4C6XJPNKLU0bQwauOXzWUCKmc30l29e4ZNYOyLdF0mPaWNe45ahuQsp6UqljfISZY7HmTkfitE08dMxznOZkNftks0lW6UmOmDX2yLrdkefFU9CLgMUpc8+1bPyHBWds1dr/AEntyPwxnRnE+J4eGqcxwAwxsuQuVJSCjcx5MjmZksvqVup6g1LLMbhZrcaf8q6DXkX7faPIE2HlzQe0loL3YAOHRSRzWCzGF7zyVI8VgZbPlOjb5D9VA1hAF+634JJijEhl043uc0w5ntZvGgHBXijLnZHE/wB7gPBULwmTUOa3g3if0CqygBk3kjnNbwaCtdmxNJc67lne98unYbfVBd8oBwR5EBQNsQXXvyHFZBRnfCQyPDb3wnU/stBJ7rRd3RBWYsBu+1xmBfL4c1VgE7u0ez7vHzVzGAC57gT73uqtLA2NrgwYWONy45F36BQPtZuBmn0QAANm5u5n7qlRvnNDYXsjYNThzIS21Lid00Xtq4DK6KgDabEY7ukcbk3N/wDhc+Tan+pEb43lpOHXK62vdq2I9s5Fx4KjaKFrSZAC8ixK1EaWNvGHyFoHAZZJLpN8Ra4j58fLos1Ps9sMhkc52EnJjjf4psji84GXI5W+qIE8wADGfLj4LO9gZaSoAJ4RjT/lPJbTgnvynjrZY8RmcS83z0WoSbqQxGaUyONjpa3BbTE9oaw8TmpTtNuugBHzTpLkYGNxvIvh5rj5M3s8eGptnZPhrIw3N57VvBaNstAqqeX32EX8Df7rk7KEj6h00mTy/Pou3thrjs6OZuW6e1x8D2T/APssaYzu2nZU+JuBZq9u62p0maHjxGR+yzUc26c0uNmjitO1J46mGOeJ+KWF1y38pyPwyW65R06GbE23JcJ0AoNoy0zMoyd4wdDw+N10KGUCS1+9ml/iFhvTVkeVju3eBzHzV2y1wWlgfE7ulpafBc/Z7zDMGO78bsLvLROoGOc4Fz73HNJ2kzcbTY8d2YX/AO4a/K3zRTdpMDayGYf7rS3zGY+RKtJF6bs50QF5AMTPEZhWqnb3ZjpB34rSfDI/JUopMDxyv8kSsFNWzyWFNZhce093A6ELZXwTMijqZnBz4zZxA9k6fNKlh9F2nKz/AG5bSM+/zXXjDaqkfG/MPaQemSVZ0xtY2v2bNSuOT2lo6ZZFcHZtVgwY/wC4w2c3rexXU2bK6GUwyd9pLXfdcva1P6Ltx5HcqQJW/wCXtfzqrGa17XIqI46trLbk4Xjm05fVGgha57HOe92HQXyWmiayppnwuPZe0tJ6FYqB7o5N3IfWAljh1Cv+KU2H0Oukgv2WOu0/lOi0bUY+WjZUjKSE9ocwdfgm7VjtuKsatO7f4HT5rVRhskLo35tLS0+BQ9Ofsyj3s7ZHzvwH2TqenggIjQV8lLqw9ph/KdFekxU0r6d57UTsIPTgVs2rE6emjqmswyQd8flOvw1QaqdsdZRvp3nIgjwCxUT3QyFsuUjDgcOvNXoZ8L2uxXBGiZtSLBNHVs7j+zIevA/ZZHK29D6LtKOsZ/bqew/o8afJPoHASAuOInitk1ONpbMkpXHCSLsPIjRcXZ8pthcMMjbte3keP6rX0jpbbga3dVkbbZhjz04fon0pZU07oJDdrxkeR/n3TmNbW0UsEhsJGkeHX4hcqllewlkwtJG7C9vXipP4tMjO4mMUgGMGxH0K2VMZq6ds0bf9TAL4febxB+yrXx7+nFTH/chFnj3hxKTQzFjhbPDrnqOCINDUGN7XtchtCnEErayMjcvN5ANGu5+B4qV8W4nEzD6mY3v7ruI80yCtjDDE9uNjhZzTyRSZAaqn7DT6RECWDi5vEFMoqtrLG4wnMEadfisJbLS1bcLi5rTdjx7Y/ZCviLS2qiNoZT2gNGO5+B+qsTTZXRNgeKmIDcvOfIHl4FMjttCkMDnEOGcbjq08Fn2TFG0PhnkfI2TK50Pl91WUSUNXgccr3YeY5rLRNNKRI6KQYZWGz28iuzA9lXDupTY8PFcqup5qsishaBNG3MD/AHRyPUDRGjqGyxMkjdnx5pRpqqQvJcwWqGd4e+OabQ1DXsMMtnMeLOvpystMX+qjBAO+Zm0jj0WDaFOcJqYW5D+61vP3h90lZrPNSHZlSMBLqeQ3jJ1H5T1W+Pd1dM+Ca5hk0I9k8CstHMZ6c09WcTHZBw08fFUwy0kwZJYnVp4OHMfdVWVhnoa3dSmzozw9ocCFqqI924V1Oy9/7rW6f5D7rTV0o2hTWZlPGLxk8RxaVjoKvcvsTZ7TmOXRVAqaT01oqqbKraMxfKUdeqFFV3dcHCR3mHmtU8Ho7vSqZtotXsZowniOiXNT+mg1NLhbVNHabwkHXry/4RXUjcyqjAvglHdcfoVwayCXZ0zqmmYd3fFLCNWn3m9OafS1QDjYWdx6FdXs1kO8jd69oz6hT0OXCf6tFj3oEozjJ08PBaKKqdA8skBa5uRadfJc6opX7PlNVSNtGDeSIasPNvTmunCY9r0ofG4MqQOeR/Xx4K+xKylEIFVSkGFxu9g0aeY6fzRJlih2lCGyXZKz+3M0dph8eI6J9JUvhe6FwAd3XMdkCkVlP6K7fwOLqd584zyPRT0FwOlo6hrJwGyjQtPZkHMH6rTWUnprN/SjDUAZt4SePVSOWOpg3FRiLD3XDVp59Ck+uopQHkFnsyN7rh06qoRS1LmOLXMdcdl7HjXoQnuhMfr6cOki1czVzPDmE+enZXASxOa2qAyJ7sg/N1WWnkkhls1ro3tOYPeCitsVTHUxYZjiYdHA6eBWd1OInnEWy00mX5T49UX05lLpqfsSEXdGO67q3qpRzjtMeARo6Nyisk0DqFwka4yUztHnNzeh6LS0sqYRHKHbs6PBzaenVajBaNzovWwO7zHcP1Cwvp/QwZogZKc5kXzZ+oTYS5slDNgmIId3Xt7rh06rpw1EVREYagY4jlrmPNKhkimgMUzBJA/UaEdVgqYZaF2J7nSUh7k3u9HclUa5qV9C8Pa8SU7j2Xjh0d1W2CVlVEIpyB7shWKkrbNMZAcx3eYdCFaaERespzii1LCc2/soq9XTE+qm7MgyZLzH6LJBO+GXdyDC9uo5jn4LowVTZIt1OXPj4EDtDwSqqmbhwyHHEc2SMzLfP7IgzNjr4sMjt3MB6uUDMdOoSWSvp3+j1jOxbgew/qOqz4n0z8MgBHsvGh8FrbM2eLdyNZJHrgJQMDTTjeR3lgdqCM/BwRbTAO3tJf8ANDe//tP2SoRJT4nxGSaIcD3mjqOSeHCwlgsHHVg+yikljXYn04AeO9Dp8ArRVTJGGOcYgPZvYt8+aeDHUGznCOb/AKnPo4cT1S54cbsE/qpvZkbo4fogjiY25gVFMeBHd8Rz6rO6E23lPeRgzLOLfBBsstJLhcMPLO4ctbGsm7cPqZ/d9l36FUIgqwLg4XMORYdAFobC13apnlwOsRzPl0SJRHO+0o3NQMsdsz/kEh75aZw3jbZ9lw7rvA/ZBs3ZDyac4JB3onH6FZZKSKcuMIFPU+0wizT/ADmtEVW2ZoE7SSPbHeCdLHjYDN22+zM3UdCoObFPJTy7qoZgcPZcMiOfIq02z4Kk+rYAXZFjhkfBa5Wgw4Klm+iOTXg5D9CsklJLSN3lO51RDxGjm/qrscWt2DgJ9GfuX+67ulcuTfU0oZUQljhx4HqvZQVUc7Q2TtDS51CFVQxyRucQ2WIcHcFuZnp5ON4fo6/Rb6TatTSuG7kNhna6ZNsZju3ES4cjq3y4jqsUtBUQtOEY2jgr7a5b9vWGqjlccUgc4ey3Jo+5Qcx8jQScA4F2Q8l56TaU7ThjLW4s+yAmx19TY3kJ/wAtU4sad5jWgiw3j+dk7dtvildc8sslwWV87eLT0TXbUke2zoxhHK6nEdZ9XY4IhfyVHgvHrMhpbEsEO2I4m9mmt1BQO2I3uvLESOQKnGq6UbQBZmfTRWMOLOW1hwI+ywt23CG2ZG4eYKh21F7rxzORKnGq34msyIJPAamyXM10wAc9zGj2W6nz4LEdsU47kchvxNlP6rE4ZtLPJOCNjA2MWZZpPstFifHmriInObstGeHn5pEe0qVrRa4PNwRdtGndpJiPUZBXQ1OkwsAacDUvNxdgv4hJZPHJm6ZluWL7p7XtdkwsA53Cz2EejBzy+YA20bqPhxKeWYQ3PC3n/NFezRobnn+vJVdIyPN7mOI5fZRUwl3c7I555quKOEZHtHrqqPmfIDhsxnM8UGwlxBzJ962f7BaZB4dKe2cLOVrX8+CaIeyMXZYNG6edvur3ZE3OziNSqt3k5NjZh9vD8rfdAqV0bQWAXcdG218lnj2c8uL6iQhrtImn6n7LotZHFkwXfxKpLLHDd07rcmoJCAxp3TWta3iBoFlqK+OJ4ZEQ+U82k2QfLLVZAthg4DmUBhYCyBg/M4KwKbKyZ5M778Cz9T9ltYSYwSAyM6C1sllpoA2Yvla8OJ0A+a1SWf2Q0v4hVBDmgHBYN4m4UAyJ0bzI1SqakETi49uR2gt2R5c1pIA7T9R4KDNMZgBhjaIuIJzPUqQbRElo2R2eOVwr1AkmZ2OyOf7JdPBHTMyF3ONzbvH9kDjcgvkOQzJ5KNGJmJrm4NcyM0JH9ntZng0JUNNZ28c0Fx0aDdo6nmguA+VxxEtacgSM/JPEeBoFrdBqUuUPDCInAzEd854UiH0lr2xtm3nFzyMgorQ+NuMF4xO4NVr27TzmNByQNogXOfd3G/FJLgWmSbstOYac7+KCSPdMbDKLi4ZJZOLsQ5DibK3akzdiazg0jUdU5jQBZh14oEtjw9loNzre3zTCA2+M3KtZrGk3sRxWd15CL5MVRnMMss2JsrmtvdxJ1TZpGQR9khgtniNrnmUuqllY28T89Ay2qSYBZslXqMxEDkPHqtaZYaqokkd2QWx8XHIu8uXVbaSPDEOuVln7M9VjcQ2+Q8F1YIA5mY6XFlM8tR6fF4991ZowhziMgm0E0Ylc53eOXguZtWtFPE7DroPFbvw9EGxMcc3O18V59b7dc7JNRWpAh2jMxvtEP+OvzuukI/S6KeG3ZkYR8Vj21EGV1PK3uvaWnxGY+q2UBwgMvrktR53DorSQML9QLOHy+q7jKWKRmIsYCW4SbDRceZu52nUxHulwkb4O/e67lF/bHgrUcuifhAubPYSz4ZLbUyQ1mz56Zrrvc3LXUZj5rnVVPu9rTMzs+zx55H5hdWjp2SR3dHd7cwqVh2XUNfA1xyOh8Vq2zFvaETDN8JDx4aH5Zrlxt9G2lUwg4WtfiA6HT6ruUxbLTljz2XAg+CrLJs8iaMsdK6zm2LTbMLmscaOWSnd2nQuwt6jUfJPoP9PUOidm+NxafEJm04mx18U1spm4fMZ/QqqFVI6ejZU4CH05/wDidfstuz5fZOlrJdGGuZJC/NjwQR0Kx0TnRPMLu/E4tPishu1I/R9pslbkJxfzFgflb5pO3YvSNmsq4xeSmdjH+PtD+clv2pH6VswyM70Xbb4cfksuy2RSsdFLch7S3X5KwYtlVLZS22X6Jm04dzWsnZ3KgZ9HD9rLm0sTqOpkpybOhcW36ag/Bd6ZhrdnSMveWPtN8RewVySfxGs9Lo3xX7EjSCeRWTZsr7N3uT2nC9vUJuzKhpOG+Thkfsk17dxtFsrf7dSLn/Ia/KyQvZ21mbuphqmnsyjdvPXgfqtez5Q6N0bhiBGEhZGStr6J9PhILxbFbR2oPxSaCpOQeMLwcL+hGqomA0tTJSuN8B7LuY4H4LpwVEdTE+ml7rhbwWbbUGKCOsj7L4uy8flP6H7pNFGwljsVgM7X8M1EOp5TBPge7ttNnD+dFm2tBuqxldE31cvZmNtD7JWzasNhHVt7o7El/kVopRHVUr4pRdjm4XA8uqkVmo5cLmuvlfNZ9uw7meOvZ3TZkvjwd9vgs8ompZXU7u+zQ828D/ON106TBUUzopxjjkaQW9CqMlLVNgAcXtH5b6grPUlsM4ew4Yn5sy05g/ZZhTvpqyWnlOJ7DkfebwK6/ojK7ZslJezrdk9eBQGEx1NO6CQndyCzbagjQrmNpnU9VgmLt7GcwNHDgR0TNnylowOFnsOFzfBdSppxWU12D/URDsnmOSAtijraMxHCHDNrhwPMfdc+keIHyU1S28TuxIz3f+UyimwuFzYcQnbWpd7EK2IXe0We332/t9EGJzJKOq3bjj9qN3vBbaiEbQoMTR69naYevELNC4VdP6O51nNGKGQn5JtFOYnWsWyA4S06+B6pUI2ZU90A6nPok7UgdQTtrImf6aQ+taNGO4OHQrVtKmEUrayNvqpMnflPPzWqifFUwOhlaHRPBBB43RpzBUSyNY6nyue9cLqDG2FtS1+NwHbHNcv0d+zqj0Z5Lo9YnHVw/UfRdShmAOE6HIqWDnzwMjBqabOJx7bP+mf/AOlaIXMr6c073Frv9t49kpVXRimrA/EfR5NANOrUDAKaxjPqjmwn2Oh+ySppamkkgl3T24ZGHMdf3R2jSiQenU7c9Zm8/wAw68+idIwV0G8i7NVGNNMQ5H7JNDU7p1ySbGzmA6LURKGrAABALXa4tLHgUmtpTSWnhJNK45jiw8vBDaVL6I/0mFo9Ff3raMP6fdMoK4YN0Wh8TuybnJAh1P6RBvIMqgC4GgeOR6plBWkm4daQcOXRWkgNFKDG4mndkxx1B5Hqq1UBlaaunHr2/wB5g9se8Puo06ZtM3fxCzxm9vMLiTwu2bUCso2OMLjeRv8A0z//AErTSybxu8jmwnW41HRbwzcNE8Qc5g77ToCfsiASzatKJI32nA1J+RWemqcBdE9gt3XtcNRxBCz1kElC51Xs9t4wLvjHsdR05q8BftODGHsNUwZOGjxyP2VFaqnNJeaO7qR3E6xnkeifDWRugMNR24SLC/BLpaoxuML25aPY469Cs20aIwEVEF30xN3Diw9eiC4xUrt6MboMXZc7Uf5LcHR7RbgecMwFmyf/ANSXRGMwbqQbyN4sRfVY56Z+y5w9pxwuN2SHQdD1UDcT6eUxvBa9v8+C0OYKsB4IjqBo85B3Q9Uxhi2jAA92GQd14F8P6hYpN5SSGKVlnatzu13UHioLsq3ROdEPVTWtYn6haoC/AXsZ29XRAXDvBKbG2tjwy5SezIdQeXgq00zoZt3Jdj2nz8fBNKpUQiNrqikF4tZItcJ5gckaeoa5hAaJI3izmHMEclsmiLr1VKTvG5ujbq4cwuTNgeXSUf8Ac1fCMvEj7qgVdE6lY6Wku+nscTfaj/UJmymhoZJK8lx63y5IUVUS7E2QZag6jotclJvAZaUBrjm6PgfBAyppA1hqKXue1GPZ6jor0VXdu7cA6M6tPFJoasseQTmDYgptVSXBqKQYhq6Iajq3pzUQK2nYIicBlpnZEcWnmVyJYpaSxxiSndpIMrdHcit1JtF2YwkC9iDxW50AczeU7Q5p78RzuOPiqMlHKYw1zXWA43Wt0O/9bSu3U+pYcmu/QrBPSuhaZaZpfFq6Mm5b58QhS1LiQb3GRuOAQntvAjqRZvqaluTmuyJ8Rz6oxz6wVMRcBlhOVuvQpgdFUgGQ4ZR3ZGi580id3aFPVxlribMlbnfwP2WVMkibuu16+A6HRzVhqWPpW7xtpIdQ4cOjuqvvqiimGIDd8HjuuWtlRA8byNzWPdk6J2juiozwTsrogJrhwyD/AGh+yZYw9idolgOQ90/ulvp4XvL6Y4H+1GdPJXp6rC4xSsFtHRuQImpHxgy0rjNHqYz3m+HT5qsW1BEL301DuC2SQOb6+ke53Esv2h4dFnfTU+0O07DDVDLeDQ+I4+KIfTTtqHl1OMLrXLHaOV2g7y8J3Eo1Y45HwK58cctDJaRpa6+R4OXRa5lUwCV2GThI3gppWSvhieb4HwVHEtHZPVw4+IWEvlLC2UtdAcnEE4SfH7FdScFoEdUC5ujZWHh0KpFAadrnxtY+J3EDI/5BAqjpI91hiecXuk2I8D9lSWjdi7RcDfUD6hPFOx5x0uFkvGN2h8D9kyOoD7wVLDiGVnd9vgmzTw4mwStPNOdVtDgLrWdgxuzbO/zslu2DKO5O235gu2zZHpIJTm1TcJz+ZVTsCfXesPkUuPYdU4EsfHrzKi7a4pWkXxfNF0wBHbd8llOx69nsNd4O/VUOz69uW5d5EJs6PlqbaPB/yAVnVLCxpGG7uSwyUFZ7VM8eSQWzxuAfHI08rFWG3REzez2beao6UF176dVgfOWZXc0dQUv0k+8tdm47cdTEWk4nhxB4INkDjd0mDyK5DJ3C+QKsKnPu/Mps6dhjmm9qll+tx9VcNkIyka7wcFw3TBzh+qayoa0ZY7+IU2O02SWId8/FZpK+SaQxl/ZGWvmssNeC0MOXC6QHhswc3Kxug7UFQYyLzPbyWobSluBv78lyRUOLLdrP+cUBI4ewHdSFNpp249pOa/E98UhHvBPdtpzhnurcQCvOOqLf7bPmo2aM9+I+R/VOl09G7bEeAiJgY4jXVIZPTv7c73vdfIWuP3XEa+ndYAyNJ8FpjMLWuBkNvBNRNOq6shc4h8uFnADj5haWVdIwkCZg8AfkuEZ6VuVsV+iTNO0lmgaSOCaiaekG0IC7C19utjmnNlicP7jR5ry0TxiJ3zbjS5IstbZnYcNmm+XeGaaXT0m9jYwBr2uPCxCqBvCC8gjkD9F5l8rossPXRSOvzuVngmnoZqgk7qBoJHt8B+6DRloXP4rgGtkOUbX/ABKs2sqW6veOl1eBp3ooiSXXzOrvsnCzGng22ZXCj2lUkWOIDqQrjaE7zZ78QHC4TgjrYd53RhZz5oOcQcEeeXh/wuVLth0bTvcN9RYcFUbUkfGcEeEe9xKnGq65yvd2N/BuiAABxyG7uHRc9lW0sew4w4jvArRBUxRxNxvc93FzhopxGotubnRHFh90dEp1VG5t2PxdLFBksIGIyMc7iRw6JoXcQc36DPCfusj6xry5rGFzRxYE2SVpOMkOHBt1ikvFJG8m2HUW7q1Iy2NfZgdgLL87XWOskxtwNde2fksNdtPC5jISx0j3hva6ldJkbg3EaaF544ZCPqremsMd1kjgD8zoOi2wSyxNawDE05WKsyrEeXoTm9A4FEzxk4vQ5gRmDkuOV29cy1NNVfsxkmxpBa8gO9LjzH7IbLOCMNAvlkOaU7bEjozGYZsBGEiwzCpBWMivhinA5WWdOdlrobaxSbO32Cz4nh9ul7H6pdFM3CHXuABcpUm1opKaSGRjwHtLb4c8wscbqRrAx0krmjIXBWoxwaNqSNfVU9THo8GN2XHUfddDZ8nYAOq5Mz6KSNwZIWuJDgc8iNCtFNXQw5mUOaOIBUhcK07XYW1FNN7pMZ89FpoX2u2+uSwVm1KappnRx4w82LTbiNEuHaUEcmIucQNRZXGJZV9rM3W2I38JmEf9zT+hWmlnwvDedgsG1NoQ1jYd2XNkY8OuRbK2fgkRxyPvJC/E1/G+nktJxrdWObFtQSNP94Yh4jI/Ky0149I2e6Rou6L1jPLUfBc2VwMEbSGtkjeHNw6WIz89F0aSugZHhlkyORGayvEmhlxYXtN75/olbXHo1cydue/Fh/kNPkkwvZA+RokxRh1mfmHBP2jU0tbQuY2UCQEOYTzGg81U1Wyg30kZJeyzhm211iijNFWugGeB3ZPTUJuz6yGFo3kjQ+wNwVNpVNPLLFLDIC4dl45jgVU1WD8QRCDaVPWA+rmG6efzDQplLtBtM5naGeoHFOr30+0tjyUzpWtkLcTP8hp81y6OncxjJZgxso1GIHJa+k1TZHbqrIhuGuONlxwP73XRqh6bsxxaLys7bBble36LPXmOaGIsc1s0R7reIOqds6YR3EmXgQstcaXsuVjyJGnLU+GSVtK1HtEPc/sTjF/3DIqAx09c9sb7secTBy5hP2mIa2jfGTupGdpjiRkRp8Vf9NNFDO6oidHu8UTxhz43XPja+lqH0xdcxnsO5t4FP2fVBjG74BjgOBH2TNqSwTtjngcDNER2feHH4JU4106ZzZ6cteLteLFvMLmxvdRzuikdnGbEniOBQoqtsMoa9/q3auvp/CmbSlp5yyWORhmj7Lm37wOvwWdGqbtKl9LpRUQ9qaIXaD7Q4g/zVY6SqaQHYr3WygqhGMDz2NcV9Fzq6EQ1+9hOOOQ3cGnJjuJ8D9VU1Wra1IaiBtZC3FUQC5b7zeI+6rs6pBwFruyQDda6KpDLB5t1WKpphTVjvRxihk7TQP8AbPEJDVM2rBu5GV0XdPZlH0Pxy+CbQ1OHCLi4smU8uOF0UrCWkEEEcFypIJaWZzHDExpsyQcRzQ03V8AgnbUM/tv73jz81oop8rE5FLp6uKWmkimLSLWLSdQsjTu5LB+9Ze7X+8Oai6Z6+m9Dqt212CnkOOJ/u8x5aqz5TKA63+pYO0z32810poYto0ToJHWt3HHgeC5UELQ5pN4ZoLtB6cj9lrFLHSo5WVEBbJ2o3izwsAElFVmJ2eE3aT7Q5qNIgqg9rvVy5lo0YeXgttWyGqprb5jJ4x2DfUcv5xRdHzRN2lSBmLDI3tRvOoPDyXMp3va4seMD2GzmnVv7cU/Z87mAY+zbmU7acUdS0VETm79osWD2xy8lDVPiDKqmMEh7JzB5FY4rskdSztxN0cB8ir0MhYA2Rtup4J9cYJWB4kY2ePke8OSysjODJTzg3FhmCPaHRUr4MYNZT5uH91nP8w68+iO/jkpnRzSWA7TXX7pWWKufG42w38b5LUOLTRVLS0wTAPjkyz6rnVtG7Zs4IJNM82a4+z+U/ZXYbvc+OxFzdg4HmOi60LPSaR0NTHeMix4XHNVnjSKSVkkLoZbuikFjbgeaSWyUNUGOdijObHjRw5eKQaeeknMRDpmNzY8C9x+q6MLTU05hnaTHwNtDzCUkrDNEKWX0mH+w7vMHsnmOi6FNPkHDMEZg8R1WeHFDI6B4a5uhI7rhzHTmkvY6jmAYS6B3c/IeR+ykasbX3p5A9hO5cbDp0Kyy0nochq6JhdCc5IWcObm/dPinDmmN4JjfkW8bc1GF1LMMBxxnMOaf5miaR0UW0YA+EgTNbdrgcndClUlQYnljwLjJzCNelkySn3UhqqYWOr4RkCOJHI8/1V5oBXRbyI4ZgO9wd0PXkiaZ6qkNPeppwTFq5vFn7JtNOyeN0MzMcbxYtPXil7PqnxerdewOaM8UeJ01LbPN8Y1HVvTmqaLmp30Lwb4oCbRyHUdCtsUjKqLdTtcG27Lge009EunqBuzFMA9jxZwPG6zzU7qN29a5z6c6PPsnkfsoJNG+ikAkwuYT2ZB3XdOhV5GiujDXOwTDJknTkei0wzNljMcoxxu9k/VY6mndSvDmHeQHIO4g8iPui6Xpp5aaXdvBa9vA6nw6KVdCJHem0IIk9uMZYuo5KpLaqPBKHNIya/i39lWCWWmmAcMJvc20I5hDVZZIjUXmphhq9XR6CUD6FWo67M2IEjT2g72TyW+upmyj0uAYZLXewHXqPusMsAqxvmWiq2jU5NeOTuvVVHQfEytaHt9XUW7zssXj+qRDUy00uB92OBvYnP8A4WOCombbFFIyxzBbb4cwt+/iqI7VXZto+/d81F1Qq6P0m81LhbUalpya8fqqUVU+N5aWujkbkWnvDy+6zsqhFLu2zMdnZtjqujhZVtAqAY3gdmVti4ft0Q00YWzWfG7DKeA0P7rDUULXvLoPVTjNzDk136H5KonfTz7qWzzqHMN2uH2K1x1DJ2ESkNcNHnRDVc6KUxyFjmuY8ezbPxsujDUtezdzgPjPAn+WWWsdHKAyW7iMhK03P7hY2uliOQxN5g3Fvsouq7TmYIrO9fTnnq3x/VcuvoXRWlhO8hPxb4rbTVQaQcQFxmCr+lRB5MfYJ1bbsnwUXVKp3xVMbBIcL2iwe1SbEx4ZVsy9iZufwUlpmS+tpxhk1LOB8FanqRI0wVLA5oywuFrdUZ7LaZKdwkD7svlI03H7FacEda27cMM/vHuu8VR9O+nBkp3b2E6sOo8uIQbC2ZpdTksfxjJyJ6FVNDjdF/pqyJz2cLn5gpb6Z8B3sL97FrkM2+SdFUXbuKqMvaMsxZw8FWSGWkO9p3l0R4jVqKtBUsc0tcMbHeyUzdPgG8gu+PiwnMfqFn3TaoFzRup+gsHKUss9PIWPa5rhyuFBSVrZ34qU7ubjGdCqicSHc1jCCNH+2zw6LouiilcHi0c3P2T4pUkbZvV1LDiHdkGo/ZFeT/1TCe2w+ZSZNoywmz7c9U6QvLgbXWKuacIxai/JenLCPNjlbdHjbF2kG2Y6oR7V3Zte4GV7rlBl3RnwVZHWYW+6Vz4urvM2xdv/AAmN2wzivPOYSGEakD6KkLHCOTFqrxNvUN2uw/wLOamE1bpDmTY2y8FwC04G+AVXue14AdkpxNvXNqYnNF8JHI2VHMpZB2oYneLQvLb+VkgAkNk99VM3NhLj4WTiu3cfQ0Lz/wCVZ/25fRLOyKBx7j2+DiuF/Vp4zZzfmU1u3H2sW5eK1wy/pt03bFpnTYWve0W5qO/D0fs1Lh4gLn/1u7w65FhbRPZtrF7fyKmsl3DT+H3juTjzalnYdQ3R8bj5p7dr8bprdsjos7ptj9Aq4hbdsP8A3JMjamLWL4H911WbVYeHFJq6yOoDMOjTm3oi7c90tQ1oc6KYDW5GSX6aQc8vFd2OphcywOEW5pgMTnDIHqbK7HnvSmuOWR8lcVbrW7XyXdfS0kneijd5BKOyaOTMMDfMpuDhuqs++5A1RLmkuuL3XZdsKnOhcP8AuWeTYgBtjfiOmibi7ZBNexFiOV+Ca3dyi5cWXRdsKYdyT5Kv9Gq2nJ7fmibDdyYvV1DL8LuIVmuq4yBixdQbpb9l1jT/AGw7wKr6PVR/7D79EXbV6ZIzJzmX/M0XVDVucdWH/tt9FjkdMLF7JAfBVFQG95l/EKq3mfjht/i8/dD0sgWOY62WA1DSb6IGQOz3l+llUbYzjmvrbhdbRJbB2eze/HVceORowlrr21C1srAB+qlq9OqZ7vsdMv5mr9lgs7ELZ5lc1s7S4OOozTHStkFzkfJY2NW8E9gyQc8iiWOAtvX/ABCwYgwXabjlloqumaHDt2GlrarURsdM5mQkeCOKz1FbLHG4yPe5pICo+Vr72dmfFYKp28p3AZHGDfyK1GT6RrZdr0uE9kn6G69HM3A//wAwzs8CdV5rZMYgrYpRJZgJBPJbaqvj9IcQ1jhxaND18VjP/HXx9OvDFJLHdga43yIKU6mqg4WieSucdowmMbt+C+osqf1J8RG7leLccS56rruOtFRTySAPY9rDYErXU0MUUeIXaeea887a9Sc/S3/FUk2lJKAw1DnDqU403HVEbQ5rcbrkrdaOPCRG8nW9l5uKuMVS14ybqRZa37WaM2uOZy1yUyxqbjtyzQyAF2JuDgWpctVSNJxBrssgAuI7a8ocAJv+7D3UWbReWhz2xSAZ52v+qcKu3QkqaWXB6l4N+AsrzTQFzRHE/COn2XNO1XcYm9LE5IjaczgcNOcXO5V1TcOqqpr2WDMIWmgnIgY1j+0cWfmuFVVEwdiliLVooau8bWYL4fldb10Sx3RtCQWZIBIfzAK7aqmd32MaeYByXCfXsbIW+i3txxFWbXM4UmevfK56Xp3gaV5zkiI6ghKeKVrS4PiNjoCuO6v7X/lP/kUDWki3omqmqdOyx0Eg7MbCT0SJWRNIG6+BXOjrsIA9GkH+Lk1s7JBnDN/71rs3D99FFlu/miaqAk2b8LLJvI2ObhYDb3jx5qCowOe5ga4HUEZKbNxq9Ia0huhPMJkjsBaCAAcrrntncS0+jwOPIXTZKxzXAGkY/K2WgVOU0vUMZFKx7JMJNw7TTyTYIJ5AwSR2B9rPTmubv2POJzN27M9Ctr6qSWSMsmyw2BBsB5KsY62bJE5shboQoBjOEarLI2TV8zOd7q7auTFvBI3GBYHCFNunRhgex+Bze2TknspHbxt3NbxySjtGcNAeI3nnZKiqo5HAvhaDfUEqbqdOiKVu7IkfjN8nfZOZG0ju97kuRNtGRjuzoc7q0e1JNXs62us9p07D42RjHvXt52KVIY8Vy+QAjQD9lz5drgtLd08jlcJUm1zNga6AloINi9WbOnUu2JjWbx+LQZ8FWSWMsfixuBGfaWOTacAjBFOC8cAf0SRtlmAg0gt0KdnRlNK2KodG4l925EclqiEbLlsMxazVcOLaYE5LKdjAbZt1GS3N2g4jEZnuA1AtmtZbI6gnaWOwQut+YZ/NIY94e6ME9rK7xht+qzN2oGsMbnSvaRqXfJYqqva59mRyG41xn4pDp1mwuB7T2C3G4VCLAneM/wDcFxmmR3DTmUyM4WHE25vkCVdr07cEkL8nSWtyGq0mKNzwWOyA+a836VJEcIbhC2wbUsAMOQ4LNOnbZgDcz8lV8cEmb42HhouRJtdwk/tHokv2u8aMKzqp060wgFsULsJyFgVhraeKSdohcI2v1B9lc6XaNTLk42bwzWUzzZE6jjddMYdOvSR4IpIHOwWIsQei69BI0Nwyy3cMg3ovOQVpEUhfqLNQbtIh+IZkaZJdnT2OKLCfsUpxLj/csOWS81T7Tle113dq+RV/TJ7tJkyWOzUd50Tzo9hHUJfoeIXMjfgufHWuIsX3y0uqu2humkNuG62B4rO6dNklBhzDhlySaaUU84J7jsnDl1XNl208ZXlCkdeJR2yHj84zW+zp6PfwOxESZ+BRN3l2EjhldeffVNcCRKGu0AvfRWbVyGQvM4IJuQsmo27Qp3SsDgLGx4qbPeH0xjL874QudVbR9XmCRa2RUoa2J7ZC+Xdm4sTw6rpLdJ06pjfEW5587qF8rmEl2vC/2XEfX4JXXkxi/wAVP6q0aO8NMkm11HYaZD3ZLeeaoWzvtd5N+q479rtDuz3fd5nmrx7QxNbZ+Q4ZK3Z06ZEofh+6A3jbXv8ANYm7RjZfjfXNKkry7uSFo5EqSrqOxExz23upujYX0XGZWSuGVQwDlcqOqJCD64Hpcq7TUd3cx4C57uyRlmDmlVNKXNaWuBDdc75LiursELI2luLUqz9oF4BNw1o0CnadLTsfHKyUgtAORsu/FJHJG15fckX4cV5xm0nNpZIn2c1wObtU+GswQxtJs4NVytJp2nxRvPesqbhgF8YXGk2lgcBiv8UDtS4t2B5lZm/4vTrFgtkW6qFtnAmRg+C4p2geOC3mqf1Jlx6th8yrNr1HebIwD+4PkriZvB2S887aTD3adjRzuVeKvu22C3W5Sw6r0YJMd2yWslukdiHbv5rhmvc3l9kl21COPHgpIaj0b8Tm/wBz4FJpnPjmw4zn1K4J2s+w/UptFtGSWpY3oTqt6ZunqJIpCA7eX6XKXZw/3PmuRVbRliAxPZfli/RZhteQnvt+Kyuo9BZ3/UPxRs7/AKh+K4R2hKRfeMsfzhAVkhzM0YH+YWe11HcLCfb/APkph4bz5rgv2jhy3zD5lZ37SffKb6q6pdI+R0ZwyacDZCq7dOL6Jj43vwvxWI6Kk0TnxNs72sxbUL1ZPmY9M27s2HoAqytzd4j7q0rnbyNuHsiwTcN5JPJcnZnc67om4CNM/JWe3N/h900tyi8kHi0h8E2M8jbQN8EucdsdVokH+nZ4fqqyMuWjmB9FYhZjaXh3EC6fTvd7fd8AqPO7iaeYCdEzFYjQrOTWLNWxtdna5XMLLOXVrnl0u6YLkKjKPAzG/M8uS3hbJ2t0xtgdYFws08VrjiaA9oV5G4oQfFXY3C8joly2yS2O0J8UiJl4nDkVuAtBIeqyU2ZkakT0vM0gi2tslmjMwe0YjmVpdLinYy2hATZowHDoVZdBL3ysdYHI2Wps8jH/ABVJ2XBKtJrbosVo6Ouc4E55K7dp4csxmkUzcneSzub2yPzFQdRu1OznJkidol7w4PBIXIhZ2JEA31A8VdQ3XoI9putw+Kc3aXNv0XmoG+ouDYhxVZqpzLBj8+Oqcf4cnqm18Z1HyTW1ELs15WKaQwteJDdMknla4jFqOSnGruPTXieNWlKmggcw+rY74ZLz0dXKXkcgeauNpmM9okHmklNxvgoIZp5GStYQMgE52waVxyGHwJXLbtMbzEHix4LXFtW9rn5q3lA134fj9mQ/EJLvw672ZiPELWzaLeaczaDSe/b4Kcqf+OS/YVUy4ZIx3xCznZVcz/bDuocF6RlY1/tBM9JZzCcl7eWNJUM/uRS26C6zyulYc2OaOZC9c6eIjX4KspYYz4KzI28mydwzc246hMM0bhfCvUxwxOYNLaZjgqS0FPICd3GfIJuDzsRaaZ2dsjZZMchdm619CmzwOlneWMs0nIDgunS/h2aembJvmsJzwEFa6jUjjStmjbiycOYVIXPmfh+y9JD+Hp2YgZ43tt1yUP4Yc/8A+7awaWDf3T5MUsrzz4ntNsSjYHk/uvRD8Jj265x8GfumD8KU41q5lOeP9a7ectNGey5BxndxXpv/AApS/wDXnPmER+G6Vh78jvF6z8mJ28uIpenyVhTuvwXp37ApA04QSbZDEUmk2VSy7zG0tLTbJx5A8fFPkg88aZ/vBVJnaQ3e3toLr1R2NS2zx28QlHYVGTq/4pPLCx5t+/cM3Yh4oxzTxd1ej/oFKR33/wDuVHfhylP+5J/7k+TFNV551RUvffG4eBR3tSf9x/xXeP4Zpf8AqTf+4Ij8MU1v703xC1zwXtwd5Vf9R/8A7kN5UH/cf8V3/wDwvTf9eb4hQfheA/8A3E3yTlgPPXm/6n/zQ3krfbP/ALl6M/hmBoP+om+STS7BZNjDpZAWmwIOVk5Yo4rBPM0uaez4q3o9QXD9V6WHYbImECZ548EwbIZxkf8AELF8kjenmN3Ux54bW6oF1U+MtxuLRna69PJseJws577eIQZseBmjneZCz8k/hp5PA+93R3PiriV8f+2B5r079kwE2x/MKv8ARYObviFfln8NaecNRM5w4nldHDUOz5dQvQ/0WC3ff8Qrf0eK/wDcfpzCnyT+K8051QPePmi2epZl27+K9INhwE/3H/EK52JE1pO9OQ4kK/JP4jzJkqXC5vbxVfSJmc/ivSR7Filp2yGbAXcrLPJ+GoTn6Xx91ameI4Rqpjz+KgnnPE/Fdh34Y92t/wDh+6ofwzJwrWf+0rW8E25e/nH/ACFXeSuObCuofwxP/wD5cf8A7Sq/+Gqkf/dQ/NX8f6nJz4nPxi8ZI8Fd0lQAS1lgPkt//hus4VMF/P8ART/w3X/9eD4n9FPxWVijq6vAQ2+E66KrnVDszHddEfh/aDf9+D4n9FYbB2j/ANWn/wDcU/FduUwVLicLFYxVfIrrf0TaYcCHU+XAOUfsnadjlAcuDyibcjdVR4H4FWFPUdfgV1qbZO0Joy8GFovbNxWluxK72poG+blm5aajg7if3yPip6HOc7k+S752FUuPaq4PIOTGbCmAt6az/wBpWeavMupJr6lQUEzs7leoOwJLf+cH/sP6oDYLh/8Aef8AwP6qfKmnnGUk7GmypuZiwuxZA2Xp/wCiEDOrdb/D91RmwmYiPSn/APs/dJ5DTzRp5mDFj16oAzt/3PmvUH8Owu71XKf+1D/w5Tf/AORMfIK/JE08wXz/APU+ZVbzn/c+a9V/4epf+rL8lcfh6mvm95HEXH2U+SGnkvXE/wBz5qwbP73zXo6jYlMKljI8VnEYu1mto/DtGGn+8D4hX5IPGu3sersz1TJBNGQN4cxdeqd+HaNxuZJ+eoVnbBpXkuMk2fUJ8kXTxzzK7vDErNMzQA1uS9adgUY/3JviEtuyKPGWiSe/iP0U+WGnlSJn5+Wiqad5zN/gV7BuxqUDOWYeY/RUfsekDmjfz3Jta4V+U1HkxSvdo038Ez0Sdp4hetGw6a1hLP8AJA7Bi/8A8qQH/AH7qfKcY8tHRyyGwcb+KS6CUOIxH4r1x2KGjsVgF+cf7rBL+GpXOJG0IrnPuELWPk37LJHCEEv/AFLeaWY5Wu79/Ndt34ZqLH/XQH/3JFN+HZ6hzh6VG0NOtit8p/WduYI5Xf7nzQML72xXv1XoG/hL3q/4Rfuns/CsLe/Wy+UY/VOU/qvNtpjxkCsabFnvb+a9O38MUfGpqT5D9FcfhugGslV/7h+izzn9HkJqZwIGK6DaeQDl5r2H/h3ZgzImP+Uv7KDYmy2PtuS4e9vT8LAq/JGXkDDJbvlDdSj2vmvajZWyWf8A27D4ud+qs2j2Ww5UsN/8brPyxXiCyT3vmrt3gGUlvNe3xbPjNvR4vJgTWVFKB2WNb4AKfL/ivC4ZXe04/FWZR1El93FM/wDxaV7mSvgjY46WF9Vh2bWxYJZpLMMjsm9Oany/4f8A15luy9ouybSVBB4FqdFsXaOH/wAk7xL2iy9S/atM0/3PmqHa9L7yfLf4mnnRsDaTznHG3/KQfZXH4crjq+mb/wB5/Rdt23KduX2UbtYSf24nu8rJ8mX8P/rks/DVV7VRAD0BKv8A+GJfbq2+TCuk7acwNhTkk9Vc1FaYy8UuFoFySdFj5Ml6c0fhgW7VZ8GKf+GIx/8AcPPkrHbj9HSRM/yugdrTOzZPTn/vW5zYuUKD8UYKvqzhqEqSRjYw3Dp1Uhex2EAZnLUr129PFjOyJWdpniPqo0duRNqBaSP/ACCW3vyLhXpirxlF4j6oOHr/ACP1TC3sxfziqvb/AKhvmpFY6uTCwR20V25mIc2j6IzwNezENQVSONz3RSF1wCPktIXWOwhrEx0bg1pY7CSB9FeeIObit3SrH+03qFNitGxzXS4xc2Gaa8eq8z9VMZjdLZtza3zUYXSU9yLZlRWYH1FrJsYvK3q37KQjEx/iCoxwD4wNTYfJUCVl8QWWljwTuZzFvottrPfxyWTGRWdjtG2i1ixeh3O7fiPevl4LRMBY2zIVI6V75Mcr8r9wLUTYWLRbVa4M3PTHNJ6okMNrW4aq8GGRrXSZkZABJnw7pxw2y1unUx9UfqtcIxzpjJGxyOGuQyCQ9jzPcZtJVZG+sPC3HNaKbNl+6s8F5lMhcwSYmFoOhVLerPitoxAtFrjxSJ4wAQ3s8SFLg1M/6pTNvTyeJ+iRNCCxjrd5aKZhZC++rs1Z49SwrPprqs1O21NfqhVgiZmE2uE2lFqeToUgSOmczEMr2V+9iUwcJwCcWVrqTsvK1p0JATY24J2IVjbSMd1Cb7Ppkkpyx55LS9naYedledt8+ipJKHNYBqLBN2rItUAtAINirXcyJjg7O3xyTKgXZ5JIlaKcN5XWYqzKqUQ4uvJWir5SL2+aVE9skLx5qUou6QK6Ntkde5zbluQTRXhzT8OKwxs9W7Liixvqys9DfHtNo7OO9uCezaTS219fBcSJnr3eaLGWmd4JqIpVb6Kd72Pda97hb6PadQ2IMcXPAWJrMdQIzkDl911xSBjALcLrWV6akQbXlZ/tP+aB/EEjNGlXja+FwdGXa90nXyV9rthfSMnwYXEX8+S5TX8b+iRt2VzTZA7cnsbk/Jcyl7cJ81cizPL7LdwjHKt42tM9pJfhBHVJO2qgSYACbZ3JWeJt4B4JGH/Vu8FZhDdapts1DG31vwuUqDacsTSeDji1WasZ6tvkqsgxsHhmt8cdMbu27+tS8jrzV/6tKM8/iuaWBpHiE+RvYCzccf41utse2JZATy6ou2xKMrfNcule1mIHmryyNJAGd+iXCb9LuukdrygkdSNUG7YkLvayy1C5pkwOIAv2ifmUIRhlcHnDmnCJzrq/1WQgnt9kX4It2s9wBu/5LC4ts8B3sEfRXiZ6oFZuMXdaJ9ovlY5rXPD+d/0UpKuaFkjW5loMjj0AWQD1p8B9E6PJsw//AAyD5KyRNmDbzgL5/AIt245xOvwC5GHsBWib2zlfTJa4YnKu1FtSWTEGm2BpceZASjthzge/8Vnp3NhLy82Dont04kGyQxt2hY4xeVa27YkjNs3O534cld23ZRbIrmuZ/qEyRjQ7tcj8eC1xx/ibroDbUpF8J+KDtszMdh44QdVkjZ6sKkjW71lpMfYF+mWikxx/i7rU7bcreGQ6pb9tvkBaRk7I5rHI3N/h9wriBuAHDwWpjh/Gd1rj27KGhjW4Wjqrnbkvj5rjthxHLmtDafBE4u4g2+CtwwOVdA7alLbqv9dk/MsTGdgIwQhzNFOOE+l3XQbtxzs+3ZX/AK0/r0XOqIGxxXtqR91WVvZHkpwxpuuq3bEhF7lXG23HjlpxXOjb2PJLhb2PNZ4Yruuqdu8DJZQbbF/7q4tRT4Zg3gGB3xAP3SnRWYD1A+S1PHinOvSf1tth60hVk224N7Djn7XJcJw7DB1WmUWgd4LN8cOVdml222KnazHite5tzVnfiBt+vmvPwyMa0ZqkxD5G2KfHNrzr0J29lkfqq/14nQ5aaFclkO9mjjBsXOAvyzS44sLi0ZhriLrPx4rzrrv2+5ht5cVX/wARO/l1x529tuSMcIcLW1Wp48NJzrqt289zvaQk/ET2ntY8S5gjtK4W0KVUsBZn3uCswx36OVdT/wARyONgHFOZtepkGUZXDpmWcAeae/aL4nYIDa2RdbVa+PH6izL+upNteohbd7cN+F0tm35SND8VmhldtGJ8Uwu9rSWP+yRBGPDms8JPpbW3+tSOqA9zMTxpcrUdvVGEuwWsL6rgEhs5W172mCUflS4TfpndbBt+eS5sfioNvSucW2PxXLp23B8FI2YZXDXMhXhj/E5V1n7elAvn8VQbefy+a58rMTGN94/ZL9ELc+WakwwOVdVn4gmcbAZjqoduTYhiFz4rl0sV8+SvK317RyCXDHZyrrDbc2Enti3UKM29K/3/AIhYXNtA7wKzwMvhWeGK8q6ztuPiDS7Hc+CH9ble0uGOwXLrm3mjb0RbAWwvffRpWuGJyrcdr1Eo7JcLoUu2XRl2EPxHUpFLFdlxqAstLEXZ9bpxx0m665/EEofaxz6qO2zUOaXZ5Z6rlPb/AKlw6BabWppD0upcZteVaGbYqJCf1Kzv23PvMGnW5S6ZthbnZY5Y8dU7obfNaxxx/huujJtOUxYhLmEuPaU8hAMmqyzUuCMHmf1UhpHmyvHHSbp0m0ahshbvXWCjqyZ7BZ7wb63VGQjE4Hhl5rTLHhghb7zrqdfw7SB0jyMUjznzK0Nad44YjkANTyQporlaAN2ZHe84NHiud01NkSs7I8UyOHtnkAPonSQPfh3TL68NOC6UOyz2y99hll8FzyzkamNrn09OXtIa3FcrVT7P3MTpJyGMaCT5Zrq0MLWQjDYE8Sud+IJA3YswBzJAy8VjDPllpu4ajyzZjUVpeBe5Ls+S9js+gbFSwMfm95vYcv5ZeGpXdvCXHnYL3Oxq70qJrThvELdkZeS6/wDIlk6Y8bbumtlwtZYBo+uqkzfR6CftYsLX5qPaXmcsNnizb+CrXm2zJb54m4b+JAXkw/Z2y9OBUOvPRt/OXf8AxREccm0iHRtIZDncfm5Lc9kR2nR4o2ABj3EeQzVqUU/9UqnOjOBrGNFugX1J6jxWPOyNcLX0B66JjZmtlGHPMZWKtGzsu7XHqju+2T9ytuLVO3FI0nLDZ3w/5WWFzXzPPQfVaJzbK/spEMWGaQdD9Vwr0xZ7bxx/ziqTndT43HIXTjlEzxP1Satge9jToXZqRVWlr6bFzukRPLaQNGrXH6rXFHu4HMGjclmhZihk6PP0VCY3vljlEnCx881pA/0zD0Vy3MnmxFjMVK0+P3QSIY3tPMH6KwbhEg91VZMyFkbyL5WS3zSSOGAYGutqkx2zcpAgAD5AchZLcWteZGjFgKkkbSCGXxcTloqWc1hHTmtzBjnvphq6yVzyAcIOoS9nOtU3vnZUqx20aD/zTRzXWTpMnW3pNjoNdeC0sIkJL5LdOZWUwDF/ctbxT7boC7hksudIq2tEbufihT4DA0O1UqHtdG7P5KlO3ExrsVrLSRoIa0BW7Asful4mHIOzCq5zA3vIn2L5ow8ajqtLWse0nBfosdg/XQ9FpFomAN01zStRoa1mE9gAZ8FnMTbhrHXDeHRBsxcMg0X4q1ne+zmsWbWXRQjwtmYRhJN7pbWBsLTydqmzyOBFxiHEotjMsWCMZLFxdZlv2S5uGdh/Mq1ouxPkIYRfUEKVjcTAVj037JcMbfFv2SnQBsTHjW91opx6lnQWVpG2pB0y+CbFpm3iF+SQyIS0/UEhaXi8DfBUpW+pd/kissDSHvbyToB6546KrMqk9R+ybALVJH5SFaioFjJ4oMb2D4pob25PJCDttcLaLKs4O7nv0QjcH1B8FfDapaOv2VmMtVDwVgz1Dt29rgcwbrubOro542xz5PGQK4daM/NB+BgAa7tAWK1ZuG3qnCnaC5zxYZ+K4VbUCaMNZ3Gk/FLkjvbqOqFM28Dx1WdLarRi8T+VwrOtu258LK9KzDJO3nb7qklKHtuMiCqyUyoLIcOC6rG7eVZNuBWmGP1AHIkfNULMNU3wVlCa8f6cJlKwlg8B9FK8XoQeqfRMvEPAfRLfxT7ZXsyP+TfumPHZHgjUdmQM98/T/lMkZkPBZt6jWmKOHG52SO5LZWX5haaVuKR5txV6hpY0OGouQrck0o6IesP5j9SkzUu8qps/bK0wOc6me8i7szZSB+/LpHNwl5Jsm7DTI6ndE0XzWyAeqCFaMEZNv4U6nHYPgpe5tYRGy8zv+36JobgjkdzikH/xKjB/qn30yRrcUdI8jXMHzyUnuGnJItGFaD+4rFl4x4IwN/1IHRdPpnTo01MydxDtBHI7zDSRos8EYwNPmtD6h9LDvGi92uab8A4WUp2dhvkud9NMcjbVQ8FZ0TXh19MBI8QEypbhrWg6YUJ22p3uHvAXV+4iQt7LUaqNokpSPahBP/uKZCOwFmfM+apaw29W3D8yfumP2I+L1Tz+T7hHB2B4JtRf0c2008rhFrfVjwVXTHSM7/8AktEsG8hdnazS7xsEmh0f/ktlTE40xwcRc+GpVy9pIysj9U3xV6VtmApgGGnHgfujSNxMHwWbV0XVj1LR+cD5FIqGksAGYFvgtla31bOsg+hWeSbdMcPf7J+IKuP0lOhHZ8ikQsvGE2KojwkDUi2iNO3HE0qelUr2WqX/AOLB/wDEJErcMQH/AORdTaNNJ6dONzITitkCtNHsL0iIGpc+JrXZMaM3Kys1xDTPkaAxuIt7RtwHFXZTvkaWgHtCy9jTUMFELRQjeAZuOtvFSudiYzOwvcJtNvEupHQHC7wUdC3fts4aLVtZmOYkOzWfZee0IB2jaRv1XTj9ucz70fBE6aoY0GzzobaWCXTtu0XOLXM+K9m9pklDwxpc/M9gE28Vz6zY8LIXSxxvjLc8r4Vy27POytxVDG20b902KPC4WTJ6dzJsTu0C0C6dGwYS7kLpy7JpxzO5z3OtkXF3zVJHYw22twtcUNw3K9/0RqIbOgGG1z+i3sViY2OoY8i7SbuWmTYhJMkbw+M8VpbTtaHOGjWE/C6x0rHbsnFrwBKxyrUgWbRtc49+xt1KxskkDiMOpsU+si/1TWcgT80+OPCwmwyF81vaVjp2bwkniVoqogykc7DyCeWxGsl3IaIw6zMN7EDK+avtFlqFvV4HyKlvaacdokGQ0tmm0cdx5rQ2LDDIbd0K1FFZgPNW5dGhkZiqGNtwVqkNjhIA9k/onmMuq7EcB+qVtAWicOdh8c/sucu10TRs9X8lSRt6sjwWqjj9WEpxBqneI+Su+zXS82VK821S6WPEAtNXaOjd1IH8+CVSyMu3tZcUnpFKtn+uaOTR9yr1DbUjjzcB8VJxjr3nlYD4J9Uz/SxfmePum/S6SKPDTyO5MJ+SzUzbtb5Lc6O1BOfy/ZJo47YfBTfSsLm/6mRa5m4aF3WwSSWMqpQXcbfNPqXMk2Y4h3axAW81fuITSi/mVmhZjlcebrq0EDu086MaXfBO2fHiAPPNX0DWRiPdMGpP8+q00sVsLuQuhtJoNVEz8t/iVpw4KWWT3I3FZtXTl0rMdncytFazC+nH5SVKCO5Y3mQtu2WYa+Nvuxj7qW9rIOzqZ0uYb5rYzZ0byA/MuffwWjZDN3Tuf0JVdnyulMbSy1iV5s8r9OuEh7qdkNmx9L353Wh3ZhmcdLuKpNnWYOTmj5JsgBiN9CT8yvPb/XX0VSztmpsbRdoyIXm/xDUsqIWlhxHeYSdL2Fzl4ld57BR7MlIzDGk2+nzXj6sO9Ep2ltrh7vmvb/x8Jfyefy5fTlxS7uYPabG/Feq2CZn1gLXdkZm/JeRcbG/IrdRVDw02cS/7L1+TDlHDHLVfQ6WTeQPkDu+5x8rrPtqcQ7NxO7pe363SdgSTybPJljwR27HVM2020NOznKPkCV8/HHWenqt/Fxjttk1cyUyhobGWAubzKENYHPnc2SKz3g5OtfshRjI5a+XExjmNjaCfPVLp6eCSkllfE0nE8tPKy+jHjCHEYSRr1RBcP4EmWVzLgd0fRLjdiF8XHoum3HX22zuAiBvkGZ/BGHtPkedCBZYauWR0bmYSGWyPRbHOfgIZ7TAfkuGT04rSEbhtjnc/Vc0yzGobveJFk7DLjafZvnqn1bW3vpax+aypp0eOSy07f7/i36KzqlgfgD7l40vqlB742yWAJfwutSJyk9nSuDWBx7tiPLJIa6SRuAdll9eakZONpkuc+7yTHPa4DIklbmLnlnv0u5sUcQtk3mbZrK97xICI7s53TnNBaAW3BPNLLWvN8Oumi3i5ZbMjfvA44bG1geiW8ODXdrgeSZh3Tb635FIxYxfOxB4BCRy6odpVojhqmHqjU8FWlNp4zyKsda7r+zJfW4VXyEWHRVdO4PGE2yRbaSxdms7ctMcudzh/lk+idaAFCeMZ2J+KlA7Cy3NWmMUmeL28eCuw5jx0smOwZXfnxU30QA9awWz1CjRuKzkioDi8Ea+aW6qhB/v3Vf6jC3g53khpoga4gXjeDlc5rQ6XDfr0IXNdtUexG7zKSdoyuOTWhOK6dWYbxjTprxV4JMNmWt1uVxH1s7v9wDwCUZXu1kefNTismnp5KeEts+QNOtys09TBYs3jLjK91wLPedHFMfBLEAZIntvmFOEbl069K5r4XYSHWOqY8eod42WGldLTSNj3YIkF7ArbG9sscljazswueWLUqklQGQMA1t9kdmPxwyH8yO4Y6Jl0dmsDN60c1melIfb0pvgU+n/80zwI+SRMz/UxN53CvSxOjqoiTrl8lfpWg/3ZPBVphiL/ABCvMx5mdu+SRTRyh8jb5lZEkbaoYOqsR/qI/P6JLmyCoixaYgPmnuyni8fsUVlrh2Lqr42mnbIcja4T6ttw5LjGOhZ0/f8ARdJ6Q13ajYeGG6FJo8+BRid/pPKytRC7n+A+6wFyxXqCB7oT4GkQuHUogXqPFp+oTGts2Tx+ygXTt/05/wAj9UipIina7p+i2wj1bv8AI/ZZNoxXkb1Sez6JqpGyUR/nFbKHOCM/lBWKWmwQyE6WP1XQ2cPUM/wC1f1RnrY/XRG+jimvGQRrYryMdbuu/RMw3aPBY3039s9M0NkkAOKxz6G2avURXjf4EIUjRv5La3z8bZrbMz/TyHTL7KW9prbBSs/0dud1angML3R6lji3zBTYGn+ngjUNJCrSCRzry4t5c4r8753WtgVbGOicXZA6fBMgb6seSlbCZKcgd4kBWpntEPCyzfSk2/1bvAK1ez/QuP8AOCsC11Y49B906sy2e51r2z+iT3Bx2j1YVIxaqZknMbeNv0Qw2q4/BbjLcKYVLDHiw3BN/AXUpmjA3LO2qu6l39O+PFZ2EnF4C9leib6tvgM1i+mmWvs2rjvphQqGtdSTEntYgr7WgcauEj2mpHozjSyPflYXHVWfRY1U7Lt8ljfE1tU0h13Obdw5G+nwW+mZ6sDoslRGKeVkouTJiNul1ZfaU2eO9NMeQ+4VWNvCFZzy+mls3LCUYB/pgeikVioW9l/+S1VUpgpsvau0+YKz0B7Lv8itG0YsVGD+YfdavubZ/wDABiNLYOzLT9EyjZaO6SylwxF+L2CfkttHF6q+mELFa/8ASNoR+ppzkMUhz8lknpRhB1uQt9fKxzIY6cmolBLy1mdsleloqeu2c+eWtMJabOFrNiPInit4y6iZWOcKaJrmh2IOf3QF6HZexoWRQyS4pAQHW0aMvrmvOyV0ldtCn3mAmIbsObxFzmva0rHO2fCA7WNo+QTLrpPo4O3odYg3430HkquY2NpbckZnIoQRGIXDw48joryQ7x2LGBh1wLLARxh7G6YLm1x1XK2tKQWRsc02NiF1w0MbgsDbiDl/yuTtRp3bDfA8uv5LUZrzO0d4ZPViyn4fFtsURk7gmF/iFTab3tmAbrzVNiyPbtClc1xBEgII4Fei/q5Y+32BlnsxxAYXZjLVcrb1Q1ux5ZMOFpIb54v2XPdXTOka1tRNc5G7wFz65rvRCLOc1z+PPU5Ly12y9Of6ZHx0UMlNM0gttfK9rJe7/J8kcDR7PyWHm5WeiJKeNp9W8kcikzZzwDktmBvL6Kpiuf8Ahalbx8tntZ5wUdS78mH4kBZ6JnYCc9rnwOiPdcbnLkrQN3Qucg0X0R6MfJKwT9uvkvo2wWpkDpYzGCA94wgnS5WCOZklVK7GO0828OC1VQJpHDjcLpZ3Gv8AwKOLAwAlptxatG02YYIW/nJ+SFGyzRzyT9qM7VM3oT9AudvayMMgwUUl+It806gDcLf2Sa9v+jYObh9Cn7Ppw4Nve6t9LPa7G/6t45Gyy7Wd6xrPekv8P+Vspo8Uz383E/Nc3aDsVbE3xPzt9kw9rWuFpswNHO91lYbVD3HOzz9V0acXcMtGrFSM3mJx4uup9IttZwdTRNDC3E7VIoaHfThoflZbtoxXfSs/KXfRbNiw4TJIdGglW5ahrtyoI7zSZ6vOZ8VtrAb0zDpiJt5JVEzFgvqSCuhtWNraumZ7rCT5lYuXayEVDcOy5uth8whQR3eB4rTtPDHsgXtdz2jz1Q2ThMgOLgpb0SduK+j3lTK4+8fqtFbRmClhN7mR19Oi0OaHVcg//IfqVo24yz6RnJrnfGy1y7i6YGR4Nn1Uhz7BbbxsFTZTM2fotNQ3DseT87gE7YkV5BbgFbfxTTLXnHtEk+w0DieZ+6bVuEeyHni+zfMkJc/rK6ocOMpHwOSvtt2CmpIOL5MR8grO7BTZmVTD4pu1e1tSQe6Gt+SGzIsVZH0UrHbzadQf/wAlvhYLF9rPTubLjtTSD8pTqWJnpWAMAs0Am3S6GzWf6V48Aq7MfvauqfzkcPt9l5b3XTG/RdRVRx1Rkd3BKRfyWx4G5y5CyxChE4niBzMpGLlmVtY5ojZE993H52ss2ba3pxts18cb2UbmxuBF3hxI8Mx8VyKmamFHMGsla4sNsE5LdOIPBV2r6TNXTPEb2sLrA4df5Zc2taWMPs82i9j+6+r4fHxxeHPPeTmOzcmU7rShvPJUAuVZsZxtPIrsmvuPd/hmobJTPgbHm67yc8tMl0NsxmV9ORDJM0FzjuhcjLVeS2ZWSUVWxxtkbm54Ls/iasBlo3R3s+MvGZadV454/wA3bl+LIGCOonfK2piY+2HFGRwSYJIW7IkaJ8M2Fw3Zvnmks2pUR5CaoYOFpD908bZnIs6VzukkbXfZeng83MhwccQLb3SWxWLThfl10WqOQPdl9FVju04Bbkc7T5WY6TTUFCB94Ync2AfAIOe8sEcbLnO5y4rJHHNK8QHKOPJxXK4u+OXRk20IqeItviffRciqrpKh98VhrZX2nBgrZANLjJZCyy1jJGu6ZRvtVxk5EldljCH35rhwZVDP8h9V3pJGNIHMZrbjnAOYvi0WeSS72vHDJNxsvbtZ+CqYhl0UrM/02Kbex5ag9FJHYSRqqhtgLNt0spNIWYQxgfL7p4dUi3Ha0vdsTgJ5nUpDnsYbOdmqOfu3mV7y+a1ugXNqZnSOOae2pNJO4OSonYZGu1sbpd1duZA5q6Xe2x20XHMMSzXykWBA8leKiEmr/kqmma2Xsgujbqp0hLqiV2rlXeP98/Fa544Q1rYxd5zTII2NbjwdkfVXZpgs93C6O5k90rosiLsT+6eAV2Ypps+Czya057aSV4uG5BFlK4i97NW+c4HFrO57Ss5xs1keeLUKczTGygL2F2MZK9NRMlBJdYDJPdI626uMza/JCUejBoY4guFipyorRwRb/DKcr2BViGCpMrIhuWnMD6q8rGR0zSBiLtM0sS2ptwARIThPgpto6Jj6maWZhsG5t8tFojArHuklZ2WNPZ+qWXOo4zEHZPAu7krVkbIBEGCznts8Dj1WbRlge2CV28uWEdkoBskLDMNHnJaJmiaKGOHUDjw5qlODVGKCRpGC+iu0aA7d08eM5uV6E4nzeKVBFFHXGOR4LGHs30H7qjZjDJJKyM7lzrZceiy3BqjgqIhycPqtA/8AMRdSskrJJ8NRbDGCNVqc5rpYu1clylnTUbGsvUP/AMfultbhrHf4/dOhkbJUPaDcgaeaUcq5vULKs9SLOZ0cFJP7kf8AmEa1tneDgjIO0P8AIfVQJqG3D/FIom4qRo5ErTVDvLNszOKZnJ110n6obTi0Dme6SFeiPr39QjTjtSoUww1ltOyR9FgPaP8AWMHQj6J2Gz32SyLVcXUn6J+H1j0UqEWxeISdoN7UPins758FSuF205/OFlSaplqOXhkVo2U28cf+IS6of6Kb/E/RHZkrGRsBd2cIutf9an2vtEYZIR+c/ROhju0lxFwMtEra7g8QvjcD6w/QJEcM8hGefiVj6a+zKQf6ib/IrbOwGlkI0wH6LHQXE0wdqHFdQQD0B/RpPyUyvaxz6do9AJOgbn8FWke2aollZ3XvLs+RumUwAoHX0wZ/BSkhbFPJC3Rjy34Eq76TQVzL0D7HO+XxC50cMthY5+a6tcd3s6XjY2t5hGkYHNb0F030a7YKRjxO4P1sPut1cz/6VLxyP1Cx1cphrDYcB91Z9W6TZ0zDmMB+oT7gxRsvG3NQjDWRi3BCOdjI23F0JpC+aFzG2yW/tl1ZYHSUsrY++Wk/Q/RVoM4meCpEah8Ur3PLWhhPyV9ni7GZ2sPisX01Ftqf+aph+Uqzm4tnTn8p+xU2oLVVKebSmwWkoKkcmO+hWb9NMNLviwBqTW0+7q23N3OBJHgV0KAWbGeaTtZmCsp8tQVrG9s6Rrf9PUdIz9FSnH+n+C1U0YMVUOBjPwssfpENPTetkwm1wCrj3TqRk2f3PMrZWsLqMNa0ucXAADjquIzaDohaNg1JuV0KarpZaCZ1VLKyrjN4yzW/C3Dx4rrfHfbnyjq08DYagQ17HQxyRlwdoHdDyWVm0ZGGWkgqWtp5JS0VDwbNHL90yIVO2pDFVVAhZEy4iDbOdfQ2+qWKp0lE7ZLaWGecOwgxkBtve8U4m2sgfh6pYWSCaCZvbbljB1uOix1VBVVEUm1H00bYXu3no7XZuaNSr0jafZ1XJHtWMvcWHdy5lpFswFjNTI6MU7Xz0+zJZThxZ4efl0WtIFVU08+1IHUjMETWAAWtY3OXVeypIy6jgPshrbnnkF42opoYNtsipz2WtHG/DmvUQV1Q2BjGUzbNaBfPPJYz9xq/q6DnF1yO9e4yOijC5sZGK5vcrFvK13cZhvyalvkqsV31DWEfmAWdVh1MBeBd1vygfJcrbXajbcgAG97ZBZ31zW3x1kfLv/osktdZwwua4a6fZb41ly62Bz3uwuLjybxV9hbOlk2nTmSKVkWLtOwHLLXNet2dtLfxtD7a4RYWyXUwYgDfwWss/pMcN9s5oqVkAiE73hp4N1BQq6CCaFscDXREHEXO+mS0GPMW1VwLarg66+nm6ulfSSASi7eDhxSmuaQu5tnC7Z7yNWkO89PuvONkN/8Alc682eOjy1jtWBUMDSfab4IbxXY+7SpLWFfR28JDdLqGOZTyk9uzCfknEvuBr5pFY8+hz3Fuw4/Jaxv5Lj7eVpo99UNYXYQ42xnhmupV04pYWEPeYSc43HO/PwXLp83OjDC5zhhAHPmupSRMbVNbtAEPA7If3F7a7ujs+VssbXhpDeqZXzRT1ELYnskDWZm+hvouOXmOSU0rnClLrOcOHULTVxUsFLHJE4b0ZtcNX87rhcJa3Mz9ow9inGt7m3wWzZ0WEF+mFt1zqIGsc8yTkPZcNjbwz1TW7Vip45aZ4vIQWjD9li4X03jnGyh7MRedAwuXEq+1tQN90NHyXViqYKemk3smHEA1t/muQZRLWVMrTiBebHmtYY2Sra7lOLRzv91h+iwbPe1oF9SU+hncaeZpbiBYbu5ZWWjZ+zo5JG4tFyt1K1Ca6QSV7Wt/22AacdVupmMi2LUyuyxNIB66LHMA7aNS9uTQ8tHlktla3d7Fjj/6j2j6lP4rJs6M76Jvgm7YmEe1R+RjR9f1Tdkxf6th5C6XWRtm2tMAMRa9rfgAFN9r9F7ce12zqZrMjj08BZY9l01S+pBbkAc3LobdYwS0UYZbJzj8lt2XEIaOaTkwn5LVy1jpnXbl0QMlS1ztXSYifNatui9fEz3Ix83FV2XHeog8Vbao3m1Xjlhb8r/dc99tQjaLMNFTs9+T6ArZsSOzXyH2WlZ9rf3KVg4MJ+NlohkbT7Dq5eOAtHiclv60l9uXSNxmMnVxv8UnbcuPasDP+m2/mVt2dHd8bRw+i5m0xh27L/iD9F18ftmuxsVmKpZ8PkspG8q5Hc5Cf/kVq/Dfame/kXlZqTtPB8/uuV91Z6emo3YKFzzwBPwCx/h3ODEdXXPzT6t242FVHnE4DxOSV+HLGjvxAXGz8dttFEe293J7j8ysm2WiE0sjpwwC4N+PTJaqAXgLtL4ivO/ierdUVscMfdiGfir4JvJnzZaxbY6iIbwSVMbswW2ysPBcbb07ZaBpY/EHOHHkFjLZAAcAuOqz1uLc2LMGfPVfTljwY3dYo9SvQbKooXsxvAcbXsVwIwvR073QbOkew2cBcHrcLGVe3Cfja1HZ9NJcOgiFs7tcfkr+gsnc0VFQ6SNrcLW5C3Rc9u2JBHYM7Z1cCnQ1hkGN3ednot6+3j3u11hs7ZkkYjMMjQOIebpEn4dopDeOsmaeGIB1vosgqc01tXbirtNOew7pt3ZkJbaluPT5IVINgUkxOiAPetnroqy0yGQPBZxFlW85y3lvJCN7ri/jqVcvwkdtmXDNRe2GpDnnE8XcePVZHjNdGqGTTzHJYJNVmvVj6Jb/AHmf5BdzA1shcBmeN1wXZPB5Fd4HHhd0utz045lPDmkYWYhrxV+09rezwz1yULgxhfI7C3qTmlSOdK0YvVU/Iau/RRmRcz2Jjhs42sXnQeKymUR3bGSXHvPOp8VHyXs1nZYMg3ms1nzSWa23MqN60tM4knD2hoSsr2EZLpz4Y2SRRdoXuT0sskjcTAeiSjErM7wvzQcLORC2zHVmfgZHbvkZKQFjadxPZcNQeJS6cXc3GbDgbIz9qowxjFbIlc2i2xuAMp0JyVoWl7h8U97xuezYZWslMe6KVpPFQNL3sZgORJ16K4bu2BzX2ISn+skcdANFYP3xYwaBQMjYHRPcTe/PkszcUT2l+YOiZVO3dgBcnhmjI/fNYGHCb3KoBiMjXOJw8kILTS3kdc2yVi5zWGI2zI7SlRG2JrcIs85eKiqYmekEuHYaVdhdLI+cWuMxfkl47QtjjF3SHPyTm4mxCLDZxQaadrauZ8kt8IboOCrQPjbVYpHCzQQ2/JUkhFOAQ/tOFnD6p8ojkgp4YQ1z3ctet1hqE4308olDLxvJ0V3wbqCKpbIWyOdw1P7pljUtipw3AR3/ACVaZoZVsgmeDGx9gD1UUSYpqGPAQ+Yu80slzohTNbgfiwu8OKa44Kt1RFHiiY7CSFaRj5C+uYQ0NcMnclNqgjc2WOhmc3C19y4cbp8UEX9Q9He/1Ubi1pPA20S2xNkpJquR5L8YsW/IfzkmN3H9N0xTufbPUn/j5rNrUXgjwVkpa/EyxANtc1V+dXEfFH0i9O2ks6OoZLmRyOvzShdtXE1wcJA4h4PBIJXizD4ozC7Wnlb6q1f/AGz5qk5xwkDUBCk1Yxb035LJs04Z5m87H7Jk2O787ZdVnphgrsIOdl1x+2a34XtlfG32h9Euma9la1smdwQPqi0ubWNF+iuw/wCvi81hWmTKriH5h9CtDx60pE1zNAdO0CtEuUwKiktd6wZaj7qu0RaFnR4+qtILSMS9putRg/nCk9htQ29LUH8pXIhppixjo8wW31XbcN5TTH8n2KpsuMGmp+oVt1ivtStpDBRQOfq6X9Vuoog8E9Ezb0dtn0//AKo+hV9lNvi8FwuW8XTXbm0rP9ZVf+q4LsOZbZs3/pHTwXJhyqqm7st65dpskTtmzNa/Pdn6FM76J9uTTuD6MRtcDI5hAHWyXstrg8h9y8GxB+fzVqDZ5cGSi9wCQQeiNDJvZ3SP1c8nMK7TR21GX2dObcj8whs5m8e0flC0bRc07Jnz9n7hL2SO2z/FTf4ta7ZtoU49Pe38jfumz0DGbJqHhuYYfqptc22i/wD9Nv1K1TuvsKo/wKnL0aeYgpd6Y0+ppdzU04/KT9E7Zv8Adi8k/aotV0vg77LrMu9Maamxj0GYONhgIJ8kjZkeKJgA4C2mllubTl2y52t7xY79VzNn1m4jDD3iAB8liXqq0beiwT0n+Lh9E6hZ/wDT5erHfQpW3KhroKKSTLJx+QWH+utp4MEMYfcWxOyA8lqY5ZQ3pt2XYxs00AzU226J7myRSRv3DS6RocOi886smxNtIxrWeyHZEa2KVW17quobMYo2gWGBoyNl1nh7YuTsUFcypp6pxn3EjWGzNcWXNebqpXTSuc44iU6trfSZGP3TWYBbILI/M3PivRjjI4XLYM0XboYYP6car0gNqYz2Q/Q8hbjzuuIzTLVd/Z1AH0T67FC4wEXieLA+PXkmSxpLp9tSB0QjikhZqDZz75W8EuZ1L6DFFDA+OuY62FozDuOLn0V5pJ6+oE+zad8b2MIc9vHoeF/ml3p4KaGekne2rxWLXZlx43HBc2zIWR1rqkbRqHsnYD2TkGD3gkMr6iqhbs/HE4E4N47iOC0s2fWbYY+pxxAsuxrG65cLcEt5/qUcdJTUNqhgs4s0jtrboiERUbqXa4pyS4tyBHHK/wB13anab+2GzPiZGbFo110C4dI2UbXDanHvm5PLtb9V6Go2ZM12NskVmXNi82Kn/ZrP9XLNcZATI+oeOBz/AFXLlmvI58jXuecxwFl3azZLjEJHVhJcNLHCudNsxrYiJJjitc4QukjzWuJU1WOQOa3CAdLrZFV48J4kXISmU8MUxGIP8VqbS0z83MIPNrrLV0sdTZMjnSNwYvLRewjlwx9peQ2dNT0Oe6c/qXldmLa9G8eshI88S82eNrrjZHRftCOPWQHoCqCtfKfVwyHrhIHzS4tpUR7sjWdCFqZURyH1cjT4ELPxt84z1FJJXQmMybvMG1r/ADCwO2DVNPq5In9CSPqF2i15zElulkwF4bke14nNX43LKcnm5dnVkZuad5txZYj5LO/FEe2xzbcCCPqvXF7rCwz42PDogXFwzsRyKzfHGPjeQ3uL2fmFn2jJi2dP2fZK9i+kpZDd9NGTzDQPmFxfxJs6nh2NVSRsLHNAyBPEhMcNZEwsrxVETGXztP8AaIuPeB4LrtMm2BgaGRRRC3MkrkUTYjO3fNJixWJ4XW+UF1Q87NbJ2WHGWZC3E9F6MnRpFZJFCaIwB047Aa0XaRzKRBT/ANNqYpKqMPY4XDtcB8ERTUw2fv2TkSMNzIdQeVvuhDLJtJ7YppRGxurW6v6rKBXOFVUufQtfiY045W5YvL+XS3Ch/phzAlvn79/0TRPLsyV0GUrHdtt9Qeqkmzqho9LeI5JL4zEOSqOVVzTPYyOZti0ZX4jmkQOex12OtbMrXtapZUysc06NzHI8llhfhDzzFl1ajr7Mr6h94MLHCTsFxXeo9qUtPYPOEkZ34HqvH01RJCBujZ2IOxcrLtbllCHGoLZTPGe0OBvp8Vw8mErfPTdC04XF47T3XI55rdtlwa2ihOgJcR4ABcCFxhpG1Je9zhIGYBwy0Wurq3ONLNMBZ7LNDOfX4rlcG5m27Oq8NRZmmTVKY7+ufIPbmJ+ZshQGKFkpkwMmaLhpyJ8k3YzL7k8+0uWU6blI/EDQdqQgatiH1K6TButk1R/If0XM2mce2JHF1wSGW5WAC6cnZ2LJ+YAfEhMvUWFbIjvUN6NWaoO92q93OY/W32W/YzfXOPILn0w3lY135yfiSsKm1nW2hC33IwPmVTakjG7JiiZ/uSAOy5XVNqDebZeOWBvyCm2W2lpI9BhxrtixWOBhZYskcA3PVc+R+/r6iS988N/54LpzjdUEr+hK5GzmY4ZDxJXfCdWudr1f4bYW00gyxlrrZ8Scly6cztfGBzAK17LgfHS1E2I2hYbZ8bJ2zY8UkYOtwvPb26T0ftWSX+hPE2TpXho8NVu2K3d7PceTL/JY/wATvtFSRnLE8u+A/dbqKWMbMlwyMLsGl+i5X9W/tI5GwUL5H9wR3PmV5VzQXEuviJ4r0G0pWRbMdG7vSDCPI3XAFuS34o8f/Jy70sImYxbVcrbIwiEc7ldMOtnbjxK5O2ZMc8Yt3Wr1eP24eL2ywi9l6OGlkqKJ8UcZeT7I8V56mHrAvYbLqvQGmTd48Qw5/FXL9n0NfhXOZ+G6l4za2MfmOak2x6uJoEYEuHhmvRDbtOf7kDh1BTGbVoZB3nt8v0XSPFxeOfFXRGz6WTySzUSR/wByKRvi0r3Lamil/wB+PP3h+quKWml7r43eYVHh8QeRnleyEkYxOSYGFty46kZXWiTtOJuM+q0xVmNY2PFh1HRZi5pItiHiE14AYcgckprbi3yzV6RJh6tvmsLx9Vulzj7mCx+KxPH1XKvXh6ZpO8F1jOGbtkfrJi3TgFyZe8tsL2wsAiPbcO04/Ra+mb7NkwscHzvMkmtuDUmSYv7bzc+yEmaS5zzKkDN6SHcGkhEXEbpGh3Nwb8lriILnRQd5znW88voluc6QMYzQuv8ABoToQKeJsjBeUxtIHM3yWQlzjDAIu8+RnadyskOHq2/4j6LVIwmiYSbySMdb4rLHi3TSeIsixheLOUCMv9woBdWHXu0UbQdbZBSmIjNnjCXcVmpjcjECQNFrqTk0ZErlVJmaZHuewAAZeKq44g2xsXcU5rhE1wORbp5pDX3luBxy6oi+J0Ycx4uTxV8IYGv7vklSM3zwdM9U2Md1mK9lFMAEmZdcLO07t4LhkTYJ722JCrK0FoztxRUZBvXF17W0KLHB8gxPyYrxjctILsjcJW7DYy4ix456hQEXMxmw3bi+CZuDOZH4sBAuP0QaWujawHMm17/NVbLu2va2TJ2SK2UkrZ5/Xvu3DkD04KtK4U87ZXMIZcgeCTIYmxMLBief4VZ1YHUjIicNjn91nTTQ7GWOrMZa4vuAeSs1sR2YX2Dpi/hrf/hY31rAWRCTHEHXJVXVoFQHxxhrAcQYeKnGq6ccpFG+hLC2UvA8QkzxvppzROlvG5wdfqss9ZNUTicRkOysfulSyyzPLpZYw53HiLJxXTo1jIoqzBGHbsAFzBwTaidj6/fQYCyMNPIEj7rig3veaR1+DeKvHSSyf26aV/inBdOhUVkM1VJU73A5pGBut+iQa9svrCx3pJfixt5clePYtbIR6iOPq7h9VqbsCb/cq4mZcE6ikCZ89O7HGGu4FxzPxS5KxmEjmOS2jY1M3KWsc4/lT/6ds+waS85a3ULpjk7cbXD2gPouVF2doRjxHyXdqIxCzA7No7ptqOa4TnN/qcWHg+y3iw2yjDUxO5kD5JrT/rYeHa/VLq34Hxk8CPqtDrb+I8cQWFMrey6M8nAp82czehss1cHCJpdmAdfgnud67naygErcIiffj9lTaAB2ZK7lY/MI10jGxN42fok1Mrf6XOONtfMKT2rcztU0n+H2KOx2jcU99LfdKonYqb/s+ydsbKng8Pupl6rUbvxKwegxW4TAfIquyj23DmE78Q//ANsZ/wCqz7pWye+fArh/1dPtwaoPFTPb/rn6rqUUM76Od7uy0RuOmuRSpIf/AKlVN/8AzX+IXaiZg2dPw9W76JneomPtl2ZG59AI4zhe5ha08jhXDbS1FPUSQB13MdhNjqvQbHcGU0LyLhoJPwWBr9/W1E2GxfK5wy4FWXqlMlpZf6LO6QjJl/mEzZwtK0cwtVSf/oVV/wCmkbPF5WH+aLP/AFrTNtrLaRPONv1K0N7Ww6j/ANM/RI22P/qA/wDRH1K0wMfNsedrGYvVm9hpkp9Q6cCgNnsWraQxT0h6H6Bdih/Cgaxkr6wuBFwA39VvhodniV0T43SSQi53n2Xb7257c6nljFLIHPBJYcr66ryU9caWQw7oFzbA3Xvpn0tIfSjOyCEMwiPAAL5Z35r5zt6pZVbZqpo3YmPeXA8118ODGWS/p0tfPG2pkdum+y2wsOn7rV6HQBp7NS4uGIAPZc9Fz9mxiWqYwmwzueS6T6yKml3dIN5INXldb16K3Uv4YgloRWSPfHBYkucbWskwbO2JNe1bcjO1iPLTNV2pWurKaDZ9HlHE0bxzL4Xvtn5BXhp4tlwOlOcwsc22z+2abZdSP8JbPkhbO0yPhcAGkO4+C8lt+iioNpSU8LXBrAO94L1+w9oRt2XK2aPFJDOC2M3tmf8AleX/ABU4O23M4MezE1pwv1GQ1Tx27ZrjtvhFtbr0NDQSS7O9PkLZoYbB0A7OJoy1XnWi4su1Q08j6Ns72l1K1wD44zm7qt5+ljr1FeyOpln2NE9jN1ae7LMab6gcwmGmh2TDTbUgqYquRzu2Hkdu+pbyIWKTaTaSon/pryKd4F2PzAJFrhZWtdRzQ1MkMc8eZsO6D+q5Dpzio2m6s2hs+IwQkBr4xJ2pgNT4/ZZ6ypoadlJPsgvZVBtiyxJItnj6/ZYXzOY+WWnElPSyPs62linO3dDLDU0s1y5pxsOpC0ylDUOq9rumkLBI/tEAW4DJd+fbU5tu4mR2Fs153Z0mKvfIcy43W05u5gHS64Z5WZdL5b+KVVRXSG28aP8AFoXOmhqJHOMksnxK6Tj2h+6s0kcBl1UnlryOA7Z7mOxB5BHNDd1Le69egJv7PyQMbL5xgrc89+zdcEVFTHkWk/BEbRezJ7beS7bqeN/s2SX0DHcPotTzY1edYWbSBOqfHXg8UTsqN3/ASzsRvsyWW+eFa5t0W1ZGdydzfMrZF+I6qMgF2MdQCuH/AEmZv9uceauzZ9QzMuYbcb2UuWP9amb6DRTiogD3tsQE4yNbxyXl6TactNTCJsLcQ9q+vwVJNo1clu01nRo/Vea5O08mMenNS0BcL8VVbXbGnjD8RJbl/wBy5uKSUtxzOPS6xbWibFs84e8XAH4FXx/tNp8svTDQMlqTJA04GPsZD4LsUdc/Ywlp5YsbHjE0tNiuHSSOhIljcd9iybwIXQpaVtbFJNJPeTO50DF6MihUQTF3ps1M0Rl13RgWNudka+SOrli9Dbedrb4hkGjkhFUz1AFIJWDEbGXmOSZu3bKe0hxdBJZrmk2dcDUKMhRQ0ktLMJf7ovvHP7zc9QsbKuWSMUYnDI8RG8PEckyWmqNoOdUbrA23Zaci4fdMqHU01KyCCH/UOyDG6sPjxWkcvacDaepMTTk0A56lKja008h9q4AUqmyCdzJi7G2wz+So1pMN+F11+m8XY2O2A4t6WC8bjc6hOa+aTd1EjgYoHNaBxtz8Vi2dQuma+R4JjjaHkDiL6LqStbLVupqSWMQzAOIHdbxsuOXtaU0RVddK+QOERBe0OyB5lJZG+ppnzGU2pm4WX6G4ur1MpqIIYxGb07fWYfZGiu6OOo2iYYzaAlotHo9wbew6qRBk30sR2hI5pII7GWbf+Vog2nMydlQyNsVKX4bHgeaRu3STSUEbgIY3uc5188HJLY+eWH+nhhfI1xGLkL/qhvTXHK2q2vOWPa7E7HceGYC7NXVQS7N3cMjXODxiA1FiV5rfMipKd8Vo6uJ5BA1PX+dUwB9BLFUPdvmytIPjy+i55ePbc8j0uyzu4Zn+60/ILnbNka6qjaG8MzZYaOsqYJTFNIIY5Y7jFysr7F2g1tTYQkkg2IOZHNcvjrpM5TZjvdtSu/8Ay2+CG1H7zagadGNATdlFj6wmS1y4uLXahY9qvc7aswYcwQ2/wWpDcV2ocOyyNS5YdkMvBfqT/PgrV0tQKRzZMmkFN2Q21O0LvOsGb27sI3ewKl3vdn5hM2XHeoZ0CFW4R7BYP+pI0fUpuxnDfG68l9V0/wAL/Eb8W0IWH2Gk/E/snEx0Wx6qqMWLAznbjZc38QziPaocbgdlt+tr/db690Q/Dsm/vu3kNIGuZutTH0XJ5uTb+9kN8BZqGSM7vgRmnRVlPMQHAxk8WDGP2XMk2U98D6iONzIhoH6kc1kNLK3C5t7nSy9fHH6eXKcvb0ZiDz6p7JujXZ/DVcLa2L02zgQQALFLFXURmzpC63B2dkuWR0zw92p5LWOOkxw1TqT++1dmukkZSwCOMvzN7fBcalykB5L09M6llhDXSi44Ahc8r3t6cr+HThenvj78cjVZu1GcfmCvTDZTJpGMa8kyaXZqkbR/DrqNofLEx0Z9tmnh4q/J/Y8X5TtxG7Ra4jNvx/VPZWgZ5+RQfsuB/sWSTsiP2Xvb5rU8mLPNSxjZ7Jz0WcvdcG9ul0fSor96/BLkqInHFicbdF2RqDxIwWemuNgBa45rNC9r2nAxzW8XOz/5VzVAODIe0fDTzU26THZs4tBbQ30XOk1TXPc15L5LuOVgkvdiK516MJqaZ5u9omAuLGjyVZc0+mZjYSdGjEr9JktHEx00V7nFnbwui5lpomDMOsCfPRWmv6VC1nsgD5Kxu5kbW5yPDSowL5QwlrW53eQeVzZMgjFM0SPOIsEZt48FUhjKVpOb3MaD5m6uwOcwTT5BrD2f8RYIKSNkZTtlLTvM8I5XSgC2BoOovf4rU4byL0l3ZaGWAWKEudAb63U+mmCbOQqoVpwRIVULrPTn9ulA1jqZGJwLuduuiTFlH3rXTWRRxtL3Pz+qxWtaMmezG3VLeWsBI0PDqlh8TiC64I4oGVpltbskaKSGjYZDhtbpdVBcHucRa2Z6pMjw44WNOEKOlcWhuQsroOBdMQQ7Q/BWE2CXsi47t1jxZntqXvweU4jXI/F2sbWgZqr5w6PCHeI5rMcv9seaa1km73gLWtV0qzJHNYWsa7MWUaZGsIJa1p1xWuld42L7lN3LNznJ278kTciv+Upt0uUC5jeBPiquZZ2uLwVmx9hpwEm/HRDmhdcZMA6p0M0tsO9wNCsyR7YxdjRnkSM0I2RvLDiwC+Y+6aObZS0PpAc5wkkAGbhoF2Y9lU0VOZTA1wsLte7teK4cT5Ke8Ae/C/IWtmF243TRwhm8u1rbOGWS5ZN45bLFS2MkU8LGF35VdlRNI0uMhDOIGoTIGGaI3jEduXLkE0QsxgMjkmcDcP5ngNFz20yMImBaJJA6+bXXt4qz6Spx4sbZABeQgjJa5aOrqJBIyjIw5BhCMGzK8OsI2MzvjNr/APKm01WCWFxiL2ta0AXNtLJz3OkAEEbGR2BL76nw0XQH4fkmbIyWSxc2xGL5rTBsARwYN6MLRoU5xdOM6N7KWUYonYWm/MXC8fEO2LZZlfSP6HEYHOEhNgTZtrXXzuIATNvoF18d6prt6ajhp5dnsbPGXPJcA7klvhkikYXMu1pDgei7n4b2fBPswSSMxPxOBPS667KKMVclqeNsQaMLjquNyaynbxlbK2Sn7OduCXvTK9vZtjtmvYV/4dpKp4OI07nZWjthPiPuF5uoptxKYnG7o3YDlxCsqMtdSiNhAdk1wCQ6LDs2Y/lIXSrW4o3G/EFZpGf/AE2X/A/RWCtHUPZTsAZiBb9l09jHFDF2bZn6rmbNbipWG17x/ddLYYtTxj8x+qzn9ri6m3GA7NuRezmkdDf91m2b3/IrXt13/wBJccOLQ35ZjP8AnNZNl9pzT0Xnv6u32RUnDtmdvNzT8WhdhgvRzDmx30XKr2f/AFdwPJh+oXbhYPQpB+Q/RS/Qw7CHqYD4LHK/e7Sqn4HsvIDZwzHZGqdsuqZFSxZXc0XtfXzSp37zaM8123ldiscrZAa+S3jNsZZadGON0mzJ2taXucxwAHE2StnbLqzZ72CJoHt6pQq5onYYZcDTwsBbz1S31MhkYBUSO4EPcc/FanjZyzdqnpqOqPpTgyQt7GJ4NhbhbROhcymxY6tj2u7rTYNHRcF7Q4FpkvhFyR9FmJEMW8qZWRMF3YydeQW5gza9D/Uqb01tM1pvYWeNNMguFtn8Sw0ZdHShkkw7xb3W+PVeY2ltY1LyIgWRgWx8XLC2B0vacREwe07Urtj4/wCsWrV20ptpTYpnPc6/HQDw4LA42efgtFTIxo3cAwDQn3lkwG67yRztrbTHC/MlocLXDb2TqbZ08s0ReyVrH3LbNIxeC+l7Hje//wDjcR5lz6aVot1Lk3YQa/8ACskVTUY4omuZvHey0AaeClXlt5T0M0MDZnQSgDDilMdmtvllz8Vz6kSelmKR2JspLQ7nlf7r2ETRP/8Ax2xsxxGQYSR/6q4tJsmprtlsqJQGCPsl788RBsD1vouGWLrjduZQVBincx7u1M2xHUcPkuNto/69+RGQyI6L1dVsOan2lTukbiMj2OYBmHXIBF/H6rHtL8OVdft2rhp9z6TGxsm5c/Mg2481rx+2cnkR3R4rs0fpL9nNLnyMoMYDy3PCUmn2LtCp2jLs+CnL6mJzg9uQAtxJOQH1XZp9m18VDI1lVANl7wNfUxSBzRmGnra5tkLHXRdcmdkyvh2dNLTtdFVwyNDhhIu08ieA/ZNbs00no/8AVA9tG++HA7EyM8A5dEbIk2ZDOXQRT7OmYPXEgObyaehKzRbOqoqimpNuungprEwtDrtvpYnTTzXLSuaXujLqaGdstO6TA18jeyOiZUUrtkVDTURxzxvbZrxqF6T8O0UW0parZ1QYauhphZsjRa9+FufVZqiSgptuzs2jQRijw2p3OuQQNc+auk285s6UekzStYGtJuAOGpsnOrKdzjeTAfzarqGmpH/iC+zIyKd4icxovxAdbPxXoqjZDZWkzUwkAGYLbgfoscJlV8veMeShe1wykxAdf0Vy22oxjRdeX8LUtQDuYHMPF0V1nH4Vq2MMkFXKGtNu2zFZZvh/jzcHOAAtdmEdCjiIAGp0vkurQfhzak84BfAae/akzB8hxXLmFXSyET7PnDQ4gODcWLrZYviyZ1YrcniR4KweXHN1+OYso0YoN+WPbHe2J7SLHkgGiTukOHMFYuNn0LF5PDMotIHfZbqjLTuhGGXGH658fFbJNkVVNs51XJ6lgIDQdXX4pJRiOFx0z8CiBh0OQUDshm23EoWx3dZzQOLRkFAbgEC/RVLb2cMxrqo58bbjeIhxJ7Mg/wDaqCLLnbdd/pG5avGXkV0sLj/uDLoFkr6CqrpKenpYd9K6TQNy049F08f7NYe3O2XMKaTfSi8bjhx2vhsmSMfUumnigcyPLEBkXDj4+SbsLZUVZtn0GsmkAa8ssw54tL/JdTbtOfw/XegU0hmBjDmvk1bcnLJejKO9rnVD6N1AwR5PHcDO9fqq0UPptSfS3ue9g7MbuIVhRybPc2qcGzAEF4vpdSobLtKdz4I8IY22M5Yul1gKNQ+nlfTU9Q0wudYSHMMTpYDst8dTHIXtFmvDtTzsoainZsx1M+HDIDg3emfvdFnhhLauNm0TI0YRu2v08FYjl18oqKl0jRhDtAUkSHd4T3cV0ytAFTI0WsHG1uSNNTSVbjHFmQC4rtPTU67dCg2i+mikY2O4nbhBHTJarmipnY/V1THtcLcrcD9QuK5lTRydtrmEHK/1C1xbUL6kTVTd7ZuCw0/5WLhvuJy23gPgYIWWkNWwEuOgJOZ8EJMUdP6EGONRFIXdjl7yRE+J1O+UykVEbhugc7AG9loY98IZtCR+8bMCHNZoOIt5rGhc7ulp6Wpp3t37gSS72r6qzIn7OkZPI4ybwFsobpc5hLoaeMxTmePDJgBAdwYRqPNCFstdCMUvq6dgDbeGSimwFrJZZK6ENMjDICdbcR8EungNVTyOdLIXwNwxN90XyKtJLUVcTKt8LXR09sYce+faQrKkVFeY6SWxlbunv4HNRC6mol2oRgiu2JuJ5PG+qbXTRQRUksBwEC8dvd4380GSHZjpoADM14BZ4pNLBE4zNqm7t7WkgO0AOtlQ6FnoTYKwkzCT+8OeIXV6Qsn2iTUMfHHUXdGOt8vndZKSCWuaYRPaOEEtbxN0x9Q+qpoKdsbzPBftHQAfz5JYsI2vXtmYynDCDGSHEceVk/ZlVEGMjMlnAAWPFcaQEyuxZm+ZQDO0Fu4yzTrHvdqlv9NpWi2cl9fyq2xmMBJcdON15ahpTUYWyyvcwaNJyW99tmV0cpZ6iQXC81wnp0ylxm23bDoakVhJwOhd3j8j5rn0UtRtcCnlf6mJtsJ4nglPlFdtFstVEY6eoIHlwPxTKxx2XXB0OBj3Mwuj90810k1NPPaYNoFlE2lEbn1TSYhfg1ZaW+zdpiOqAbiGBzm8OoTYIpKCqilqH3bKSx5J0us+06j0uS0TcbYewZjx8fsrGSdoOp5ZXGFjmD3jx6rn1Ee6qHx4w8McW3HFdp76Y7COQa52reJePtYrk0VI+rkIBwsHefyXXFuFRMknkwR5k/Jew2Rsd1NC3evJe44mxNyz58wjs7ZLKMMwsL6l2bYuJ6leroNmtp4i6V28neLufyXPPNqdmbPpdwwSSuvKRmeSx7drrUUzWAOvZhPiptKufHSybvN8bSS6/guE55/owLn4nTTF2fmvLctmc1iwZa2QNuSmOxzNkdf2K2+dfbikQNybCz5q0OcjGNY1ocQMghDUGS+GOJjRxKDKxwqGN7IGIZtC91d3Qq6ECN4DCcsjdCh2aJ6MTXdHnYgD58106sYmObzBWKCpfDQOnxY4gdBqFx5O8jJJsuOd5MFQC4ZG6yy7KqYjm0PHMLuUu1YphhFnHkQtrKmneReMB3Qq8leJmhkYbOYR5JtGBd2LMWXrKmnppCzPIm11mk2LG92Jsg+SvIriTgtqnt1JIF/+1VibgYZHuu6wcPgutLsSZpxB2IhZJNnVLMzHiAFkZKbAQcUmbW4MlZxM1ZEH/wBnE+/hc3RqC97XhzHtcSDZUleH1DWNOGJpOfjmgEjiS0uyhY04RzWeG+4cCLYXZedk2Z2MNAd6mA2/y4rOXHOQnMm4HJVWOo/uG6W1NqGuJxFKauk9MfZhNgM1Ac9LrTTU29GI4iB0Wr+myPN2wPaB7PNRbdMLWSOBLYsuau2nmcx0lrN0XUjpappEZDbkWBNshyVxs+YRtiMjGsvc5onJxmQukfhc+3UpkdGHuLcYD76D6rtDZrQ0l0gDbagKtPsmFzd5vHnOwyUTbmybPEUoaXXCucNA28b2yPcNF1P6dFbuvdx7RVZdlxlw3UbAeJJTaOQGSVpL2RWAzc4K7Io2Cw7Qtn0K79NC6KEMJjt4Kkjt1K2NkJLXWu5o0U2unIbHG9wbDC99zYnqt02w6gt324uLZ3/dd/ZlMyaUXkc0jPDb9Vv2lAWUYbG8FxdnjsuVz7bmDx0WyJTC4kNafFGPY9VmHzsa0dOC7RiJDg6VoHEBZ3GVtXhtjiFu19sluZM6c9uxmYix9WXuaNAMwtDNjU7oX2EjnYSBc8VrL4w7EIbO1uQqTV27AaCxoPAlAaLZEDIQ98V32u43Xo49n04pzhgYMTbXIC802uZnepjw6kWXSk22xrYmRvxaYznouXklbw6dChjbSNioy9pmIOYH84LTJBO6pZI2XBEALsPHJcx216RrjJgMktsnYbW8+CUfxDeNzBTgBwsSXLnwre47byN24Me3FY2JPHRLpmyCMipe17ye80aBcKHaop493CxjWjQZlUftaV5uJWsOmTR91fjpz09IWRnXG6/FLMsWKSlPewAuy4HJeXl2jUu/+9f5WH0WOSdz3AuqpnO6uKs8SXN6/dw09M+GFrw0A8eJXzBgtMPFdmWQkEb2QX43/VZYqaBrsWFz7a3K6448Zomb1GxZWN2OI966J4kL7gcL6Ls/1RgbYRPIHtEAea8N/UXwtwxMwtGeq20tfPI25XO4Lct16p+0YceMU93kBoJdnksO0ZW10dnQMjeMw8HMdFyZKqUu7/yCoJZXHvv+KmoLzYgyRsjbHh1SQ29BP/iT8kmrndCxr3OLm3AIudM02GeOTZ0+BwJwk2HBakWJslv+hYfyfcrVsmVkUQxcHn6rLsY/6CPpf6lWp6JrnPEhDHNk1PJYzbxldzbEjJ9jTGN+LCL3HIELNso5tztlryyWWprIYqSSkpgZDI0tc++Qz+awbyUjASbW0XPHDpcstOttKoi/qLXseXDAASDxBOSeNusEeBrHjmbLghrsJ7KBa/F3VuYRi57dF1VT4QLPsBbySzV04zDH38lhAcBm06qWz0+S6TpzvbeK6K39t/yVTWtvlG/4hYSDfupjWE+yfgqmlK3bbIAWMiJeebtFyPSJKyYb1wNzo7ID9FWviPpTji1KTawvpbiu00SNs7IoAMYaXjRrND+iwzVD5T2j2Ro0cFC+7C7kbqjW7x7bc1qRmhhJF1shc01TA47wltsSSWljsBzw5XC0bPpBJIH7wswu4aqWrx36fVaEspvwOzFk1lOb+Ga8dUbVrpopKR01o4ZA7Axoa17OOQGeSNNW7RiqZBJW1Qhf2W3ncQ245XWOVxa6N0+J00TjHL2rFwOhJ4/uuNzldMcNe3sKm/8A4DhMbN4Oy4293Hn8l1Hxib8PU7acb8MDDYG2K2Z/VeUgqaungfE6skkhAuxhd3oz+ipT1s+zAWRTOaKbPCfbjdx8lPlifHXYmll2tuqCWM0hje0wyNdnbn8EJaNtP/8AyJQSsEhM0Ly97jrZpFvouRU1k+MT4jJNTEOxjV8Z0P8AOqVWbSr5IpJ/S3ek0MmON9tGO58+CePP+rn4/wCNNVW1Oyfx5tLaDaZ08AjaJw3vMjwsuR4Gy7dWaLbX4cravZkjIy9hxlzbAOycQQcgevPNeKqNvV7HxVsdRapcHNc5rGguyHeFrHRYB+JK4bJfs4CIUtrBojHE3Xfe3HWn0uup4GfhWCGWEzQMjaJGwi5PZt2euKy89tjake3IqCkqoKihDnYo5ZdZABa3iTb+FcPYf4rqtlsljdLLLG4ZXN8PgDxSZ9uz7XwQbQqGtixF28MYuOQFkXT234JnjgdWbMJgEsLg5ro9ZW8z1AsF52u2O8bSqaXadRPeNp9Hc7NpbwPjloubSbWgoqR8LG4auJ+KOeDMudzPTmF6Cl/FG0aqOanrKyGimDQGPbHm463ucvIBQ+2z8BUZpqzaQmbaaLA3iMs/tZeg2U6T+oVDZPaF3eN/+V4T8OVtTHXRysl9ZPMQ5x9rLjzXsW1krBIWWD3m7nBtlnHJrPG+/wCujswBtZW294fUquxnuc2Zjj2W2t53WGlrJKVpAiuXHMlWpqx1O95a0YXHS61v05abdjOJZNfTF9lipRNLWNsBIWknt6DNSlq/RnSFoDmuOnJWFbu6kysYxpIII+abXTXRwhtRVseA8P7wGngVg2Jsaloo6uemhEdQ/E0PGZHgOCbFtB0dRLJuhhksSMSrT1b6eQlvbYT3b6eau4mnMjpqil2XUUjZTLJI/eRSSkeqPTLL91u2ma+H8NU26JlqhhxFjtcs9VepqmyA7unEd8ieacK9jqYQzRXLRYHqonF4btzV8bKltTE6WQNJIuMzbVeo/EG62PTUUVOGxjFdwP8AuWGhPFXwsccjne/DJNr20+044I62nErI3X8ViYSSpxK23Swsn2fUxRMY+V4a4NAtZDbDoqLbVBuqeCzhYjAAMzr4qbRh/qFbSySPlhgpXhzGxnIgc1TbrDXVFNV0r3h8DheKRowuAPPUFWxNEfimCCnqod1FgL24jgHFM/B87n1E0AA3eEvzYAb35rJ+JqqWskgkgpJ3ljbOtaw+efwXL2N+IotibRvUUswjlbheXd5tuIHFZk/PZIpsusNd+LaWJlLHGYqt73PjYGk5nVenr3UTvxc2Kohikc9rG9vUXvZeYpazZuzvxFFX00kooZbyua8XcHaZBdDaNZSS/iCj2zTyPlYy28iDdABqCulroZX7Gp6r8Yx7NzjpGxCTdN0NtQuhR7Ppv67V0jaXDs9jMnC9mycTi52XLq/xHFJ+IIK7ZoFS0NDZMbC0tFsxc5K+2q38PVTpql0j21BAEsYizd08euaz0jh7U2Y/ZNXNI2bFJDJc4+LTpmssz5NsDC1gigacydSeSTEwvmgjqjNHSOJMTXcUysI2fVNdTEdvvQa2WWnBmFp356Fd/Y8LY4sYzcVwHEundcWJdey9Ls4FtGM7XTy3WLpJ+FrXuxK0h7Glpyt9ljn2PSym4aYjzateLtDta8iqhwuNR9CvPM7Pt5OWnEqNjz07sUJxt1y1WcVErCGStJAPG4816YPQmigqMpYyepGa6zzf1ueRxZq8VsjXySYSGhh4Yh4hawWOrBBSSYIpmhjr6mypVbBa44qd4zywuXOmpqqjNrOsPh+i3OOXp0mUrpOkkhfLs+nAe0yZOdwyzBV2RRx7NlZKWsljfYniTw+65VLXGCoZK6PtZ4uoK3Q1MVRXb+drcBObW8ORKXFo8+kTMbtF8l5GkHANABqqVDzUz+mGG9MxwZY+03mpETUVD6SOW1PjLrN18AoyqeyCSi3Tny4sA5W/W6gm0ahkVWHUrhjwYXFuljp8rJkLHbMcXSvxMmjLCRwdbIK9NT0/9Ml3jBHI27XSHgRospFRV0pcXjdUzbBvNTY5DjjkceqY0dpvglDMHxTW98eC6V6MXb2aMvLgiI6jajn7yQGOE4WtGo8U3Zg7F9bBYptouNa99G7dGZgjd8bXXHGd108/qH1VSJ6GGl3Tn1TCY8uACtSUsVZRVEsoO+YLPe7QW08uHkrUsX9MkikmfijlDmPd7pvr00WF8zamrcGF1PFM6zzw6381p41zPUbQghpIor7sHHJ73IlaopYY9k3cGtsTHJGNXO4FCeMbGqmuiBcyRmbHd4nn8UmmpH+mRPq4C5sgJAHPgqM2zYWy1BEkQk7Jwtdz4L0NBs30JrY2NEtWc2t4NvxPROgpy2UGNjTUy5NFtB16L0uzdnso4i53rJnC73kZlTLLUbkV2ZQR0bN9IQ+Z2bnnXwCy7W2m6ExRs7W8cW35KVtWROYYj2b2J5W4LlVwxU1LKR2hIDbxuvLct12mJkl37PrbjOxNvILI+N0ezaSOT1lw5w6XKeZGx0tYxv8A0wSepaENoyiN1NGfZivp4rMc/P8Aq55EZ70WvRQ08Lzrh8L2TDUNB1v0zQEmIXxN8Ft8941rS/PgnRNDZG+IW9uycU5YJLRf9Qj5LXHsWEOBM7jnwavpV1dOU3jN/wCZrl7HImZVUkndc4n4rpPvhtcW68QuBs1zo9sAty7RuOi4T7d46WzqUULpJJO812EeASdvQOa9lRGczkSPkU7b5dFEJI+5JkUaaZ1XstoHej7JPhon+qNLTy+iBsjzv8GNv6JNHtSodMYZGYsF7rP/AFFw2tG+Xssvgc3xyK31MbaSsfJ7UwFjz5p/6Gy7U3QwyNdG46HorR15cy7ZmHo4apNXEKyhEg7zDZWgiZujTnBcsyWRI3tqZAZS0g8GrQaClkzw28gubSUjmOfvHYQHYRn806tM1CA6N5c29s1dml37EjkJwnosUv4fkjJdGVtpKud9NvTGwgdeCazarLjGcJPVXkacWq2bKIMIjs4anmuW+kmjObV7Cesjkh7DgRfPwTGxQSxAuZwWpmzpwtjS7qmnJZiORA55LpU80skRxtDToA7kmu2dA83jOE+YQNBUM/tynzIKvJLCJoRNM2WSRrS3g0ZIukbURjBKxzWlIqYqxgIIY8EclgDqiEENYWnXIKs6dtzmBhaQHN0NgowADsQtt0/5XAnmmkiLHyPIvchCnldhtjfhGdrojtSwmZ4e572tBthCrM4MaGxSNa8e8RmFxZSHEHP4qkcbnuOCMu8E0bdxtXHA0b2ZuJvugH6IM2xG/E3G+/DLVc2PZs8o7TQwfm/ZaI9lMZ3pfgmjbsbI2w9k190HNe3Jt/mo6sqKmaonLMrXDS42HILnxwQQ2w3xDjcqzqjDx+a53BuZrzVVXJibHG0fm1z5Zo08tcP7kjD0vos76u3H4KnpZPBb1E3s59JvJTLJO8k6huiHodMDdwLyOZKzmZ7zYHM8k1lNJIQXE/NTlIutm44IxdrWtt0CLZd53OHII0mzXOcTIOzddJlNHDkxgvZYubUwIhiDrF+K/QWWeutFYsaR1JXSZGDqcIvxKVVwxSx23jfkscq1xcN9Q45YkvHc975ps1NI2QhjbjmFRtNNhN4yujC8WN2TdCqvDmPzTY45WC1nDyRMLnZua8lWIRNicA4iwVGvAac81qdEMrxn5oBjW/7SqMbiXZro0U7IwGk2uOSqC2/dVg9o9lZs2srS6Rru68WTGhjgLyD4rJvGobwKcF5JtSNjaO7X4nFw4jquH2gcsl1toODqU/5DkuR7S1rTrh26dBUzRNbG11m6DJb33lnic9xJcQuZRH1gXQkyAK8+ft9Dx4zha6QpWu4fRT0Vo4LmtlcPbd81YSya7x/zXaYvmZZdujuWj2VUwN5LB6Q8f7j/AIlT0mT/AKicWeUbxC1vsK2Fp9hc41Mt/wC475KekS/9R/wCcV5R0d23klzyNp4JJLd1tx4rL6VKD3vkFk2lVyejkE6nLIfzVXibjj1LzJUHxwoFxZ7N7jiqZYyBw1TgxpBc89ltsup4fBba+l43Mha8Fm8fuyGn3XHUnwGiyta3dufi7V+yrmqe3esi7LZMj181pEDIWiN+HeWLnHllkB91tz9s00TYpAxrrkNBceF+K1bOkwz255rNLhdi3bHYWgdo+OpUpXWqGE6HJYy7jpj09UXibDTaGeMEf5NJKROcDBNK277GKo8dW/zomikfUwQyxntxuJA58U2rlhErsYO5rI7eDhovJ1Oo7sjZJnQR0zG+vZZ0bubXCxC3tYyalhrQLmEYXM5t4BZiHRhpaPX0eZbzatNM9ssz2YHNgmDgPv8ANZyv8WNUQazHA1ofurvafejJzHkuVAxsO0TTSHFHODH4j2T9FqjqJGxuIaWT0p0PtMPe+GqXUBrqJkzO9E7eMy9gpj0VT+lRi4wuyOWan9HY7XHbyXQNQy7XOd3xjHmiKlh9to65r0Y2vNZ25rthU79b/AJL/wANwO9u3kva7Bmp61j6SYNe4ZttZLooxT7ZfBJuyxvexciunbG3iT+FA7NlRbyVT+FJxm2raRyc0r322qWOkmimhDGsdkAdLoVdTCK2COOGHC3Dju0Zk8FezbzmydmOoWxmR7XOYS7s8z+y7O+xaDNdTa9LJLPDFTxYsLD2W2AGa4ssLoZd3IxzJL6LFxXlyP3lxa6gd+eyq2kqi0ubE8tbmf8AhMoqaarmwMbZoPadyTVOhbILjtDzum7wW0B8Cs1Q2Sne8FtxisDbXNANkLnXge0NGLunTmtJ00iVg1bb4o42nT6LGDdwADiToLq8hmiFpWOZfS4IUGnI+z9FA4NFrLGHWBe1jsN83C+qs6UsI9W8E8Teyu0aHOZxQBjBuliV4FzHceSG/b7XZPUWUDhI3CSql9+GSpvmu4tUu33vgQqC7CTay8Z+Ms9pQi17RDLzK9icje/0XiPxbJba4PKNv3Se1nTT+H6TZ0tJO+rcMbA4SbzINadCFzy1kswibPJHQSTECV98K0U2z6na0ElbeElgDWRDV4aulUbTbtCkjoKKijMsjcL4y2zIba/8pWmHaFO3ZFS0U9SHB7bujOduRPNAbMrJ6f0wvje7DibY9mwzsSn0ccGyKySHacTTiZeOdwJBHEDx06aLnPc+RrnNFTBsqSYXAztny+iaZ0ZNWyV0IhZTGSTVx4DqEqleylfJHNHgmINnu45LpbVbSUDqWbZ0jWz2AEbRfet5u6rI2F+06WqrqioZeEHDFGMm2HLgFZEcJgxTAdfuvUU8dqKLTieq8xT9uoHivXQ7MnrKdrqecQllxhIuDnzWPJN2R1//AJqMAIHbIRtgyviI9pWds7akOe7hntn2T+qTJU1FOD6RQzRgcQLj4rhfHXjsN3vH9VAMY7OY4g8kmLaNPIM5A1x94aJoe15uwtA6DhzWLjYyjGta46/EZK+pvl4FUcXHg1x8ErHIyzTHGR0UnR6LqNlU07i7Njj7pXOn2HLGcUD8Y5XsV1t4eZb42VmuINsPS7V1x8tjcz089jqKR7d4whzTcE5fPVaKHaDYZzI4PJcDiB4rszMjqI8EoxDXW9vBYZNhxSXMMjmv4By6zyY326TyRUlldXBzjghkcfa1Nka8ilmeyFwDJmdpnKy59Ts6opSXFpLRxbokCQvc4uGeE8VqYy+nSXarM/inMHrAlMTmd8JXqweg2cwmJwabEjK6wMMMNNVQTWbIw3a63aceH85Fb6Zxio5JBqxpcPIXXKbHNPMKupjJhc/guWH2v/IvUhkfpe1nsaX+rjaAOWn1WieeJ+y2QPH+pjdgDBx6oVkw2bWSGlLHbxuTRo3JSjhnpaiKSeMyma7csyP3W/bxjT0bdoU887qgGXJrL8OS7lPC8Mia9wlmLbMadD1KzUlJFRsfO5uFzzlbieAAXpNj0JY3fVNnTP8AkOACm9OkxP2bQR0rN64tfOdXcug6Ku0KtzIZdz3mtJ+SFa9tO9zmGzcBJYOd9VjiG8nq2anEfm0Ly55u2Mc6AESFx9iYk3/M26a5u92e9pztLa3QOIWVrt3TOeBbsRPJ8Oz9lpbPeimdaxdNp/3DNYbZqqBrJjG3i5rT8f2VNuuttNzR3WtA/nxWwjHtBo96cD4Ln7WkL9pTf52+AW8Xm/5PUYw9Q9rPPLoVbCHDMAqbtoGjx5ro+ccQ5p1Y3/u/RLcbn+7b/EErjnacp0DG+SrLXSuaML81769HTvuyiGfmQuc1rIT6T7hcD8SnUZlexpe4lhbx5rNTPD556aTRxPldcHeN0Mg2nsySNx7Tbi/0StnGOnZTwud/cOF3jZL2RE6kM2N+FpdgA59Vk22x8FYx7cmntDon+KdtPZwO1ovckIv4XXRrmipoyYx24OH2+CtUY6rZwlAwytbjw9eS5mwqsurJIn6S5p7U7YhL4pmONmvJsFTevh2pG3DmXYLdFJGuoa0xN0EmMD8vBbKuJrahlS3Qt+ayM+1X7ppc02DhZa4nHaOyRfNxZY+I0+azVIFXs5xAu8X+KH4dOGJ7XPykOQ8E+gykqGNdBTHskgst1H7rP6EItoukdlGzO3VVr6Z7NqMLOLg4fFbtpMLmtlbqOy6ysRz6yMTUr5Yr42nO3JV2G6Sd7mySPwN0N9DyWuBgawxgixyWSCb0F8bBq2Q38Ff8DvTZ4ap0BAdhdZt+q3Grkh/uxkAm1xZUqKdoroqjgRl9U+zaqncNTw8lkD05rmu8OKy0+Cea0ju1rZXp5I3u3L2lzHX8iss8LaWTEDgt2gb6qs+3Sfs6CX3c/BZJ9hA3wacgVKV08lO2RkgOuVswpFtcg535FXZqM/8AT30+kUb7cHBT0h8WToS3/FdSLaUUlsWHzTT6NLmWjyTmcXENYD7duhCU+qJ7rbrs1VHTuYbZk8MljdsIFuNpseYK1zTg55kc88suCXf6rXJs2oiPZeCOoukOgmZ3oi4dFN7NKXWinp3SuBIyVI5Yo++xzT+YFdGCdrmdmRp6CylakjRHQBsYd2fNEFrRbETxsFTMnXhxKsDboscWt/w5kxAsI/iqOkcRpZDEFXFcpx0m7QIJ4/VEMCBKFyro7XsLKeSrisrXz8kEOSqX2KhOeiBOeiC288PgqOdiUuBwRyQUw34D4K4a3/pj4BQBTEBoM0NDgZb+234BDdRk/wBtnwCm8twUEmeeiGmTacbG0TsLLZjRcIald3abw6jd4hcOwstR0wbKN3aHkuk8ZC+l1zaMdtvkuoG5NJOhXDP2+hh+lN9Gjw912duJQNM386vjz145qY+q6yvmZTso0rffPxQ9Eb/1HfJOxIX5FXbOoSaT87/koaTCD279E0PeCQTcI3JV2ajNbAbAC/guRtSXFIGN0Bsu3OA2J7jwC85O7G8353K1jUk+kiaSRfS6tu8TYgf95xd/PmtFMyJtLUPk0ayzR1KTTS45YzKQGNGG/TirHTNUME9WQzJjbnwAT94yJ0m77TzFgBP/AMijTOZI6sLfVtcyw6Z6I4cNRu3DsABrugFifilrMhbHRsjkYGhwwOxOOgdla30WUX1HBMdilY/D7RL3eSpGbW+Kq4vZ7LlxULnjVgEgHQapsrGYaqm0bM3HCDzv+q5v4cmuzcngC3yTjBI+nJk/v0kl2392/wCy8OWP5PRL0fHJhdDUPb24/Uz/AGSyTTTy0zGkiI72IjgNbfD6JkssT6sOcz1FU0B7uTgkTRPko5J3XFRTynF/ieCBtQJAI54RjbCS53VpP7p1O5rSIGNxxsBe082O1CXSSOMAewdn6tvl88kjE+mqSGPxspjjb+aN2vwy+amt9Kk4dHTiMG7qd5YerdQUhskh/wCAmNYY6uphAux7cTfLMfJUyGYa2/gV6PFfp5vLPtu2XVuodoQzOzYxwxW5aLtfix8La2KRp7csfatkbcF5cHL2B5FPlqHzvD3gOcA1gNuQsF2lctfb1c1ZFWfhZk73t30BABNu+P5deeo5C+uhdZhxSNubjmsjalwpzTgvELjjwYcr81aCqNJOJou+zMdnj4HJW1HtdqSOb+JdmNDrAgggeaVtiOWT8QUIpiBLhxG+ll5aTbNTU1UNTJIXTRdxwaBb4Jz9t1r6yKqc8CaNpaCbC44iyu009Xs5jo9vVrZZMchja5wAIAWX8PuadubSa3QfquG78RVQrnVUTYmSOYGkG2dlmg2zVUm0XVbQC+TNzeBTcNNMdWabbZfMH4GTEuHS69LLBHtAPrNlVY3trEX7J6EcF5Oq21JPtJtY2ngY4G+DXF480aLbjqF8slPTwskkFjhuRbwv90HYoGVbdj1xLo2sJIdI6SxBGRFrHLzCfWSf/wDIQyueXPGGzzrquRQ7YLaCekkjbNFLiJ4WJ1Rl2jJLskbOdFGIwAGuF7j5qbi6rsTzyRfg6CVrvWdnCR4p0zzV/hdtRM+0zGYw48SlVUTR+E6Zj2l7W4btvqLrlbR2mKmhjooItxTM9nXw+au4mnW25UyUmxqCSIdslpIt+VHalQKn8OR1xjwydk6DibfBTbzGf0qh3rHPjYRcNNvZXI2ztN1dBHS07RDTR6XOZ5JuGnLfXy/wBU/qczfaHmAlmnd7/wBVV1I86FvzWemtUx216kAjdMcfBef2tLPW1zpzBa9suGS7ZpZb6s+KqaWbp8QksTt59k9VHG9jGyR7zvBmQKMNYaaSJ9OJIZI+8S7vLtPpJRngB+CQaftdpg81dxdsM20BWzOfXTyFuGzGx6N8E+Hbk7dnvpHNZL2cDcYFsNuP2TH0TXf7bfgsz9mtv3LfFU20bOqI9lVTJXbqoD2hu9Z2nReSTtOcVM09Ts9j4oXNtI6+ESeAWWXZ5b3brM+J7MiTZVNt2zZmU1pH07Jr553XoqXb9LhwFj4PDMfL9F5NkgDcPAZK4eOazYvL6fQKXaEMzfUzsffhfP8AVPMruOi+eNf5LZT7Uq6e2Cd2Hk44h8Cs6HsZaWmnylp4335sBWGb8PUMp9SJIHfkf9iufT/iZzRaeAHm5mR+C6tLtmjqAA2UBxywvyKhqVgk2DWRHFTVgkAzwyJDoNpQA72kEoGhjN16RsjXcweYTWnk6/Q2U441i4PI+msYbVET4jyexNhqaZx9W5l16d8MUnejasc+xaGc+sgaOoGfyWb4ozwcnsyAcOqoQ9pz7XI/8LZJ+G2MN6epliPAahZpdlbRi/tzxydHC11i+Gs8bALhmOHTJc7a0EYpzK2MNeTa/NanmugJ3lK8jmzMLn7RqRLS4cBY++bS0hXDHKVrDe3Nj4J8I7aTGOK0U4u9dMn0sPp3D6vZlR/h9QudNtczUQibHeS2EkaWHHxXTLBLs+RhNg/sk8s1wpdkTRyDdvDrnLgs+PVjP/IvchtJFBPTTA3NQXANBXpdnUDYIWPqXucGDCLa+AWbZezG00G9kLhfl3nnkF6OgpZLiaaMEsHZj4NHTqmWUjlMVqPZjpZhVVGRA9XHwZ4rZV1zaeEl18Q0AQrK5kFMX20Fy3yXnql75toQlxtjp7264s15sstukjaakyQ1uPux4hn0aChSSl+0nvAuyVjX4vIiyLWN3tcxmTXNuW9SzVSg7sRGj4WfI/usNuXG17nAuDcBgcG4dMnXzWyYZS8M/wD/AGYqMJ3uEC5EksdvG5Cu2THTyyNbYllyfAtUVaF+Pa7Ite2991w6qbFUyOOYc8u18V2adlqiaoP+1E4/Ny86HXdlkedjyXTB4v8Ak3swyg8HKb7nr1sqhzxqLu4EKu9GQfHY87Lo8Tjlj3xB/EIxwSPGUeI+BXoW2bkyHLwAV87HuNXuehShaRQxtc2xDSLEeK5LmP8A60XMyAdc9V3m5x6/JcqreIah0p0B+WS4fbtPQ7RGBolb2mXAJ5dVou3aFFHIG4nNNyOZGqzbNqhXNmhm9q58jkt1A5lM2OlPMtJ5uS9KrR1olqZKe1g4XB+yxRxR0W05cX/ZfqhU0j4duROjOFrzvAfDVbdrw42NqBmWDF+qjRe2ImzRx1Ueo7Dk0RGbZRiOb2DVJ2bI6ooqiJ3iDyPJIo6smowynJ/YI8FBbZBc/ewHQC6tFA+CcAPw4HfFSL/S1UjzqXg+S2V0WMNmDrNcMyqzTKwj1dRrgNj4FKifv4pQW2a7NqIZJUQujY+4tbDYfFZYJzDLHCGYnA4XdArpFoHYS7F7Jssm2aYh7JRxy/RN2njieWtPq5cwVpZ/qNnguFyB9EU7dOOzmtdnJE3PLhZKoZsErmYbYhzR2dWiapkhd7bf4FibE9m0Xsv3DfF9FCt8hZBLKdL9r9Uqvb6TRsm8Cfv80raUb/RRMXZ8fBM2S91RQSQy6G4UF9lut6v3xksO04dzXscGd8gjxSRUPhqosQzY6568/kuztNm9pWzNzwHGFRzJqd27dL7uqlJG97XOxuYwfVX2bNvhIx/HtBEzGOMM4x3FlFUFXNvjAXA2zBK2R18kYIOjeIzWHcFjmVANy77rcYsLGh3eOqug+PabH5OAceeS0CSCW9x9FxWxshncdQ4LW6kdunPhe8PIvZZVuNJTyC92npks8uyYHG+AeSxRTSHC4PvfUdVZ1ZJAfWYgDxzVTpKmmdTZMlkB4DFl81VnpgaDha8dRZCSq3srXl3dyyvp0XUp6uIsAybl5Ko5xqnx5SU8g6tsUxlXE72wDydl9V0vVScGH4Kpo4n/AO39E2Mgka4ZOv4EKYx7ybJs6M5YfkscmyTqyTysgeTfirA5Lnvo54+N/ilESR94St6g3V0bdO+SBdZcp07h/vOHjdQTSE5TZ+KcU26mLooHFc01E49u/wAEPS5R/ufIJxOTp3PNA35rnCqm95nyU9Olb7hTico6IPBWtnmuaK+T/ps+aIr3f9MfEqcTlGjaA/0TvELiXyXQqqszQluHU81zhqta07YXboUhu7RdF9jFl0XOonWxDxXSkyp76rzZ/s+jh+lN4lRc817DmY3Z+Ch2lGD/AG36dF3mL5eVm63FymqwjaDCO4/5K7a+Pk/5Jqs7jWBkjis4BZPT4vz/AAVhVxHPEfgU1V3C9qThkJaPaOX8/mi4Xtm3ktm1Jcc7XMzaMx4cFlpmY5Wjrmuk6i4+2h7cMEgw91uviVleHRSgXs5gz8TqnzVMh3oZ3HEWVYn3ie/23uGvxViZXdaYIhAyXtDesAeR11Fvuq02hlndZkjrOxam2vkhUu9HfUhr8Ze6wfb4oxvxHdntFseFoHA8SilVrJYyHmzRUNc8AcATosbDZdTaMm59SXtlcIsGIcM9AubYNeLcrqz0n29B+Hy+Cua13tjEPNd/bQdE5piFzIQx/wDicwvJUNS9lVTk6N7C9pVuY8xh7rMqGFnnwXh83WUr0YenPdAIYquha/E2wkiJVYqnGxk7hfMMnvxFz9kmUzyPfO8buSkIaW828fmjI5kM7we1BWDLof8AlNAwkNdLRyZCMk3/ACE3Pyz8lJmuipmytON0Bcx/VpJFvmo8OifDMBd0RMEoPW9vjmlOeyo2gKckljjgBHtAtAB+QTWzbowiOnjje0iRkOZf7zDoudPaOR8YOQOtzpqCvSbWp4tibDpqJkgc5xxTOeLks4nyc4K22qSKp2BHtJgMdQxrQ/AMIeb4Tp5rvj49Vwzz5PK5H2vmiG2N94w24XXX2HXxQ1sFLHSR1DJXND3SMu4k8uVlr/FFBTv23SQUfqZ57NfgFmi+QJsusjlf48/j/N8yqmS+V/mvRbbZTbHqaCmipxLu7Sy48zJfIdeBy06KfijZkFLHTVlCQyOY4S1hu0ki4I5ZX+SaNvNgi/e+YVrj+Ar0G2aGm2RsqkiMJkqJiDI/XJuo6Zn5Jv4g2VTjZEW1aKPc4mtc+MOywuA+YTRt5rQfsVZuY4f+0r0dDJsOloooNosDqoND36nJ3ab8iFz9sz7OnlpqfY8J1NwNXEkADPw+auhynttnfToUovz/AOV6qq2Xs3YmzovTojW1Up7u8LATx8AP5049HSQ7U2vBBFEaVkubhvcegubeXioOcJXNN7fC61QVuEgk2cDkc13G7L2YPxK7ZT45h6rCx+O93Wvc+SxO2Exn4k/pZlcGHNr8OZFrq8UlN/q9VJEYzUOLCLFvRZcZa4FtsWua6NdsyioNu0NI+Zzad8ZfK9zraYs7+S6Aovw27Svbf/1ws8WuX+OS/a9ZLEYnzYme6Wiw+S5+J3kV2KTZtPW19WKZznU1M3JoNy88glUOz4a6iqXgyRTQAvOLtNLRw4ZrOqu45ofyVg9y27N2L6ZRz1TzKGQghrWNs5x8+CdDscT7MfUR71k0Zs5jgM/BQc1uMt1Uz4pjKSozO6f5kJgpJ/8Ap/ErPON8aTYfyysYmPb2mtI6pvoc3uAeZQnglhaTlc8wVPkkOFZnUjT3XYeiS+FzDm3LmFvp6SpqGF8cseEZd05H4rQ3ZVSQMUw8mD7q/KfHXDdCx2oWeSia83XpDsQuPbkefIBMZsOPiHnxKfPE+KvHybLa/OyzSbMe09g3C93/AEaEDufElVdsiIOzjbb+c0+Zfir5/JDJFe7cuio2Sy93V7MgjYSGtHgAhQRQyMDJo2uIdhDgBe3VPmi/E8QHo4rr6NHQ0sjSQ1t2m2g1TW0EA9lnwCnzHxPAUtfWUwG5keAPZdp8116Xb8hAFRSOP5oxb5L1Yo4QeHwU9HiwnT4KfKfG5lNtGOZt4326PBFvIp5q2A9p7BlrdaTDFxCzVUUFtfgp8rXxxPTIyMpgfih6Ww8HO8Gko0Bgax7BoHXHnmtzWxa3UvmqfHGAVEbjbdTG/wD+IrlbeoptoQMjp6d9w8OOPC3gvSkxDiiJGA8PknzVZ45Hgo/wxXkdxgH+YWuD8MVsTrnd59SvXiSnhaA3A0E3IHM8VU1cQHeCzfLXTHpx/wCk1LIi0PYDl2jfgkQbFnY18zi2d18TWNOR6Ls1UkNRG5uK3DVcClknY58TJXiMOsBdMamWsrt1aSpNKQ6tot0zHYSgh1v0XYlniZGxxksXHC2/MrhVbXGGljleXbx5Nj0tZbdosaaRr7dqK0o8L/uueWS6ZJcUtOHyuxOaZo3W+X0WeTtzUMmgfE7LzB+63xMxOnb7lTi/9w/dc+obghor+y6SM/AfokqtjpWf1KRjsi6FgPjndIoXk7Np5G3JDbX6XC1sY1u0d4G5vgZmfE5rPRi1DK3FcMkeB5OJT6GSTeSbUkcw4WRTh58XAAfda8Yc2VgGK0RHz/ZJrHGnqqw6F8UTvgbfZWLrxVDmmwMYv0OIpUOmeBTbUfrcBo+/1XmjmO58v0Xcla6PZm0ATe9QW38wuLZ3IE87EZreLw/8i9qsOEf20XOHvW6KF5aQHtz8FbG3TD8lp5mrA4jVVtg1TsRtZVLb6r6LsuzOM30XMnYySqML9XNuPounHk3PRceu3h2pS7vW68+vyd8fSuzKN8VZIXHC2L53TNsxkbuoifoRc/dW2gXQx71nKx6I7MlFXQywP7Raded0/wBabnH0mgZUW7bG3w/VJ2VUCqo3RyNvhJy5gqUFbgrtw7IPFgOv/CTFTvodpyOblHbFbmDoFlUppxSTspSy7A8ku5g8VK2lZHXslYMLXkOA6q9bF2xKG4sQtitonSMfNRAtN3xi9uiibUr4myQtkZxHzTKT19E6IixaLDw4KtC91RSPhfqBf+eaTS1Ahniae6SWnz/dVn7Sil9Hrmsfx7BCvtO1LU746SD5pW1KY+mRSNNhIQCevFb6qEV2zy1pu4i48Qm1ZX2r9nbz2ma/f5JtCzdRNjx2cRiI68Vm2Ax4ikD8mE287JE876SvaD7By8FKFzRvpdssLBcYwR4FbdrTejhszRa4wn7JlfgZJBUahmR8Dol7lm0KKVrHYnAEAdeCuxfZ0ortnSMk7zbt+OiRSTCCoih6lpS9itMEjmydkPOGyvtCmLa+N7TbG4G/UFWw2XtKlPp92dyTtfqutQvY+B0R0YLLHtDFLHHLbJtxfms2y5HMrTftNcLO8VA6mo9xUT4tGmzfD/iyy7RZmJBo7X7LdtGSRp3rBk4YT5LPEBUUeB3ebcJAaEvlpCy1gDYFCerc0tae8DnrlzWmkexlO3gAM/HikV1NilY5uZfl5hBdxZdknBhB8loiq2mrEOK7S2wP2R9GjbEI28BYrjFjmVQYMn4wB8UnZ6b5osNY4N0tjWmaIVNDl3mZfBVrWtjiZUDNoGF3h/ylbHqTJJKw5F4Lh4IFUsQlJORA581Sogwyh7CWtbmcN9Fredy+Ro54gehR2dIKqOVjuN/gU2voiPeH+3ISdVHV08L2iQE30IKfTtFPFICe0w4fABUDG1UDrZkXt4qB0W1QSA7LxWplaxwvdc7Z8Acd642DdFsraZk9D6RDcSMGI25cf54qUjSyWOT+BLnbFZoAsXZLkUIkfJd0hDAbLZVtkp4Q9zsbWnIkadUVq/p8UjM2hw8lml2JC7QYT0JVKTaL7G7XHDmSOCfDtBjbDHccnXV2moxP2G72ZD8lndsioYez2gu+2ra/gPJNbIxwV5JxeXfSVLP9t3kUp0cgyc0t8RZet3UT3AA5lVdQ3BsrzTi8lu3+PmFZvZHafY+AXoJ9mMIJfG3xAsubPsuC/ZlI6K8jh/HMmPZd2mH4LOFofSS4ntYMRAJ8h4rMw2OeRBV9uvjmvbpUgsF0pjanHiuZRHEO5fPqt8xvFax04XXlz/Z9LCyYORivbLieasLXyxAq26eT/akGeuav6NMR2Y5F6ZZHycsbbbC3PcON/IJZeTy+CcaCpd/tv+SIoKkf7RV5RnhSWOzH7LQ2VoIGL/4hWbQ1RH9j/wCKsNmVWIOEViM9FnnGp4651a71hZxGSbSRlrJZ9Wx5eK1/0GpkkuWnEei1t2NVGm3OCzb4riyXPF2ww6edPrGsjY3iXeKMbS7A3M6uy1XoWfhia/t5ixzV2fhaQHj8Vflx/rHx3bhVRvM7FYWaMLRpoLAIRzuZThsLbEMeHHobZ/Reh/8ACrzrb4lXZ+FTxOH4qfNgvCvNU1PvHh0rskuqj3dUQNF60fhYD20P/D7I3DF2jfUhT5ovxvKscWlpGoIIXtHsNZshskTrvhIkZ1TIfw/T2xHQ9AtLdgwAC7nkcguOecy06SacmormyTU8gHqahoEoHwKz1RYylkgD2F9O+7CHDtA8R8l6AbDpR7F/FXZsmkbf1QWeUHmZp2VBvjwidlpG8nAZFUopBHgc95DmPBsAbntAj6FesbQ0rB/bGvIK4p4G/wC2PknNFvxlEKmloayIOewndutpgcM/NMq3PpPwfS0chd6RK1sY+PHyQ9IdFCIw+0YNwDYrn7RnNQQ58ty0iw1XX53L4vpTc1+wtpxQ0+OXHhcXBgIzJyzzXc2rQQR7YoK2JgEj5xvDe1xz8lz9n1suBpdLic3McbHzWmWq3jsUz7lPm0fHtm/Fmz56ra0MscTXskiDAcWmZ4ea6O1opGUWyYmhjnU8kbnNP5W2KS7aRwtaZbhpu0ZZWSpNoMkOJ7sVkvn96J4/Rn4z2fNXijkhLA1mIXPM2/RNrqORv4QjonSgylrM/O9vkkHa43IiLgWg3sUibbLZiC6QdnID9Fb5k+O9IyDaFFJEyaCjlAa0EGG7iAALX4aBbtq7IpItp7OqoWNiealuIMyDjlb6fNc934huWl7o5MOYBsuZtXbT62aN28HZIsBwSeVLh29TtSll/rlJWsme2OJobgFje5OLXS4yQrtnwU+2qbaMMYZKA7E0WDXa3JHvdo5rnO/El4Yyd2XR2sXc0iT8RMkkD5XtPTQeSXy/wnjdtlHS1G34q+Jjt8AS8nTu4R9U6WCKb8QQVBaDJE0sB5ZE/dcJn4pijYWwxNaTxAJKzx/iUUtRvZInudrY9VJ5PScK7m3qKGprGOlYHHABn4lU/pVLQUwne1m+IsMrAE/suJW/il0tRHMKV8bm2IHNHaO3qvaAjDKJ7DHc4r6/opb3btuY3qOvQGSjinq4gwxN77Sc3HXLXmt9PLSbXp3yU7iyTR4vY+YXlNm7aqoYZad9H6RC8EFpOA59Udj1T4J6p9NEGOe0MZvH4i3nfsj7Lcy1Gcsd16qgcaWne/vQ3z+ifJHDUUz5YHWaQSQNCvOjaFRS0rqSrpvSIpDZjojhseIKwt2rUUdLUxBpxTG2NxuGt+56qTKa19Fxu9uu6WMEh3ApTqmActVwqeKeqvhqQCdMkp1NUtlLZXua0ZePXwXn49u+9R6E10I4+Cz1VfFujYhcDBI2TtyvMZyv9102bMiqIexJIHnQ31S4aWZSr7N2huYZL2sXrX/WWfyy4VRRsa8xtc8Ea9rRbdnNga9rJYWF3Ua9UuPSb7bnbYbpj+iS7bbB/ufMJlVsemlDqmGNtwLujYMj4Lj+jMaMQa0EG97adExx2lre7bg9l9/is79tvJti+RW7ZtTGWlhjFj2XC3BL2hTbiVpa31L9D9lZO9FvXTC/aUk+VnP8AVSnqJqOUufFKC/QOaVJpRTytljuXHVvMc13KKoi2hThrj2uDuSuU0Y3blu21I3/AGXgc8J0Todo1UrexC93FUqo3RTubMLEcOfVVpZtxKO9uybB3Xkrcetpy70Eu2JGPwOZI17ciCFnk/EWF4acbSTay9BVU3p9O6SINNSBbLRw/VeNq6UB5YWgOBIIdzVwxl9s5ZWenYbtCqkAwRYvMLJVbWkgJbPGWZ2zP2WanMlE9jZj6t2hPDoV163Zse36QWGCtYOw8+2PdKsxkva27jkU22gZTHHmX5ZrsU89ZILtLANe8cl5vZ+w5pq5zJmGJkR9YTl5LvRyso6pkMj7hxszEM/AhXOY/SYX+q11dUUbHOkw9k90HVY6bbzqmYROAjvkCV26+jh2nR4XWYfYkOjDy8FzaHYQooZHThrpjcEcGjl5qYzHXa1qEVTL3KhmmWRXBrtp11HU7mVga8Hrmt1PtFkNWadxvGDZrjw6FdGtpIdrQBrzgmb/AG5Ex/H9orz7NoVM1SIWEAOHaNtOq7NE0NFn5k5/dc3dCDaIgdEGOazTkuvSDE+/EgngrnrXSN9Y0b6kZxDS75hPrJL1ElOBe9KXfMpFQL7Qgb7sQ+pV6tttvRD/AKkBb8HFebTrCXv7MxaN250cUgPhl9lnrnMFmY821Js12puDn4ZpjfXDd59qkcLjXslZzSh7GvfixsDZTbWzuzn8FZEroyTYKmF/OJ4y6EH7pFPD6PFVRGTHupy7F4sUxGSOiJbYu3v0BQmp5DUVJEmBrzH2eZLbXQL2hCySYB5JxQtBA6PH6qej7h76eC15S0Au6uNknOKnp946/qnEm/JzV26KiDCa+ZlnubaFjtWDn4rUl9JldOftqiq/RW01Nu2uDsTzzOZ+68++DaVP/dpd4BxaV7QtcXlzjqgWAr14+OaeLyflXh/TcGU0EkXi1XZUwSd2S386r2D6Rknfax3iLLHPsKimPbhaDzCXxRyuDlF1zkgQeagcAVBmLAL1NLDIHNYJ8JqmSH2Qfstbnhhs7Rc3akpibG8WzdbyXmyl27Y+hp6ltZvYH6WIU2e8UUbg7XHmsWzWWqHSHRuidtaO7RMy54FP8bi+1YXsqYqiHV5GnPgutWtdJSCUd9gs74ZrnUbnTUIGHtM7v2/RX2RXmeeWnl7IdcgcuYU0NtE70mhdGfZyCVTziKpDH6HsHxTISaSQRDQO5c0vaNNeojkGTXkA9FlADhSVZDu4DfyKw7XY6OpbID2XZ+a17VYZKVs7M3M7LlSNzKzZwxC7ozn1AVNNMhfU7PDyMMwGMDkUjYdYTK+B2rjiar0dXvJ3RE94ZdEtkbaWte/IG/ZUU2pkFFJh0aXY2j6pe1KffGCZmYNmkrVtSP0mhbKPY7Q8DqkUYkkoBG7vjNqgZUMaaV0Ydpl4FYtjE09U9j3dlxw26qtM98lTIx3H6hUqw6KpaRo/tHxWoi+1WOhrwW913bHiujM7f0bKhveLcVlSuYKzZ0dQNWi5+/zRoJmuY+A+zY+XFEKoX+lUssDu8LlLgtCx7y67jw8FKeP0faTmaNB/+KXtZroZOyOzJn4ordGw1tE8l1y8Gw6rNQw2ifITa5whTYMzsTozfDqCrbRf6NI9nsv7bPun+Kz10RjLcuwScuq2QB8lKwlvbGYPNUe4VNO1/u2v9CnsnDZ2Qt0DclBg9OIq4zq3ukeKvVRiOpjk94W81mr4MNYA3uvN2roSR76jPEgXB8Fpn2dSSNrKWogP+K5+z4THVGQ5YDYjrxCmyJDHW4To7Jy1V5ME73cJhiHjxS9HtbbEN4GyN9nslZdkl4qrs7ts/FdCm/1ezd272mlp8Qs9OGU9PY8LlyzKtn2rtTHG7EP90fBwWfZUpa9zB3bX810Ksel7MdI0doDHb6j4LHC30alDj3j2j9lYUKqo3LHx8NW+a3bBnx07oX+wbeRWDaLAY45NRb5JmyRuXCV2jzhTXQNU11LvIv8Apuy+oXQhPp1BYi+Nnz/5WDbsLw5svsyZO8tFfYT3CFzXd0m7c/ipr7VaEx0tFd+pu536LKWiqoSWi7h2gOvFTbkb46izf7cvb8+PzTtlxujiOPQm6oWyFsEDXPNrZk55dFaqkmpJWGM443jIHms+1C+N5hcLm/yWyMmbZTez24jkfDiohja10bbvbfTNaBXhmUhLXEZX1uuDWVYlAaNNSuqA2u2UHHN4Fx4hOK7apK67XdpJp4rXMnaac28weK580kbKVts3HJdmJt4m9AsXprG9sUsbY3vhYHFrruzPG45J9JTQviaBTMZJ71gbfFKnAFYMuB+oXQoBcAdT9VLem5e2ujo4mOLZsMgOYLmgWWs0tJbuR/ALnbZ31O2OaGNzhm02OhuFyzXVTfYwgC5u+65TddLk9B/oWtD7sAHRNY2mc3ExzCD0C8vSbRNZOad8gjIyvriXVloqrc4qeoa9wF8Lm6q2a6Yl26FTum0szm4bhhI05IEw2a52ZIvkVyY4KmWnf6XMWFwIwgD5rLC/HK+J073BmQbdTjVl07Us0AB7IPwXJnmJqm4ZMLbaKTUQmDo2SyRyEZOxH+FZ6TZcjMRq3PLr5C+g5q4yf1bXdZUxtYLC5trkiK1gzyXmK2qp6adsdi7Ptdorr01JR1tNqW7wZSNJyS+P7OTo/wBRiv3lR204gD6wfJcqn2H6M6T0p4e7Rl9Lc/FZt7Sx7QFPZh6fZPj36Tk7J2vE0/3B8Qqu23CP9wfELRDS0dTC9j4WYJBhNgAVyT+HYtnPkfJ6y/cPIeHPqmOOPqltnpsG2mu7va65/ZZa7aWNl3NLcsjY/dc+k2pDFXGBhvFewd1XpY9xW05gqGB0coseitx43tJdudTbegbExmO9hzTm7bEhAjDnO8CsLtiw7KdJI842m+B51AXKp5/Sq1+5dbdtLh1WuEvo3/XpX7Qqg0vFNIWtFyQFkbtx8jiGwvy6Lo7G2iKpgZi9Y3VSt2dHGX1MLOye0W8jzXLqe11/GCPaVTO8iOG55EhUrJ9oUbQ+SPsOyBDsvDosMFX6JWsY++J5xOudOS9ls2Nu0KV7HYHRnJwdwW9f4nr28n6dWPiMrGANBsTdLjmmmlDJZQwO5L1dfsaeOkdFSMhzyF3hq4R/C+1ScTYYcXNsrf1XTHDc9MXONEGyXyRnd1bhLbsAgWPisL6SuYXCokEZBsG8T+y9Bs/ZO1Y2N3tPYt//ACNN/mtO09j1lZs8hseGobpmMxy1WJjlL6XnP68hFjM+CWodgvhxDgupUbGL6USU9S8OtfM/JZf/AA3tj2qJ7uuMfqt7NlbZETaaSB+794EZdFrLC/STOfbmz0TIYQ6SRxAzJvxWSnZEJGmYY2E6XXf2x+Hqx0ETqZkjyMnx9eawUn4erXXfNRTMA0ZY5lXHG6LlPqnVNDSTCNsbQxxOWHkuZLSNdWejwNAe0Wscrniurs7ZtdHWkyUVQWcMUbrWXq6DZDI6k1czRjczCW/W6YYZctGec1vbyOy54JG4XRMx3s7LkmVlHT0zH1cUeJozwjS6ftb8Pv2bI6ekZLM0uxDDmRfhYJ1GJ3x4ZKWaxbZzXsIy81nLGzJccpY87S1ghqMx2HHO3DqvRsZHtGFjXtBkjzYeBHJYf/Dzo6pz3Me6AG7AW69ChSzPgrDE1kvZORLDY9FMu+4uN/rFtapvUbtrSHRnO4sfDwQpto4Intvn9F2Np7K/qDWVEAwTA2cBoRz8QubteKGkpomtb3SLD3uas7npN6aGVDmbKdNHF3cvjxXH9KkZUtfGLuJAI95dnZtax7AB3CLEfZW9CpqKGWoB7D7nE7gOQUnX0uXfbbQVcdXCA+9jkeYXA2rFNT1hE1nNJu1w0I6dVki2i6CtMjR6sm2EcV6aMwbUpGsks8ag8vBP1u9JuZOFSTuhlEwYRBiz8V2ntdX0r2xuAf8AUclh2xKKcCkY0NdbPoEjZ1XuJWtLuz48Es/7LL9Ftjklk3Ia7Hob8PFWgqpKOcwyHQ9khdqpaHQPqYY/WEXcBq6y8xPLvC573Xc43JPsrUvJm/i70sQrYd+wXmYLub7wXMlMpdvSS1wzA6aq+yqx8MrARY6jqF0dpQ44fSIu4e+DqD+in+Nf60bH2iHtax3eVtoUEYlE7MonHtNHA8158PkZJvIdWi5XpNk1rKqnaw2NxYglc8pxJd+3ErHhlS18Y7Q7w+y61DPHWUxgkF2uy6tPNYdp0HoUpeL7lxyJ1B5HqsQklpJWylnqic28uq3rc6NulLQso43slcHPccnDQjosUJNDK2RmcZPaHuruQuj2lR4HGzhmxx4FcmZrhMabBhfoQeA5lJ37SuxaLadK1pykGbHcui59WBBEYHsz0t91gp55dm1W6f2mNNweC60z49ohrW/+YYMnHj0KnpWWgq3wSMa/O+QPMLbW0EVa9tXEPWNN3t95caeKR+NrTu3M+vJbtjbQeC1kosRw59VbPuI5dd/qXluoaeXzV9n1TqeVsb7gk5EE6LsbUoRK30mlj7RzexvHqPusbtnxtpHGU9vUvHC3ALdssZksrqOBqmYwy84bewOUg/VeD2jJJUVL5JW2fewDvZHJen2VtDdSNhlysbBx5LRtLY1PtKVlSBhlafWNH+4FnG8fbV79ONsqsqGU0Yqf7bj2XHj0P2XTlhfV07oYZ3MkcCGSH6FYNsTtgoyQ2xsQGlYdi7ZLnbipfe5sHHj0K3x3+USX6IkgLXuilYWzNNiwLq0b5KaJrZiD7pGg6eK67qWKtc14bapYOy85Ajk7ryXmdpVD37Q9He1zWsdm08TzKkvLprTo7SlbNNGT/evh8Qt1CLu8rrgbOxS1s7nuzYA0eC9FQu9fhtfQfdZzmok9ny//AN3AOgDW/JU2m/Btmhde4u5n0VPScO3JmvjuA6wy6Km1J2vqKV7eFQ4DpkuOPt1gU5a3aAgxXtvm389EyZ3qpCc/9Lc+RJ+6TCGyV9RUnJrHv3ZHvYc/smWxwPdb/wC0vbz1QEyYoKOUswjeuFvJyX6Q90ZBGF94S/wLjb7K89r0DC24Mxy/7UoQS1tXVRQANlBg7R0aAL38FvSHbJjG0KqkxDEyma4yA8CTYD5Lt1EjpHWb2g3S3EpNLRxbLpTTwuLnPOKR5Gbj/NFcOsF38eH28/kyJc6Uf7fyUMrwc2ZeadixcfgjdehyKDg4628/1Vh1zCkgBytfol7vLukeF0R5zIcFR0gHG/RUuVXFYLqwMvasVz66ESOhY4mz5LG3BbwCVV7WE5tDj4LncO9tY5KQUMUcZEcjm8y6ygoJxA+N+GVpyBBz+aJgxA9st6Zo+lupGNE3dyAd11XO4usy2ytmfTPiidEWtIwkkKGnY2vZOH4QO1lxXWp66GYWxYr5ahXdS083s26tUac7aHrYG1EdwRqLLVTPFZSC2b7WB6jinR7PMcbg2bEHcHDRZWipoyBJHiZmLjgsjNQzGaSell7r7gfz5plE1lPHuX8XlrvsoY4hXtnJtcX/AO77JFe3eviqIXYsWRIPLRRFI6Yx7Tbh0ab3Ta2JxBkGbb/JOlc7cNqhoRY+KNBJ6VBJC/XW3igGz53vozA1gNrtFzwSoZX09VFC5mDCAwgFGB/ojog7XFZ3gnbTgxOhmvk5wa4/dULqohDVvk0D7EK1TH6RSCTQjtfqqVcRkgfIHZtOY6clfZtjFhPdNwAop2y3M3T4H6OBJ88lh3b6avDW95rw3yJVrPpK/tZlhy8FsrmgTR1LTYWsT9CgTtJgaBI3iMBUkHp2zmuPfj18OKu4mqhkjaLEC4HVJ2KSMbfZuMvJBaha2nhBGpN1q2rFv6MTDMszPgVzauN8Ej4x3QdV1NnPL6IRu0ILR1CX+k/jLDCIqdrRq4ErmyEw1IJvkfktcs72VLWnVhsVWqiG8Y86HIqxKfWesp2ye1H2h4cVm2fUO3jmO0Kc2Vzo8LW3524NWempv9SXHusNwUGuJrIpn8C43Tqy1ZQb5urDfy4pFdF6jeRnu9k+eqtsaYGKSEjI3NvHIhQ9LbIL2tkB7tx8Vn2tibUW0Y/tfqi6c02NmGxa6yvUufVU7SGWcztX8U+z6M2RKXwPicOzoB46hYNoOcwiI5uabHw4LoQOZRsYDoCL+aTtuNt4pfaeLO8f+Fr7EpT6Rs50XFoI+GiRPPhhDW66ALTQxbiIXyxfwLHXxP8ASwLd7QfZB2wP6hssgjtOaCB+YLnx1LaeWABuQNj0CfFSmJjGB5GVyLrlVcbxWODh2i7shQeg2jTsnp43u0jfcjodfssk04gewDPMC3RbqFxfSiGTXDgcvO14e2pcx3snCFnW2vTpbVp96yGRmp7Lk2mLW2iHLLyQgJqNn7s5OLT8RouVHVOFdC8eybH6Kp6Kq6fBVui62+K72zmhkBhHAXKz1bY46xkr24rtsClCqazaMLW5NcbHzWtpIw1rMFcWWyBsF6SIdm3L9VhnpW+ntkOgbcDqMltjPY8lzyv01ixzH/Ws8D9l0tnajxXJncTXMHQ/ULdRB4cA08fus5emp7eilljbgY8NLX3FivP7apzSQOkZcxnQnh4o7brH0k9LvM2OLs+Wi6tPNHVUxje0SRPbY8lwkuN27XuaeAJLLFps4HVes2RVztjjjqYyxzrWJ4jmpBsKCi2gZ3P3kbTeJp59fBYdv7SDLRREOeDe/uL0ZWeTpxk4e3Z2tFLNRukpgDM0Hs8SvCNfLDOHXeJLnEvTbM2rJWRtiLrOGpW2q2PT1E7KtrbvaO0z3uqzjeHVas5dwnZ9RvWsMse7fa9ua3z0/pVOWg4X2sHcl5zbG0fRZWti/ua+A5LrbG2oythBFmuGTm8lnLCz8o1jfqvIbRppaeqfHN/cBsb8eRXoNi0tRQ0gklce1mIuLQu9UUMNW+OZ0d5os2k8Oh5rg7c2p6Od0wHf6W93xXTHPnOLOU127bXtrKZ0bpMBI7Lx7B6Lwu1KGo2dXFk1g4HEx40d1C0bK2rJSz2kc50bjcnkea9a1sG1KdjZgHFhDmngFZfiuvpOs5tztkVkrWMMos4jTmF3y2Ovo3wSuLWvBFwdOq8bt2ompKpsLWmNzTjvxP7Lq7F2s2oj0s9ou4fdYzw/7xccv+rzm09mT7PrjTub2gewW+0DoQvQbMnlpWxsqLFxGXTp4rvvhjrWi7QJYzeJ50C8LtysnNY6FzXQmM6HvFbxvyzTNnDt7OrjhrKE08r+zILA30IXio6SfZ+1mxFpvisPzAlbtk1zZ5G70jE0Zt5jovUupoap8crmtMze6eixMr4941vrJxJITs17Zmm0gzd1C9Ds6sjqIQSMTHCxC8vtZ8ssEzy0xvjeBhPhxV9kV0m+L2R4YbAuHI81m47mz007Q/DttpDC4mnkOLHy6H7LTFUsoapsQd2XDIXXaicyoh3buPFeM2o2aKtkZUC8oOQHLgmP5dJeu3sZ4Idq0JhkcdOy4eyeBXlYNkTemvhqhgZGe2Rx5ALobD2kcAa8nLLxC7e0IXVNIZoG4pmNNm37w5KbuPSe+3mdpPFNNHusntztyC7Gyq7exsLTc8V5d53ry6QY3kkm66Wz4paSHfuGFrjfD05rec3j7Mb3p366kDpDWwmz7WeNLfmXmKzaE4nO6qH4WnXHqV6mknZLHZ4BY8WcDxC8/PsEw7Rs+7qbvNJ18PH7LPjy+sjKfx3Ni7VdUwhsjiTazhfVc/b89dRSNjjqJ2Qvza8SHPosFRWimq2NizwZHoOS9BGYdrUBhebteMne6eBWrvG7vpJ28sNpbRaQG11QTwG+d+q97+HNrvrIXRVJAnjbcniQvKU2yzQSySVDhvB3Og5rINpvptoieB7bAFpHMHUrrM79McOu3f8AxbtPaEMsTqaZ8NLoCzUu6rkUO2Nq2Mr6uZ8Y5uXdglh2lROjkIdFILZcFydrFuz4hCzJ2jQDqOax8ly6XhI6tLtWpnisah4uLX5Lj1W1dtU1XuPTZSSey4gdoc1zaKtMMou7sk55rqQ1Jr5gALiMXbfh0WeWWNb4yzp06D8QVZkbHUS4naHIfFW27tPa0GCehquw7Ix7trrHney8jVVMwqXOecDmHu8ui7OxZt5IA83aDfDzurcsp3tOONapdtbXpqZks1W1zm5uBjZ+i0UX4inqG2kMZv8AkC4/4mgmjLZGtxUpOvI9fsuZQb0EvjaTGztOse6rbbN7TU3rT1D6vavphj/0xgPa3hibpyS5vxDLS1jYjHS4dDaO1kaOcSw4cViRkRwPNeZrqaaOsfHJ25Cf/d1THK33VuEnp6mvgi23TYhgbUAdgt0PQ9Fzn0EVHQO3zzjGchOt+ACVQSzbPkYyY3Dv/j0W3asP9SpWOiNpm+zfJ3j1WN3a666ZNk7QbcRuuDz6IGmpp6x0kUd48d7ff4rkx0U7948XbhuLdeS62xZGxgsNidHA6JZr0uN37ZtpSB0gERF2cfsteydoEERuAzyIPFZNobOlgqmtpwXwymzM9DyKNZSsoYmOa+72Zud7x5LV7ibsdLaMENPRmSJoEZNgLaE81yqSp9FlDmdy4v8Aquhs6tiqITBIMUcgs4HisNRsl8FbY9und2mv59FMf5kZf2PUQvi2jSYJBcOPZPIhcHakb2z7iQWIzPUJezq0UlSYieyDcG+nRdfaODaMbYWtvK0dl19L8Fifje/S+45FJVGinb/0z8l6K8dbFvGD1oba/Mclwm0OGne6pOF5BFuQCTs2vdTStje7K/ZWrN9xJddLT3fK8Sts69i08FWie2mrhd+R0ufquttGm9OgM9M0GcDMe+FyZ6NscQLn9v2iOJ5K2yzR6ruVVIK6LeQ5SDVvvBciZgwntYXM48jyWrZdc9j2xvfdw0I4+C6NRRx1EgqmC9hdzPePvLMvH2ut+mfZVc6wieLSN1HMIbapnGISxZwk9tvEH9FzqpwErJIzZ7STf7LqbOr2ysw2udHNP0Ka1+Se+nB9HdUPwxOsW9rF7q3bN2g5jtxL2Jmm2X1W6ppmUUT5YmncuzJ68j9l52ovLIZcVnk3DuS3+/afq6H4i2ca2ldWU7fWNad5GOOWo+64eydmtYx1ROMV8mNP1Xf2NtF12tcfWA6cwht+gw07qyjb2c94weweY6KzOz8V1L2xUu02xT+jmS9jYP8Asm10ba+UTAYZYxcngRyPVcCOMOjuRdxOQPErsUkj6INZOe8LF3LkE467jW2XY4wVlUDkcQC9Ps6IPkBc3PLNefje1+0pDFkCMyvS7MFje+gWfJUx9lUXb2pPJzkd9Sk7ahYXMkDrYZhZnO5I+y07FGOSR/vOJ+aw7cludnG+TpX/ACXCd10aMJbUOY0ayy5c+wlYi6iOWfoZJdyzKc5168N5vf8A/o1ZZprMlZyobj4lWewzDI6nomwxYyZwGtOh7H2XZjEOyKWGJpL5pTbEdXm2p6BYPw4C6k9NmOCFjewDoQGgF3y+qwSTzbQ2m2pkjLWA2bwwALrJ9MZO0Hue4k94qXcBmlMc0OB7Q63WhkjHNyNyvVPTzX2oJFbFcaK4cCP2UwX1WkKaGtdcj5plmu0VXQhxzPii1gjyBum0ePfmdUMeHRVOI8ECDxPwXZzEuujG1zjcnJVBsnDstsfFREBtx4rn7VGKlv8AnB+RWxz1k2jnSvPUfVZrePtxgSw5ZFaoNo1MPdeHAcCshU4Lm9eunoqbbEj2MMg65LUNoMkmb6y3MLh0mcAdyukyOxyErFjla9ZJDS1TO20G+VxqkHZYjjc2GS7eT+HwXBp6ieM9iQ25HNdOn2k9o9ZfyU0mz308rYpI5ojgw2BZoDzyWCkd6K8uzve1rrrw7Ra4jO3ik1L6eonYx8bSDmSUGPaMWEskbmHcV0IWtqaIxO1th8xoryUDZId3G8ANIsDnos1JTVVLM7eNEsTtC0/wqNE0LhvHwuNw6+SU5xpJ2tGW7dmtFU9kM5eG5v7WLlzVK58c0LamMYmjsn7fNBNpx7yBszdRk7wKc0GaidEDc2uFShfvIjEdCPgFWIGGa182ZKBWz3kVIucnA36JtQ4UspI9oh7VZ4EFRJb/AHLFvnqr1jN5S4nd9ilqwa9oqIIqhundcjFIyKSJl+yRhHVXpYmik3L9HjTkueWFju334yqLbdh7Uc7cw7J3iNEGx7yjDT3gLea3zNNTRkDiL+YWCLE0tJ0KsqaZ6Jz2VDC0YuBb04hbappgYXMzYRa/JWgjY2R7hpqPApv/AJiF8Y6kJasjLRyb+GSnkyJBsk0R9HeXHUPsegV6WMslxM1HP7qtZE4yiU3s/M4eP8/VVB23EcUcw7sgsfLRbNkG9KGuZn9QoMNVs7Bq5oy8kmmqQHsGGzLi+R0Kia7ZNo421BieMo8v0W4H0vZ7HOFyw3tzDckdqU2NzJOJ7J8eCvSkNJiHKw+iu+l059bU9trWG+Gzr8ui2yFgdDO4WDfqVl9CEleYx3b38luqImGJ0QzAGQUQiSuw18TR3Ae15p+0ImsqYqg+B+y5rKXeSXB6nouxJGKqiMYuXWsPEJVhNDWN9LMLcjwKptamB2hDL7Dx9P2sufCxzahrm95pvquhVVTahm7jBxM7QNkIlNUN9LwD2h9P2WSqpCdpiO3ZecR+6VCHNqRJe5uCulWOsI5x7OTvAp6PYV0eKnLhfEyzh4LjFodKJPaJuPFdiln34la7QjIfVY6WD/VEO/23Z+WiuKV1KsudFHIO8SMXnqnsPY8lk3xkikbfNvySWSy4CA742WMm4vIL15P5Sfmt1A28zf8AJcaLeyVLu1nhH1Xc2U22DELuusZemsfbN+LG7w0udrYjl5LJsZ9VS075Xj1AzsPqF6qengqoxDOzExwuDxHXoVzdqvOz6bdhoDiMMYGluYXPDPf4uuXSsL5KuISM0Jve687trZktHMXudjiebh40vy8Vv2XWmkAifJjaSbHkSu+GRVUDo52GSKTVv3W5eFcrObxezaSUuM7HGMNzB5leq2ZtBsgDb4ZRk8Dh1WPaMD6Bm7jsGOyY8aD91xYoXwSiVsvavmea3r5El49Ov+I9iipYa2lHrGgl7B7XULlbIpJYCarNo0a33l6jZNaJ4wx3fHzVNrUZbA+aFnaANwNB1CzPJr8a3r7Shr2T9m9nNyIv8ln27sf+ow7+IWqWjh/uDkevJecpxPSzmVst7nPqvX7LrBURNaNeKzlj8d5YpLy6ry+zNkl7nTzsIaw2a08SE5204qKuETDiZxPJeh23SyPpXz0vfAu5o5cwvEOpA49nFcnieK7Y5c/bFnD09XNDBt2m3TuxNq2Qaj9lx27NdsjHJO7DKNGj2R+617LL9lRtMxAxnj7PRdTaVCzbNBhDrTMzY/n0P8+6zvV430177I2XtRkzRhyA16KfiKijr6dsg7FUMgT7Q5H7Ly7Mez6stcHB7TZ7Dx8V3aKqdVStY7Jp4n6LOWPG8sVl5dVmotlspqJ0s+Urx/7LLo7I2o153eO72n5c1r23s59bs9zqW7ZGC5Z7wXj6WnnjqGuiJEgP8C1rnO2f1e3raQV9KTEBvxw95YJ4otn0QYM3Ado8ynbOq3Na1rzheNbJe3KN9XEKmmdcx9+Nun+Q+64zq6+nS9zZOyNoPa9scly4dw9OS6e2KenrKSJzspb9g9OIP2XlIYqieYNjL3O4m+nVdmkx78RTSYiLZ/dbyx13Gcbv2VXObRxx7rhkB9V2tj7QEkbSM+Bz06LLtnZhq6YVVMLSxjtsHtDmFydlmcPdI2xib3ungnVifbvVuxoTXNq2G0DiCWDQn7Ln7brBEwwQm79HZd0Lu0FQyaPdSdx+S81X7JkZtR0AONjzix8LdeqmN/pf8DZNe5pwvDiG5eK9Hb06jdCHYS8HC8eyeC83tAspIWwxWuP5datm7VDB23ZZBXLH7hL9OPUROpppIpWhrwc7rp7LllosLpOxG8iwIz8fBdP0b+pP9MmizZ3W6kjrzXD2tViZ+CMktvdxHPkrMuXScePb0e1KT+qbOxROInaCWj3hyP2XlKalkqajchuCx7bj7K6+wdqEOEMr7nQX4hdWvibDG+shiubY5Gt1PipyuPS65ObDIzZ1RG3H6uSwA6810do0Ldq0XZHr2C7DzHJeSqZ3VExklZid46L0GxK91mxzAh3AniEyx1+Rjd9ObFs5sUEr5snZ36WVtlVTWyBtrZ5A8RzXS/EsTzStniNgTaVvE9R05rz9LA5wMwOC3dsrPyieq71ZQQTytqCPEc+q4lTXCGtD4SDgyJ5rsbOrWyNwOdmOy8LmbW2ZuZxJC0mOV1gG8DwCY/zJcv7HoNn1sW0KR0UoxtcLEHjdZqqCDZFIGiz2kmxd7a5jad+yd3LvA69g5o+y7sckO1KExSG7XceR5qXr/wAI83R126ms4jCTlb6L0UJjqCyQta6VndceF1zafYm5ne6pFw3ujmOaz0lcIKl0XAOy6plN/quN+qz7aqHSVJiDSwN4cb8wrbNrpBhD+yQQARof3W/a0UFTA2YuwyjJZasQQ0LCwZHQczzWp3E1q7dSaN8lNJUU4xPaMwDr1H3XnGySRSB4vcntdV19ibRczCwmxW6fZkG8NXEzJ2bm+4efmsz8fa3v0FDUxyw4H3z5cPBcTbTJ46rBKAYzmxw0I6KstVuqwujN2A5jn1XXjMW06Lcvd/i73TwVn43f0n7dPO08j434mDIZkL01BUMrKYwyOyIsCOB5hc+elZQQObIMTvetqufSVD4HhwzZdaynL8ozjddUyuo5KSdzHgZZteND1C37FqDFWEzXEkgGHnb9V0YjFXxMbIMRBxNPLouVthzGyhrSN43MuHBY3y6a1rt2drUUlZSGSmcN8MywaPH6rycuMON23F9eS9FsXaocWxO7MnTlzC07R2XHJMK2EZjN7Of5h91ccuPVSzl3HN2NtJzHiCW4dw6rTtagdO30um7QHejH1C41QBNPiGjdCuzsquc20bsrHW6ZTX5Eu+nOp4Hzsc8OLC3Nviuts3aJLt244ZGmxshtVhhgdVU7Lj2wPZ6rzbZXtkErT2uvFJORvi9PtSjbIw1VOM7Xe1vHqPuuPu56IipbfET2mcLfqujsnaQe1rM78U3aFPvIy+HunvAfZZ3/ANa1qe2rZ9bFVU+ge14sWnjzXLr9lSQ1LAwE07zk86joeqwsmdQ1gfDmx/eZ4cV6WinjqqfC7tRu1sn63UPbzm1CKSAVLQC5tgwcF0dibVbVRCw1GFzTx8VyvxJTywxysl7YNsLhyvwWXY1DM2kdVB5ja4dge9ZdbjLik6diq2fTUlS+ohdiYMw33CvOVdYaiqc1jrsb3fHmu9smoZMJBK4SCTJwJyXJ2rsd1BUOkicXU7+6Tq3oeqvj66q07YhdKJHv1dIR8l6ig9WyV3JhPyXmPw+P9CL5doleojbh2bVP/wDxu+YWPN7TANhi1EX/AJbrn1bAKKkmLs4nC3g4EH7Lp7MBbsxwbqQQPNc2qJj2NG1/fa+Nh6EGx+i8+Pt1aGOP9Rw8S9x/+DUrZlC7aLopASymEW6lPF1nd0fdLcJZtrbunAE92gYjoCzM+S6e1NoM2FstkcIvNhwxA8+Lj9fNbxjOV0btF7DCKWPsgd62jQPZCwMiazQ526Lk7D2i6RzoJn4y672uPzBXZBBOi9WGOnmyy2u04dU1jmd8E3HJUaLpmDKxFxzHBdIye17XnJ1nchojvcORF0gNDXA6W4p1sZuCqA4lxydg8kHNdzxdQr4D0QDctDqiPHKpy4qpcSgBc6WXZzH2wnlmenBZ4wA9uJ181qErRkAVmrCSzLNZ60f6SU9P0Wp5udbLPUC8EngVmtT24BKuW9kZ3PJU4g9VcZrnXsx7joUn/kCbaXCQyLIknMrZs9mOhlHuuCYIPJZ245wiOM/JaGxX4cE6OKwTwzNNsaZxAL5omEYg/iNMyn9AM0LFParRzPj4/VPbWi4xZFZwbIYcQU0raXw1DLSxteDlYgJUtDCGGOM4Q4WDToFmMahMtwQ65BvndRSnbOqoJg9t3NGXYNrIVOJssZjIaL4Xh+vit8VaWZSNLev7rTihnHbDJAfC6o5pkcITI8YtzkbcleCdszXNY3sm40WttDA1r2sOFrha1yVi9EmpsAjY1zGDVpt8lnSqGd4miafYyKbUtYC2XVrvsufXuxVDZISWtdr4haYXunZK0yZgCzeZ5ppT6N8ha4MGEk3HgqTwmGSz+d7gcClU1YBK1pu14NvHoujW5xMl93I+eigwODSb4u0z5gq7HmF7SNQqtaDIHHIObhPXJSJuGN5l7zezY/VUSeQQPeC0lsnaxcuBCIvJTPYe8ztIEiSE31ZmPurRSBrg/wBga+CB9G9kdM53Em6yTx4JCALjl4q0sIhmMY7t7t8E+obvImS8WmxUFww1FMWXIdb5jRYYcbJQ52q1U09prcChUt3dRit2X9sD7Kik8pie2ZmYPZP1Qa518R0dr4LTBgqIHNDcxkNPELPCwOJxaC9/FRFIpd3LI1wtj49Qn0ExMzmnR+f88kidgJx8QqU4cZoyzKxF+q1oMqwIquRoyDiHDzWilbHIcY4G1+ittGLHEyYat+/7rLs6UCqDfYf2fPVPZ6SKnw1b2u0Yf+FskDZYpI+JCTXtMMrZm9x4s7xH7LLHK655v+qns9KsOFvVwsVRz3xTYhe8gv8A9yEQkikLZRcuz/n85rfKTNRh7f7keYPhr8lpllo5MMlne2Dw46roxNu3Rc+GSSQgYcr62XTpQWxEEWz1WMmsWKBgFdMPyt+66+zyGuYBrdcmnH/1Cfwb9109m5uhP5r/AFWMvTePtq2jXCjrKdrrASNOvMFbHNh2lSYJQ7A4ZEd5h5hcL8WC8tKTwa76hI2VtURSCNznOZpc/Qrjw1Nx2Co2bLHVmneGi2YcO6RzCfBVehythfI5w4OPDoV3bR1sIa92F3sv5FeYrIpIal7KhvrBp1HNdMcufVc8px7j0QEdZA6GUAxP4Dh1C5A2M6CttOA6MG7Xe94IbOqJGNGNrsF7B/Jd2JzamHdu73Ag6Hos3eB+zz9e8U9THJE60nEDkuvszaDKmJrfb0K89tGCanqntmAL73a7g4cx0VKSWZs4MVssz4LpceU2zMtXTrbV2EBMJ4OxC49tnFvXwXPlmFFOzcjTUfdei2XtBtUwNI7ehHNcnbmyNyXVVO3FC43c3i0/opMt9VbNdx1aPaEctOXl9srW6rmVNAymqG1jWervdwHsHmuQ0ugDZHdlpN8P3XqNnVAmha2wIItY8Vmzj3Fl5PL7SqDXS3A7AyaOfVa9j1jqaRsUubfZJ08E3bOyTSPNRCCYXnO3sHr9kmhoQ9pnmHqx3RfXqu25li56srs1+yoNollU1pe9uZ//ACdCuBV1IbVtdE2wjyOXyXV2RtVrZfR3k5GzXDUpm29lMqG+l0gu/V7W6OHMdVidft6a/wDDdl7R3kbAded1asoImyOr4I+1a7v1H3XHjpH0tKJrkO7xbwA/VdbZW0MbGjh0PBYv49xrHv285U1EhqWyx5AaZLtbKry9rXsBxDIgfRV2zslzHtqKRnq3ntMboCeIWeSlFBDjx3e3vHn0WrrKMzcrqzQQwxvqoWBgdcy20B6Lzcs7nVO9ZkQcj0XYoNpBwaLXYciDxWHaezt3IJIG4onG1j7J5FMOv2Mv8dvZFcJWNwDMd4X4qbVjZRUr5IY7RHN1hoSuLE4bPDXtzcNRzXoaGrirKex7cThZwWcpq7WXbzVPtKVjTGDYk2x30C9HRMbVQvu4Y3DsvJ481ydo7LZQ7yS3q33LXnh0S9jbRtJu5eByvyVs5dwl11WCup5GVMjZ3ESA5g6nkR0TKSjlLN7fCBmz8y9NV0UO1GML8pmG9/eHun7Lk7SqDE0RM7LxlbkFqZ76ZuOrt0NkVodhHdcciFj21scmpbPSs9XMbOA0aea5VLO6CQWvY6jjfmvW7Nqm1EAY8ZHIj9Fmzi1Ly9uPNSU1FRnMdkYr/mWrZe12Pg9a7tDXqud+IIJoa3tWdAR6o8Dz81io4nyyYmNY1rc8X2Wrjym2ZdXTpO2bA+uMrLiAm4ZyPJZNoTiOUNiNnsN724cl6HZskEtM6ExgB1w4DnzXn6zZM0dcKcRh4eSWv4W5qY3+tZdG0FUa2qhE2TRb/tyzT9rwijiDoW3jfk13u9FlqGR7NfE9l94D2r+1zJXbpXx11KYJWkxPGo+qt6v+JK8kyV0E4c0C5OYvqvTUE4ljGJtxxB4LPS7DNHVPfUODsBvHbQj3lidWtj2i4x/2yfnzVy/PuJj0ptwTNrPWZstdh4Efql7MqX0j2uN8BK7j2Q1tO1smY1aeXRcvbT4Y42QRts4Z291Jd/iWa7d2Vjdp0JayR0b7HC5p06FePqKWaOrMLhhkBtbot2ytpugkZG9/Z4Er0csEdawSNDd+wZHn0Wd8Lpr9pt5eGPDUMjnPZ+q6tfs9tdSiSEWmjFgPeHJcasc59Q7F2Sw2HRdTZNfkGF3aGXirlLPyiS76YqKhke18pcWYO71K7Wyq4PDmONyOy9p4qu1XO9DM8Lbn2hy/MvNRzup5BI053zSfmX8XT23s1tJMJImk00h7N/ZPulZoHOoXtkcbYu8PdXoNnVcdXAYpB2Xc+B5ri7Yhkhq91KLgdpp94c1Zd/jUs49ulNHFtSlAxDegXY7gei4sNE99WYXtw4T278B1VqGpdTuDXG7efJd5rxMxz2NvKBcfm6LO+PTWuXbiVTzRSODDZp/+KbTg7UpHXI3rcgeBWad5le578znccuiNDMYJbA9kGwNvkt61Ns730tT0M73PkuYjHoeN+Xgu7sbaReN27J7TmAUqoL6qjk3NhJ7Q5hchjXscwxjt3sBzWP27P1dramxt7I2ekIaxx7bRo3qOiTWwR01I0RvsWZjqea3bPr8Vonts8ZEXWXbVG9pFQw3h4j3TzUmW+qutdpsvaLZWbmRoJORaTkVnq9h2rA6Mk0zzc31b0/RczC/eNdCLyDO3Rd3Zu0BUQ7qRumThdW/j6J37c7aTGRSskg7MnLoFam2xaJzf92+hQr4Xxzl0pxNOjuixOheDvwwWPs8wtWbieq6ckLxD6U5lg7I4fqssMr6V28j7pObAfmF2NmVcVRBu5bPY8WIA1XNrtnyRVQhteN3aD+Fv1Wcf5Vy/xonrYNpsjopGb0OIOP3fD7rn7dqnQhlG0YCRYjkEuMtodog8D8l2a2gZtWmbIBaojHZPMcj9lr0Y9vJU0j6OVuEXDiA5nNengkZV07qaobcOGEXFlkpaBsBdPUf3G91vu9Vikr/9RK+MYogbEcyOKt/LtV4qZ9LUPgjfcA5G32XWjmqDs2qEp7BaAMtbkBczZ+OS8zz2nm9+QXWq24Nlxt/6kzRf4n6rnnTF0qQYKBjeoC4VTWbzZcj3jtSSF2fIOP6r0DwWUkYGuJq4uyKE7RipS9tqaIHeg+0SQbLGE6dPTp7MjiJl2o8GMSMAYX6tYBr4fsvFbc2q7aW0XyE+qb2WN5NXpPxVtC0Qoocrj1hHAcAvEyDC9enx4/bz+TJqgmdDNHKO8wgr2rbkE34BeEjPZuvabPm3tBC7nGPkLLo5tTE4SW1WbHh1Vg8OGeYVGps4cMJFwEYntddtrJDI2k+addrXkAKstAaLZFV/XqrYxl8kDIEXp4fQ5aqrsROqZf8AJbqqlzL6ru5AGuY4ElabaFZHyg5NTmvc5oN1mrFnaKjz6tw6FQl19UmRzw0gG6mll7cI5EJoOaqY3B5GDQpscEjs2xlcsns8eU126exxihqG8gD9VpLbBZKCGWAucThuBxW7J2Yy5rlYzlZb0tGeXJNI7WuaUwOaAL3OnmrjGSkYGyhbxRsLZnNAtJORW0Ds+y2xRtnqjgsdc1Xd5aqidniVUvA0RwgKYraBRUzKrgbe4OEjiCpjzQLjyU0G79zDbFiVn1fqnt0vlmkaqxGfkpoPpjDg7YBJyubK3oNM52OOzDxLT9tFkdHc62QAcx+8B7WiKc/ZjmzOmicHHWxCYwPNK+Kdm7vdrc75cDdCOtLO/p1Wn0mORuZy8lBw4ZJXzOa8ssw9p30VBUAPfjf2Cc13X0tNJdxY1vUarmv2M97HlpABFg08VoWpJY35Nex9+ugSyGseIsVi04R1CXBSOoGyvqI7OBAuM8vJJq6gFrJozY91NDoSv9Uw6uj7BP3VqWUS3Y4dmQWt0WenL5IbyiwlGG33VY6mNkrGOktIw2tbULOg0RFswY7vA2K1VLN5ATo9uY+6TVXjc2WPMHIn6K8J3cYxuvfXxUVWkdgmA55IVT9zM/3XdoIQhsc8jS++HMIzu30Aecy3/hVCozju08c0I7RBw8vJWp48RxcGqs7bAvGn2VSN9I5tTTPicNAQfArHTQmOV+LVhwlHZkjm1IAzFrHwTtox7qYvb3ZBY+IRWmRoqqM24/ULk07BLO0DnfyC37LkDQ6I8e1+qTIGwVUgvm7tNPTipBSrb2A/Us7PkVKBwa90XB4t5/8ACtHJ6QJWHIOFvFZaUO3wLj/bNyfBajNaIThlMRGbDb9F0GG0axzx/wCuilZpJk76rWwZDNc8nTFlhyqJ+lvot2ye0yA6Zk/VYIDaeY9R9Fr2I7FDS25LOX6rPY/iaOWappo42XLwW35ZrIYoKGjzNydfzFelmwOk3cmbXAfdeW/ElJUQ1cRk7VOSAxw08PFY8eW+nW+mvZte9kgjlPZPdN9Oi7VRTRbRgGPsub3X5ZdF5yOn37sLW2A1K6dHVmmlEEzrngTxCZ4/cYmW/Ze0HtpYdyGi9rBvNI2ZtBzXNZIQTwJOvRdXaNDHtSAOb2Z2jsuOV+h+3/K822lkM+5LXMe02seHitY6ynftnLcvT1M8MW0aYxyA3t2H8Wn9F5qra+jcafuPGp5jmtcNeaGURyHHxyWyogO04g6QBrvYI1HQpj+K38o4NJO+klD2P0IuLr1+zqplXALEOvk4HivNwUDRK7eNcwMywnU2+yrHXmkrC6HNjdevVbyx5emMbr22/iHZboLTwgup75t908/Bc6grvR5B7v0Xq6aujqaUnCHhwIc08VwqnZBjmErG+ocdD7PQrOOW5xrVmu47dNUR1UOFzbiQWLea5G2KeSmAawWhJsHDh0SBVto6gNBs3p7K71PLHWU+CRocHCzgeKxJxrV/KPHOaRmH5jovS7Lq5IhGycWcRcX4pbdkNpKwyvfvIxnGTz6rnbTrS+oAieDhN7/ZdLefpiTj7dDb1G90HpFObxnORo+o6Lg0tRuX55jlku/s3arTEWSOytmstNQQSOnqWR2YCcLfd5lSXXVXX26mzaxszd2QCCOJXO/EFHJG9sgN6c6A+yeq58dW2GrxM7gNr31K9JS1UVVTmOUXa8WI6LlZcbtvrKPJwiTfARi98sN9eq9Bsl7MbxJmHZEHgrM2fFs/eOBN3d1x4DkuR6bgrS5pGC+nVbv5+mZ+Ps3b1LJDUgntQOzjdySqKR9A3euya7PD05ru0skdXAYJmYmk5cbHmuJtcGOfcPDss7j2grjlv8amWOu49LG6DaFK5j/WRSAA815iq2ZLSVzWXBaTdkg0I/UI7Nr30smEYzGc8Nl6JuCshBJu3XLh1ClvCrPyYtm1hDt245jPwV9tbMFbEaqnaHTtHaaNHj9VxKxstFXEyEh4PZIGRHMdF2tl7QxsZbXipZr8os76pNFs5tHSmWVvrnDh7A6fdZKSuENZaPJl+yV0tvMl9F3sADoznIOPl0XnIIhLI1kbLv6HRdJ+Xti9entjFFtOg3b9Hd13ungVwq4DZ0Qp2jt5+f5lp2bUmmkEchB8eK3bX2ezalKHMA9IYOyeY90/ZYnVa9x5iiqzTVAGO7XnNt7r1dJM2phwFxF9HDguDs/ZwpoDU1LcEudh7gHFL2ftPBUljxZhOX6K5Tl3Gcbr2y7YZUNrXNms147oGluY6J+xpZ4WmR/apwcjxv06c13aqki2rAzGbStzDhxHJc/as8dLTCmhsHAWDRoBxPirMtziXHXbqzRf1LZzomSmOWxwu4HovLwUE81Z6M+7XMPbPEeK2bH2i6N4jebgELu1YxQvqIY7vAuW+8pvj0uuThsf6HVbgu7JzFyrbTohXQiaIXmaLf5Dl/Oq4lXNJLM6V4diJvlw6LbS7TfgMYaMRyueCtx13Exu+qXR7PO6fNIMyLi/DqnUe1HwEMtdxNh1WipbOzZmJtyCe2TqBzXKjjL3tY3vXACs/Kdpfxrr7VoJZoRVsb2yO2OXVYGvjho2Ef3Qbr0Wzai7BDMLvAsRzXH27sz0SXfNHqH6H3TyTG7/ABq2a7jXs2ubLHhcMjkR9kio2M1laJNad3aA4g8vBc2lZL2pYxlH8+i71DVieLC83vwPBZynH01j+XtzZ6hsFaDHna2MLpTSQbQ2eGyPs4H1R68lxtoUj6aocH5tcbh/NJaZIJY3ub2SbgFa19s7+q6EdA2KN4lFzYg+CzwVbqQgG9r9l32XWbENoUOHFaUZtJ49CuNNCZHmEx9u9rJO/a3r00SRmuIe3KV2oPEc1asjYyNkDMsOfieapRgwSCP2m8ea0VtMD6+PtM9ocWn9E39Jr7UoKoxyhju8Pa5hdQU0T3Gpa2xOo93quRDRmoa57TgwjJ3VaaCtMcm6kGhs5qzlP41iTXPLKoPhPaYNefRdCl2ow07t4Bh0c1w16WWPaFIIPXxZxSHMD2SsslFIyMTEdo95g0t+qtksO3QiFNHvN2CxriTiJ06ErnTuBkM0bbOv3eYXZ2aIJqYtLMYkFiDbMLBVbNkjq9xa7D2mv6cfNTH+Uy/xpoKc18LhPLiFuz05LNWjdPMBFi3UW0Qgl9AqWsa44Tmei6VZAK+ASxj17csPvDknqp7cSOY0swkb3T3h1XoqWdtZTYXnC46HkVwNwwxudI3nYEcUaKd1JI0OdiYch06K5Y77iY3XTFt1kkUdQyUWeMj1zyK17Arp2QME4cMXdd7wXZqaKLakcZkbje0g5e0PdXntu1m6LYoxZ4NweVlqZc5xXWu3c2hTOrKQugNpeIGhHLxXkqdpbTkOyOI3BXe2JtJ1QGsdlLax69UrbNOHF9RAMJLjibzsdR91nHr8WtmUEdo/AfoultIPNLRiO13TXz0yaVz9nPD4mkcc/Jdmqb/5IWvm4/IBY8l0YFAVQEMGM+ucQHu0ACZX1MOyKJsFKGNcMmt1seJW2SKN1DimHZa0uxcstei8fVVElRJvZHlxIA8rK+HHkz5MtMk7jI9znuxOcbk65rBOy7luk01WKc5r2ya6ebe+2dhs8hey2SHN2VTjjguPmV4+CMzVTIxq8ho817mNgYwNbo0WHlks1o1rcR6o7vslVbJYXAzTAcR8kEja4aHxTpTkOxiPNKabNVnjEwWOSIuJCI72vbK3j/Chv3D/AGyoAyNr+QHDx/dAOa494/AqjyRzaQs78jZXIdiAsiGZZldnJQWtmtFM4B9joVnlIaEQ7IKDpbtuuFLcxhB7KtBJvGgE5gKxCyvTM6NoGTQqtjbyWgtvwUAw66ck0uyczlbJMZkM9OKjj+VQLNxlalEHtEalX0CAbcKEOa4X0555rlcdOkuxBujrqVUutxsrAXKkVAVDn9lbAphWkLLSgWlOwjmgbDXMIEligYmk8gqubdFAWaMtUA62mqB5IYSoLWxaqW6IgKHLTVQBUMbSLhtiOKvitwt1QxXKAHeWcGuz6p0Na9rQJG2txS7qtrtOag6DKlkjeHnZZajZ9NOc2EO5tyWcRXIs/PxTWOkjae3j8clVZ6nZtUJA6KTG1ujD/LJFVA41kT5IyAc336Lpx1eHJ4zWlsjJAePwV2OfHNFVwSwxO7TRk4DislNUTSOfHNYN0vbiF0Zm08dUN2wBxGbgLarPUUUj3PfBKwEm5uEElp7w79ju0Bdw5jiVaglY8GNrg5umugKFAJ4GOiqI7Bow4gb3BWOGJtHNM8uza6w8NVNDQ5xjxxnvNNj5qzG44Szkl7ScWbuojGJruyT14IUUzpoy8NwsBsc8j4JrpGmjwRwEjvX7S0y4aqiJGfHzC58xfGXX0en7OlaMUfP7aopVG7DM119NVr2lGHRNlGrfoVhllENRI3hq1dGieJqXBLqLgqI5tPJaUWCNRMYXvcP9ztDx0KfBBunyY7dg4QkTgOhEnum/2TayNNBIZIAH99n8H86LX7JPRY6JnYLzkHLYB6rXms5LixQm+/PJx+gWz8P501KehWKm/tT/AOT/ALJGy4nyx04F7FoBzVs/FZ7dvbG0RRbUiJzifGO0OGZzXTifFWUpjlAfE8ZsXnNtUD5p6aCNveYbnl2jmn0rjstzWGS8drF3Irjlj+P4+3fbfWxM2dBraL2Xc+i87PKZpt6XFpvl0XsWmGupTDKGvY/Ro1HVeXrNjz0tY2ANL2uvgf7JHVXxZf1x8k/jdsnaeIsie7taBdiop9/GZIw3egZH3l52rp46GmAFzIeJ1v8AoujsbapmAilycOPRM8ddxcbvquDUtJmk3zSHg5jj/wALqbJqi0NjmuWE2DufRdXaGzI6/DM0YJmnM8Hjkeq4m0pGxgQxjC9uRHJamUzmk1x7dSup/SInMY7DJYhrj7Q5FebkiLXFj+zh1H2XZ2ZW71ohn7w7pK1VNBHXFpfdkzTbFxeOqTLh7W48nHoMcB3rc2Beko6llRFZwDmPFi055Ll7QnhpKcQxj1oGTR9VzKOrfTSB2O7eI6pceXcZmXHqtm1tlOo5N7GcdM46n2T7p+yFBLLBFvP9u/mPDou1SzsqoTG4Yo3g4m5Z9Vy9ptdQMDWMxxHJj+Hh4qS7/FfXbswPZVwAEXaRYrzW0aA0MguLxEnC48EKHaMtM7mDwsupA4Vz/WC7T3jfXomvjXrNzqbZz5aZ0x7PuDn1P2XV2ZNGIw1oBvk4HiEnbE7qSBsbW2xiwcNAP16LjUc5ppA7H2b55p+3afr027X2a2jl3sIvTSHsk+yeR+yrDvaARvfk12ZHJd6mljnhwuaHxu1aPiCuJtwSROEJFw/MPGlv1SXl+NXWu3QFZHUxOiczE1w7QXKbs95qgw5w94O97osdM5zH4cbrHVeqpWx1FEIy6wIsHDgeYU//AD6X9nFbO2mqt2DYa+HRdSSOLalJu3m0o7r/ALLh1tJLTVDmTDtE3DjxHNbqUyQYRNcX7pBVyn3Exu+qjKJtFTPdUOtIR289BwCz0NfJTyHGPVl3ZF9ByXSrYnV9I5sbrTszDRo8fquHTUs9ROWWeGt7zuSuN3O0vXp0w1u1ZyJL9k3GenTzSNoytpZmYOxI3IjpyVqT/S1mEjz6LZtOg9OhE0Q/1DRw9sclN6rXv0dsuvbK0NPdOTlJaKOgL54j2HZl3u9FyYqWWjgMziWuGZbwH7rubOqY6ulMMwxtIt4hZvXpJ/K8zUzySVAmHZcDkOXRd/ZG0d5CxrjYcf1XKn2dFDtDCZGPpsV78T0RrKwRzsdG0HDrnoOS6ZayjM6rt7cpn1NE6SFxLgMT2DPEF5enp3VU2FrQOLnAZALtw7RkqY2wQus6Ts4uS1y0kez6Z80LHOFrvB1J/RZxy4/i1cd9s+zql0EwhkPd0J4hW23s0V8XpFOLzgZj3x+y8/LLPJU74vs++WegXo9lVxc1rXizuX3UynHuJjeXTMykioNnuLz2yLvI58lfYm1RIGxuNnC+v1SPxJDJhZIx14jq3rwK4dM2bfsdEe0M7rcx3Ns28bp6Da2xwZhUQC0bz22+6eKwbRijpo4y3vN0XRpqt9W1tMMh7R5Lm7cpZYKxr5O1G8dhx4dFnG76reU+46WzqllTBuyLtIs5v2VWUcez5XyYrg90+61Y6Olmp6f0k4m8cJGo6rpsLK6l3chydo7keaXr0TuOLLtB/pm+jdkDYDn1XoqSoir6Qxy5xyDPovNS00jKgwBl33sMteRW1g/ps0fbBY6wdfmtZTfpnG/VOrGnZgMQbmO7+a/FcynndBOH6hxzH3Xp3wx7UoN244XDNjjqP2XCo9mvmqHioG7ZEe3fnwCmNmuy9duozdV1OGP7Vs2u+i420muEojI0+aZ6UKKsMYyZrYeyVoeXbTx2YGbodl3Au5JjNVbdxlpKp1O9oJ9XwJ58l2XtiqWieNlpbWd1XFFKJKZ0tQDEM7A8LcSjsfaginEJfc37JOqZT7hjfqqSkvdvAbZ6ldHZ9QHDDbLQhX2rSOmY2qow1xce0z7j7rNPTuo6dj4o3SyjvFg711L2s23zvbS0/q+ywXw5cSuFI118Y11N12KWT0qlLJKaVrTkQ5pH1WBuy5n7R7W8NKO0DpforhdTsya9m1jS0RSDE12RHinbSvgDcN2vzx9Eisoal0jH09OS4akkCw5WWxlHPNSugqmNDCOD+71Wfsnpyo5fRZ2HW57oPzXfp521UNr5kcOC5uzdgOpDI6VzXucbB3IcgPqtNNsuenlcRKMDjdrQD8FctfRHE2lM2nqpGz5O4gA6c1p2RXG/tBvskjvBdXaWyWVzWb+S5ab3aOHJY5KGGaojYJ3xCMXFrLW5Ymh2sz/TelQxGVur2N4dQuPSyyV8u7bThrRm57j3V6yDZ7I43DevcHCxDiLHxVabZVLTRvZGwtaTc3OazM9QscvZ9T6PNuHuub3F0n8Q7KbVsNdSAGZo7bfe6rrjY9AyQSiEF+ty4/cp5ZBGAAGBTeu4rylHs8U0O+qJLSkX/wAQg+uE1n4bOhyt73VepvTgaM15BB+4eMBIA5gC61zTTg7LBNPEDldoyXaqv7tIPdY4/wD6rDUU0dMGSRTukc52YPitlRIPTaXF7hPzXPP8msevabcqmMpfR2uvJJa45NH8+q805rcVl0ttytfX2Y67Q0AnrmuY9+a9Xhx1i8/ky3SZRhNgVgnGRutkpvcgrNHDJVVDIYhdx+A6rsxG38OUbp6t1QRZsQvfmT+32XqsHaBSKCkZS07YGZNaOPE8StTnYLA5hcq0W5t9W5pjRzHBAYnDMZJoHPkilOvy8Fe5wDLxTB2nAclHsF8lUVY6zHZcArxluA2bl5Krm4YXHg5wb5C5SohYGyqPIB1hYu4q5bdwKm7AcEbkLu5M07eis0erCY92RySojfEgdE/CQ4HMLYyQSDLsn6LBomNfYg30UVtLe13kC1SF7Hjs97im4LqBBCqQnlgCqcPJBVpTGycHWcDzVSOeiqWX4rNm12u5rSbszHXVWAWc3HBXZILWKxcXSZ/VOtfvFTDyUa7EeiuD0ssNdfSrWi2eqhbdEDLzUJtpmqKEZqW56K11LcUCy3JDCrubiOvgoBZBXTJC9virgFw7KWQQNM7qAnPXRCzeSBuhdFWsP1QIQv0UAugmG414qYeWqmFEDNBQtsVYNB5t/wAUwBEANb4hQYpInmUPY/FbnqmNkAzcXRu1Tv0VXHgdEGqGXE0DW/FXkpYJ29uMO8s/iuW5zW902z4JjK8x8bppdxqkoMdI6BjhgIyv7JvdZmU8tHTOaYi4t93iVqh2ixwzPxWhs0UgyIRHF3pqKF+AFkjDcXCRs2SRwfK43Le6LLv1EUbo3Oe3FbPgskWzg9kmeAuysOXmqMFU9xaKkt9Xew8OCdsypa5xDDdui0+gPbRPpnkyNIs0jK3kubBGaVjmvY6Mg3N+PJB0doYmOD2Z4hY9Cs1Ni3b4nZ8vunTTmpoHOYc7Yvhqs1FKTTCWXvON9OH8+ykimMqrCJnI4SPBavSmtj8isEsdqneH2hfzWndY4SbaBZqxSmkD6eV3V5W/YUTH0VMXcG/dcenmMdMWiO4diz5artbCN6Gm4dn7pl+q4+3WqYS6LeRgFzRmOi8dtiqdJMIuAPxXsjVhtWyIEi7QcupK5u3NhistVUgAlGZYO6eo6rz+PLWXbtfTnbN2iaaRjHEmPnyXqIZmVEIa8FzXcRqvNspmUFIXym0hHaP2StnbVfDIGydy/Z6dFvLDfeLEv1U2zTTQ1h31nNPceNLdFnpo5HyYozhw9rFfRehqaqlqqXczG4dm08jzXOlbHQ02bbg6H3lrHPrjWbhq7dHZu0BKN24jet4HiFNq7MbtCPf04PpDRmD7fQrzTZi2bfNdZ98QI+i9PsraLaiIcHjVZzxuF5LMuXTg0NG+aoIAcwMPadyK69PU4ZRBL3gbg8SulWQOLHy07WumtctGjx+q8dPK+SbG9pxXztw6Ky/Im+DvbRofTryRZVTRoNJR+q5+zaE1VQQ8ERsPaJHHkn7OrTKAxxtIzMPGnh4rrueX07nxN9eAXOjHtdR905XHpePLtyqiQUVQHRd12Zby6rbFNFVU5ZIC+J+Rbx8V5+eeSWYyOd2iePDon0Ur4W76wdHfPD9lq4a7Zxy+mn+kPFXZzw6DVruDunjzV3zMoKpoY7C12eHkulTzMkjGIksdqG8DzC89tSlmhqnb2QPa7uyDRw6LMvLrJb+Pp6Rghr6UxyAOY8Ww8jzXHGyPRqz1j7sBxMPv/wDCRsuolibi70QPe5dF6OJrK2nwvNjqCOB6LN/BZ+XbhuqWUdYGtf2HZlvJdd0Ue0qXdv19k9V5zaNK6jqHsnc5xdo46Ec/BbdnVL6R0O/vgfmwnXwK1ljr8oS/VVqqRlFSPDndvV2XwS9mV+B4BK7O0IGbQo7s/u+y77LgUdK+V8jpTgYzs2tx5JPynaXp6UxxbQpmtfm8G7CuBtZz9/u74C2zk7Z20GtlwYrlpsM9eq6lbRR7SpcQs2UC4J0KxPxretzpzdm1gcAx5bfmts1RFHHUWwh+pI9rqua6jbSUhJDnza3AzvwCRTRzTTNcYJrAguGErVk9sy/TPLI10oldIQ8aC+i7Wyq3Exjf54rNJsFsu0myiN4pyMZb191MrqKtM7HU0QDWjMmwuOS1lrJJuH7bgfNTieI3aM3s97quVRyTAPMY7Njc30XZo5pAzdvFi0Zi4IRfsk7ksikYw3uMrrOOX1WrPtm2fTNlFpO6AQTxzXIq6OSnrjTGPFJis23tA6ELv0ey5KWJzHVmPEdQzTpqthpGOwOe8veBk42+qc9XouO3Ckibs2NkuK2DvdV3KKsZPG0ggtfqCdbpFXsqmqbGcPktmBitbyCZT0VLSi0TMI/yP3Uysvr2Toh2x6amqXVJkvHrG08Od1w6vaDYKzC27rHtOB+S9Y98WQPaHikSOprG0TPgExy/qWfxxY5XbQlaZAAAMhwcOPmnx0DaWQta0lju0DxtwC27PkiiEjSQ0XvY2Wo1UQH9xiXJdPOv9ObtBstPRyYBqMNsQXoosM8DG1EJtrhcMwf1SX7Qiae+34IHakN/7jPkl7ITtaCsqYt1TABpFi5xtl4WWOj2XXwCz3x26E/ouidswN/3B8lX+tU//UV39IYaJziHG28A79j8Fzq3YZnkxy1TgBnYD9VqdtqHg9xPIArJVbWZKy1n5cgUx2Wxu2RAGxua2dzi02F7La+lEpu9+ZztpmvM0u0TBI52CQuGmS0u25MdIz8lbjTlHRfsCic8ucHuJNzdxWiHZtNEMLGm3+RK4R2tUu9n5ojaNS7h8ymsk3Heko6Z4s+JrgfgqCkoo+7DE3/sC4Rrao+0PmgZah/+58inCnKPRF8MZGEC3Syx1M7RI07yxGdlxyZz/vHyCW6B7jd0zyRwsFqeMub1PpLJGW4EZ9VZtTGy4AHyXnMLnAjevzHP9EBB+Z/xKz8Zzek9PY1p7QSX7TiBvvB8lwXQj/klDdtHsD4K/EnN2ztmEf7g16Kh25H73FcoMv7GHrkrWw5HRX40+Rul22HAgMe6490rmMm9e5+4fYaK1+n1Vgb8LLUwTm1t2nMAA1hA8lP6lUkdy3mFmAuiBYhPjhzCq2pLTROmf3RyP0XKf+J7nJjvknbZdahIvqQPkV5rDxW5hj/Gpdu438QzSOs2O1+v6LbBUzyi7n26WXnqVt5AvQUotFfopqbdLPxtNY57HBwe4kcDZGrq31EjXSW7Iwiwyt/Cql/MJEhzyXWYR5LlarJJms75M8wAOZUklLddEqJktTIIoo3OeeAHDmtdRkPWzP3cQL3uysAvTbM2c2ig1Dpnd532Q2bs9lDDe4fKe88aeAWsuXO1uQwEtUxOS23cdUwC6imMKvrxslBmXZOaAc5p0VU4ZC5RF3uAa7XLxVCC8C+QT4WCFhkOpyAWUI2hiMbGtNrWus8Ujh2TY+a0zYnZ9Fn7YkcNfEALUSvMtNuHmUHk+0VMuGqq7VehxSSxBBOaTGMLiEwtceKULh/1CC7jYog55aqjzdysDmimxyYXZZHmunTSslGB/Zf9VyQ7tC60A3AU0OsacFV9HaBoslPXlhwTdpnA8l0WyB4Dm5grndxqapO5ah6M0m91o8kDfkputajMaVpCHonVabqpF02ajP6KRo5Esc0px7yOIaEKXtYylxHBEHLmtBia8fqss0EzDeMiQDgdVnS7EBEHJZPSXMdZ7LHkVb0wcAmqm40OCrqk+lDiFPSG8k403Dw+2QCrqPNLE7Exs8XNNLtMCgHRW3sR9pDeN99NG4OC4F1N3Y5KNlZbvq2Nh9ofFTSqYLhS1kceWRy8UuR/Zy5poEuzS3yBIfLkkPfcrUxZ20un6pL5uSSc9Sqq6Ta7nEpZNipmpZVE1V2yOY3svLVGhnFXDY0si7MNZIY3NviuLXWumrhkHnQeC5+FmE2QBYO8Fji1MtPQtqWy2u4WRLGSa2t1XnxM1nccQmR7QezhiU4tbldQ0UWEhrSwX9nQ/Zc6o2fUMhLIpGu8crJ8de1xBdiHhdbI6mOTqs70rnQB4a1s2T25LW1v+m+KdK1j4yT/AMLkTbTDInCNt7cVL2sMpYmyURBzsXW+a6uwxh2fTA6Fi5ey3l+zy52ri76rp7HNqGnHNgTPqLj7ZfxBO6Da0T43AO3QyPHMro7M2qJmtaSWO66g/okbapWSVTKhxthjtblmc15mSpkZVbyI2DTqOK5zGZx09PZbW2YNpQiSF2Gdovh0DvHqvMCknNQYSx4e0534eK7eyNrCVoysRqF1amOCrZfEGygZEfzRZxzuHSXGXt5hzG09TGx0nYNhi+y9RA2mraIQSRkMIsGjh1Xk63ZVdUSvkkY0NboCcgOa6mxqSvhaC58b2DMG5+C1lJ72kv0zVGxZ4a5kGTozctkGhH6rZVQN2bTB7DYsGa7k13RAPYTfLE3gfJYKrYkdaR6RPKWjQAYR9Fnny6px16L2dtP0ljXM7Odi3l1S9rbJ9Ic2eCwc49sfcfdbKXYdHSuD48YcMu8VuLYg3CbW6lT1fxX3O3GmipqOgsSbBpcep5rFs/abpXMOB7JRobHML0L3UrDng+SUaylYNVre09PP7UoDNOKiJ+6BzkHDyWiaJ0tM2OnGJtu10WjadfS1EJj3nHQDVK2dWxU8REhDXX+XBb70nROz6baMEh3kV479kAi660lP6TA+KaMlh4jgeY5LLLtimecb3vNtLHJT+vxiwDCWrF3/ABZYe6gLqYwxtjjFiBY/PxRoqGelbZ9QZbaENIv0ssrtvt9mM/JKdtyVx7LGj/uCusqbkdWtp46iONk7MRBBBAvbokVOx4awNEsstgbgNs23XRYHbYqCD3Piskm1Kh3tsHmUmOSco6QiFO9sYeZADkXHRdA0kLjie4G/AryT6yYzCRzmFw8U8bTnOsoaFb46TOPTNpKOB1xFGCOIaE3fQNyH0C8m6tldrUuHkEh0znf/AHD1PitT5I9i6qib7Vvglu2hAM94F48vd7xf43UEjeMf1WvhT5I9d/VKYf7g+Szz7XpzGRvNfBeaMrb/ANsIjC//AGlfhPkbWV7Yahr2uxAkXz+a3O23GPbcegC4ha0ew8eaWSLcfitfFGfkdt+3WkEWf5WS3bdIFmxuPVxC4/kjZPhifJXSdtyWx7HzSHbWqH8bfFYyhhWvjxTna0+n1Dmn1lvigKid3+4VSOHFwWpkOHgnHGG79qxh5Fy92etuKvg/M49LlX0CrcnVTUa3VSxlu4PNUMbeDGfAJuuuiIbkrqJulWsdB8ArjQpmH6KhyTUBbkFL81Cc/NENBQUdG12drdUtw5v6rQOSOC40QZr3Iytfhy6K5JF7Zj6I7oZW+ah7JtY58lRA/L9EzHckDvD7qmHEb+aGCzm5X6fZA7EWnNESXyISx4+YTMFz2rA21GhQWaQrhxbxv4pPdNr3CsP4EDicYvdLA0si38w/dEAXNuyVkVItqFZpUxOHDy5KxGIDsqivDS6qW825qxb+6Y0ZXDj1QIwvbopvwzJ+R6q0k2HJoz+izuAfm7VakZtjFtqTFTjx+y4bQuptw4BG0cb/AFC5jcytWadMGijHrGrvw5Qtz5/ZcjZ8GM3EjCRwvn811JXYAwDIWXOfs75/oL3ZpD5LAq8Mc1S/DExxOl72+JXTh2TCGjf+sfxFzYLrt4dbcmmoZK1+QwxjWQjIeC9BR00dHFgijtfVx1PimNYGsAAs0ZABWxNbks2tSaXGl7I7sSJQGIhaIm2asqruS3uoWcOCda2iIZdAoXVwMrlqvhw6FPiiDW45B4AoulY47DG/S1x1SZn72VrdArzzF5s3MDgFWJmHM8wFAqocBJne1vEqjZGuItbP4ITdqUlwN+YCoYWucHAm4zzWkeZJtqUbhx7oHVVdkNEWtxC69Dil2sOqVI67hZNLWmSwFyqujNtLIEu7wHDgoMiEXC5t/AhfF2eSKYM2lNBtYFJGRTr9kIA/uq0FTJCew7IcFV50SyOPVZuh2aevY8doWd04ppqGkZDNcEOs0p8VQ5jbXv0U4ryrqmfkM0s1OeiQyRr7WOF3JN3TnDu3U0bqOqX8slV1S++iBY5pthU3YOozTS7qjppDxUErx7XzRczkqGN3L5qp2D7Sd/MpLoT7By6p+7zRbELd75KdHbLhc3ggtu75nLwQdEDo75IsZDqhbJNfHKD3cQ8lRxc11nMLfEIqh8VL881Cb6jJQnNQA66oXtxRKmHkURMR5oYnc0cLjopune6r0oZniqEJojcOCq4HknQXZTLkib8lTigjuqBAxZIkX0QsgmisJSwWsqqYeSgbv3X9n4Kb8nIhnwScxqERmgsbO4fBC9uKnyRTSrCocBbA0+SIl8W+CXZSymjdaRVODS0uDgRbPgsIpsUTm4g087pqKnFeWmijG7gDA/MX7PPNdOgFqWM64WA6rgyG0biNbFWpNuPhYI3RB4Atkc1jPDbphlt66ERVrpHVcYO7dhDTysD904MoIe7DE23AALxVTtmomqJH07ixjyDY+AWWSrqnvGOV+q4/Df67/T21TtBgjLWQW4A5JWzdoRQ43SPDQQBY9F5suc7PF8yhi81v4tuN8urp62p25FgIY9hBFrLnUO1mwQ21JvkuJvHBHfPGrsvJJ4U+V6B/4je0EMjPw1WSTb9S493CuXvn+8gZHH2lqeGM/JW921amT/ew+Crv6mTWc2WAZjLVEXHtLfxyJztayJXD+98ylGnc4d/jxJSsTveKJcb6/NWYpyH0dzRbXzVWjd3FnfEoYirBzfaDvirpNrARu70jgeqY2OL30u8R9l4QwRHR2fBQ2Y6KEnv/ADSnta3uuupbD7V1ds1h/bYfJXRtQOwnNrSOqYJIuLFZs0Z1ZbyCtvIv4FFVxwcvkquMF9DpwBUe6Inu/C6WQ2/ZuEQS1h7of8FGl7W5M+IVmyvZobq4qXW7oTsBszgO1Gj6S3/pqek39hULsf8Atoom0n+0FQtLNG4fNVeM+6QhbLVVEuSNVU5I2RIzVQALo2QVmsx6IBhvoE6KAki4ToIclow4Tl/wsWtyFBu7GSGM2TCLoYL8FlVAb5qX7Welky1uCGC481RTXI+asGC2Stgtr5o6aKBbyQBYqOcQ0deKMjb3PVBsmFpvoFRMXaH8siHCxtrorEMc0OAsSq4LWz58kBu6/RXaVQ5FG+duvwQXNiqE2cBf6q7WtIUawAZHgNUFMVgjGwZG3a+6YI8QuNVCcJ/mSgo5tmkDTp9lGPNwTpqcJ4dFfVTALjL+fwKiYcTuAdpcaf8AKB7Gqs9htcHNDCXOBdqgt7XgrhKHYcBrlrdWB5oGdnkqgC6XJK1htiubaJLpnXyy6JpNtTnsZ3tVnlmxd3IJLnknMqXW5ixaBciHEKhfzRbnxVRyttHtx58PusLBktm2QRPGDrh08ysTdVK7+N0aHJ36r0FJQRzRtllecIywDj5rz9CvWULf9M3lmuX27Z/q0sEbIw1jWtaOA0QL7HMZKNjHJXIw/BaeVAzEL3Vgyx0VGynSyc1/ThzV2C1rQO7Yo58DkrDtHIWV8IAve5QUa24u7mrOcQAG534DVWbG52ZuBz4pjXNjFm68yoJDGGjE/XklVE5LsLdFV812kN1JUhiu9vPVBI4sLXuPBWdm/wACfomX7DupWZ0zYwXPyuTY+ailAYziva5v9UcDjliv4qMLLDt3v1V8ViO12vFbR5Mi4KsGi+t+iBvfVS/Rd3FYtt0VXNJcLqmCwuCbnqVobHZgJKDM6HI2ckSdh2q0y5ckgsxA31QWYcTVc6JAuw6pgkBFkVaR1gFUEFhQdnGSqMNgoDorAclQ6q4OSgdE8PbZ3BaWTSR9xwcLaFYBqtTDkM1RrbV3/uNt4JjSyRtwVhvcZhS5abxusQpo23GBruKAiwcQUqPaBaMMjWnrZao6hspv2PgFFKtl3R80CGn2fmtDgHcGfBLczPuDyQL3JOjD8kTG4f7fBHdm3d+ili3UGyCoH5fFERB3+3fzKvdnMj4KFrTo4/BToZZKVrgcLHtd45JIppWjLPzW1zeqriIyuisbmSM78dutkLX4D5LfdpFnY/IhKdTQPNw94PkisuD8g+KBaR7HzKe+kPsPFuoSzE9gzaCOhQ6VL3A93hzKrvG8WfMqEt4xn4lQRtdo35qA4oye58yqljCcgb6aq26vzVTTu5/VBR0eXdd8FXT2fimHGz2vgUBI72n/ACVVXHYdwH4qEtce7w5q+Tvbb5goYGk/3GfNQV3OM935hEU1vY+YQ3eXeZ8UASw6/NQExOB/tlAMaBmw6q4k/lyjiaeB+KIraPk75IYGnu4/gi5jTmAb+SpgPVVQMZ668igWO/l0wOe3+FTeO9rGETol49W7wK5JC7hIMbu285HguIBkFK6+OdtVIFuETXx9pY6MDD5re0WZZebO9vpePGcaphPLjkhgcOCbui7/AIVRC63HVejH0+XnPyqirbNNIc32fkoX52wjTktMlWRsVe48PJEf+o34FELvZEK+AH22fFTd9R8UNKqK+F3HMKuQGiora5RI6okAuFlbd3HZcECipfnomugOLvA+aqYnDggohdHDkpbpZAFL5ZaqwsjbogHFQl1+9w6I2/dQjnooBbqoFFYBVUtYo3tojhCBGaAHPO6F+0FbCoGngogWyQIV927kdVMDuIPXVBQBaonRt1eNORWcs6fVRreyp7J03CWK/wDcHRXD4/fHxC5yIU1F5OkC08R8Qhldc6ymY0KcV26NslLALn4ne/bzKhe//qH4qcTk6F+CqdclhEsg9sprJXkd/wCicTkffJHCHCwWYzSDj8goJ3fwJxOTQG4cuCOC/tX+6z+kP5D5qCrc02wj5pxXk0EOBPkiL204JAq8u781PS+bPmFNJtpBVmWOmt1nZUsw/wBv6K+/iJHZKaq7h1xh1Q+vFKE0ZGts9c1cTs963xyTRta3W/3TG6pO9jI/uKb5jRfHp1Q2aX2aclTeZWwrO+sPsi/ikOlc/XRWYpybH1DWO1ueSQ6rcRmLCyzgiyo4rXFORwfide6viCXHTTznsROz4kW+q1w7Jl/3JWDpmrtNVmxgA/qqOkW5+zsPtYlT0J9+CSxNVlDhcGTFbp+6eyvp4GnBG7LjxRfRyg926Wdnvee59FSWxydr1TausY9rXCzbZrK0LsTbEkkdcMs7xCT/AEaqab7px46HNZrthkNDFkBbPX+fFerpi1lJHpbCuHs/Zs4N5BuwM8yu61rWhrGvuQLXsueu3TPKWGCRp6eSjpbnu3bzBVSxkxLAQcNr2+KYyJsbCGsv4fZbcUY0XHxWlrARkcliZUdvCI3tv0W5je0OQCymlwy5sBYfRWwNiz1J+SLpBGOzqkueXm6Hox8vZSGh0l0SCcj5pxG7iB6fdPR7K3VgPHJPGUvkq6NYOZugXg4z5Ke1Qu7LB+Yrm1oEgbG7JhuDn5rW8Ew4WusTexSBA/AGyOBBBBPBWJVYojHHhD8TW6AlWBOHRPNO32X2wjql4Rjd2stVtHmLKW6pmGyrbPX4Ls5AMIOaDnEnLRXAjwm2qoXNbogqRc5o7tQkHRuaYxziLHQIMsjOyUlzcIFteS3lpOizPjcePFAsOubcFBkVHR5G+R5/qELXcBdFWLcWagOFG9kCLoCLXstEbrBZldpyy1UGi11U5KrH5WKs7Dhy1VC3G6qHEG7XWVXHI21UaLlQa4q2Rgtk/wAVqjrGOHbZhPRc3CrtyCg7DHRyZ24cCChhbbV3wXKY9wPet4J7Kt7cr4vFQbCOo8wludb9iqtqb65JokB4Md4hBUPfbJ5+KgncD2iD4hXxN/6Y+aqQxw7vzRRxtdxZ80N3i0LPiqGMHRDBhQMLHtOR4cCFQuc1EO/L9UC78v1TsAyk96Nh8QlPY157jW+F03F+UKpP5fqpoK9GadC2/iVV0MrNY2uHQphCAxg5OTS7Z3ENycxw+KHZPvrTd1u0qFgd7KaNkOjadA+/gqljxwd8E8xjgXA9CqlrwO+8+YQ3Cruby8wEd4b5sYR4KxxX/wCFUtvxePIKKmJp9lnzR3Yd7LPiluaB7XxCr/3IGmA65fEKha5vs/NVxc1YObb+3f4oJjI9n5lQOY4Ztd8VCWX7vwJU7J4fNVRcGFjrYwbdFxrLrkZOseC5GixXXx9tlK6zF0A3EwLn0oXRiNorX1P0Xmy9vpeP9VHMdwI+IQO8B1PxCDu85VOq9OL5Wf7VbevHH6IiQnX7Kp7yIF+C0x2teN2of8lCxnA8OSGC50Vgx1u5dBTCBorYiCrmFxPdVvRnE6cVNxdUrG7j9AgXeHwTxSuRFLbV6bNVm1UWr0do4kqwp28leRqsnkq2yW7ct9xTdNvk1TkaYCUF0DGL5AX8FYRi18KnI054aeSsInnRq6GAXRATkunP3Dj7Kt6O48Lea2uCABumziyilcT3grspMu9wTwOzor8Vna6hLaPLvfJQ0g94/JagbEDyUdmU3TUYzTtabX6fz+cExkLW5W0Tiz5fNQD+BDUVAHhdGytbO3JGyiqhuJQxhWyULrK9p0pum+4PgENyz/pj4BNtiGeiJbopunRBijP+2FX0dh/2/qtGDorBqboyGlb7tvNA0jeZ+S1lt+CBGHVXZqMTqbP/AIVfRjwd8luyKpgBHmrtNMjYLmzsIPPOyjqV41II6LZu8/8AhTDYZf8ACbOLFuHICncR3fmFuAFsjndXDVdnGOYad3/TU3Lv+mfgV0ixVuGq7TTn7t3un4FUs4O7p+BXQdM1gOaWZpJD6uJzr+KbTTKitQpKub/bc2/vEBNj2RIR6yVrfC5/RXaarAfBUcLZ3yXZZsqED1jnv8LBPZR08RGGNtxzU2uq4DYpJD2InOHQFaotmVEguWhg/Mf0Xa0GQt0UN8Qysm105jNkgD1j8XQBaoqWGI9mNoPMrRY21vn8UcN1Dou5b9lYNx+KOBFrCeCiqGE8XKu7trotLWlvFTDcZc8lQi0dnFzhYa3UMbBYgEX0zGafgc4Zsba3FQQtHADwQKa25AOhstUcZYLE5KjYmt0F7eCcyJ79AnQhDMVrN+AWfdAuAEbg6+WEa9V0GUx1ccr5p7cMY7IWbRynxvYbYDomMlsWgDN3FVqZe2FR5DIcVkX01PwY4mtGY7RB5dUuaTC7LPoFkpJHySvcc3aeS0yx9hp43VTa2M2cSnRt9WHDMqtRHgDI+eqc4COEKbNKOGGC/NGU+raAc7hBxu1reZS5e1NG3FpwWVNf2pIxySZZWxQyYgcROQHFSepbHNidqBksgY+eTGTh5WPArWkLjqJTfeROZnlccFvY5ro7lt0sB3dviA5qzThGG1rnktRlZr2ltmsF7Jb/AP0wfJWac/NAdhpJkc4E3ztl0Wlebx4RkqudfgjI7C61kACRe66OagH1TgGFvdySyM72QIJGqqGtDSLWuoQ0Ovh63GiU0IOJ4njmim5O/n2VXM6qmK3RQG4y8kF921oybdxWOojwOuBmfktLi5p7x04KjWYxpbqSURmkf2QW923zQZJdwB4rR6N2sjklyQAG7dUBIzyRaeao1zm5EJl7tuijhvohitkoH2IyUeQSgW45eajBnkqk5a8VdmaDXC2978kp7bE2VmOwhRxxHyUCr2UxKO7JsqkqBzXc9Ey4OmqzNOSu11iiNLZnsGod0KYJ8RzaR4LLjRD7Kq2hzXDvDwKJ1/RZGFr9DmmDE3K6iHZo25hIErmtzzCuJwcrWRe1i0KYDwKAc0+0iQgm4e7h8wrNppOXzCrZAm3/ACVDo0UzuJChpfzfJJ7fN3xKLZJA3V6imGkHvFAUred0N/LcZ/IIOnf0+Cna7hghaB3VC0NOizmeTn8lN+78vwTVWWHnC7JzcvBUNPE//bZ8Eo1DvdZ81PSiP9v5qaXcR9DAdC5vgUp2zsuxKPMJhqf/AMZ+IQ9MYNW/RO06JfRSNt22H4qopJfyfFaPTGcj8FPSoufyKdnRRpXYDmNOa8/rYcv0Xon1MZaQH3JHG684T2gpXXx6bqZ1mFdCJpda+i5tIbtK61KLxFefL2+jh+q+6afYVhE33QFpbE3d3twH0Vt03GfHmusr5+c7rLgboAAfAKwZbh4pzYBiJR3D76+Ku2NEgZZDij8uqZ6O+2RztxR3Dr2FsPjndRSw22Z0NlaysYna2+igjdbu/REUIsqWTnRuv/bPwVcDvdPwKqqAdEdB5q1ncj8ChbmEFXBAjPyVwOQ/ZAg3QUBVwpZWGSC2AEoYLfFXa4e15oktPFQJ5KgbcZ58+qdhBH8/nBUtl5KoFhyU180W+GSta6KgCIF/5/OamgzRvYkWz0REJuDbIlUIz5cVY3OY11ULTc2Zly/n81UEGfFHD1VmRuH+3p0Vmxuc3+2fNVSsF0CMK0CJ/u/RD0WVwvZvxQKByVmlMFG88WDzKYKUjWQfBEKAUsL3TRT5Zu+SIgHP6IEjulBzMV/FaBC3+FTABwQYy3D/AAoW6rbg6KwFunwQc/CcV8J04XVxE5wB3b/NbvAWKOHtD+WVGL0ZzuFvEqwpX++B8VtDTbTirbvlqiMbaAO1kkt0AHzTG7Opw04m4j+ZxWhrCG5lHd9fFUJbTQN7sbB5BNaA0dkAeCsBZWtkgQWucoYiD5Jp7yqXgZ21UFRGeKsWXOZ4KB4LTY5+aHa46JqglgF7DNSwBRA6K4aD4oF5HqlkHgeKc5pIIVAy2qBWovh7Q0dmjDI/ABI0XvwvZaBECERATy+KbTsq9zpZE5DPX6JwhsO0clYRk5Nbbqpyi6KY0ube3xOacyO/M5clZseEdo5pkb7NtZOS6QQ2OnFNaQxKdLbUpL6gHQrPs3pofPbulIknwvA56LO99yrtbjIcOGi1JpLbfTO52KUEpdY4mGxzFwtjIQ57eV0qqjax7RzKbNX7OoIQ2AuQkN5oxfuuT4W4Ye9w+KUyK8okLuKGhnfvKhoGgKbVEAgX1KS+QNnB4/dSS8ko8VFWnyey/NJq6gQyEgXkIsG/dXqnloxtYZHAZAc1mDaiVwe6FrXHmrIlpcUpdYvzdxDgQ4fqtDZO0L2t1TXDDbK+lxZTAHeyD0WtMlvLSW4bjMZg2smtlOmLF42SsIDbYEWDp+6ou52I6IuHYFm53S3B98iiA64zRXmiiCG6AX5lWbG+TO1lHMw5XuV1cynuJ4/BDiM1Ys6fVAM/NbxVFbZZnJTXL9UcRaM25881MV0FHgg6otbkrjCPbTGuyzdl5IEYrHu+ZumsLSO9ZSVtxkkljuSI0kC98Q87JT4g83IsOeV0nMKXQF0dsnAPbw5pe7HsOt0dqroG7si3RAh7SDmFUrSG4jhOnkg+nAOqKQ03Fk2Ftwb6pT2FuuisySzhfRBouWoxnNVJxC7fJCN1nG6Ijjmb6XS3DNXec1QqKjDkrXVQMkRl91Ba/wC6DirtAcEC2yojdRfVObIQkg2HmrByBplvwVMaqMx5olvJBcEXurteeazE52RvZFbBK8aOv0RbMcObVi3nVWEhvqg3NmYdRbqmNayQ3Ejb9Vz8ZAV2yDjyUG/0ZzhkWnwISzSyW7nzCzY7ZtcrCqkb7bvMqdhu4c3WNAwOPsItrpOTD5Zpja42zj+ana6hBp3cj8CqGEjh8itzKyO3aZhPkmNqYne38QmzUcvc56IGLouyJYiR22q2CJ/uO+CnI4uCYLG9kt9Pc6L0Jpmk/wBsfAKvobCP7Y15JMji8vNTuvosT6d7SRa/G69t6DG7Pd/VU/pcV7gdo8Lpbtcdx5ylpCI2Pw9jiuvs6jL23e4xQjV9viLLoNoo2jC1jcJ1y4p4juLHPLTJcssdvVj5rOmPc9rInLgRqFYQ5Z+C1BrQNOvBR2d8lJHO3fbO2JoCsWZDtJhFj3fgpboqyUGWapg6JuG6Jbz81Qndo7tN/gUxch4IF7vVS1lfFb7KXzQUw3Vg2w0UBGSsDl5KoFvyfJTB+T6I3Vhe2qBJaPc+QQwD3R8AnnXRVy5IhWAH2R8ApgbyHwCdbogWo0TZlv7Y15BHAw/7Y+ATQxt1MLfkjJO7Huj4KFrWvHYHwCfh56oFiNFAgDuj4BWb5IiM5IhpCAAXCGh8VcNyy1Uw/sqADw+CmG6thvwVgLajJBUNy1UcMrDI/RW4dFLqBQa++brhWtzN/uiTkhfl5ICAwaoOaLGyNrnMcELW10VADM8tUSLKXRzUFcOSmHorBt/DgrAW0cm0DBcG5uqYCNB+6cBzKNkQkMd7/wC6u0fmurFl9So1uVuqoNuiP8KqXMZk84T1V2tcc73CdCqgBV8IA7TlLs4udboCh2oNPNDK3dReQG3ZdxQ7RvwWd6NVA3LLwTAy50SgHW/uceitpq4nzTZpYtzQA7J7V1AeihcpuroM+XxIRaCQhiuFA+2hzTamNZmLm6vitkktc4nMphfb45qC1s1ZxDX56JDpwD5pUtQmtpvTQ+YHwCQ+btBIEhIzVYxiuCbhak17Te15pn4slIGueLnWyY+C1uqdEzh0V3Imr9kv7JtxstVN/bSZG2TWPLYHYVN7XQYvWCwsszxjficbkFVfM4OJ0H2TIs42vOWaitcbsMA8Cksdd7SnGxjz0ssUdQ2OYsxXk5cvNVFpHDejgOJRdM5+Ld3FtMwqySRjtykBp42y+SayJhfjY/MDgdR1VkFCA6PMuD+YP0WiI3jGIOuOfEqjoyTcOyVmtt7SsZWc46WSw9zQMbcTvBFzSXapMjpWnPT6LQLi5xvhw8rohxAsRdVNywFRodcZ3QMDcR71lcR/mSw2x005cURkMnZ8kRwi8MblqkNc9zycKaNM8h0Vm5jRdGS7k5Xwg6gItjaOFuqhixfFBoawHVBV1mjT5IE4m5Ny6gI2xi4QIwqhjWMLc2D5JM0bQ7IK18tfFVIJNickCgLHJWAJ1VxE2+RzUcwtyQVc2yW9rbpmEquHJAtAi7hdMcLIYbnVBUJ8Ud2El178EkghNjJaLu0UAkitr5rM+AE6YeoXRbhfHcB4/wAtUtzeiqOc4Ojy1CjJbLc6EF2X2SHU1+9YG+o0RS7B2d1MJOiEkW7NgVQSlhsoL5jUKcFZkzHdl2quYgMwgkZsFHm6Ibb7qrhcIKEo4srIEfzmjfMILNyCsCqteAckSePwQR+twq3Jysic1UahRRLDyUCviyQwjVQEG6hKI081CggKBKLhYKoaqLhxvqrB5ugwcFHiyC+LNXa/LLW6QDzV2m/VAwuuqF6jjhSybnTwUDBVzMIwyPHmU0V9S3/ddl71ljdqrx5DVTQ3R7Znbk5rHeS1N2qHNu+I+RXDD7OPirvk7OqaXdd5u1qfPsvHwTG19M7PeEeRXlS/NaGONgpxOT0Yq6dwymZfqrCeIg+sZrzC8/f83yTGOy1U4ryd4YXDvs+IQw9fouSxwIy1RFrpxOTsNbbii5l1x7H2XuHmVN7OzSZ/xTivJ1izPzVd3lpwXM9KqAP7rvkiNoVAFsYPiE4nJ0hGpgWFu05Qc2sPkVY7TdwjZbzU41dxsEaIjWH+qO/6Yt56K/8AUyT/AG+HNXSbbA1Ww2Kwf1L/APH81YbRaR/bf8kNtmFAtWYbQZb+275KHaLAP7b/AJKaXbRZC1kg7Rixf23/AACPpsRF8L+uQTS7h9uQzUzCSKuMjR/wCsKuM54X89ApqpuLi9vJEE/qlCsi5P15I+kt4MvmpoM4KEXKUalo/wBv5hAVPZPq/mroOUt+6SKr8tvNEVXNv1RTbKWSxPc5AKpqHYtMkOjwCjhuUjfYvbt4hQuk4OyQNw9lEC/80SDI4av+ShkudX6KqfhIVg3JZtTqT5lXaP5zUDbM4u+aIDdcWuqSG3bmiGWNr9FEXc5rVUTtvax+Co4WBSyUGneN5Itly7nxJSARfIcU5jbjlzHJATK4vbawGd+qrjkw5nx0RLQqYrFBHML3Al2ia19uzyOSW2VoHPpZAzZ6W5KjQ04hnzRaMtVk39hc80BVAi1+KyrWXNaDkkPnIOQsl7+/mql+eg1t0QVc57nd/otEdwzM3WUusbotldcIjXjtpqg5925HwSxbvHiocJ0KKNzzUaDc3N/uq7xkfe1S3zYtFdVNxoa/CMlXfdrJIMuF2qUJhfyV1pnZz3k2JSz2u6rNbjF7prGaJuQLaMLTc6p0Jta/mhPHYJMbng+Km9q3zytwgB2d0mF15CeqS67j9E+njsCSVFSR5c6wvZaWNvFrwWaWWJjrFwJ5ItkeW9m1vHP5IMz3WlAtZpOnNa3TNjjcGsuW8LJBc2IWlYJGX/uBuYPUfdMhmALRa7uF1dG2V9TLMQC2w5Xz800PgqIsDxfDqFsIEuUjLX8lmfAxpHHiDktRnsmzIc2Oe48BcaJjZHPbk2yq+LtDP4hWbGeaqLRyOZYE2T97dw4DnyWbA+wAPkcwqCOUXxHPnmbqjoNbjz3nzVXRZ5Oy8VkaHjLTrmiXuZ1+KB7mYcxwUbZxuHXPK6pHLiFxmeRRY2Nri9rGhx1OiIbgeSpdzDzHmg6XIKOkBvkiuDfgqF+HK6Zh6KYW8l0YV3jjkTldC2aJcAdFYMxDIIKgdk2bYoYRxOSY2I3Cjo7DVBQBoGQt1QLL5nRWAwt5qXvwQU0UeezZWkblfU8kojNQWZooQDz+SBFzkiGknu2+KCmDsm5yVCFpsW6HJBzunyVGcBXAF7vT923I81QxjhzVEuL5fJS/8ujuyVQ5ZFuagZhxFVdHx+CAeWq4ffjZBllgLjeyzvisbWXSLs8xlzQMbHm9/oiOS6O2mnVRkjmCxzC6L6ZrwSNUsU7AQDqgz77gdLIbxOkpmkHJJdTkOyI88kUA+7VQnNExlpzHwUwg8UAumB5ulnJFo44kDL3VmjJLcW5WOaYx6gq8doIi4CLu1moFFQORxKWv0VXCxQXBVktrkxul1RYFE5qod+6sHfsoQA1nHVWtyKocwbqoNiimkX4KhHRXbJYKB/ZPyRCXtu7NEAAWsmYQc7KrxmikPyKLxcDO6tIMtFIzzQIwnK7VqhHZtbMpLtSb53WiN9/goh7I7EZqOajizP6qrnc9FoXZ2RZWFlnxqwd1QPBAy8la+eqQJBdWxIHfzgqFoHwVGuuo52agLilvFz5qxIPFDEAFFUu5qu1xuOyq3DlYGyKcxzDqrBzeXFJY45m1vsmtIIva3UKCFzTn1QtcKOGLLpZFotcKqFjwGSsFD8VAcj4qC4LbKF4B7vwS8V2lWtmgLpM1BK4aFVLeiW7I2OigfvHnigS4uzN1TR2SBJBt5IGefnzRt+ZLBv8AVWA5u8eqKsHWGRQM1unxQJbzSsV3ZaKDSxz3C90xrnYSqxgbvXimWaD5KLAbnw8E5reipiDT2QpvXKqLtVZg7OqWHYhfqrxm50QXLngG4sLDmgLn2kxruybaql7DS1kFXjEcCqYxe10wG/BTz/dQRrcJAKuXBoySje+qKiIX3Kq4cS5RwGK6W51iopsYDGE8wlvfmgH5apLjeyos9wc8ZJZBFrapjWXc0dLJoYG5IgsaTH2yqggO0z181XHgt8/t9EiWcXNtbpo2eZLixFvsqF4u2+izGVxdmiJFrTPJpdOQbcVQzvvklOBJ8CmRizdEOwdI85/VRpLiCTfojIBcD9VdsJvre3BXYD7Ftm6qgjIzunbsgFV3gaRfUrOw6FmBhtxWmFg1f3kiOQHIC99Anb2wtdrfErLcCRuJxJOSW0Yn2GgQd62UDFbqLpToXNeTi+aqb00TPAFgcwlsldI0tz8r5rNNTue6+K/2VGyvjNhcHW+aujbo+j4gQ42CsYrXDXjy+yTTTPlD22sY8iba8irPmDMnx2Ol1dMmNZmcyT1VpIxI0Ai4CDXl7A5otxUMjmu7l/BVFbPa0tabttodAqBzrWlZccDZWdNiPd08Vb0ixAw/JFKLjbCNWqodYtu1zByHFOdhJuAQW8ePxQE7m3sA/wDyFiqI17RwKYJAURLG5tnswnT+WVcF82HJREL7tNlTfWyRc5jcj2fL7oXaRpf4ILtcw9fgmOLLn9krsZHCgWRvHesgkkoabXsbapdsWeJR1K0G4cb+Km5LeN+qrLO6nGIZqei34/JbLNGgQLm+abrWozNpOaPoxBuHBOJvroqtzdqmzUIfTFx73ilGFzBYLY8ZquHJN00wua5vspZcQdF0MGWqmFgaTYC2eack4ueXOcbXQ3TjqbBbxDGRjwnxCoYWn4c1eScWdozACLgtApx7LkPR3E6XV2aZ7tHio5tzc6K74HN9hVEb8JyV2hT3WRaTcXNwmCIk2IV9xZwz+ioqMNj2UmRrbp5ixC1kBHhaVAlrOeisY2+8rHqcks6IDayOEKMY4poAAsVRRpwhTDiGYV8PJAm3s3VC3x2NhpzQEII7yvhJz1+6JBxjO/3QZnwXP6LPJCLaLoEkeyg4jH2o0HLMPX4oYHN4XXUMbX+z4JTqcWOSyOeS4HRAZEraYba6JLoRbRAtrwr3VHNwuCNxz+SouM0HDkiTn5cFXGOaADIoh9h5ZK1xdENBUFC+581dstgquZnkqhptpxQOEmWaFwToqAdk3V7aKKOLDkiDxuqcFdgFs0Fg/nolv7RvdR5wnJVD80FgMiqXsLK7HYmKrhcoqp6ap1OGjVKwoty0KI0mw0VHOz8lR7rAWOahdYKKOJHVUBTBoqLNVwUklRp5aIhwdb2LfZFuY04pV+StjsEUXnDl5FVuqF2IqXw6qBreHghfstSxIpjyQNYO2Uxridcs0prsvMJgIJCirg5Djz81YPuBwv8AolkYTl3RmOo4IjK45EBFWJvwVRx8VCf5yRxWcB5ILNNlYuAKpcBpI/4Sy4ajyUQx8nIXQY8kZhJxXHn/AD6JzTl5fBFMJ0yt1VbfRTFYogktOVkAt2SUBqAfBMcLWHS3gqxtuf1QUdocv5/CqwtzOXmnvju0W5KNbbTVZVZuRGaY12HLlmqgWICLmYtdUAcb58Lq1x8uio1hAvfgmBgGZ1RQB4HXn/PNWDiCbaIYbcdOqOjgLfBBoa7s81UvFsku6Bd/OaC9+JVg/qs7pQMkWPvwUDgcvNXbmPNKxD2vJTeclFFzsIz0SeeWiYe1fJUDbsv1KqAe95qBlrZ6JhAawW8llqJe0FdbTcOx4XhwOio6YXJvcXWQvdl2uigGLDZa1pnZrpmuGiU7GS25V927krxsOWnmiKsiJVzHbK3yTg/AWkA5kNy80zd4e1e45ZKba0rFFb4Kz+ycm/si11hfFYDRKc90rm3fh8uCyvUAhzHNvli8dFpjccGQ+OWSpFG0O7xdxzN0wuysGmx5q6CJmuOrbW6j4qoDA+28HC9s0zc3dnmESxzNE0KtcHvdgBNuN/sFYsccy7IcOCALvd+SLnvurpFA6YSux23fDW90y5KLAXaDNNaLahULLDmQmmZjWgBuY5hWD8LSqXQRr8JNsIvqo43Glz5aqdm+nTmpgB9rpndURhswttZQx4hr9kcNvauphcRnfxCoqG4B3lO0e674pjWMeMTXDD00UETb3GoUZJMoabPYCUWviLcIGRTTG0/ZDci6CmJrNcggHNB7BwX4Aj42VnQ3yOiBpmhwLRp4Ibqrpd1bEMbOPH5K7RA9pdCQ0nQHMfBUlgfKLAWI46Iw0zY4sN7Z3vpmmjatsXZkjLLcQbg+aaxrR1PlqixhEZbjJueNroFlhrfoRmqL3FtVMIPFJIaHDtlv3TmAW/mSIVe+Q1QLc+6rBotl5K4AF75rLoTgNsx+6l8OR81Z5zyKrhv7P7IKSSgOsg12LQfVXMdmnj91Zo4nLK6gmC5Nkuwa12M3dfRMJOH3R1QIZfLM3TsKJ7OTbKNHS32Vy0KwwhmQzVFbWKszstvxCGK3BG10QcZcRdXtzCUWtuHBouM0XveXgnnmgs5kbvZzQMTLC4RDnHvaKXF1d01C9wy2V1V9OCeyc7JxzKLR2Sm6mowPp3X4ICldbT6LpW5nhogB0TkcWEQPae6pu3AZtK32tqUSBzV5Jxc0ssdNFVxDVvfa2XNJcbnMa+CcjiygF2aJy9paxHcG48VXdMHBORxY3KYjdanRNJsAh6M3l9U5JxZu8dFYDyWgQN6q3o1+KuzjWRwvqEgw3JstroMrYvkqindbXiryNViNPzcEl1OLtsc/BdJ9M7mlGneFNmmPdOCqWXFiFqdHI54bbRLbG5vC/RNpqs5g5XHgqOY9p7JHmFtdGSO48fFUELgePmFdmqyYnjvAeRREmWi1GG/D5IOgIPdQ7ZsdzdMa/LMeCj4CT+yAhzAt9UFw5RxBOQztwQdC4aDJVEbxqMkCZHOvyVC92IXKe9ruSUYrlQXYTx0RL8JscwjHHhCtuwRayKqCDxVwqObgyAUxEDRQXxdFMSU4k52RGK6KaM1C6yDMr/y6OJpyQAlQOVsIQwtvoghd5qXKJYOaBFkFcRB+nRQuUcLHMIPHaQWabEdU1rQW3WdouPNaI8i++YARQtb6KzHWt+iDbus46Oz/AIFbukADPRQM1Vo2nDz6INcP+1Wda/ZN80Ub2CWXZgIXcL/y6GHREHFYgX0H2QLL+XVXwZXv4IX6ZHRRVC0WTm6gcwqNFwL5BMEdsWdrcUSLOGF3Ph90Lq5Fma5KaOCKq3Tu8U1oIztf7oBwvqmajLVQKJx2GFENw5eStE4DFj1/n7IGSMZX424/zgij7QN+qa0rO6ZvssxX42UZK617WHj/ADooHgYW63zBUccTRYA5i44WVTNr2eKhnGK2Eqi2HDlbs6X6fwpjQL3z1VGS9nRXFQAMhmgNiWpeDpwS5KhxKUJnFveU0LPBACoH2U3rzlxKpjc51uSuk21scwgF5sUXSNGhWNznA/23nyRa8gXwhvif0V0m2oTcgg9xGax78B2RN+g/VHfvv7Z+Cuk21nHJcAWJySvRgGnE7tKvaLw5zXnDna5WyINkZcDAT0/VBi3GIi2fFbGRQsYMXe8lY0xPtu8jb6Ku4wuHHxy+qikyW9lxvfgCoyJ0mAs01OtrLUyC7nA93Kxvp0V2w4Yxc/NFUbEyMdvXpZAsaSMPYI/llcxi2l1W1jkFNCroruvjJ81HRscBivcZ9UTdWa53L4oFtkbELBl/FCSdthjOFpOWuqaRiYbN8FV1O2Rg3rWOIzGWhVQd1hJJuOSgAPNXYS82dYAac06NkbWEPzde1wisZa8AWzUYbN7QWppa24abhUwsc65aqKiVrW5BFk7C7NQxtcRk7xy+at6PHY8eHkibq43ZzAv4qrixvsFw5cbKga1gsAjnbNVVscDzZpDXcQrNia03L8Q8lTKyqTh/fNRGgRt1ulPwgkYrqjQHNNwfK6LacRjKQm50KIADQL2sTqrtFxmrYLHMXGigGWYw55Z3QC2E5FQ3Of6qxGXA/wA/5S2zdrDb+dFRAL3UMbv+p5Kzu07sZcymgd7Pjn1UCWtc32slHDjf5JjXAXHKw+6qSLGyqF4hizGd0RLYeaBz1YiM/Z0VRQkObnoqgYTeOQN6cCi29z+6Lmgm9kghcXZX0UubZIhtsyUbrDqA6qwFkPBEDmgq8G+XJUzGoTCeGqqRzQUvkjwzCls1ALN5IBkgG3Vjk4KAZIBp/NFewvdDDzzKuGcygrbFle10CwsyLrq2DLzRazLM+CBbhnlog0G2fPNOwoOHaQVxWVsSrlbRVbmCgtcl6BdllqidBkg4ZZIJfPn91C64vboqgHUi3S4yVgLm9tEA9oI2aDeyZiBGYGfGwuq2B10QVLuISWl7nG2iaWXP0U3ZGYPigqG20Fyo651/5V2jr+6JbbNBRj8GSsXYTiw58UDnwy4KrW555c0DHua9os3PokhuEX69VcA5ABOa0NaQ5wzFsuCDKXZo+XlyVxFuwXPOLkgHAlvZRFCO2OzZJfH2sWhvqtLm8QrNjZbPsEDXI3KKyNaSMz4o4TbM+KdGxklxi7I+ZUEdsYJ/5RC2jimMcbWsDnxVbXNlcAgaKAObG4NAjtzuAq7iO39sJmG5ULc+appQU0ZGbfqqmmjuMsz4p47uTc0C4j+FNmoxupGlwUbQsvqflktRNje1vsqjNo4dSm00R6Kwki9/go6hjPHh0T8NuOQ8skxpFu0PBNmmH+ngi4f8ko7OIHevnrYrpk3180A62iuzTlvocsh5Z/EfNLbSvAyH1XXcQTkPBLkvfIWNslNrpzhSSn2G/NUkpJA68bSW9dV1mOLQMTcR42CsHtI7lk2acZkM4BvHkiI5P+n+q7Nr5kIhm8Hatkcssk2mnEdE7/pnloq7tx1Yc+h/nBd3cBos25AFuqGBo7PA8k2acMMsBdhBz5qpGfj0XbNM1wuCh6LfgmzThtyAysrB9hy65rsmjbwNuF8skRSAA2zPOybXTkB4uc+X8+Su02w2wCw5jkuiaKznHVEwWOcbbEck2ac5hu82yA49OCYDktXoLCb7pnLRMbRtA/thNrphcNFLXC3+gtvpe3A/zoj6KzTcjCeN1Ec+1zceKjnBht5FbHxMabNixXWmKkjeA4MZccE7OnKbI23nyVmyXA1z6FbZqdrLYGZeajI8ZBw/JRdMj5L2y1zt4qjZXWF2mxXU3cbcOItbe1tEHQk3DHDxsLoaYb3vlpoqtc6Q2b2jyzXSjgc5uF2duPNUMDmlu77PPLVBiMMlyRG/98lZlK5jWgMf2RbPkug29tMz4pkbbjM/HVFc3cSjVn0UDHDPTzC6TqOJxuCbjmSkTULJ2Bpvla1lUZG9sZcTlmmBjhlg81pZSsYwDIgG+firGzcjx0TQyyRuAcRa3RpPwVWBsrXOY55GhByz/n1WwZaHLqUCQeH0V0ywPiLjxz6lJdTjhpfmdFvk1SuwWnnwsqhEVMwvBcAfElamMDG2a0AdAjE26a3JqBRaXAkdrjZNFLHLHZ5wg5HJUJPPio5xeQC3MeKoIoms9W7CeI8EdxFHkdeio6Vzf9sfNFsocM2WKCskRLuy7JWje0yGNr2F7e80EXHjyTG5uOnmrMwhzntYGuOpsLlFWbrmFC5rmlrhoqF5xaW+yN28dVBVwOIWHigS/QFR2N2XAqzI3AIDGHYCgXOBtfXmrNMgJA4qOjcdVBXDzVsCHaa4DBdR7ntcLDJDpCwg5aKwbkgJBfMK1wR1VFDG2/VWtZVIJaTZZIK5k1XNA2ORro9S4dk+HxTRtqtzLdUbt/l1UZk9u/RXZHisboDkBkhl9uKvuj/M1Nzlm63VVQs2+v1QAs22vDj/AD/lFjAWXD72JGXjbL+cESCDoiAIv5mq4WteGYu069h8E0uyFhdS4OrBbryQLuWuw58uqriOK3LJMDW4swb8Cdbo2bfPX7IimIo68vNF0QsXA/VLDHEiz7H7oqxbfL6qoZm0+aEkUveEmG2drD4K8GPdDe5SaG17HwQSV+BoWeOU4ra8LLQW3acyl4WgNa6Ox0xNGX7IhhNnHrl8FAeyUous8Xyv46pl8kZB2ZVXmzsmkZ6ixCJKgvhOd/utixAfYuN1XARxyRDgoc9NOCgqTz0RvmiFLZrm6hc8UbfsjbmjZAAOaDgOSNuvghbPNBXDmgBYmwzTLZ5Kpy8LqAW7Qt5o6HVVAc7u9kX5a+SuAAMszz1uqI3MK1rKzGYhmiWNH8CCpbcBWw2OamgCPickFLdoKmHshWLrBDFdACMtEMKsChisM0EA6qOGfmoDi004Kd3vaIK2tqEceVm6IjT6ohvRAu2I381c2vnmUbcELW0QQZjPkjhPDzQYMs/JMxYRlqgoOozVC9jXAOdmefFNt8lR0bGOEj2XcNLoI5meegKFuBOSjZXym7hmTceCthyJQS1ipZUBN8x4q4dZQF0jdzh3Y17yzyd9OJvohguqFNJNgi6Eu1OXFXLDGev3UJc7V1s0CsmZRi3VSziLnVMxtZkBcqoOOzrX42QQdhobxBT44ssPkeqzuDgQTkBzTWTC3igLot3mdLoA4hkLclYzC2bksyjlb7ILlpvm7JEsbnYXKVH23XcdFd5/N4oFvFjYalVI62Cv2ychYfRQtsczmgq4WshisLJjL3BOmSaZWh3dQZb56olt+CsbF5OFTTr0QUwOBUcLcPBXZ2r3Vy3sXOiDP0sj2xoLD6Jr24Gi7dTbIHVCyCmO2mt1cPJNuiGAkdkWV93kLOz45IKXI9r4IEkouGHXmhcHQIIC4fdTG4BEDEo5tjbmeagqHv3t/dF/M/wq2+ceKuyHsukJsC61/wCeaWG3aLHr4oGiRmG2HPnfNUa5tx3virCG580BDhanQZHhcbc+as6O3tJIB5W+OShLuGqimNa8Ww3v0V32YzFI8NAyz49EtsjmiwR3pdkWBw5lVF3xMkYQb2PHirRRx08R5DPMlKxflJ8OKaTcHOx5GyJ9rExus4suDzQbGHNGA4Ul5IeDjuOX881YSMOV+0igYLPu92Icsk4DDGQ1oS7NOt0S7BkSgs1zm+yqPkJ9lAy5qhmz1QMvcIX5aINkuR9FchpzGvRVNiH5WGhQuQcz4qpOE91Vkk0yV0hhdfilA62HglF7QL6BWDsR0uE0mxdjJBB8rJZdgJFvDVNvnlkqyC7r30+SqhcFwurNa0tyb9FdrWuPeweSBDQ5zQ4EhQLD3MNjGLdFZwv2gOKLsQkAtrpa6tZwyVRQ5nu2GWfVUcM8nXPRaGaWI1Sg7A89i3VRS8BkFnPz5KzY3MIwjEEZI8Tr+Ss0mJmTSbckEN9C1TC4A/NKZIx5JIkaeR1UcHudcXt1RVt5h1Vw7EEGtz7WZ+SDtfa8kDGkWRxvGQ81Vhx5KxYAczcoAHO1xX5KwkPEKoGXa5dFe4woBvOim/YMnPDTyNkHFmINvfFchAsYc8PxCgsA14u03+CthtqqMayN7ixti7K+f0V3tdfXRULmkbFm7ieqjA14xDQ6IODjkQLcijFGIoy2Mlrb3sSSqyTU0olZ22kHgRkb9Exlw22Y65q4OdnFXxWytkUVVpdpbF1V8Fwc7IY7ZYUMWIKKsAGZNDRfW3NQud4quh/W10BJhd3fhp/NEQzInIZ+SB7KGIO6KeaqCX3vkiCL28lXjfzzsrYeI+dkVDl1VMbtcIbxsbIA65/ZS/VEXL8Te2LHrzVQ+2rUNUHC2hRF95y0VC4clXRC6qCSq3QtkiG5hUEK2QBsLnkqZhpwo8ciqIDiIIFiRm23Hklb0scA9tgdDn800lBAw6+agOSsW2Dhqdb5ZdP5yS3us558CuLqsrABVd2m3GWSIBsL8s1RLZZKaK7W3OnHXn/LhB4UFb30Qd4KW/N+6hGI2ByuqA4YnZaq7Q0DMi/VVMfaABR3dtSgs43JtfLkpbO6sMgFUuyOSA3vroqnLRAOF1ASW9pAD+YqWHNQhRAc7adlUAxa881a+SIGSCaZBA65nNGwPFSyAAZZa3VgM8wjewCIPMIBhuEA2wVicuyFS5PBBa11XTVWaOZRfYOHEIKsIvmo9gffELhQAFt8APirXzth48OCCh0sMrCyXTNdFjDhm4g3v/LJpCFkAOiq4acuCcFUlgyLr9EFBkQC24Ks6PLsu7PJEW/S+qsALZ62QKczPVVEGNhMklhwTHNOLN3ig4WPDTyQJyaXbvM8+SvGRwGXE8/JXw9rNWLRiHPy1QAkPzcyxOYNtOiW/Iq+ZsgXMZkRmgWY8WE4LDg0/VXMNrOyOLqEcV8vZCqf+UEPMKpzycFdqs3NuYQLa8R5W/dWgGNwGl+PJBzLqD1ZGEZoDVBrDgjHiVXCo8l5uVUl17HRBGdlxIGivuSWOdcWAGpF1SyIGX1QFosr6myDBzzPFXaMr9UEFwLKu4uLjW91fEcJyRZOWk3bkgDLsyLUC3EWnTorOk3meGyVNJIGERBhkJF8R0HVBVzcRIIuOfJTd2NhmgHEO0F+Nrp4zA+SgoI+qWeY5/z+dE4txJbWCNlgeOLzQAAkW5G6vhIN+qAzLrKAucAXZE5/X9kVHHojiINuiNtVLc/NBAeYVQL2sr9lTGBoEAAzyGaYDloll3aCN1BHOF+yM+CpZzxfoicwraAX80CSLZAWJ4/zxUFx16pxsl3zKqIHWIcc1aR2YKDcJ0LSeliphuPBAt5v9kp2IA2fbrknFlzkqujueflqqijZOAN8symNdi0VHDDfL6JbXOOG7eGa0yd2g21yeGaqTYZoaa+aLQS2/H7oK2DtRn00WhrdAltxXGQ+CaBllqgAj1soRhVzkOSluN+CKW2xvZ3HJXDXEqAX1Aurh9hYalQVFweHnwREWIA+3xtrfigXYRnmVZnayvkVQpuIOIFw3io6S/ZcA5OtgFh2lURB7b2seKgo3Jw4nlZVBxSSZZC3PrwVy3DojgBkxkWdbDfPS97KiuEOCOEhw+SYIWvF7+Co5mDifioqrh7zrnyzRbhtm1LaHSS20dy6JohcBqqIcIBzt1VThJuXJjY2lvbzshZrJQ12bXAm/UcPmonYYGuI5+eSOFgWizMAslTNGdhnmikuw+fNWJs/l1V2OZFGMXeH2/dAvbIb3/ZBC+7wg6XCCCLgqDDbXj8URhIUQA5gb3bKYu0HDjko+Nt73S3BvDI81VMIDjmpg5FUAzzKvfOwKRAzVg65shY8TkqhufbBtwVDHNz1upYX0so3qR9ronL3vPVFVLR7v1VbW6fFWvdS/TwURAoQpiAOFw42GvzRLeSopgsNVNOKNrKpSMhiyQJOiOLmFNQrPaF4rFWurYbqwjBHaWhQZlA6Ivsx1m5fZQE8c0EJyz0QaRZQgnJBrcIQWuqkjkjblqgWg+Kge9/baBqFnka57mluTOPwT7YR2cncSg42Nxp9FydRiZlc6aqx1HzQxFwy0TL2YAgrjsCAqk3cLqHxskiojEmAut1/dA0t/nNFoDRbyQ72YNxw5KtjkbkKi+h1tzVie0Mug6BVa66hQRzuSpdQ5DLVHigjW3aocla7b6qhFgA3u8EBAxaKaCylsuqFjx80FuKhJ4jLggDloi49lBL30OSsOmiEfaFlfDbiiK+CsRc5+SmKysO4SRfLRBS3ZP8ALIgXOellZoxcOGgQJvkOCAXa3ICyoQSVcBvmoRb7oKXsQi4dm7R4IYcs9bfNHz4IJbC63DVDMjMWFkWuzHVWIvm3zQLPgrNF87WuiRcOP8Kl8LgPJBDyGn0Qu1g1zPAqMPVXBFtEVQc7KXzTbZ58NFXDlfogVbLjb5q2ID4Krn3DgM3NNvNVZES+54Nt5fyyBobiOWv0QcbXtoT0Vg3BqeHNF1rB44i+iIzvbfO2iW254J5zN736D7KBufAW5aIAwloVA/DcppGSUWXOSKLTiC0xva1lt20u5ngsdrWTMWF1+SBjGlrrm1jnkqS4SclA5xF7XAHyQDxfRELI6W6qzW/umHCeFvsqO7OiKs0Zgogm2drdVVpsLg+CjnYj5ZIKvbvGluYy4HMKzRgsLk25lC9imDMj6ckFC7sGwzQYMQy8+qdh7JuUpwwOBPHJBLWH/CN88xklPY1kriy1yQSbnXj4aq7XdkqC1889EL5afshjuCi0A58LcOSgmbewNDxP86qwGI+IVgW3AaL+KvhBHa1VFMOEWKjUcYjIAHa5lMbHibiJ1QUwtccgqujHDVR0ZubnJRrXB2ZxBBS2FTU2TXMudbJb24dCgrkBYBWBtqgGnELcFH5alJBCQUmR+6zOp4clJIi9xdjItmLFQOyOIXOlytIVDJGwkRMwg5m1rLQ14Lb3WJ0Zc4dkNHOyaw7ppyLuRRlox3Cq5+eSU15kN7JrA0O7SoFsSq6FNu23ZCqLgXy16oEOZbs88lcDAbXt1T8OI3tZUfBicLtxdSgrit7QPig7FiAN7aZFNEIbwR3SCzcwCDwtmo0AXI111KpZzNFcFxyUUL55pjQLZGyWezrmjdx0VFyDbTF1SsNnYrHtBHtAd5Wa6+qItjFgCrCZoabBKc+xS2NDsRzQAVLy4gsbbzTmG8dyLFVwNxC7vLJMdhBy5KBGJ2G7u70TG3e0EHLggJe14q7X5nJUUaCxxI1Vg5xJuVZxudOKF7HlmiiHEZFUc3O7dFZ0rR3RcqNdizQVBvmXW8NEXkWzcLdVVzDY2bc6KmEA3fmeXJA2JuOPtXOtr62SZYXxvuxoLTqCTfyKeyfKwCD34tFBBEXai/RTdAafBMhktlxVHTesLcPW6BT2534fUKEa30TDJbskaoF3aHYyVQGGwVsbBqwnyyQfiIbu2s1zvcZfqr4Ljl5p0RZjmOH2QcxvAKpiF7sdpwRs6yioG9VXthpB0UtbR+am8c3hi6p2F3e0gxi41II4JxJLidB1Qa/Hnb5FF1yAqiYsOX1sgXHgb9ECy4OaTZzC0HMWsgdiF89bKpPJUsCoNNVUBxHFS+fRWNn5DUKpbYHPwVQd4A4WKLZMsxxSgAX5eShOAWcciqLtdmezZQOBtY5qOczdF3JLD2uIt7SgaTcFAC2jviqk3cG206KwDh3vJUG/P/lUd1GSsLE2Kbu8+9cWQWce1e1zwQLQTd+Z5KE21VS7F0v8lxdVsTQgST3VG4eGZKN+A80CGtc7+5iLuQVhTMcbuYD4pqmLNNADLshuFo0spxz04It0UOqoIOSGLskIWyz0ujZACTdFrbqwChdbRAL4TkFUG40UsXI4bICcz5qpNgbeSJIb3svsoS1wuDccLIC3XNUcHOGuSIbfoiRkgjThICviFs3Kt+1ZG3IZIi7bHP4dFCeBGaDfHxVjmB4oK3GnwRsFbCoWXAvI3wsbKigNnI2zvZVA1CZia2MWddxzI/VBVrcThfT4KPa1pte5P1Rbd4xAZD+fZElQRzRgFj2lVt2DDzCjgS7W6qXZ2wdo6ILXsNP2SS7v9Mv5/OauTh7LT2zkSNG/uhDEGhp0HHkUFrZC2qLSAM9b/FXBBBvayFgPZ08EVCbjJKe5znYYxfMA263TL30P7qrDgbY2xc7fP5oLxsDQBx0UEYY219MlmknLGOLXXN8IaefJOjfI8DeAA8giLBr79pVJxgnFkMk8t7LsWQKzmPduIvYg6fJBV7ftfTyViLG/RR2vmquNz4oqY7oHva3z+KqG2JsrEX01v8EAzI7KsQCLEZ8VGmw6q10CSC0ZHJQO/ZEi7lQNu43Nx9UQXHD2VMWqlsbgOSqG7h+EMe3CL4yOJ4IC5/ayH1RAxcbKpcGxAE3LTbEo2UIHsAGZ4IOddwsqBj32LHAAdNdfgmBoGpz6qKONAFu7IcM+Dh/P5dLe2x0zGeXNWLrA3VBaRcA4bWz8FR7bGwOQ0KhtZ135cbpZwuZjx4jfFf8AXyQXL8JsPJFjr25ZceCLY2uAI4BTDnfzQXIFrWVmsdxNvNLcczxVmuyQVdELt7Tjh5lPjfgGZuPqgxuIXKgaS6xOSBgkDtBl4IXaMQtoBnzVHXZ1CBlaBm5EEgHiluJBVx2+78Ut8eZN81dIq4tDSGuu6ysQC0F2TraXVALHLI80JgbXxX8FUUfK4GzcgqiZww4s/EK4yuXa80HSZ2tx5Im0BcRkbcVR+I+3YdRwT2OYDl5IOHAC4vZUIBywEXPNNbGCxpveyvgZbNiIcQchYAKBXDSyJd2G2VzZ2fBANGE/JFgse63aOSc3MW4JLW5ZqwNjZFXPZ4KDPMBC6Y02QU1BBQY2x1THFirdo0QQnE0g68VVw7Wqa0ttmhgubk+KgUVTdgm+O3wTXR55KpYiABbirgDX9FTCjZ410VVc4SMxmoMHEKrW9nNA/wCP7ILOa08UxsYGeLgsxbd3n8Uxoe0aoGPtiVN3wvndVLnE5eSY12EZaoAYX3z0RLMjdTekcUMWJ6gLDgyOiW/N+LXLRXLlQm6qdIC08EAbXHz5otPZ/NxRw31QEOzCIcCPNVazJEtLckFWtxOyd5W1RdGTmqm4B7Xy4clGy4croKNY9jyQ66uScVxqrZP11RbHl3/3UAB447c0WkEd66sBbhfqp2A03ago62LTOyjW8tEcLNURYDLkgqMhkql9lbELWuqubc5FVBEh9kqji4tLr6ZlQ9jXyUAxLUZUOZvb6qoL3C+HCQnHsAA6IEjUaKqRje0aWz+CgLnjPTmdVd9Q1kjWW1CsHYhm3LxQZjC5hDmOumMMzsixoHUp1m3ucgERIwaDF1WRmklwaNGaQ6ZuhbloH8k6pc3NveJ1WMHDcDMckG2Jzs8b8bPzZH905rmMkawvsSNLrDHLhvzUJDnNxGzdWuve3RUdItIGWioH2ss7XPh7r8QI1Gaoakm28jvf2m6ojccxnpZWAFyicihboubshOaluisNVCcvogGWts+Cl+ijhqoBdwucvFAQBhQKvZCyCgF/D6q/NVPRG+drcMkB00QUvZQXcSTogF+Wql75/BWcG3PFTDkgrhxa6I2wgckb/wA5IgfDgiBa6I00Vmt595Ww4UCXfNWY0OGuX1RaMTzfMckWM7ISBjWNLTZQlrDY80t2RyUvkba/VUWIzxX8VUi9iqjrrw6KEW0OY5oAeCsHh7XNblkbHTNVtn00zTImerBvxQWbkMIyaqnLLhdWt2SqkYxYOzHL7LKRA5pdhF7ouIabDNx1vwSshfCbXyLxlzyCa0BoItbhyuqqNaMVwMwLIOOeZyUv9VL5D+XVFcwcj4pjemqLBcZ6qrwQbaKBVsLx3shw08/ioHXGQyumYSdPIo2wjqiktiaDiOicwAWcc+XTxVMRtnrdRz+y3qbfUoLyS4GgDVKe7EXHjkg7NzUL5FEQnPyQ110Rw5/JC2XlmijbPXxQtnooDmjf4oBn8lVwflhdlY521Vi6/wBkAcrIKxOc1nrHYjfWyjnXOQRI5qhOE28skEJwm41W2GrjfHZ+XS2qwnNQDkM9EReqNPI7EyN4PPh59ElgwC3LJXcy5y081YR568UFmusbeRVsV9NFXBfK6t3SiqRnGwniTl5XH2+ahY8i/mrMAbG2+jQPorCQcDceKBUgs27tCQBkdUAyyeyRmHupjSxwyGaDNcg+aa1mI6IvFlSV3YyQXuxmqF2DholtuTeyv2rHKw5nVEOaQdHZKOe1uX8CRGbC45ZKziXDTL7JoEyNvqqvcx9r8FnlAxXtohuy44hIQVWWpjsLSMWfBBxPDyWFzHQyte5+I21TPS881RZznZZotc5Rrw/EQM1drXO1GSqEhuNxOisI8057Gg+XRJL34gAzK+qCzWjAbm+SsQATZt+pRwYgfFSxZcHJpsodgRY5cslBob87aFVcXDMJkZxM7TcP2QQC6BGHuhWs2N+uqOIcAgphJKu2PK41HzRByyGatcE2dz5oqmHFxz4KrjhNrrQ1zRroqOIub6KdhAccslCbeSaQMViMlN208LIF4n3z0Vg8jimhoHVAtHBUK3juaIkyVjHyGao5tuCdHY7zp4KB9lN3ide9x9Qpu8xY3+6dJ2tvL8FMTb9746qbvE0kapZjsUVZz7aaKNkBz5qpiN/NUfTPe4EOspo3Wlr2kZqzy24sOKwx0zmPvjJ6LRheAqLFtxn5qbscCqgO4oh1mlAcHJyrbLyUxKYjw0Q6QNuhayN/5yUvnmgqMj5KY3NyVy4NUMgJ7tuqdihcS4IPha7PTLmo6+9D2vsziyw/5TcTXXzsnYjGNwi0nXNFzSNTcJTLADtacEWuyFnXHEILkXulySWIA4+Kvi4nRV7LhrxTRtI3EjtO48kXYeH2S3NHTVUDbcSc+ZSRLTCb903P1UDnAWtfqqkcQfBTGADdWItivdvgf58EbW0KoHA6I+C0CXXyVHB/sYS3ryRuRw8UQ4W80CXMDnDeC/IJzSB2dMsrImxz+CodFAmZjy0kPJI4FZhe4OfVdC/YuMzZKID9Y+zx0QZi/g4A/RKAabDDx4XT5YCw3vdp+SUWeNuiCzZGhpaGW6q1O0OLW4+ydQUhrb3DmDFwPCya1pabhxuOACo1OpQzuaBYsJe8HS54Le17ixpy0zuswhcyZowZA6hB0bWCsArAqZclydVb201RHdOSnZAQQS99MkNFFL+8iCDbvI3HDVB3C2iF/gijc8vBQjJRoaRrf7ouGuV0FXC9s1YDM216KoBOV7l3yT7NaLDMkZohQIytbAdSVMQtYKOPDmrHsedkEazE021Vi0MsCblVxWzJv0Cse2M0BB5Kr9HK4s3QcFMIIJeLqgMYcNyqvcb8yeCZISWC2Q4BKY5oLjqTli+3xQTXMDLXirjX9ErEXFpthB4Z5dFfhre3BBYsvfPK6qW2KLXWDf3QecWY8UE14aqxxBv3CAOR5cwg44riw8EEcbdlpAda5PCyoDdtmjsH4k8/BFgxXLO6TrbMn9Fa2Fthpp8kAAJ7Xmi06dfsi0XzGtlHGzsj49UQQMyb6lTCdUGOv8boPLtAOKimR9qM56hQPZ3SLEfJLad265N4ycuhRkAyOpCqCTYZ5DmqFwDyb3PNCR+Z8LWKowYmnMt6jUKKsw3dcZNH1z/RB5sR0ecrdP58lBwFg0gk2Gh4fFGQ5v8AEFAHdq4OrVGgAeHzRIz8ELWN9EUbqgbcCyaXXFkCDbWyCmC3X7oN1OWis45/zwVoezjecxfT5IhV7jXipdXkwk4m5A8OSpZFUvcE+aIKhahbDlx4oLW5KoF/ihbIK+hOfFAW5i5FgrcR81U5hRptny+aBllSTsRuN9ACrMJePNUlwlufEFAGesia4DMgH4gKagnnmpjLQL9AMkSRw0QABNjy08kpuqYH2QGQnFdJeblWc+4KWc00gh+EjL4BWDrt0VcTGtNjmhiF7q6ZFhtnfVW3jQ0i+viqXULSQbCx5qhLhr0H1Tox0+qoyN183X8lqYyzVUIk7R6EJG5vbO3QrWbAtULA83GYQY7FoDWu7WnJFtTIRh7xPFSVoZLYZ8bIsGYIbbkQFBZhe7N2aaHWBuP3Qa15GZseaZYC980VVsisZMtFWwdoFR7HE6WCJ2IeXOz0KuH2yCoyLs2c7gntaGsARVGtMgBt4onsFPjDbW0VjHf+aIMrjdvMI4mgpxbY5j4KpaNQi9KluIXCAzPj4p19LaqBzG94WKISGm2f/KNrn6JhAvf4qpNiooWe3QXVXFxN/knteLFR5xOQILnt00VCeZz0zWrDcJRZYaKoTjI4K+O/wVsIQLQdQoLNksMlMV0WgAaIFqoN7oh9jmhgshhvrpdOhc2OaItbPRLItwRbp2vPqoqwaD/NVC1BrSdCo4EHXjkqhbsj9UW2tn5IHMaKpaiHC1/ojhB+CUxv85q4LmjpdUB8ZGbW6JZYHHW7bpoccBvyzUacj2lF3FHQWIbi7R0QETrX4FHHdzSew6+nMKb7tggDCc7X4IbipZhysg2MEcs1Zz48TWYrX4Ik7s4TfPinbPShiJB/VUILQtJc3GG6Yhe/7oObn73VWDO3PUIgWvYKzxyVWhaFS62qAPa1Uc0ElUDM7oLYi2wHgi0nDclS2ZS8VnfzJA4OByKmEcCl4uaIdbJAS390RkrDMHxVcA1IsUCwDc4cvsrgutmLdUchqMvoj2TxyQRrjxF0BHG8HsC3RQAgdULm+t/ugQaVolsS9vHzTYYt0Sb4iU3EboOdne3BEEGzTx+6qS3EOzY81A+5HFXwg5lA0lS5OShzz4lS1lxdgAsMtVa1vFAOyyRuqgFqBFv5qrX7QQeb+CKDc/C6OHK50VmtyF9EQbC3MIgRjQnRMxZABuqUX3IazXlyTsIa23talULLeeXgjzt3vLVR+brXtwy4qd1wbpbioAWhuQNyNfFVc3EcR7rcmlRw7Nr6XzVwC4W0xIKl2HvA3tw4psLMr5EnglkYS0AXcf5+itHKTJh4c0iLGwOJ2gQycQS29tFeRtyLWv1SnnFlcgdOKqqu7RAv3bZoj1jWkZAHFb4qA4nOB4GxPXkiDkBz+aCWvmf5/LKN5q2gKqBmfLJBNLAaZ/HJRpuL8yh3cLXcbNHja6LQQTxQSQ2dawPDoqszcRfMjjwy1VgL568VB2Ra9ydSggdhaGNyFiELk52tbh8M0HHgi0ZHh0v8kBabEW1CvgY4Fzi6/CyU0afy6a3LIHNBXJugt1VrX1KSThcAM+F8XzVwXHU3Phb+cEEdcAg6Jdsx5rQzPIqPaEGctzyVgbDLyRLSSi31drsugqyMuaARlog9uE5nMtsfH+FPM7WjTNJLsXxuoA5l2kIWc83PRzfuFYHLyVm5m5GQF0C8QaDy+yq6a/dyFlUuEnCw4J8VMXDE/RIFQRukkDnZNGSvI4N7LBZt8+q0P7NmsGSVLhEdzwVSMzn2BS+07MG2aDTiJuLDmf50TW5FRpQOerYr5dclCez5j6qYCBlqERZvKyvgBCUcRNh/PBMYy2bicggVhItlxUBcGppcJHNN9c7n+fy6t6Pf2wiktkVah/Yf/if0TTAGtxE5AEqgjJiYTq7tHzzRE9o/y2f7K5FsWfFDDZxOO9s7FENy14KorxRuockNURZrbgElQAEaJRvbIqwfhNjxVRYx9VXd210Vi7NVbiMmqqbo4QGd1TFc2I7QCuW2KqYr6lAp8uEttz6qekYwWk5cxy/hUkyY1ulzqq7rFl8lFWDnDM5O4JoIsXDRAx3aOgSyHu42aOHRAxzWuJcBY8wg5pFu1e3A2QaMr8k9ovc8FFLAsLkoveA0t5j4q7mAtPxsklna81QxpBaPgquF+4LjiqkZW4Ig4dOaCG7XCzc05hJbm3ilGQ4gmtIc0m3igaM+CsTnkbBUINxh+vwQDHYbkoGCymBuEkFIxYbIYr6nJAw5FB3abYj4qpdln5I4swgFgDqgLvFwVci+mqOHiTxUFN26ylrBNc4BoSxIMrIvS7JMwCNUJG3Nwll/Ntjf4J8brgXV3UZ3B19FW9gtDzZxuLdVQtBzCCjXZK2LJENULTwRQLjnZAk4gbokEeyi1uIefxQ7Br+wfBEvyOShj5W81i2pHi2XWO5U8mhPulOkbMXVTHcZL5MotcU2+tNI9pMAYF8gUU4m32EYToq3AP1XyFRXidvrjhdpVX9kgfovkiiaH1nA0OHRKmjLTiDcS+VqJofUxHvRix627IIyRANgHZvGYXytRXSPqbWu3QB1vyKkeONp1NtAdV8sUQfVBZ4udeCo9hOj7HyXy5RB9NBcW2cbW+as0r5gog+oG9+6lhtnghtjay+ZqIPqAGV7qYMWosF8vUQfT3S7rDoL8c7KweDkRY8wvlyiD6oqksB73gF8tUQfUnYb55O4KBuV7r5aog+nvBLhnc8eqGK3BfMVr2X/AP3Sj/8AWZ/+wRH0TEORUvc62RwqrTieW6W8ckH/2Q==	f	\N
61bd4894-7aa4-437b-bcb2-285bdc034994	doctorasifali786@hotmail.com	$2b$10$G/KMWndVOm/ikm/GcJM4beuV9WJmgei7oDDyrwgnHtEXTYI61yfSG	Asif Ali	student	trialing	1-year-plan	2026-08-12 12:41:05.131	2026-02-25 12:52:32.344069	t	\N	\N	+923227310300	f	661657	2026-03-05 03:54:37.241	t	\N	\N	\N	none	data:image/png;base64,/9j/4AAQSkZJRgABAQAAAQABAAD/4gHYSUNDX1BST0ZJTEUAAQEAAAHIAAAAAAQwAABtbnRyUkdCIFhZWiAH4AABAAEAAAAAAABhY3NwAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAQAA9tYAAQAAAADTLQAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAlkZXNjAAAA8AAAACRyWFlaAAABFAAAABRnWFlaAAABKAAAABRiWFlaAAABPAAAABR3dHB0AAABUAAAABRyVFJDAAABZAAAAChnVFJDAAABZAAAAChiVFJDAAABZAAAAChjcHJ0AAABjAAAADxtbHVjAAAAAAAAAAEAAAAMZW5VUwAAAAgAAAAcAHMAUgBHAEJYWVogAAAAAAAAb6IAADj1AAADkFhZWiAAAAAAAABimQAAt4UAABjaWFlaIAAAAAAAACSgAAAPhAAAts9YWVogAAAAAAAA9tYAAQAAAADTLXBhcmEAAAAAAAQAAAACZmYAAPKnAAANWQAAE9AAAApbAAAAAAAAAABtbHVjAAAAAAAAAAEAAAAMZW5VUwAAACAAAAAcAEcAbwBvAGcAbABlACAASQBuAGMALgAgADIAMAAxADb/2wBDAA4KCw0LCQ4NDA0QDw4RFiQXFhQUFiwgIRokNC43NjMuMjI6QVNGOj1OPjIySGJJTlZYXV5dOEVmbWVabFNbXVn/2wBDAQ8QEBYTFioXFypZOzI7WVlZWVlZWVlZWVlZWVlZWVlZWVlZWVlZWVlZWVlZWVlZWVlZWVlZWVlZWVlZWVlZWVn/wAARCABMAEwDASIAAhEBAxEB/8QAGgAAAwEBAQEAAAAAAAAAAAAAAgMEBQEGAP/EADIQAAEEAQIDBgQFBQAAAAAAAAEAAgMRBBIhBTGREyIyQVGBFDNSYSNCU3HRBmKhscH/xAAYAQADAQEAAAAAAAAAAAAAAAABAgMABP/EAB0RAAMBAQEBAAMAAAAAAAAAAAABEQIxIQMSE0H/2gAMAwEAAhEDEQA/APCCJn0DoiEUf0DouhMaF0xEGwRBH9DeiIY8f6beidGwuNBaeJhwkgynV9hsFRYpN7hj/DR/pt6L448f6bei9Y3GwQ2vh2dT/Kiy8PFPyxo/Y3/tN+oRfWnnjBH9DeiAws+hvRXTQlh9R6hTOCm8pFVpk5iZ9A6KWcBslAUKVxUWT832Utrwph+loTWJITWO0uBPkVVCMaJC14jibqf6ck7HyXk0RR+ykZHqAvke8q8Ob4SZujTZJBLhsARX8qmeiah6GLHeMR50iQvrQ8Hl5lZfFScSbs2Oc80LsVR8x1W1DxRsGPPC0Ds2AB74yXC/I36ErAz8wzvMJcx7BqIeNySR69FXXDm+X5PXpEZ5GhplYAx/Ig2CgkFH7FcMIDgAOfdKEOtjR5jb/Kgzq86gHKLJ+b7K1xUOT8z2UfpwrjpWCiJ7pSwUQKYUtwsnH7Hs52W4eE3WyVOWuFtPd9fRSObR5WPRPjILSA2m+hNqi1VBWp6C3IlZG5gc4Nd4hexRQWTZO55/YINLSDbmiuYJ3Rg6Y9hud1qFz+FhycaOAnTql/Kb8/2UDDsSUDgC7uNLR9zZRXQpB6pkodJUeR8z2VRKkn+Z7KO+FMdKAVoNwmPwxKxzjLWot9RdLNBT48ueMtLH1oBA28inTFaNOThjAIhHKS91h3dLhYrlQvzTYeDgOInnaxpje9p0uB7o3sEWs7Eycl72wxvZvfjAIN7m+itxzxCTNbBGYGOiBruAMp1A+W97JqLCnE/pubLEbmTR/i7s7jyCLoEkNoe6RJwd0fYMdkwCedrXMh710eRuq+/NMY/iYMccePDlO0uIacUPLBqO245X7KaU8TGZCZInieBjQwFlU1uwRNBRwQ4OMWRHJocA/SHbWa9N0yPhf4rDI8mO6d3XNPtYSHnJwmA3odKbII3FHZJ+Pn/L2bd7OlgFpaGCZKD3AcgVLN4/ZPLiTZ5lTy+P2U98Hz0ba7aBdRDB+NP2EzZNOrT5Wq4uKvjbCOzt0bmlzr8QabAWcvlqCGtLxgyYckHZFutmnVq/v1f9pLZxMNxGYz4i5gaWuIfRNuvbbZZtr5aghRkZDZGsZGwsYy6BdZ3SLXFxahh20mTxJiW/xJNcGR//2Q==	t	1
demo-user-001	demo@maternalmind.app	$2b$10$ueoGa7U8m7K5MBZxRtg8m.ufLn9vt4RKJ7.PmNOr2VvEkVrX658rq	Dr. Farzana Muneer	admin	expired	6-months-plan	2026-05-23 17:57:12.589	2026-02-07 11:26:55.113138	t	\N	\N	+923001234567	t	\N	\N	t	\N	\N	\N	none	\N	f	\N
\.


--
-- Name: add_on_bundles add_on_bundles_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.add_on_bundles
    ADD CONSTRAINT add_on_bundles_pkey PRIMARY KEY (id);


--
-- Name: add_on_bundles add_on_bundles_slug_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.add_on_bundles
    ADD CONSTRAINT add_on_bundles_slug_key UNIQUE (slug);


--
-- Name: add_ons add_ons_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.add_ons
    ADD CONSTRAINT add_ons_pkey PRIMARY KEY (id);


--
-- Name: add_ons add_ons_slug_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.add_ons
    ADD CONSTRAINT add_ons_slug_key UNIQUE (slug);


--
-- Name: announcements announcements_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.announcements
    ADD CONSTRAINT announcements_pkey PRIMARY KEY (id);


--
-- Name: app_settings app_settings_key_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.app_settings
    ADD CONSTRAINT app_settings_key_key UNIQUE (key);


--
-- Name: app_settings app_settings_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.app_settings
    ADD CONSTRAINT app_settings_pkey PRIMARY KEY (id);


--
-- Name: audit_logs audit_logs_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.audit_logs
    ADD CONSTRAINT audit_logs_pkey PRIMARY KEY (id);


--
-- Name: bookmarks bookmarks_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.bookmarks
    ADD CONSTRAINT bookmarks_pkey PRIMARY KEY (id);


--
-- Name: books books_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.books
    ADD CONSTRAINT books_pkey PRIMARY KEY (id);


--
-- Name: chapters chapters_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.chapters
    ADD CONSTRAINT chapters_pkey PRIMARY KEY (id);


--
-- Name: code_redemptions code_redemptions_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.code_redemptions
    ADD CONSTRAINT code_redemptions_pkey PRIMARY KEY (id);


--
-- Name: content_blocks content_blocks_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.content_blocks
    ADD CONSTRAINT content_blocks_pkey PRIMARY KEY (id);


--
-- Name: content_reports content_reports_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.content_reports
    ADD CONSTRAINT content_reports_pkey PRIMARY KEY (id);


--
-- Name: coupon_usage coupon_usage_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.coupon_usage
    ADD CONSTRAINT coupon_usage_pkey PRIMARY KEY (id);


--
-- Name: coupons coupons_code_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.coupons
    ADD CONSTRAINT coupons_code_key UNIQUE (code);


--
-- Name: coupons coupons_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.coupons
    ADD CONSTRAINT coupons_pkey PRIMARY KEY (id);


--
-- Name: invoice_line_items invoice_line_items_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.invoice_line_items
    ADD CONSTRAINT invoice_line_items_pkey PRIMARY KEY (id);


--
-- Name: invoices invoices_invoice_number_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.invoices
    ADD CONSTRAINT invoices_invoice_number_key UNIQUE (invoice_number);


--
-- Name: invoices invoices_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.invoices
    ADD CONSTRAINT invoices_pkey PRIMARY KEY (id);


--
-- Name: manual_payment_proofs manual_payment_proofs_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.manual_payment_proofs
    ADD CONSTRAINT manual_payment_proofs_pkey PRIMARY KEY (id);


--
-- Name: mcqs mcqs_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.mcqs
    ADD CONSTRAINT mcqs_pkey PRIMARY KEY (id);


--
-- Name: package_features package_features_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.package_features
    ADD CONSTRAINT package_features_pkey PRIMARY KEY (id);


--
-- Name: package_prices package_prices_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.package_prices
    ADD CONSTRAINT package_prices_pkey PRIMARY KEY (id);


--
-- Name: password_reset_tokens password_reset_tokens_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.password_reset_tokens
    ADD CONSTRAINT password_reset_tokens_pkey PRIMARY KEY (id);


--
-- Name: password_reset_tokens password_reset_tokens_token_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.password_reset_tokens
    ADD CONSTRAINT password_reset_tokens_token_key UNIQUE (token);


--
-- Name: payment_transactions payment_transactions_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.payment_transactions
    ADD CONSTRAINT payment_transactions_pkey PRIMARY KEY (id);


--
-- Name: quiz_attempts quiz_attempts_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.quiz_attempts
    ADD CONSTRAINT quiz_attempts_pkey PRIMARY KEY (id);


--
-- Name: recent_activity recent_activity_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.recent_activity
    ADD CONSTRAINT recent_activity_pkey PRIMARY KEY (id);


--
-- Name: review_schedule review_schedule_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.review_schedule
    ADD CONSTRAINT review_schedule_pkey PRIMARY KEY (id);


--
-- Name: scratch_code_batches scratch_code_batches_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.scratch_code_batches
    ADD CONSTRAINT scratch_code_batches_pkey PRIMARY KEY (id);


--
-- Name: scratch_codes scratch_codes_code_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.scratch_codes
    ADD CONSTRAINT scratch_codes_code_key UNIQUE (code);


--
-- Name: scratch_codes scratch_codes_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.scratch_codes
    ADD CONSTRAINT scratch_codes_pkey PRIMARY KEY (id);


--
-- Name: subscription_add_ons subscription_add_ons_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.subscription_add_ons
    ADD CONSTRAINT subscription_add_ons_pkey PRIMARY KEY (id);


--
-- Name: subscription_audit_logs subscription_audit_logs_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.subscription_audit_logs
    ADD CONSTRAINT subscription_audit_logs_pkey PRIMARY KEY (id);


--
-- Name: subscription_packages subscription_packages_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.subscription_packages
    ADD CONSTRAINT subscription_packages_pkey PRIMARY KEY (id);


--
-- Name: subscription_packages subscription_packages_slug_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.subscription_packages
    ADD CONSTRAINT subscription_packages_slug_key UNIQUE (slug);


--
-- Name: subscriptions subscriptions_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.subscriptions
    ADD CONSTRAINT subscriptions_pkey PRIMARY KEY (id);


--
-- Name: topics topics_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.topics
    ADD CONSTRAINT topics_pkey PRIMARY KEY (id);


--
-- Name: user_progress user_progress_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.user_progress
    ADD CONSTRAINT user_progress_pkey PRIMARY KEY (id);


--
-- Name: user_sessions user_sessions_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.user_sessions
    ADD CONSTRAINT user_sessions_pkey PRIMARY KEY (id);


--
-- Name: users users_email_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_email_key UNIQUE (email);


--
-- Name: users users_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_pkey PRIMARY KEY (id);


--
-- Name: idx_addon_status; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_addon_status ON public.add_ons USING btree (is_active);


--
-- Name: idx_announcements_active_created; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_announcements_active_created ON public.announcements USING btree (is_active, created_at DESC);


--
-- Name: idx_bookmarks_user_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_bookmarks_user_id ON public.bookmarks USING btree (user_id);


--
-- Name: idx_bookmarks_user_topic; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_bookmarks_user_topic ON public.bookmarks USING btree (user_id, topic_id);


--
-- Name: idx_books_published; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_books_published ON public.books USING btree (is_published) WHERE (is_published = true);


--
-- Name: idx_books_title_trgm; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_books_title_trgm ON public.books USING gin (title public.gin_trgm_ops);


--
-- Name: idx_chapters_book_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_chapters_book_id ON public.chapters USING btree (book_id);


--
-- Name: idx_chapters_book_published; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_chapters_book_published ON public.chapters USING btree (book_id, is_published);


--
-- Name: idx_chapters_published_book; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_chapters_published_book ON public.chapters USING btree (book_id, "order") WHERE (is_published = true);


--
-- Name: idx_chapters_title_trgm; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_chapters_title_trgm ON public.chapters USING gin (title public.gin_trgm_ops);


--
-- Name: idx_code_redemptions_code_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_code_redemptions_code_id ON public.code_redemptions USING btree (code_id);


--
-- Name: idx_code_redemptions_user_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_code_redemptions_user_id ON public.code_redemptions USING btree (user_id);


--
-- Name: idx_content_blocks_topic_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_content_blocks_topic_id ON public.content_blocks USING btree (topic_id);


--
-- Name: idx_content_reports_pending; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_content_reports_pending ON public.content_reports USING btree (created_at DESC) WHERE (status = 'pending'::text);


--
-- Name: idx_content_reports_status; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_content_reports_status ON public.content_reports USING btree (status);


--
-- Name: idx_content_reports_status_created; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_content_reports_status_created ON public.content_reports USING btree (status, created_at DESC);


--
-- Name: idx_content_reports_user_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_content_reports_user_id ON public.content_reports USING btree (user_id);


--
-- Name: idx_coupon_active; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_coupon_active ON public.coupons USING btree (is_active);


--
-- Name: idx_coupon_campaign; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_coupon_campaign ON public.coupons USING btree (campaign_id);


--
-- Name: idx_coupon_code; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_coupon_code ON public.coupons USING btree (code);


--
-- Name: idx_coupon_usage_coupon; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_coupon_usage_coupon ON public.coupon_usage USING btree (coupon_id);


--
-- Name: idx_coupon_usage_user; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_coupon_usage_user ON public.coupon_usage USING btree (user_id);


--
-- Name: idx_coupon_validity; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_coupon_validity ON public.coupons USING btree (valid_from, valid_until);


--
-- Name: idx_invoice_status; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_invoice_status ON public.invoices USING btree (status);


--
-- Name: idx_invoice_subscription; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_invoice_subscription ON public.invoices USING btree (subscription_id);


--
-- Name: idx_invoice_user; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_invoice_user ON public.invoices USING btree (user_id);


--
-- Name: idx_line_item_invoice; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_line_item_invoice ON public.invoice_line_items USING btree (invoice_id);


--
-- Name: idx_manual_proof_created; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_manual_proof_created ON public.manual_payment_proofs USING btree (created_at);


--
-- Name: idx_manual_proof_status; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_manual_proof_status ON public.manual_payment_proofs USING btree (status);


--
-- Name: idx_manual_proof_user; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_manual_proof_user ON public.manual_payment_proofs USING btree (user_id);


--
-- Name: idx_mcqs_published_topic; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_mcqs_published_topic ON public.mcqs USING btree (topic_id) WHERE (is_published = true);


--
-- Name: idx_mcqs_topic_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_mcqs_topic_id ON public.mcqs USING btree (topic_id);


--
-- Name: idx_password_reset_token_lookup; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_password_reset_token_lookup ON public.password_reset_tokens USING btree (token, used, expires_at);


--
-- Name: idx_password_reset_tokens_token; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_password_reset_tokens_token ON public.password_reset_tokens USING btree (token) WHERE (used = false);


--
-- Name: idx_pkg_feature_package; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_pkg_feature_package ON public.package_features USING btree (package_id);


--
-- Name: idx_pkg_price_cycle; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_pkg_price_cycle ON public.package_prices USING btree (billing_cycle);


--
-- Name: idx_pkg_price_package; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_pkg_price_package ON public.package_prices USING btree (package_id);


--
-- Name: idx_quiz_attempts_user_created; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_quiz_attempts_user_created ON public.quiz_attempts USING btree (user_id, created_at DESC);


--
-- Name: idx_quiz_attempts_user_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_quiz_attempts_user_id ON public.quiz_attempts USING btree (user_id);


--
-- Name: idx_recent_activity_user_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_recent_activity_user_id ON public.recent_activity USING btree (user_id);


--
-- Name: idx_recent_activity_user_topic; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_recent_activity_user_topic ON public.recent_activity USING btree (user_id, topic_id);


--
-- Name: idx_recent_activity_user_viewed; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_recent_activity_user_viewed ON public.recent_activity USING btree (user_id, viewed_at DESC);


--
-- Name: idx_review_schedule_user_due; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_review_schedule_user_due ON public.review_schedule USING btree (user_id, next_review_at);


--
-- Name: idx_review_schedule_user_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_review_schedule_user_id ON public.review_schedule USING btree (user_id);


--
-- Name: idx_review_schedule_user_next; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_review_schedule_user_next ON public.review_schedule USING btree (user_id, next_review_at);


--
-- Name: idx_scratch_codes_batch_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_scratch_codes_batch_id ON public.scratch_codes USING btree (batch_id);


--
-- Name: idx_scratch_codes_code; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_scratch_codes_code ON public.scratch_codes USING btree (code);


--
-- Name: idx_scratch_codes_status; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_scratch_codes_status ON public.scratch_codes USING btree (status);


--
-- Name: idx_sub_addon_addon; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_sub_addon_addon ON public.subscription_add_ons USING btree (add_on_id);


--
-- Name: idx_sub_addon_subscription; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_sub_addon_subscription ON public.subscription_add_ons USING btree (subscription_id);


--
-- Name: idx_sub_audit_action; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_sub_audit_action ON public.subscription_audit_logs USING btree (action);


--
-- Name: idx_sub_audit_created; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_sub_audit_created ON public.subscription_audit_logs USING btree (created_at);


--
-- Name: idx_sub_audit_subscription; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_sub_audit_subscription ON public.subscription_audit_logs USING btree (subscription_id);


--
-- Name: idx_sub_audit_user; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_sub_audit_user ON public.subscription_audit_logs USING btree (user_id);


--
-- Name: idx_sub_external_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_sub_external_id ON public.subscriptions USING btree (external_subscription_id);


--
-- Name: idx_sub_package; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_sub_package ON public.subscriptions USING btree (package_id);


--
-- Name: idx_sub_period_end; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_sub_period_end ON public.subscriptions USING btree (current_period_end);


--
-- Name: idx_sub_pkg_display_order; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_sub_pkg_display_order ON public.subscription_packages USING btree (display_order);


--
-- Name: idx_sub_pkg_status; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_sub_pkg_status ON public.subscription_packages USING btree (status);


--
-- Name: idx_sub_status; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_sub_status ON public.subscriptions USING btree (status);


--
-- Name: idx_sub_user; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_sub_user ON public.subscriptions USING btree (user_id);


--
-- Name: idx_topics_chapter_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_topics_chapter_id ON public.topics USING btree (chapter_id);


--
-- Name: idx_topics_chapter_published; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_topics_chapter_published ON public.topics USING btree (chapter_id, is_published);


--
-- Name: idx_topics_published_chapter; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_topics_published_chapter ON public.topics USING btree (chapter_id, "order") WHERE (is_published = true);


--
-- Name: idx_topics_title_trgm; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_topics_title_trgm ON public.topics USING gin (title public.gin_trgm_ops);


--
-- Name: idx_txn_gateway_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_txn_gateway_id ON public.payment_transactions USING btree (gateway_transaction_id);


--
-- Name: idx_txn_invoice; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_txn_invoice ON public.payment_transactions USING btree (invoice_id);


--
-- Name: idx_txn_status; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_txn_status ON public.payment_transactions USING btree (status);


--
-- Name: idx_txn_user; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_txn_user ON public.payment_transactions USING btree (user_id);


--
-- Name: idx_user_progress_user_completed; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_user_progress_user_completed ON public.user_progress USING btree (user_id, is_completed);


--
-- Name: idx_user_progress_user_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_user_progress_user_id ON public.user_progress USING btree (user_id);


--
-- Name: idx_user_progress_user_topic; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_user_progress_user_topic ON public.user_progress USING btree (user_id, topic_id);


--
-- Name: idx_user_sessions_device; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_user_sessions_device ON public.user_sessions USING btree (user_id, device_id);


--
-- Name: idx_user_sessions_user_active; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_user_sessions_user_active ON public.user_sessions USING btree (user_id, is_active);


--
-- Name: announcements announcements_created_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.announcements
    ADD CONSTRAINT announcements_created_by_fkey FOREIGN KEY (created_by) REFERENCES public.users(id);


--
-- Name: audit_logs audit_logs_admin_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.audit_logs
    ADD CONSTRAINT audit_logs_admin_user_id_fkey FOREIGN KEY (admin_user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: bookmarks bookmarks_topic_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.bookmarks
    ADD CONSTRAINT bookmarks_topic_id_fkey FOREIGN KEY (topic_id) REFERENCES public.topics(id) ON DELETE CASCADE;


--
-- Name: bookmarks bookmarks_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.bookmarks
    ADD CONSTRAINT bookmarks_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: chapters chapters_book_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.chapters
    ADD CONSTRAINT chapters_book_id_fkey FOREIGN KEY (book_id) REFERENCES public.books(id) ON DELETE CASCADE;


--
-- Name: code_redemptions code_redemptions_book_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.code_redemptions
    ADD CONSTRAINT code_redemptions_book_id_fkey FOREIGN KEY (book_id) REFERENCES public.books(id) ON DELETE SET NULL;


--
-- Name: code_redemptions code_redemptions_code_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.code_redemptions
    ADD CONSTRAINT code_redemptions_code_id_fkey FOREIGN KEY (code_id) REFERENCES public.scratch_codes(id) ON DELETE CASCADE;


--
-- Name: code_redemptions code_redemptions_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.code_redemptions
    ADD CONSTRAINT code_redemptions_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: content_blocks content_blocks_topic_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.content_blocks
    ADD CONSTRAINT content_blocks_topic_id_fkey FOREIGN KEY (topic_id) REFERENCES public.topics(id) ON DELETE CASCADE;


--
-- Name: content_reports content_reports_reviewed_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.content_reports
    ADD CONSTRAINT content_reports_reviewed_by_fkey FOREIGN KEY (reviewed_by) REFERENCES public.users(id);


--
-- Name: content_reports content_reports_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.content_reports
    ADD CONSTRAINT content_reports_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: coupon_usage coupon_usage_coupon_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.coupon_usage
    ADD CONSTRAINT coupon_usage_coupon_id_fkey FOREIGN KEY (coupon_id) REFERENCES public.coupons(id) ON DELETE CASCADE;


--
-- Name: coupon_usage coupon_usage_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.coupon_usage
    ADD CONSTRAINT coupon_usage_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: coupons coupons_referral_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.coupons
    ADD CONSTRAINT coupons_referral_user_id_fkey FOREIGN KEY (referral_user_id) REFERENCES public.users(id);


--
-- Name: invoice_line_items invoice_line_items_add_on_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.invoice_line_items
    ADD CONSTRAINT invoice_line_items_add_on_id_fkey FOREIGN KEY (add_on_id) REFERENCES public.add_ons(id);


--
-- Name: invoice_line_items invoice_line_items_invoice_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.invoice_line_items
    ADD CONSTRAINT invoice_line_items_invoice_id_fkey FOREIGN KEY (invoice_id) REFERENCES public.invoices(id) ON DELETE CASCADE;


--
-- Name: invoice_line_items invoice_line_items_package_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.invoice_line_items
    ADD CONSTRAINT invoice_line_items_package_id_fkey FOREIGN KEY (package_id) REFERENCES public.subscription_packages(id);


--
-- Name: invoices invoices_coupon_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.invoices
    ADD CONSTRAINT invoices_coupon_id_fkey FOREIGN KEY (coupon_id) REFERENCES public.coupons(id);


--
-- Name: invoices invoices_subscription_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.invoices
    ADD CONSTRAINT invoices_subscription_id_fkey FOREIGN KEY (subscription_id) REFERENCES public.subscriptions(id);


--
-- Name: invoices invoices_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.invoices
    ADD CONSTRAINT invoices_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: manual_payment_proofs manual_payment_proofs_package_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.manual_payment_proofs
    ADD CONSTRAINT manual_payment_proofs_package_id_fkey FOREIGN KEY (package_id) REFERENCES public.subscription_packages(id);


--
-- Name: manual_payment_proofs manual_payment_proofs_price_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.manual_payment_proofs
    ADD CONSTRAINT manual_payment_proofs_price_id_fkey FOREIGN KEY (price_id) REFERENCES public.package_prices(id);


--
-- Name: manual_payment_proofs manual_payment_proofs_reviewed_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.manual_payment_proofs
    ADD CONSTRAINT manual_payment_proofs_reviewed_by_fkey FOREIGN KEY (reviewed_by) REFERENCES public.users(id);


--
-- Name: manual_payment_proofs manual_payment_proofs_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.manual_payment_proofs
    ADD CONSTRAINT manual_payment_proofs_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: mcqs mcqs_topic_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.mcqs
    ADD CONSTRAINT mcqs_topic_id_fkey FOREIGN KEY (topic_id) REFERENCES public.topics(id) ON DELETE CASCADE;


--
-- Name: package_features package_features_package_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.package_features
    ADD CONSTRAINT package_features_package_id_fkey FOREIGN KEY (package_id) REFERENCES public.subscription_packages(id) ON DELETE CASCADE;


--
-- Name: package_prices package_prices_package_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.package_prices
    ADD CONSTRAINT package_prices_package_id_fkey FOREIGN KEY (package_id) REFERENCES public.subscription_packages(id) ON DELETE CASCADE;


--
-- Name: password_reset_tokens password_reset_tokens_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.password_reset_tokens
    ADD CONSTRAINT password_reset_tokens_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: payment_transactions payment_transactions_invoice_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.payment_transactions
    ADD CONSTRAINT payment_transactions_invoice_id_fkey FOREIGN KEY (invoice_id) REFERENCES public.invoices(id);


--
-- Name: payment_transactions payment_transactions_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.payment_transactions
    ADD CONSTRAINT payment_transactions_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: quiz_attempts quiz_attempts_topic_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.quiz_attempts
    ADD CONSTRAINT quiz_attempts_topic_id_fkey FOREIGN KEY (topic_id) REFERENCES public.topics(id) ON DELETE SET NULL;


--
-- Name: quiz_attempts quiz_attempts_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.quiz_attempts
    ADD CONSTRAINT quiz_attempts_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: recent_activity recent_activity_topic_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.recent_activity
    ADD CONSTRAINT recent_activity_topic_id_fkey FOREIGN KEY (topic_id) REFERENCES public.topics(id) ON DELETE CASCADE;


--
-- Name: recent_activity recent_activity_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.recent_activity
    ADD CONSTRAINT recent_activity_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: review_schedule review_schedule_mcq_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.review_schedule
    ADD CONSTRAINT review_schedule_mcq_id_fkey FOREIGN KEY (mcq_id) REFERENCES public.mcqs(id) ON DELETE CASCADE;


--
-- Name: review_schedule review_schedule_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.review_schedule
    ADD CONSTRAINT review_schedule_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: scratch_code_batches scratch_code_batches_book_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.scratch_code_batches
    ADD CONSTRAINT scratch_code_batches_book_id_fkey FOREIGN KEY (book_id) REFERENCES public.books(id) ON DELETE SET NULL;


--
-- Name: scratch_code_batches scratch_code_batches_created_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.scratch_code_batches
    ADD CONSTRAINT scratch_code_batches_created_by_fkey FOREIGN KEY (created_by) REFERENCES public.users(id);


--
-- Name: scratch_codes scratch_codes_batch_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.scratch_codes
    ADD CONSTRAINT scratch_codes_batch_id_fkey FOREIGN KEY (batch_id) REFERENCES public.scratch_code_batches(id) ON DELETE CASCADE;


--
-- Name: scratch_codes scratch_codes_redeemed_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.scratch_codes
    ADD CONSTRAINT scratch_codes_redeemed_by_fkey FOREIGN KEY (redeemed_by) REFERENCES public.users(id);


--
-- Name: subscription_add_ons subscription_add_ons_add_on_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.subscription_add_ons
    ADD CONSTRAINT subscription_add_ons_add_on_id_fkey FOREIGN KEY (add_on_id) REFERENCES public.add_ons(id);


--
-- Name: subscription_add_ons subscription_add_ons_subscription_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.subscription_add_ons
    ADD CONSTRAINT subscription_add_ons_subscription_id_fkey FOREIGN KEY (subscription_id) REFERENCES public.subscriptions(id) ON DELETE CASCADE;


--
-- Name: subscription_audit_logs subscription_audit_logs_performed_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.subscription_audit_logs
    ADD CONSTRAINT subscription_audit_logs_performed_by_fkey FOREIGN KEY (performed_by) REFERENCES public.users(id);


--
-- Name: subscription_audit_logs subscription_audit_logs_subscription_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.subscription_audit_logs
    ADD CONSTRAINT subscription_audit_logs_subscription_id_fkey FOREIGN KEY (subscription_id) REFERENCES public.subscriptions(id);


--
-- Name: subscription_audit_logs subscription_audit_logs_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.subscription_audit_logs
    ADD CONSTRAINT subscription_audit_logs_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: subscriptions subscriptions_coupon_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.subscriptions
    ADD CONSTRAINT subscriptions_coupon_id_fkey FOREIGN KEY (coupon_id) REFERENCES public.coupons(id);


--
-- Name: subscriptions subscriptions_package_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.subscriptions
    ADD CONSTRAINT subscriptions_package_id_fkey FOREIGN KEY (package_id) REFERENCES public.subscription_packages(id);


--
-- Name: subscriptions subscriptions_price_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.subscriptions
    ADD CONSTRAINT subscriptions_price_id_fkey FOREIGN KEY (price_id) REFERENCES public.package_prices(id);


--
-- Name: subscriptions subscriptions_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.subscriptions
    ADD CONSTRAINT subscriptions_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: topics topics_chapter_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.topics
    ADD CONSTRAINT topics_chapter_id_fkey FOREIGN KEY (chapter_id) REFERENCES public.chapters(id) ON DELETE CASCADE;


--
-- Name: user_progress user_progress_topic_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.user_progress
    ADD CONSTRAINT user_progress_topic_id_fkey FOREIGN KEY (topic_id) REFERENCES public.topics(id) ON DELETE CASCADE;


--
-- Name: user_progress user_progress_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.user_progress
    ADD CONSTRAINT user_progress_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: user_sessions user_sessions_revoked_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.user_sessions
    ADD CONSTRAINT user_sessions_revoked_by_fkey FOREIGN KEY (revoked_by) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: user_sessions user_sessions_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.user_sessions
    ADD CONSTRAINT user_sessions_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- PostgreSQL database dump complete
--

\unrestrict Kb05GoQ8OCCK2jKehJCzMlBidtD8grWil1QnQta3YeD0bJiJWOEwv4ujRLRUB1k

